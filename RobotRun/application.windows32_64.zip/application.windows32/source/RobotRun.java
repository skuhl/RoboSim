import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import org.apache.commons.math3.linear.*; 
import java.util.*; 
import java.nio.*; 
import java.nio.file.*; 
import java.io.*; 
import java.io.Serializable; 
import java.io.FileInputStream; 
import java.io.FileOutputStream; 
import java.io.IOException; 
import java.util.concurrent.ArrayBlockingQueue; 
import java.nio.charset.Charset; 

import org.apache.commons.math3.ml.neuralnet.*; 
import org.apache.commons.math3.ml.neuralnet.twod.*; 
import org.apache.commons.math3.ml.neuralnet.twod.util.*; 
import org.apache.commons.math3.ml.neuralnet.oned.*; 
import org.apache.commons.math3.ml.neuralnet.sofm.*; 
import org.apache.commons.math3.ml.neuralnet.sofm.util.*; 
import org.apache.commons.math3.ml.clustering.*; 
import org.apache.commons.math3.ml.clustering.evaluation.*; 
import org.apache.commons.math3.ml.distance.*; 
import org.apache.commons.math3.analysis.*; 
import org.apache.commons.math3.analysis.differentiation.*; 
import org.apache.commons.math3.analysis.integration.*; 
import org.apache.commons.math3.analysis.integration.gauss.*; 
import org.apache.commons.math3.analysis.function.*; 
import org.apache.commons.math3.analysis.polynomials.*; 
import org.apache.commons.math3.analysis.solvers.*; 
import org.apache.commons.math3.analysis.interpolation.*; 
import org.apache.commons.math3.stat.interval.*; 
import org.apache.commons.math3.stat.ranking.*; 
import org.apache.commons.math3.stat.clustering.*; 
import org.apache.commons.math3.stat.*; 
import org.apache.commons.math3.stat.inference.*; 
import org.apache.commons.math3.stat.correlation.*; 
import org.apache.commons.math3.stat.descriptive.*; 
import org.apache.commons.math3.stat.descriptive.rank.*; 
import org.apache.commons.math3.stat.descriptive.summary.*; 
import org.apache.commons.math3.stat.descriptive.moment.*; 
import org.apache.commons.math3.stat.regression.*; 
import org.apache.commons.math3.linear.*; 
import org.apache.commons.math3.*; 
import org.apache.commons.math3.distribution.*; 
import org.apache.commons.math3.distribution.fitting.*; 
import org.apache.commons.math3.complex.*; 
import org.apache.commons.math3.ode.*; 
import org.apache.commons.math3.ode.nonstiff.*; 
import org.apache.commons.math3.ode.events.*; 
import org.apache.commons.math3.ode.sampling.*; 
import org.apache.commons.math3.random.*; 
import org.apache.commons.math3.primes.*; 
import org.apache.commons.math3.optim.*; 
import org.apache.commons.math3.optim.linear.*; 
import org.apache.commons.math3.optim.nonlinear.vector.*; 
import org.apache.commons.math3.optim.nonlinear.vector.jacobian.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.gradient.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.noderiv.*; 
import org.apache.commons.math3.optim.univariate.*; 
import org.apache.commons.math3.exception.*; 
import org.apache.commons.math3.exception.util.*; 
import org.apache.commons.math3.fitting.leastsquares.*; 
import org.apache.commons.math3.fitting.*; 
import org.apache.commons.math3.dfp.*; 
import org.apache.commons.math3.fraction.*; 
import org.apache.commons.math3.special.*; 
import org.apache.commons.math3.geometry.*; 
import org.apache.commons.math3.geometry.hull.*; 
import org.apache.commons.math3.geometry.enclosing.*; 
import org.apache.commons.math3.geometry.spherical.twod.*; 
import org.apache.commons.math3.geometry.spherical.oned.*; 
import org.apache.commons.math3.geometry.euclidean.threed.*; 
import org.apache.commons.math3.geometry.euclidean.twod.*; 
import org.apache.commons.math3.geometry.euclidean.twod.hull.*; 
import org.apache.commons.math3.geometry.euclidean.oned.*; 
import org.apache.commons.math3.geometry.partitioning.*; 
import org.apache.commons.math3.geometry.partitioning.utilities.*; 
import org.apache.commons.math3.optimization.*; 
import org.apache.commons.math3.optimization.linear.*; 
import org.apache.commons.math3.optimization.direct.*; 
import org.apache.commons.math3.optimization.fitting.*; 
import org.apache.commons.math3.optimization.univariate.*; 
import org.apache.commons.math3.optimization.general.*; 
import org.apache.commons.math3.util.*; 
import org.apache.commons.math3.genetics.*; 
import org.apache.commons.math3.transform.*; 
import org.apache.commons.math3.filter.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class RobotRun extends PApplet {













final int OFF = 0, ON = 1;

ArmModel armModel;
Model eeModelSuction;
Model eeModelClaw;
Model eeModelClawPincer;

final int ENDEF_NONE = 0, ENDEF_SUCTION = 1, ENDEF_CLAW = 2;

float lastMouseX, lastMouseY;
float cameraTX = 0, cameraTY = 0, cameraTZ = 0;
float cameraRX = 0, cameraRY = 0, cameraRZ = 0;
boolean spacebarDown = false;

ControlP5 cp5;
Textarea myTextarea;
Accordion accordion;

ArrayList<Program> programs = new ArrayList<Program>();

/* global variables for toolbar */

// for pan button
int cursorMode = ARROW;
int clickPan = 0;
float panX = 1.0f; 
float panY = 1.0f;
boolean doPan = false;

// for rotate button
int clickRotate = 0;
float myRotX = 0.0f;
float myRotY = 0.0f;
boolean doRotate = false;

float myscale = 0.5f;

/*******************************/
/* other global variables      */

// for Execution
Program currentProgram;
boolean execSingleInst = false;
MotionInstruction singleInstruction = null;
int currentInstruction;
int EXEC_PROCESSING = 0, EXEC_FAILURE = 1, EXEC_SUCCESS = 2;

/*******************************/

/*******************************/
/*        Shape Stuff          */

// The Y corrdinate of the ground plane
public static final float PLANE_Z = 200.5f;
public Object[] objects;

/*******************************/

// for store or load program state
FileInputStream in = null;
FileOutputStream out = null;

public void setup(){
  
  ortho();
  
  cp5 = new ControlP5(this);
  gui();
  for (int n = 0; n < pr.length; n++) pr[n] = new Point();
  armModel = new ArmModel();
  eeModelSuction = new Model("VACUUM_2.STL", color(40));
  eeModelClaw = new Model("GRIPPER.STL", color(40));
  eeModelClawPincer = new Model("GRIPPER_2.STL", color(200,200,0));
  intermediatePositions = new ArrayList<PVector>();
  loadState();
  
  /*for (int n = 0; n < toolFrames.length; n++) {
    toolFrames[n] = new Frame();
    userFrames[n] = new Frame();
  }*/
   
  // Intialize world objects
  objects = new Object[2];
  pushMatrix();
  resetMatrix();
  translate(-100, 100, -350);
  //print( matrixToString(getTransformationMatrix()) );
  
  objects[0] = new Object(125, 60, 300, color(255, 0, 0), color(255, 0, 255));
 
 translate(-250, 0, 0);
  
  objects[1] = new Object(250, 125, 500, color(255, 0, 255), color(255, 255, 255));
  
  popMatrix();
  //createTestProgram();
}

boolean doneMoving = true;

public void draw(){
  ortho();
  
  //lights();
  directionalLight(255, 255, 255, 1, 1, 0);
  ambientLight(150, 150, 150);

  background(127);
  
  if (!doneMoving){
    doneMoving = executeProgram(currentProgram, armModel, execSingleInst);
  }
  else{
    intermediatePositions.clear();
  }
  
  pushMatrix();
  resetMatrix();
  applyModelRotation(armModel, true);
  // Keep track of the old coordinate frame of the armModel
  armModel.oldEETMatrix = getTransformationMatrix();
  popMatrix();
  
  armModel.executeLiveMotion(); // respond to manual movement from J button presses
  
  hint(ENABLE_DEPTH_TEST);
  background(255);
  noStroke();
  noFill();
  
  pushMatrix();
   
  applyCamera();

  pushMatrix(); 
  armModel.draw();
  popMatrix();
  
  if (COLLISION_DISPLAY) {
    armModel.resetBoxColors();
    armModel.checkSelfCollisions();
  }
  
  handleWorldObjects();
  
  if (COLLISION_DISPLAY) { armModel.drawBoxes(); }
  
  float[] q = eulerToQuat(armModel.getWPR());
  //println(String.format("q = %4.3f, %4.3f, %4.3f, %4.3f", q[0], q[1], q[2], q[3]));
  
  noLights();
  
  //TESTING CODE: DRAW INTERMEDIATE POINTS
  noStroke();
  pushMatrix();
  if(intermediatePositions != null){
    for(PVector v : intermediatePositions){
      pushMatrix();
      translate(v.x, v.y, v.z);
      sphere(10);
      popMatrix();
    }
  }
  popMatrix(); 
  //TESTING CODE: DRAW END EFFECTOR POSITION
  pushMatrix();
  noFill();
  stroke(0, 0, 0);
  applyModelRotation(armModel, true);
  //EE position
  sphere(5);
  translate(0, 0, -100);
  stroke(255, 0, 0);
  //EE x axis
  sphere(6);
  translate(0, 100, 100);
  stroke(0, 255, 0);
  //EE y axis
  sphere(6);
  translate(100, -100, 0);
  stroke(0, 0, 255);
  //EE z axis
  sphere(6);
  popMatrix();
  //END TESTING CODE
  // TESTING CODE: DRAW USER FRAME 0
  /*PVector ufo = convertWorldToNative(userFrames[0].getOrigin());
  
  PVector ufx = new PVector(
      ufo.x-userFrames[0].getAxis(0).x*80,
      ufo.y-userFrames[0].getAxis(0).y*80,
      ufo.z-userFrames[0].getAxis(0).z*80
    );
  PVector ufy = new PVector(
      ufo.x-userFrames[0].getAxis(2).x*80,
      ufo.y-userFrames[0].getAxis(2).y*80,
      ufo.z-userFrames[0].getAxis(2).z*80
    );
  PVector ufz = new PVector(
      ufo.x+userFrames[0].getAxis(1).x*80,
      ufo.y+userFrames[0].getAxis(1).y*80,
      ufo.z+userFrames[0].getAxis(1).z*80
    );
  noFill();
  stroke(255, 0, 0);
  pushMatrix();
  translate(ufo.x, ufo.y, ufo.z);
  sphere(15);
  popMatrix();
  stroke(0, 255, 0);
  pushMatrix();
  translate(ufx.x, ufx.y, ufx.z);
  sphere(15);
  popMatrix();
  stroke(0, 0, 255);
  pushMatrix();
  translate(ufy.x, ufy.y, ufy.z);
  sphere(15);
  popMatrix();
  stroke(255, 255, 0);
  pushMatrix();
  translate(ufz.x, ufz.y, ufz.z);
  sphere(15);
  popMatrix();*/
  // END TESTING CODE
  
  if (mode == THREE_POINT_MODE && teachPointTMatrices != null) {
    for (float[][] T : teachPointTMatrices) {
      pushMatrix();
      applyMatrix(T[0][0], T[0][1], T[0][2], T[0][3],
                  T[1][0], T[1][1], T[1][2], T[1][3],
                  T[2][0], T[2][1], T[2][2], T[2][3],
                  T[3][0], T[3][1], T[3][2], T[3][3]);
      noFill();
      stroke(255, 0, 0);
      sphere(3);
      
      popMatrix();
    }
  }
  
  drawEndEffectorGridMapping();
  
  stroke(255, 0, 0);
  // Draw x origin line
  line( -5000, PLANE_Z, 0, 5000, PLANE_Z, 0 );
  // Draw y origin line
  line( 0, PLANE_Z, 5000, 0, PLANE_Z, -5000 );
  
  // Draw grid lines every 100 units, from -5000 to 5000, in the x and y plane, on the floor plane
  stroke(25, 25, 25);
  for (int l = 1; l < 50; ++l) {
    line(100 * l, PLANE_Z, -5000, 100 * l, PLANE_Z, 5000);
    line(-5000, PLANE_Z, 100 * l, 5000, PLANE_Z, 100 * l);
    
    line(-100 * l, PLANE_Z, -5000, -100 * l, PLANE_Z, 5000);
    line(-5000, PLANE_Z, -100 * l, 5000, PLANE_Z, -100 * l);
  }
  
  popMatrix();
  
  hint(DISABLE_DEPTH_TEST);
  
  showMainDisplayText();
  //println(frameRate + " fps");
}

public void applyCamera() {
  translate(width/1.5f,height/1.5f);
  translate(panX, panY); // for pan button
  scale(myscale);
  rotateX(myRotX); // for rotate button
  rotateY(myRotY); // for rotate button /* */
}

/* Handles the drawing of world objects as well as collision detection of world objects and the
 * Robot Arm model. */
public void handleWorldObjects() {
  for (Object o : objects) {
    // reset all world the object's hit box colors
    o.hit_box.outline = color(0, 255, 0);
  }
  
  for (int idx = 0; idx < objects.length; ++idx) {
    
    /* Update the transformation matrix of an object held by the Robotic Arm */
    if (objects[idx] == armModel.held && armModel.modelInMotion()) {
      pushMatrix();
      resetMatrix();
      
      // new object transform = EE transform x (old EE transform) ^ -1 x current object transform
      
      applyModelRotation(armModel, true);
      
      float[][] invEETMatrix = invertHCMatrix(armModel.oldEETMatrix);
      applyMatrix(invEETMatrix[0][0], invEETMatrix[0][1], invEETMatrix[0][2], invEETMatrix[0][3],
                  invEETMatrix[1][0], invEETMatrix[1][1], invEETMatrix[1][2], invEETMatrix[1][3],
                  invEETMatrix[2][0], invEETMatrix[2][1], invEETMatrix[2][2], invEETMatrix[2][3],
                  invEETMatrix[3][0], invEETMatrix[3][1], invEETMatrix[3][2], invEETMatrix[3][3]);
      
      armModel.held.form.applyTransform();
       
      float[][] newObjTMatrix = getTransformationMatrix();
      armModel.held.form.setTransform(newObjTMatrix);
      armModel.held.hit_box.setTransform(newObjTMatrix);
      
      popMatrix();
    }
    
    /* Collision Detection */
    if (COLLISION_DISPLAY) {
      if ( armModel.checkObjectCollision(objects[idx]) ) {
        objects[idx].hit_box.outline = color(255, 0, 0);
      }
        
      // Detect collision with other objects
      for (int cdx = idx + 1; cdx < objects.length; ++cdx) {
        
        if (objects[idx].collision(objects[cdx])) {
          // Change hit box color to indicate Object collision
          objects[idx].hit_box.outline = color(255, 0, 0);
          objects[cdx].hit_box.outline = color(255, 0, 0);
          break;
        }
      }
      
      if ( objects[idx] != armModel.held && objects[idx].collision(armModel.getEEPos()) ) {
        // Change hit box color to indicate End Effector collision
        objects[idx].hit_box.outline = color(0, 0, 255);
      }
    }
    
    // Draw world object
    objects[idx].draw();
  }
}
ArrayList<PVector> intermediatePositions;
int motionFrameCounter = 0;
float distanceBetweenPoints = 5.0f;
int interMotionIdx = -1;

final int COORD_JOINT = 0, COORD_WORLD = 1, COORD_TOOL = 2, COORD_USER = 3;
int curCoordFrame = COORD_JOINT;
float liveSpeed = 0.1f;

int errorCounter;
String errorText;

public static final boolean PRINT_EXTRA_TEXT = true;
public static final boolean COLLISION_DISPLAY = false;

/**
 * Creates some programs for testing purposes.
 */
public void createTestProgram() {
  Program program = new Program("Test Program");
  MotionInstruction instruction =
    new MotionInstruction(MTYPE_LINEAR, 0, true, 800, 1.0f); //1.0
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_CIRCULAR, 1, true, 1600, 0.75f); //0.75
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_LINEAR, 2, true, 400, 0.5f); //0.5
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_JOINT, 3, true, 1.0f, 0);
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_JOINT, 4, true, 1.0f, 0);
  program.addInstruction(instruction);
  //for (int n = 0; n < 15; n++) program.addInstruction(
  //  new MotionInstruction(MTYPE_JOINT, 1, true, 0.5, 0));
  pr[0] = new Point(165, 116, -5, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  pr[1] = new Point(166, -355, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  pr[2] = new Point(171, -113, 445, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  pr[3] = new Point(725, 225, 50, 0, 0, 0, 5.6f, 1.12f, 5.46f, 0, 5.6f, 0);
  pr[4] = new Point(775, 300, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  pr[5] = new Point(-474, -218, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  pr[6] = new Point(-659, -412, -454, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  programs.add(program);
  //currentProgram = program;
  
  Program program2 = new Program("Test Program 2");
  MotionInstruction instruction2 =
    new MotionInstruction(MTYPE_JOINT, 3, true, 1.0f, 0);
  program2.addInstruction(instruction2);
  instruction2 = new MotionInstruction(MTYPE_JOINT, 4, true, 1.0f, 0);
  program2.addInstruction(instruction2);
  programs.add(program2);
  currentProgram = program2;
  
  Program program3 = new Program("Circular Test");
  MotionInstruction instruction3 =
    new MotionInstruction(MTYPE_LINEAR, 0, true, 1.0f, 0);
  program3.addInstruction(instruction3);
  instruction3 = new MotionInstruction(MTYPE_CIRCULAR, 1, true, 1.0f, 0);
  program3.addInstruction(instruction3);
  instruction3 = new MotionInstruction(MTYPE_LINEAR, 2, true, 1.0f, 0);
  program3.addInstruction(instruction3);
  instruction3 = new MotionInstruction(MTYPE_LINEAR, 3, true, 0.25f, 0);
  program3.addInstruction(instruction3);
  programs.add(program3);
  //currentProgram = program3;
  
  Program program4 = new Program("New Arm Test");
  MotionInstruction instruction4 =
    new MotionInstruction(MTYPE_LINEAR, 5, true, 1.0f, 0);
  program4.addInstruction(instruction4);
  instruction4 = new MotionInstruction(MTYPE_LINEAR, 6, true, 1.0f, 0);
  program4.addInstruction(instruction4);
  programs.add(program4);
  currentProgram = program4;
  
  for (int n = 0; n < 22; n++) {
     programs.add(new Program("Xtra" + Integer.toString(n)));
     
  }
  saveState();
} // end createTestProgram()


/**
 * Displays important information in the upper-right corner of the screen.
 */
public void showMainDisplayText() {
  fill(0);
  textAlign(RIGHT, TOP);
  String coordFrame = "CoordinateFrame: ";
  
  switch(curCoordFrame) {
    case COORD_JOINT:
      coordFrame += "Joint";
      break;
    case COORD_WORLD:
      coordFrame += "World";
      break;
    case COORD_TOOL:
      coordFrame += "Tool";
      break;
    case COORD_USER:
      coordFrame += "User";
  }
  
  text(coordFrame, width-20, 20);
  text("Speed: " + (Integer.toString((int)(Math.round(liveSpeed*100)))) + "%", width-20, 40);
  
  // Display the Current position and orientation of the Robot in the World Frame
  PVector ee_pos = armModel.getEEPos();
  //ee_pos = convertNativeToWorld(ee_pos);
  PVector wpr = armModel.getWPR();
  String dis_world = String.format("Coord  X: %8.4f  Y: %8.4f  Z: %8.4f  W: %8.4f  P: %8.4f  R: %8.4f", 
                     ee_pos.x, ee_pos.y, ee_pos.z, wpr.x*RAD_TO_DEG, wpr.y*RAD_TO_DEG, wpr.z*RAD_TO_DEG);
  
  // Display the Robot's joint angles
  float j[] = armModel.getJointRotations();
  String dis_joint = String.format("Joints  J1: %5.4f J2: %5.4f J3: %5.4f J4: %5.4f J5: %5.4f J6: %5.4f", 
                     j[0], j[1], j[2], j[3], j[4], j[5]);
  
  // Display the distance between the End Effector and the Based of the Robot
  float dist_base = PVector.dist(ee_pos, base_center);
  String dis_dist = String.format("Distance from EE to Robot Base: %f", dist_base);
  
  // Show the coordinates of the End Effector for the current Coordinate Frame
  if (curCoordFrame == COORD_JOINT) {          
    text(dis_joint, width - 20, 60);
    
    if (PRINT_EXTRA_TEXT) {
      text(dis_dist, width - 20, 80);
      text(dis_world, width - 20, 100);
    }
  } else {
    text(dis_world, width - 20, 60);
    
    if (PRINT_EXTRA_TEXT) {
      text(dis_dist, width - 20, 80);
      text(dis_joint, width - 20, 100);
    }
  }
  
  // Display a message while the robot is carrying an object
  if (armModel.held != null) {
    fill(200, 0, 0);
    text("Object held", width - 20, 120);
  }
  
  textAlign(LEFT);
  
  // Display message for camera pan-lock mode
  if (clickPan % 2 == 1) {
    textSize(14);
    fill(215, 0, 0);
    text("Press space on the keyboard to disable camera paning", 20, height / 2 + 30);
  }
  // Display message for camera rotation-lock mode
  if (clickRotate % 2 == 1) {
    textSize(14);
    fill(215, 0, 0);
    text("Press shift on the keyboard to disable camera rotation", 20, height / 2 + 55);
  }
  
  if (PRINT_EXTRA_TEXT) {
    textSize(12);
    fill(0, 0, 0);
    
    float[][] vectorMatrix = armModel.getRotationMatrix(armModel.currentFrame);
    String row = String.format("[  %f  %f  %f  ]", vectorMatrix[0][0], vectorMatrix[0][1], vectorMatrix[0][2]);
    text(row, 20, height / 2 + 80);
    row = String.format("[  %f  %f  %f  ]", vectorMatrix[1][0], vectorMatrix[1][1], vectorMatrix[1][2]);
    text(row, 20, height / 2 + 94);
    row = String.format("[  %f  %f  %f  ]", vectorMatrix[2][0], vectorMatrix[2][1], vectorMatrix[2][2]);
    text(row, 20, height / 2 + 108);
  }
  
  float[] q = armModel.getQuaternion();
  String quat = String.format("q: [%8.6f, %8.6f, %8.6f, %8.6f]", q[0], q[1], q[2], q[3]);
  text(quat, 20, height/2 + 148);
  
  float[] c = objects[1].form.position();
  String obj1_c = String.format("Object 1: (%f, %f Z, %f)", c[0], c[1], c[2]);
  text(obj1_c, 20, height / 2 + 168);
  
  textAlign(RIGHT);
  
  if (errorCounter > 0) {
    errorCounter--;
    fill(255, 0, 0);
    text(errorText, width-20, 100);
  }
}

/* Updates the curCoordFrame variable based on the current value of curCoordFrame, activeToolFrame,
 * activeUserFrame, and the current End Effector. If the new coordinate frame is user or tool and
 * no current tool or user frames are active, then the next coordinate frame is selected instead.
 *
 * @param model  The Robot Arm, for which to switch coordinate frames
 */
public void updateCoordinateMode(ArmModel model) {
  // Increment the current coordinate frame
  curCoordFrame = (curCoordFrame + 1) % 3;
  
  // Skip the tool frame, if there is no current active tool frame
  if (curCoordFrame == COORD_TOOL && !((activeToolFrame >= 0 && activeToolFrame < toolFrames.length)
                                       || model.activeEndEffector == ENDEF_SUCTION
                                       ||  model.activeEndEffector == ENDEF_CLAW)) {
    curCoordFrame = COORD_USER;
  }
  
  // Skip the user frame, if there is no current active user frame
  if (curCoordFrame == COORD_USER && !(activeUserFrame >= 0 && activeUserFrame < userFrames.length)) {
    curCoordFrame = COORD_JOINT;
  }
}

/**
 * Converts from RobotRun-defined world coordinates into
 * Processing's coordinate system.
 * Assumes that the robot starts out facing toward the LEFT.
 */
public PVector convertWorldToNative(PVector in) {
  pushMatrix();
  float outx = modelX(0,0,0)-in.x;
  float outy = modelY(0,0,0)-in.z;
  float outz = -(modelZ(0,0,0)-in.y);
  popMatrix();
  return new PVector(outx, outy, outz);
}

/**
 * Converts from Processing's native coordinate system to
 * RobotRun-defined world coordinates.
 */
public PVector convertNativeToWorld(PVector in) {
  pushMatrix();
  float outx = modelX(0,0,0)-in.x;
  float outy = in.z+modelZ(0,0,0);
  float outz = modelY(0,0,0)-in.y;
  popMatrix();
  return new PVector(outx, outy, outz);
}

/**
 * Takes a vector and a (probably not quite orthogonal) second vector
 * and computes a vector that's truly orthogonal to the first one and
 * pointing in the direction closest to the imperfect second vector
 * @param in First vector
 * @param second Second vector
 * @return A vector perpendicular to the first one and on the same side
 *         from first as the second one.
 */
public PVector computePerpendicular(PVector in, PVector second) {
  PVector[] plane = createPlaneFrom3Points(in, second, new PVector(in.x*2, in.y*2, in.z*2));
  PVector v1 = vectorConvertTo(in, plane[0], plane[1], plane[2]);
  PVector v2 = vectorConvertTo(second, plane[0], plane[1], plane[2]);
  PVector perp1 = new PVector(v1.y, -v1.x, v1.z);
  PVector perp2 = new PVector(-v1.y, v1.x, v1.z);
  PVector orig = new PVector(v2.x*5, v2.y*5, v2.z);
  PVector p1 = new PVector(perp1.x*5, perp1.y*5, perp1.z);
  PVector p2 = new PVector(perp2.x*5, perp2.y*5, perp2.z);
  if (dist(orig.x, orig.y, orig.z, p1.x, p1.y, p1.z) <
      dist(orig.x, orig.y, orig.z, p2.x, p2.y, p2.z))
    return vectorConvertFrom(perp1, plane[0], plane[1], plane[2]);
  else return vectorConvertFrom(perp2, plane[0], plane[1], plane[2]);
}

/* This method will draw the End Effector grid mapping based on the value of EE_MAPPING:
 *
 *  0 -> a line is drawn between the EE and the grid plane
 *  1 -> a point is drawn on the grid plane that corresponds to the EE's xz coordinates
 *  For any other value, nothing is drawn
 */
public void drawEndEffectorGridMapping() {
  
  PVector ee_pos = armModel.getEEPos();
  
  // x-axis : red
  // y-axis : green
  // z-axis : blue
  /*pushMatrix();
  resetMatrix();
  // Display EE axes at the EE position
  applyModelRotation(armModel, true);
  float[][] tMatrix = getTransformationMatrix();
  popMatrix();
  
  PVector x_vector = new PVector(5000, 0, 0);//transform(new PVector(0, 0, 5000), tMatrix);
  PVector y_vector = new PVector(0, 5000, 0);//transform(new PVector(0, -5000, 0), tMatrix);
  PVector z_vector = new PVector(0, 0, 5000);//transform(new PVector(5000, 0, 0), tMatrix);
  
  stroke(255, 0, 0);
  line(x_vector.x, x_vector.y, x_vector.z, -x_vector.x, x_vector.y, x_vector.z);
  stroke(0, 255, 0);
  line(y_vector.x, y_vector.y, y_vector.z, y_vector.x, -y_vector.y, y_vector.z);
  stroke(0, 0, 255);
  line(z_vector.x, z_vector.y, z_vector.z, z_vector.x, z_vector.y, -z_vector.z);*/
  
  // Change color of the EE mapping based on if it lies below or above the ground plane
  int c = (ee_pos.y <= PLANE_Z) ? color(255, 0, 0) : color(150, 0, 255);
  
  // Toggle EE mapping type with 'e'
  switch (EE_MAPPING) {
    case 0:
      stroke(c);
      // Draw a line, from the EE to the grid in the xy plane, parallel to the z plane
      line(ee_pos.x, ee_pos.y, ee_pos.z, ee_pos.x, PLANE_Z, ee_pos.z);
      break;
    
    case 1:
      noStroke();
      fill(c);
      // Draw a point, which maps the EE's position to the grid in the xy plane
      pushMatrix();
      rotateX(PI / 2);
      translate(0, 0, -PLANE_Z);
      ellipse(ee_pos.x, ee_pos.z, 10, 10);
      popMatrix();
      break;
      
    default:
      // No EE grid mapping
  }
}



/**
 * Performs rotations and translations to reach the end effector
 * position, similarly to calculateEndEffectorPosition(), but
 * this function doesn't return anything and also doesn't pop
 * the matrix after performing the transformations. Useful when
 * you're doing some graphical manipulation and you want to use
 * the end effector position as your start point.
 * 
 * @param model        The arm model whose transformations to apply
 * @param applyOffset  Whether to apply the Tool Frame End
 *                     Effector offset (if it exists)
 */
public void applyModelRotation(ArmModel model, boolean applyOffset){   
  translate(600, 200, 0);
  translate(-50, -166, -358); // -115, -213, -413
  rotateZ(PI);
  translate(150, 0, 150);
  rotateY(model.segments.get(0).currentRotations[1]);
  translate(-150, 0, -150);
  rotateZ(-PI);    
  translate(-115, -85, 180);
  rotateZ(PI);
  rotateY(PI/2);
  translate(0, 62, 62);
  rotateX(model.segments.get(1).currentRotations[2]);
  translate(0, -62, -62);
  rotateY(-PI/2);
  rotateZ(-PI);   
  translate(0, -500, -50);
  rotateZ(PI);
  rotateY(PI/2);
  translate(0, 75, 75);
  rotateX(model.segments.get(2).currentRotations[2]);
  translate(0, -75, -75);
  rotateY(PI/2);
  rotateZ(-PI);
  translate(745, -150, 150);
  rotateZ(PI/2);
  rotateY(PI/2);
  translate(70, 0, 70);
  rotateY(model.segments.get(3).currentRotations[0]);
  translate(-70, 0, -70);
  rotateY(-PI/2);
  rotateZ(-PI/2);    
  translate(-115, 130, -124);
  rotateZ(PI);
  rotateY(-PI/2);
  translate(0, 50, 50);
  rotateX(model.segments.get(4).currentRotations[2]);
  translate(0, -50, -50);
  rotateY(PI/2);
  rotateZ(-PI);    
  translate(150, -10, 95);
  rotateY(-PI/2);
  rotateZ(PI);
  translate(45, 45, 0);
  rotateZ(model.segments.get(5).currentRotations[0]);
  
  if (applyOffset && curCoordFrame == COORD_TOOL) { armModel.applyToolFrame(activeToolFrame); }
} // end apply model rotations

/**
 * Calculate the Jacobian matrix for the robotic arm for
 * a given set of joint rotational values using a 1 DEGREE
 * offset for each joint rotation value. Each cell of the
 * resulting matrix will describe the linear approximation
 * of the robot's motion for each joint in units per radian. 
 */
public float[][] calculateJacobian(float[] angles){
  float dAngle = DEG_TO_RAD;
  float[][] J = new float[7][6];
  //get current ee position
  PVector cPos = armModel.getEEPos(angles);
  float[] cRotQ = armModel.getQuaternion(angles);
  
  //examine each segment of the arm
  for(int i = 0; i < 6; i += 1){
    //test angular offset
    angles[i] += dAngle;
    //get updated ee position
    PVector nPos = armModel.getEEPos(angles);
    float[] nRotQ = armModel.getQuaternion(angles);

    //get translational delta
    J[0][i] = (nPos.x - cPos.x)/DEG_TO_RAD;
    J[1][i] = (nPos.y - cPos.y)/DEG_TO_RAD;
    J[2][i] = (nPos.z - cPos.z)/DEG_TO_RAD;
    //get rotational delta        
    J[3][i] = (nRotQ[0] - cRotQ[0])/DEG_TO_RAD;
    J[4][i] = (nRotQ[1] - cRotQ[1])/DEG_TO_RAD;
    J[5][i] = (nRotQ[2] - cRotQ[2])/DEG_TO_RAD;
    J[6][i] = (nRotQ[3] - cRotQ[3])/DEG_TO_RAD;
    //replace the original rotational value
    angles[i] -= dAngle;
  }
  
  return J;
}//end calculate jacobian

//attempts to calculate the joint rotation values
//required to move the end effector to the point specified
//by 'tgt' and the Euler angle orientation 'rot'
public int calculateIKJacobian(PVector tgt, float[] rot){
  final int limit = 1000;  //max number of times to loop
  float[] angles = armModel.getJointRotations();
  float[][] frame = armModel.currentFrame;
  float[][] nFrame = armModel.getRotationMatrix();
  float[][] rMatrix = quatToMatrix(rot);
  armModel.currentFrame = nFrame;
  //translate target rotation to new ref frame
  RealMatrix M = new Array2DRowRealMatrix(floatToDouble(nFrame, 3, 3));
  RealMatrix R = new Array2DRowRealMatrix(floatToDouble(rMatrix, 3, 3));
  RealMatrix MR = R.multiply(MatrixUtils.inverse(M));
  rot = matrixToQuat(doubleToFloat(MR.getData(), 3, 3));
  
  int count = 0;
  
  while(count < limit){
    PVector cPos = armModel.getEEPos(angles);
    float[] cRotQ = armModel.getQuaternion(angles);
    
    //calculate our translational offset from target
    float[] tDelta = calculateVectorDelta(tgt, cPos);
    //calculate our rotational offset from target
    float[] rDelta = calculateVectorDelta(rot, cRotQ, 4);
    float[] delta = new float[7];
    
    delta[0] = tDelta[0];
    delta[1] = tDelta[1];
    delta[2] = tDelta[2];
    delta[3] = rDelta[0];
    delta[4] = rDelta[1];
    delta[5] = rDelta[2];
    delta[6] = rDelta[3];
    
    float dist = PVector.dist(cPos, tgt);
    float rDist = sqrt(pow(rDelta[0], 2) + 
                       pow(rDelta[1], 2) + 
                       pow(rDelta[2], 2) + 
                       pow(rDelta[3], 2));
                                                  
    //check whether our current position is within tolerance
    if(dist < 0.5f && rDist < 0.0005f) break;
    //calculate jacobian, 'J', and its inverse 
    float[][] J = calculateJacobian(angles);
    RealMatrix m = new Array2DRowRealMatrix(floatToDouble(J, 7, 6));
    //RealMatrix JInverse = MatrixUtils.inverse(m);
    RealMatrix JInverse = new SingularValueDecomposition(m).getSolver().getInverse();
        
    //calculate and apply joint angular changes
    float[] dAngle = {0, 0, 0, 0, 0, 0};
    for(int i = 0; i < 6; i += 1){
      for(int j = 0; j < 7; j += 1){
        dAngle[i] += JInverse.getEntry(i, j)*delta[j];
      }
      //update joint angles
      angles[i] += dAngle[i];
      angles[i] += TWO_PI;
      angles[i] %= TWO_PI;
    }
    
    count += 1;
  }
  
  armModel.currentFrame = frame;
  //did we successfully find the desired angles?
  if(count >= limit){
    return EXEC_FAILURE;
  }
  else{
    for(int i = 0; i < 6; i += 1){
      Model s = armModel.segments.get(i);
      if(angles[i] > -0.000001f && angles[i] < 0.000001f)
        angles[i] = 0;
        
      for(int j = 0; j < 3; j += 1){
        if(s.rotations[j] && !s.anglePermitted(j, angles[i])){
          return EXEC_FAILURE;
        }
      }
    }
    
    armModel.setJointRotations(angles);
    return EXEC_SUCCESS;
  }
}

/**
 * Determine how close together intermediate points between two points
 * need to be based on current speed
 */
public void calculateDistanceBetweenPoints() {
  MotionInstruction instruction =
    (MotionInstruction)currentProgram.getInstructions().get(currentInstruction);
  if (instruction != null && instruction.getMotionType() != MTYPE_JOINT)
    distanceBetweenPoints = instruction.getSpeed() / 60.0f;
  else if (curCoordFrame != COORD_JOINT)
    distanceBetweenPoints = armModel.motorSpeed * liveSpeed / 60.0f;
  else distanceBetweenPoints = 5.0f;
}

/**
 * Calculate a "path" (series of intermediate positions) between two
 * points in a straight line.
 * @param start Start point
 * @param end Destination point
 */
public void calculateIntermediatePositions(PVector start, PVector end) {
  calculateDistanceBetweenPoints();
  intermediatePositions.clear();
  float mu = 0;
  int numberOfPoints = (int)
    (dist(start.x, start.y, start.z, end.x, end.y, end.z) / distanceBetweenPoints);
  float increment = 1.0f / (float)numberOfPoints;
  for (int n = 0; n < numberOfPoints; n++) {
    mu += increment;
    intermediatePositions.add(new PVector(
      start.x * (1 - mu) + (end.x * mu),
      start.y * (1 - mu) + (end.y * mu),
      start.z * (1 - mu) + (end.z * mu)));
  }
  interMotionIdx = 0;
} // end calculate intermediate positions

/**
 * Calculate a "path" (series of intermediate positions) between two
 * points in a a curved line. Need a third point as well, or a curved
 * line doesn't make sense.
 * Here's how this works:
 *   Assuming our current point is P1, and we're moving to P2 and then P3:
 *   1 Do linear interpolation between points P2 and P3 FIRST.
 *   2 Begin interpolation between P1 and P2.
 *   3 When you're (cont% / 1.5)% away from P2, begin interpolating not towards
 *     P2, but towards the points defined between P2 and P3 in step 1.
 *   The mu for this is from 0 to 0.5 instead of 0 to 1.0.
 *
 * @param p1 Start point
 * @param p2 Destination point
 * @param p3 Third point, needed to figure out how to curve the path
 * @param percentage Intensity of the curve
 */
public void calculateContinuousPositions(PVector p1, PVector p2, PVector p3, float percentage) {
  //percentage /= 2;
  calculateDistanceBetweenPoints();
  percentage /= 1.5f;
  percentage = 1 - percentage;
  percentage = constrain(percentage, 0, 1);
  intermediatePositions.clear();
  ArrayList<PVector> secondaryTargets = new ArrayList<PVector>();
  float mu = 0;
  int numberOfPoints = 0;
  if (dist(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z) >
      dist(p2.x, p2.y, p2.z, p3.x, p3.y, p3.z))
  {
    numberOfPoints = (int)
      (dist(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z) / distanceBetweenPoints);
  } else {
    numberOfPoints = (int)
      (dist(p2.x, p2.y, p2.z, p3.x, p3.y, p3.z) / distanceBetweenPoints);
  }
  float increment = 1.0f / (float)numberOfPoints;
  for (int n = 0; n < numberOfPoints; n++) {
    mu += increment;
    secondaryTargets.add(new PVector(
      p2.x * (1 - mu) + (p3.x * mu),
      p2.y * (1 - mu) + (p3.y * mu),
      p2.z * (1 - mu) + (p3.z * mu)));
  }
  mu = 0;
  int transitionPoint = (int)((float)numberOfPoints * percentage);
  for (int n = 0; n < transitionPoint; n++) {
    mu += increment;
    intermediatePositions.add(new PVector(
      p1.x * (1 - mu) + (p2.x * mu),
      p1.y * (1 - mu) + (p2.y * mu),
      p1.z * (1 - mu) + (p2.z * mu)));
  }
  int secondaryIdx = 0; // accessor for secondary targets
  mu = 0;
  increment /= 2.0f;
  
  PVector currentPoint;
  if(intermediatePositions.size() > 0){
    currentPoint = intermediatePositions.get(intermediatePositions.size()-1);
  }
  else{
    currentPoint = armModel.getEEPos();
  }
  
  for (int n = transitionPoint; n < numberOfPoints; n++) {
    mu += increment;
    intermediatePositions.add(new PVector(
      currentPoint.x * (1 - mu) + (secondaryTargets.get(secondaryIdx).x * mu),
      currentPoint.y * (1 - mu) + (secondaryTargets.get(secondaryIdx).y * mu),
      currentPoint.z * (1 - mu) + (secondaryTargets.get(secondaryIdx).z * mu)));
    currentPoint = intermediatePositions.get(intermediatePositions.size()-1);
    secondaryIdx++;
  }
  interMotionIdx = 0;
} // end calculate continuous positions

/**
 * Initiate a new continuous (curved) motion instruction.
 * @param model Arm model to use
 * @param start Start point
 * @param end Destination point
 * @param next Point after the destination
 * @param percentage Intensity of the curve
 */
public void beginNewContinuousMotion(PVector start, PVector end,
                              PVector next, float percentage)
{
  calculateContinuousPositions(start, end, next, percentage);
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0);
    //calculateIKJacobian(intermediatePositions.get(interMotionIdx));
}

/**
 * Initiate a new fine (linear) motion instruction.
 * @param start Start point
 * @param end Destination point
 */
public void beginNewLinearMotion(PVector start, PVector end) {
  calculateIntermediatePositions(start, end);
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0);
    //calculateIKJacobian(intermediatePositions.get(interMotionIdx));
}

/**
 * Initiate a new circular motion instruction according to FANUC methodology.
 * @param p1 Point 1
 * @param p2 Point 2
 * @param p3 Point 3
 */
public void beginNewCircularMotion(PVector p1, PVector p2, PVector p3) {
  // Generate the circle circumference,
  // then turn it into an arc from the current point to the end point
  intermediatePositions = createArc(createCircleCircumference(p1, p2, p3, 180), p1, p2, p3);
  interMotionIdx = 0;
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0);
    //calculateIKJacobian(intermediatePositions.get(interMotionIdx));
}

boolean executingInstruction = false;

/**
 * Move the arm model between two points according to its current speed.
 * @param model The arm model
 * @param speedMult Speed multiplier
 */
public boolean executeMotion(ArmModel model, float speedMult) {
  motionFrameCounter++;
  // speed is in pixels per frame, multiply that by the current speed setting
  // which is contained in the motion instruction
  float currentSpeed = model.motorSpeed * speedMult;
  if (currentSpeed * motionFrameCounter > distanceBetweenPoints) {
    interMotionIdx++;
    motionFrameCounter = 0;
    if (interMotionIdx >= intermediatePositions.size()) {
      interMotionIdx = -1;
      return true;
    }
    //calculateIKJacobian(intermediatePositions.get(interMotionIdx));
  }
  return false;
} // end execute linear motion

public MotionInstruction getActiveMotionInstruct(){
  Instruction inst = new Instruction();
  Program p = programs.get(active_program);
  
  if(p != null && p.getInstructions().size() != 0)
    inst = p.getInstructions().get(active_instruction);
  else return null;
  
  if(inst instanceof MotionInstruction)
    return (MotionInstruction)inst;
  else return null;
}

/**
 * Convert a point based on a coordinate system defined as
 * 3 orthonormal vectors.
 * @param point Point to convert
 * @param xAxis X axis of target coordinate system
 * @param yAxis Y axis of target coordinate system
 * @param zAxis Z axis of target coordinate system
 * @return Coordinates of point after conversion
 */
public PVector vectorConvertTo(PVector point, PVector xAxis,
                        PVector yAxis, PVector zAxis)
{
  PMatrix3D matrix = new PMatrix3D(xAxis.x, xAxis.y, xAxis.z, 0,
                                   yAxis.x, yAxis.y, yAxis.z, 0,
                                   zAxis.x, zAxis.y, zAxis.z, 0,
                                   0,       0,       0,       1);
  PVector result = new PVector();
  matrix.mult(point, result);
  return result;
}


/**
 * Convert a point based on a coordinate system defined as
 * 3 orthonormal vectors. Reverse operation of vectorConvertTo.
 * @param point Point to convert
 * @param xAxis X axis of target coordinate system
 * @param yAxis Y axis of target coordinate system
 * @param zAxis Z axis of target coordinate system
 * @return Coordinates of point after conversion
 */
public PVector vectorConvertFrom(PVector point, PVector xAxis,
                          PVector yAxis, PVector zAxis)
{
  PMatrix3D matrix = new PMatrix3D(xAxis.x, yAxis.x, zAxis.x, 0,
                                   xAxis.y, yAxis.y, zAxis.y, 0,
                                   xAxis.z, yAxis.z, zAxis.z, 0,
                                   0,       0,       0,       1);
  PVector result = new PVector();
  matrix.mult(point, result);
  return result;
}


/**
 * Create a plane (2D coordinate system) out of 3 input points.
 * @param a First point
 * @param b Second point
 * @param c Third point
 * @return New coordinate system defined by 3 orthonormal vectors
 */
public PVector[] createPlaneFrom3Points(PVector a, PVector b, PVector c) {  
  PVector n1 = new PVector(a.x-b.x, a.y-b.y, a.z-b.z);
  n1.normalize();
  PVector n2 = new PVector(a.x-c.x, a.y-c.y, a.z-c.z);
  n2.normalize();
  PVector x = n1.copy();
  PVector z = n1.cross(n2);
  PVector y = x.cross(z);
  y.normalize();
  z.normalize();
  PVector[] coordinateSystem = new PVector[3];
  coordinateSystem[0] = x;
  coordinateSystem[1] = y;
  coordinateSystem[2] = z;
  return coordinateSystem;
}


/**
 * Create points around the circumference of a circle calculated from
 * three input points.
 * @param a First point
 * @param b Second point
 * @param c Third point
 * @param numPoints Number of points to place on the circle circumference
 * @return List of points comprising a circle circumference that intersects
 *         the three input points.
 */
public ArrayList<PVector> createCircleCircumference(PVector a,
                                      PVector b,
                                      PVector c,
                                      int numPoints)
{  
  // First, we need to compute the value of some variables that we'll
  // use in a parametric equation to get our answer.
  // First up is computing the circle center. This is much easier to
  // do in 2D, so first we'll convert our three input points into a 2D
  // plane, compute the circle center in those coordinates, then convert
  // back to our native 3D frame.
  PVector[] plane = new PVector[3];
  plane = createPlaneFrom3Points(a, b, c);
  PVector center = circleCenter(vectorConvertTo(a, plane[0], plane[1], plane[2]),
                                vectorConvertTo(b, plane[0], plane[1], plane[2]),
                                vectorConvertTo(c, plane[0], plane[1], plane[2]));
  center = vectorConvertFrom(center, plane[0], plane[1], plane[2]);
  // Now get the radius (easy)
  float r = dist(center.x, center.y, center.z, a.x, a.y, a.z);
  // Get u (a unit vector from the center to some point on the circumference)
  PVector u = new PVector(center.x-a.x, center.y-a.y, center.z-a.z);
  u.normalize();
  // get n (a normal of the plane created by the 3 input points)
  PVector tmp1 = new PVector(a.x-b.x, a.y-b.y, a.z-b.z);
  PVector tmp2 = new PVector(a.x-c.x, a.y-c.y, a.z-c.z);
  PVector n = tmp1.cross(tmp2);
  n.normalize();
  
  // Now plug all that into the parametric equation
  //   P = r*cos(t)*u + r*sin(t)*nxu+center [x is cross product]
  // to compute our points along the circumference.
  // We actually only want to create an arc from A to C, not the full
  // circle, so detect when we're close to those points to decide
  // when to start and stop adding points.
  float angle = 0;
  float angleInc = (TWO_PI)/(float)numPoints;
  ArrayList<PVector> points = new ArrayList<PVector>();
  for (int iter = 0; iter < numPoints; iter++) {
    PVector inter1 = PVector.mult(u, r * cos(angle));
    PVector inter2 =  n.cross(u);
    inter2 = PVector.mult(inter2, r * sin(angle));
    inter1.add(inter2);
    inter1.add(center);
    points.add(inter1);
    angle += angleInc;
  }
  return points;
}


/**
 * Helper method for the createArc method
 */
public int cycleNumber(int number) {
  number++;
  if (number >= 4) number = 1;
  return number;
}


/**
 * Takes a list of points describing a circle circumference, three points
 * A, B, and C, and returns an arc built from the circumference that
 * runs from A to B to C.
 * @param points List of points describing the circle circumference.
 * @param a Point A
 * @param b Point b
 * @param c Point C
 * @return List of points describing the arc from A to B to C
 */
public ArrayList<PVector> createArc(ArrayList<PVector> points, PVector a, PVector b, PVector c) {
  float CHKDIST = 15.0f;
  while (true) {
    int seenA = 0, seenB = 0, seenC = 0, currentSee = 1;
    for (int n = 0; n < points.size(); n++) {
      PVector pt = points.get(n);
      if (dist(pt.x, pt.y, pt.z, a.x, a.y, a.z) <= CHKDIST) seenA = currentSee++;
      if (dist(pt.x, pt.y, pt.z, b.x, b.y, b.z) <= CHKDIST) seenB = currentSee++;
      if (dist(pt.x, pt.y, pt.z, c.x, c.y, c.z) <= CHKDIST) seenC = currentSee++;
    }
    while (seenA != 1) {
      seenA = cycleNumber(seenA);
      seenB = cycleNumber(seenB);
      seenC = cycleNumber(seenC);
    }
    // detect reverse case: if b > c then we're going the wrong way, so reverse
    if (seenB > seenC) {
      Collections.reverse(points);
      continue;
    }
    break;
  } // end while loop
  
  // now we're going in the right direction, so remove unnecessary points
  ArrayList<PVector> newPoints = new ArrayList<PVector>();
  boolean seenA = false, seenC = false;
  for (PVector pt : points) {
    if (seenA && !seenC) newPoints.add(pt);
    if (dist(pt.x, pt.y, pt.z, a.x, a.y, a.z) <= CHKDIST) seenA = true;
    if (seenA && dist(pt.x, pt.y, pt.z, c.x, c.y, c.z) <= CHKDIST) {
      seenC = true;
      break;
    }
  }
  // might have to go through a second time
  if (seenA && !seenC) {
    for (PVector pt : points) {
      newPoints.add(pt);
      if (dist(pt.x, pt.y, pt.z, c.x, c.y, c.z) <= CHKDIST) break;
    }
  }
  if (newPoints.size() > 0) newPoints.remove(0);
  newPoints.add(c);
  return newPoints;
} // end createArc


/**
 * Finds the circle center of 3 points. (That is, find the center of
 * a circle whose circumference intersects all 3 points.)
 * The points must all lie
 * on the same plane (all have the same Z value). Should have a check
 * for colinear case, currently doesn't.
 * @param a First point
 * @param b Second point
 * @param c Third point
 * @return Position of circle center
 */
public PVector circleCenter(PVector a, PVector b, PVector c) {
  float h = calculateH(a.x, a.y, b.x, b.y, c.x, c.y);
  float k = calculateK(a.x, a.y, b.x, b.y, c.x, c.y);
  return new PVector(h, k, a.z);
}

// TODO: Add error check for colinear case (denominator is zero)
public float calculateH(float x1, float y1, float x2, float y2, float x3, float y3) {
    float numerator = (x2*x2+y2*y2)*y3 - (x3*x3+y3*y3)*y2 - 
                      ((x1*x1+y1*y1)*y3 - (x3*x3+y3*y3)*y1) +
                      (x1*x1+y1*y1)*y2 - (x2*x2+y2*y2)*y1;
    float denominator = (x2*y3-x3*y2) -
                        (x1*y3-x3*y1) +
                        (x1*y2-x2*y1);
    denominator *= 2;
    return numerator / denominator;
}

public float calculateK(float x1, float y1, float x2, float y2, float x3, float y3) {
    float numerator = x2*(x3*x3+y3*y3) - x3*(x2*x2+y2*y2) -
                      (x1*(x3*x3+y3*y3) - x3*(x1*x1+y1*y1)) +
                      x1*(x2*x2+y2*y2) - x2*(x1*x1+y1*y1);
    float denominator = (x2*y3-x3*y2) -
                        (x1*y3-x3*y1) +
                        (x1*y2-x2*y1);
    denominator *= 2;
    return numerator / denominator;
}



/**
 * Executes a program. Returns true when done.
 * @param program Program to execute
 * @param model Arm model to use
 * @return Finished yet (false=no, true=yes)
 */
public boolean executeProgram(Program program, ArmModel model, boolean singleInst) {
  //stop executing if no valid program is selected or we reach the end of the program
  if (program == null || currentInstruction >= program.getInstructions().size()){
    return true;
  }
  
  //get the next program instruction
  Instruction ins = program.getInstructions().get(currentInstruction);
  
  //motion instructions
  if (ins instanceof MotionInstruction){
    MotionInstruction instruction = (MotionInstruction)ins;
    if (instruction.getUserFrame() != activeUserFrame){
      setError("ERROR: Instruction's user frame is different from currently active user frame.");
      return true;
    }
    //start a new instruction
    if (!executingInstruction){
      boolean setup = setUpInstruction(program, model, instruction);
      if(!setup){ return true; }
      else executingInstruction = true;
    }
    //continue current instruction
    else {
      if (instruction.getMotionType() == MTYPE_JOINT){
        executingInstruction = !(model.interpolateRotation(instruction.getSpeedForExec(model)));
      }
      else{
        executingInstruction = !(executeMotion(model, instruction.getSpeedForExec(model)));
      }
      
      //move to next instruction after current is finished
      if (!executingInstruction){
        currentInstruction++;
        if(singleInst){ return true; }
      }
    }
  }
  //tool instructions
  else if (ins instanceof ToolInstruction){
    ToolInstruction instruction = (ToolInstruction)ins;
    instruction.execute();
    currentInstruction++;
  }
  //frame instructions
  else if (ins instanceof FrameInstruction){
    FrameInstruction instruction = (FrameInstruction)ins;
    instruction.execute();
    currentInstruction++;
  }//end of instruction type check
  
  return false;
}//end executeProgram


/**
 * Executes a single instruction. Returns true when done.
 * @param ins Instruction to execute.
 * @return Finished yet (false=no, true=yes)
 */
public boolean executeSingleInstruction(Instruction ins) {
  if (ins instanceof MotionInstruction) {
    MotionInstruction instruction = (MotionInstruction)ins;
    if (instruction.getMotionType() != MTYPE_JOINT) {
      if (instruction.getUserFrame() != activeUserFrame) {
        setError("ERROR: Instruction's user frame is different from currently active user frame.");
        return true;
      }
      return executeMotion(armModel, instruction.getSpeedForExec(armModel));
    } else {
      return armModel.interpolateRotation(instruction.getSpeedForExec(armModel));
    }
  } else if (ins instanceof ToolInstruction) {
    ToolInstruction instruction = (ToolInstruction)ins;
    instruction.execute();
    return true;
  } else if (ins instanceof FrameInstruction) {
    FrameInstruction instruction = (FrameInstruction)ins;
    instruction.execute();
    return true;
  }
  return true;
}

/**
 * Sets up an instruction for execution.
 * @param program Program that the instruction belongs to
 * @param model Arm model to use
 * @param instruction The instruction to execute
 * @return Returns true on failure (invalid instruction), false on success
 */
public boolean setUpInstruction(Program program, ArmModel model, MotionInstruction instruction) {
  PVector start = armModel.getEEPos();
  
  if (instruction.getMotionType() == MTYPE_JOINT) {
    float[] j = instruction.getVector(program).j;
    
    //set target rotational value for each joint
    for (int n = 0; n < j.length; n++) {
      for (int r = 0; r < 3; r++) {
        if (model.segments.get(n).rotations[r])
          model.segments.get(n).targetRotations[r] = j[n];
          println("target rotation for joint " + n + ": " + j[n]);
      }
    }
    
    // calculate whether it's faster to turn CW or CCW
    for (Model a : model.segments) {
      for (int r = 0; r < 3; r++) {
        if (a.rotations[r]) {
         // The minimum distance between the current and target joint angles
         float dist_t = minimumDistance(a.currentRotations[r], a.targetRotations[r]);
         
         // check joint movement range
         if (a.jointRanges[r].x == 0 && a.jointRanges[r].y == TWO_PI) {
           a.rotationDirections[r] = (dist_t < 0) ? -1 : 1;
         }
         else {  
           /* Determine if at least one bound lies within the range of the shortest angle
            * between the current joint angle and the target angle. If so, then take the
            * longer angle, otherwise choose the shortest angle path. */
            
           // The minimum distance from the current joint angle to the lower bound of the joint's range
           float dist_lb = minimumDistance(a.currentRotations[r], a.jointRanges[r].x);
           
           // The minimum distance from the current joint angle to the upper bound of the joint's range
           float dist_ub = minimumDistance(a.currentRotations[r], a.jointRanges[r].y);
           
           if (dist_t < 0) {
             if ( (dist_lb < 0 && dist_lb > dist_t) || (dist_ub < 0 && dist_ub > dist_t) ) {
               // One or both bounds lie within the shortest path
               a.rotationDirections[r] = 1;
             } 
             else {
               a.rotationDirections[r] = -1;
             }
           } 
           else if (dist_t > 0){
             if ( (dist_lb > 0 && dist_lb < dist_t) || (dist_ub > 0 && dist_ub < dist_t) ) {  
               // One or both bounds lie within the shortest path
               a.rotationDirections[r] = -1;
             } 
             else {
               a.rotationDirections[r] = 1;
             }
           }
         }
        }
      }
    }
  } // end joint movement setup
  else if (instruction.getMotionType() == MTYPE_LINEAR) {
    if (instruction.getTermination() == 0) {
      beginNewLinearMotion(start, instruction.getVector(program).c);
    } 
    else {
      Point nextPoint = null;
      for (int n = currentInstruction+1; n < program.getInstructions().size(); n++) {
        Instruction nextIns = program.getInstructions().get(n);
        if (nextIns instanceof MotionInstruction) {
          MotionInstruction castIns = (MotionInstruction)nextIns;
          nextPoint = castIns.getVector(program);
          break;
        }
      }
      if (nextPoint == null) {
        beginNewLinearMotion(start, instruction.getVector(program).c);
      } 
      else{
        beginNewContinuousMotion(start, 
                                 instruction.getVector(program).c,
                                 nextPoint.c, 
                                 instruction.getTermination());
      }
    } // end if termination type is continuous
  } // end linear movement setup
  else if (instruction.getMotionType() == MTYPE_CIRCULAR) {
    // If it is a circular instruction, the current instruction holds the intermediate point.
    // There must be another instruction after this that holds the end point.
    // If this isn't the case, the instruction is invalid, so return immediately.
    Point nextPoint = null;
    if (program.getInstructions().size() >= currentInstruction + 2) {
      Instruction nextIns = program.getInstructions().get(currentInstruction+1);
      //make sure next instruction is of valid type
      if (nextIns instanceof MotionInstruction){
        MotionInstruction castIns = (MotionInstruction)nextIns;
        nextPoint = castIns.getVector(program);
      }
      else{
        return false;
      }
    } 
    // invalid instruction
    else{
      return false; 
    }
    
    beginNewCircularMotion(start, instruction.getVector(program).c, nextPoint.c);
  } // end circular movement setup
  return true;
} // end setUpInstruction

/* Returns the angle with the smallest magnitude between
 * the two given angles on the Unit Circle */
public float minimumDistance(float angle1, float angle2) {
  float dist = clampAngle(angle2) - clampAngle(angle1);
  
  if (dist > PI) {
    dist -= TWO_PI;
  } else if (dist < -PI) {
    dist += TWO_PI;
  }
  
  return dist;
}

public void setError(String text) {
  errorText = text;
  errorCounter = 600;
}

public float clampAngle(float angle) {
  while (angle > TWO_PI) angle -= (TWO_PI);
  while (angle < 0) angle += (TWO_PI);
  // angles range: [0, TWO_PI)
  if (angle == TWO_PI) angle = 0;
  return angle;
}
final int FRAME_JOINT = 0, 
          FRAME_JGFRM = 1, 
          FRAME_WORLD = 2, 
          FRAME_TOOL = 3, 
          FRAME_USER = 4;
final int SMALL_BUTTON = 20,
          LARGE_BUTTON = 35; 
final int NONE = 0, 
          PROGRAM_NAV = 1, 
          INSTRUCTION_NAV = 2,
          INSTRUCTION_EDIT = 3,
          SET_INSTRUCTION_SPEED = 4,
          SET_INSTRUCTION_REGISTER = 5,
          SET_INSTRUCTION_TERMINATION = 6,
          JUMP_TO_LINE = 7,
          VIEW_REGISTER = 8,
          ENTER_TEXT = 9,
          PICK_LETTER = 10,
          MENU_NAV = 11,
          SETUP_NAV = 12,
          NAV_TOOL_FRAMES = 13,
          NAV_USER_FRAMES = 14,
          PICK_FRAME_MODE = 15,
          FRAME_DETAIL = 16,
          PICK_FRAME_METHOD = 17,
          THREE_POINT_MODE = 18,
          DIRECT_ENTRY_MODE = 19,
          ACTIVE_FRAMES = 20,
          PICK_INSTRUCTION = 21,
          IO_SUBMENU = 22,
          SET_DO_BRACKET = 23,
          SET_DO_STATUS = 24,
          SET_RO_BRACKET = 25,
          SET_RO_STATUS = 26,
          SET_FRAME_INSTRUCTION = 27,
          EDIT_MENU = 28,
          CONFIRM_DELETE = 29;
final int COLOR_DEFAULT = -8421377,
          COLOR_ACTIVE = -65536;
static int     EE_MAPPING = 2;

int frame = FRAME_JOINT; // current frame
//String displayFrame = "JOINT";
int active_program = -1; // the currently selected program
int active_instruction = -1; // the currently selected instruction
int mode = NONE;
// Used by some modes to refer to a previous mode
int super_mode = NONE;
int NUM_MODE; // When NUM_MODE is ON, allows for entering numbers
int shift = OFF; // Is shift button pressed or not?
int step = OFF; // Is step button pressed or not?
int record = OFF;
 
int g1_px, g1_py; // the left-top corner of group1
int g1_width, g1_height; // group 1's width and height
int display_px, display_py; // the left-top corner of display screen
int display_width = 340, display_height = 270; // height and width of display screen

Group g1;
Button bt_show, bt_hide, 
       bt_zoomin_shrink, bt_zoomin_normal,
       bt_zoomout_shrink, bt_zoomout_normal,
       bt_pan_shrink, bt_pan_normal,
       bt_rotate_shrink, bt_rotate_normal,
       bt_record_shrink, bt_record_normal, 
       bt_ee_normal
       ;
Textlabel fn_info, num_info;

String workingText; // when entering text or a number
String workingTextSuffix;
boolean speedInPercentage;
final int ITEMS_TO_SHOW = 16; // how many programs/ instructions to display on screen
int letterSet; // which letter group to enter
Frame currentFrame;
/*int teachingWhichPoint = 0;
PVector[] tempPoints = new PVector[3];
PVector[] tempVectors = new PVector[3];*/
ArrayList<float[][]> teachPointTMatrices = null;
int activeUserFrame = -1;
int activeJogFrame = -1;
int activeToolFrame = -1;
PVector[] teachingPts = new PVector[3];

// display list of programs or motion instructions
ArrayList<ArrayList<String>> contents = new ArrayList<ArrayList<String>>();
// display options for an element in a motion instruction
ArrayList<String> options = new ArrayList<String>();
// store numbers pressed by the user
ArrayList<Integer> nums = new ArrayList<Integer>(); 
// which element is on focus now?
int active_row = 0, active_col = 0; 
int text_render_start = 0;
// which option is on focus now?
int which_option = -1; 
// how many textlabels have been created for display
int index_contents = 0, index_options = 100, index_nums = 1000; 
int mouseDown = 0;

private static final boolean DISPLAY_TEST_OUTPUT = false;

public void gui(){
   g1_px = 0;
   g1_py = 0;
   g1_width = 100;
   g1_height = 100;
   display_px = g1_width / 2;
   display_py = SMALL_BUTTON + 1;
   /*
   PFont pfont = createFont("ArialNarrow",9,true); // new font
   ControlFont font = new ControlFont(pfont, 9);
   cp5.setFont(font);
   */
   
   // group 1: display and function buttons
   g1 = cp5.addGroup("DISPLAY")
      .setPosition(g1_px, g1_py)
      .setBackgroundColor(color(127,127,127,50));
   
   myTextarea = cp5.addTextarea("txt")
      .setPosition(display_px,display_py)
      .setSize(display_width, display_height)
      .setLineHeight(14)
      .setColor(color(128))
      .setColorBackground(color(200,255,255))
      .setColorForeground(color(0,0,0))
      .moveTo(g1);
   
   // expand group 1's width and height
   g1_width += 340;
   g1_height += 270;
   
   // text label to show how to use F1 - F5 keys
   fn_info = cp5.addTextlabel("fn_info")
       .hide();
       
   num_info = cp5.addTextlabel("num_info")
       .hide();   
   // button to show g1
   int bt_show_px = 1;
   int bt_show_py = 1;
   bt_show = cp5.addButton("show")
       .setPosition(bt_show_px, bt_show_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setCaptionLabel("SHOW")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .hide()
       ;
       
    int zoomin_shrink_px =  bt_show_px + LARGE_BUTTON;
    int zoomin_shrink_py = bt_show_py;
    PImage[] zoomin_shrink = {loadImage("images/zoomin_35x20.png"), 
                              loadImage("images/zoomin_over.png"), 
                              loadImage("images/zoomin_down.png")};   
    bt_zoomin_shrink = cp5.addButton("zoomin_shrink")
       .setPosition(zoomin_shrink_px, zoomin_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomin_shrink)
       .updateSize()
       .hide()
       ;   
       
    int zoomout_shrink_px = zoomin_shrink_px + LARGE_BUTTON ;
    int zoomout_shrink_py = zoomin_shrink_py;   
    PImage[] zoomout_shrink = {loadImage("images/zoomout_35x20.png"), 
                               loadImage("images/zoomout_over.png"), 
                               loadImage("images/zoomout_down.png")};   
    bt_zoomout_shrink = cp5.addButton("zoomout_shrink")
       .setPosition(zoomout_shrink_px, zoomout_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomout_shrink)
       .updateSize()
       .hide()
       ;    
   
    int pan_shrink_px = zoomout_shrink_px + LARGE_BUTTON;
    int pan_shrink_py = zoomout_shrink_py ;
    PImage[] pan_shrink = {loadImage("images/pan_35x20.png"), 
                           loadImage("images/pan_over.png"), 
                           loadImage("images/pan_down.png")};   
    bt_pan_shrink = cp5.addButton("pan_shrink")
       .setPosition(pan_shrink_px, pan_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(pan_shrink)
       .updateSize()
       .hide()
       ;    
       
    int rotate_shrink_px = pan_shrink_px + LARGE_BUTTON;
    int rotate_shrink_py = pan_shrink_py;   
    PImage[] rotate_shrink = {loadImage("images/rotate_35x20.png"), 
                              loadImage("images/rotate_over.png"), 
                              loadImage("images/rotate_down.png")};   
    bt_rotate_shrink = cp5.addButton("rotate_shrink")
       .setPosition(rotate_shrink_px, rotate_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(rotate_shrink)
       .updateSize()
       .hide()
       ;     
      
   // button to hide g1
   int hide_px = display_px;
   int hide_py = display_py - SMALL_BUTTON - 1;
   bt_hide = cp5.addButton("hide")
       .setPosition(hide_px, hide_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setCaptionLabel("HIDE")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);
     
    int zoomin_normal_px =  hide_px + LARGE_BUTTON + 1;
    int zoomin_normal_py = hide_py;
    PImage[] zoomin_normal = {loadImage("images/zoomin_35x20.png"), 
                              loadImage("images/zoomin_over.png"), 
                              loadImage("images/zoomin_down.png")};   
    bt_zoomin_normal = cp5.addButton("zoomin_normal")
       .setPosition(zoomin_normal_px, zoomin_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomin_normal)
       .updateSize()
       .moveTo(g1) ;   
       
    int zoomout_normal_px = zoomin_normal_px + LARGE_BUTTON + 1;
    int zoomout_normal_py = zoomin_normal_py;   
    PImage[] zoomout_normal = {loadImage("images/zoomout_35x20.png"), 
                               loadImage("images/zoomout_over.png"), 
                               loadImage("images/zoomout_down.png")};   
    bt_zoomout_normal = cp5.addButton("zoomout_normal")
       .setPosition(zoomout_normal_px, zoomout_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomout_normal)
       .updateSize()
       .moveTo(g1) ;    
   
    int pan_normal_px = zoomout_normal_px + LARGE_BUTTON + 1;
    int pan_normal_py = zoomout_normal_py ;
    PImage[] pan = {loadImage("images/pan_35x20.png"), 
                    loadImage("images/pan_over.png"), 
                    loadImage("images/pan_down.png")};   
    bt_pan_normal = cp5.addButton("pan_normal")
       .setPosition(pan_normal_px, pan_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(pan)
       .updateSize()
       .moveTo(g1) ;    
       
    int rotate_normal_px = pan_normal_px + LARGE_BUTTON + 1;
    int rotate_normal_py = pan_normal_py;   
    PImage[] rotate = {loadImage("images/rotate_35x20.png"), 
                       loadImage("images/rotate_over.png"), 
                       loadImage("images/rotate_down.png")};   
    bt_rotate_normal = cp5.addButton("rotate_normal")
       .setPosition(rotate_normal_px, rotate_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(rotate)
       .updateSize()
       .moveTo(g1) ;     
       
    int record_normal_px = rotate_normal_px + LARGE_BUTTON + 1;
    int record_normal_py = rotate_normal_py;   
    PImage[] record = {loadImage("images/record-35x20.png"), 
                       loadImage("images/record-over.png"), 
                       loadImage("images/record-on.png")};   
    bt_record_normal = cp5.addButton("record_normal")
       .setPosition(record_normal_px, record_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(record)
       .updateSize()
       .moveTo(g1) ;     
      
    int EE_normal_px = record_normal_px + LARGE_BUTTON + 1;
    int EE_normal_py = record_normal_py;   
    PImage[] EE = {loadImage("images/EE_35x20.png"), 
                   loadImage("images/EE_over.png"), 
                   loadImage("images/EE_down.png")};   
    bt_ee_normal = cp5.addButton("EE")
       .setPosition(EE_normal_px, EE_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(EE)
       .updateSize()
       .moveTo(g1) ;    
       
   PImage[] imgs_arrow_up = {loadImage("images/arrow-up.png"), 
                             loadImage("images/arrow-up_over.png"), 
                             loadImage("images/arrow-up_down.png")};   
   int up_px = display_px+display_width + 2;
   int up_py = display_py;
   cp5.addButton("up")
       .setPosition(up_px, up_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_up)
       .updateSize()
       .moveTo(g1) ;     
   
    PImage[] imgs_arrow_down = {loadImage("images/arrow-down.png"), 
                                loadImage("images/arrow-down_over.png"), 
                                loadImage("images/arrow-down_down.png")};   
    int dn_px = up_px;
    int dn_py = up_py + LARGE_BUTTON + 2;
    cp5.addButton("dn")
       .setPosition(dn_px, dn_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_down)
       .updateSize()
       .moveTo(g1) ;    
   
    PImage[] imgs_arrow_l = {loadImage("images/arrow-l.png"), 
                             loadImage("images/arrow-l_over.png"), 
                             loadImage("images/arrow-l_down.png")};
    int lt_px = dn_px;
    int lt_py = dn_py + LARGE_BUTTON + 2;
    cp5.addButton("lt")
       .setPosition(lt_px, lt_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_l)
       .updateSize()
       .moveTo(g1) ;  
    
    PImage[] imgs_arrow_r = {loadImage("images/arrow-r.png"), 
                             loadImage("images/arrow-r_over.png"), 
                             loadImage("images/arrow-r_down.png")};
    int rt_px = lt_px;
    int rt_py = lt_py + LARGE_BUTTON + 2;;
    cp5.addButton("rt")
       .setPosition(rt_px, rt_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_r)
       .updateSize()
       .moveTo(g1) ; 
    
    int fn_px = rt_px;
    int fn_py = rt_py + LARGE_BUTTON + 2;   
    cp5.addButton("Fn")
       .setPosition(fn_px, fn_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("FCTN")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int sf_px = fn_px;
    int sf_py = fn_py + LARGE_BUTTON + 2;   
    cp5.addButton("sf")
       .setPosition(sf_px, sf_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("SHIFT")
       .setColorBackground(color(127,127,255))
       .setColorActive(color(0))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);
       
    int ne_px = sf_px ;
    int ne_py = sf_py + LARGE_BUTTON + 2;   
    cp5.addButton("ne")
       .setPosition(ne_px, ne_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("NEXT")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int se_px = display_px - 2 - LARGE_BUTTON;
    int se_py = display_py;   
    cp5.addButton("se")
       .setPosition(se_px, se_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("SELECT")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);           
    
    int mu_px = se_px ;
    int mu_py = se_py + LARGE_BUTTON + 2;   
    cp5.addButton("mu")
       .setPosition(mu_px, mu_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("MENU")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);      
    
    int ed_px = mu_px ;
    int ed_py = mu_py + LARGE_BUTTON + 2;   
    cp5.addButton("ed")
       .setPosition(ed_px, ed_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("EDIT")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);      
     
    int da_px = ed_px ;
    int da_py = ed_py + LARGE_BUTTON + 2;   
    cp5.addButton("da")
       .setPosition(da_px, da_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("DATA")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);  
    
    int sw_px = da_px ;
    int sw_py = da_py + LARGE_BUTTON + 2;   
    cp5.addButton("sw")
       .setPosition(sw_px, sw_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("SWITH")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);     
    
    int st_px = sw_px ;
    int st_py = sw_py + LARGE_BUTTON + 2;   
    cp5.addButton("st")
       .setPosition(st_px, st_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("STEP")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);        
    
    int pr_px = st_px ;
    int pr_py = st_py + LARGE_BUTTON + 2;   
    cp5.addButton("pr")
       .setPosition(pr_px, pr_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("PREV")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);     
      
    int f1_px = display_px ;
    int f1_py = display_py + display_height + 2;   
    cp5.addButton("f1")
       .setPosition(f1_px, f1_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F1")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);     
         
    int f2_px = f1_px + 41 ;
    int f2_py = f1_py;   
    cp5.addButton("f2")
       .setPosition(f2_px, f2_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F2")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);  
       
    int f3_px = f2_px + 41 ;
    int f3_py = f2_py;   
    cp5.addButton("f3")
       .setPosition(f3_px, f3_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F3")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int f4_px = f3_px + 41 ;
    int f4_py = f3_py;   
    cp5.addButton("f4")
       .setPosition(f4_px, f4_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F4")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);   
      
    int f5_px = f4_px + 41;
    int f5_py = f4_py;   
    cp5.addButton("f5")
       .setPosition(f5_px, f5_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F5")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);   
    
    int hd_px = f5_px + 41;
    int hd_py = f5_py;   
    cp5.addButton("hd")
       .setPosition(hd_px, hd_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("HOLD")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int fd_px = hd_px + 41;
    int fd_py = hd_py;   
    cp5.addButton("fd")
       .setPosition(fd_px, fd_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("FWD")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);   
      
    int bd_px = fd_px + 41;
    int bd_py = fd_py;   
    cp5.addButton("bd")
       .setPosition(bd_px, bd_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("BWD")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
   // adjust group 1's width to include all controllers  
   g1.setWidth(g1_width)
     .setBackgroundHeight(g1_height); 
  
    
   // group 2: tool bar
   Group g2 = cp5.addGroup("TOOLBAR")
                 .setPosition(0,display_py + display_height + LARGE_BUTTON + 15)
                 .setBackgroundColor(color(127,127,127, 50))
                 //.setWidth(g1_width)
                 //.setBackgroundHeight(740)
                 .moveTo(g1)   
                 ;
   g2.setOpen(true);              
   
   int RESET_px = 0;
   int RESET_py = 0;
   cp5.addButton("RESET")
      .setPosition(RESET_px, RESET_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("RESET")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
 
   int LEFT_px = RESET_px + LARGE_BUTTON + 1;
   int LEFT_py = RESET_py;
   PImage[] imgs_LEFT = {loadImage("images/LEFT.png"), 
                         loadImage("images/LEFT.png"), 
                         loadImage("images/LEFT.png")};  
   cp5.addButton("LEFT")
      .setPosition(LEFT_px, LEFT_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setImages(imgs_LEFT)
      .setColorBackground(color(127,127,255)) 
      .moveTo(g2);   
      
   int ITEM_px = LEFT_px + LARGE_BUTTON + 1 ;
   int ITEM_py = LEFT_py;
   cp5.addButton("ITEM")
      .setPosition(ITEM_px, ITEM_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("ITEM")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
    
   int ENTER_px = ITEM_px + LARGE_BUTTON + 1 ;
   int ENTER_py = ITEM_py;
   cp5.addButton("ENTER")
      .setPosition(ENTER_px, ENTER_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("ENTER")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int TOOL1_px = ENTER_px + LARGE_BUTTON + 1 ;
   int TOOL1_py = ENTER_py;
   cp5.addButton("TOOL1")
      .setPosition(TOOL1_px, TOOL1_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("TOOL1")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
      
   int TOOL2_px = TOOL1_px + LARGE_BUTTON + 1 ;
   int TOOL2_py = TOOL1_py;
   cp5.addButton("TOOL2")
      .setPosition(TOOL2_px, TOOL2_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("TOOL2")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);
 
   int MOVEMENU_px = TOOL2_px + LARGE_BUTTON + 1 ;
   int MOVEMENU_py = TOOL2_py;
   cp5.addButton("MOVEMENU")
      .setPosition(MOVEMENU_px, MOVEMENU_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("MVMU")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 
      
   int SETUP_px = MOVEMENU_px + LARGE_BUTTON + 1 ;
   int SETUP_py = MOVEMENU_py;
   cp5.addButton("SETUP")
      .setPosition(SETUP_px, SETUP_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("SETUP")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int STATUS_px = SETUP_px + LARGE_BUTTON + 1 ;
   int STATUS_py = SETUP_py;
   cp5.addButton("STATUS")
      .setPosition(STATUS_px, STATUS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("STATUS")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int NO_px = STATUS_px + LARGE_BUTTON + 1 ;
   int NO_py = STATUS_py;
   cp5.addButton("NO")
      .setPosition(NO_px, NO_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("NO.")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
     
   int POSN_px = NO_px + LARGE_BUTTON + 1 ;
   int POSN_py = NO_py;
   cp5.addButton("POSN")
      .setPosition(POSN_px, POSN_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("POSN")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
    
   int SPEEDUP_px = POSN_px + LARGE_BUTTON + 1 ;
   int SPEEDUP_py = POSN_py;
   cp5.addButton("SPEEDUP")
      .setPosition(SPEEDUP_px, SPEEDUP_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+%")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
    
   int SLOWDOWN_px = SPEEDUP_px + LARGE_BUTTON + 1 ;
   int SLOWDOWN_py = SPEEDUP_py;
   cp5.addButton("SLOWDOWN")
      .setPosition(SLOWDOWN_px, SLOWDOWN_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-%")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
   
   int NUM1_px = RESET_px ;
   int NUM1_py = RESET_py + SMALL_BUTTON + 1;
   cp5.addButton("NUM1")
      .setPosition(NUM1_px, NUM1_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("1")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
      
   int NUM2_px = NUM1_px + LARGE_BUTTON + 1;
   int NUM2_py = NUM1_py;
   cp5.addButton("NUM2")
      .setPosition(NUM2_px, NUM2_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("2")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
  
   int NUM3_px = NUM2_px + LARGE_BUTTON + 1;
   int NUM3_py = NUM2_py;
   cp5.addButton("NUM3")
      .setPosition(NUM3_px, NUM3_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("3")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 
 
   int NUM4_px = NUM3_px + LARGE_BUTTON + 1;
   int NUM4_py = NUM3_py;
   cp5.addButton("NUM4")
      .setPosition(NUM4_px, NUM4_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("4")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 

   int NUM5_px = NUM4_px + LARGE_BUTTON + 1;
   int NUM5_py = NUM4_py;
   cp5.addButton("NUM5")
      .setPosition(NUM5_px, NUM5_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("5")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
 
   int NUM6_px = NUM5_px + LARGE_BUTTON + 1;
   int NUM6_py = NUM5_py;
   cp5.addButton("NUM6")
      .setPosition(NUM6_px, NUM6_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("6")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
    
   int NUM7_px = NUM6_px + LARGE_BUTTON + 1;
   int NUM7_py = NUM6_py;
   cp5.addButton("NUM7")
      .setPosition(NUM7_px, NUM7_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("7")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
      
   int NUM8_px = NUM7_px + LARGE_BUTTON + 1;
   int NUM8_py = NUM7_py;
   cp5.addButton("NUM8")
      .setPosition(NUM8_px, NUM8_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("8")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int NUM9_px = NUM8_px + LARGE_BUTTON + 1;
   int NUM9_py = NUM8_py;
   cp5.addButton("NUM9")
      .setPosition(NUM9_px, NUM9_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("9")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
  
   int NUM0_px = NUM9_px + LARGE_BUTTON + 1;
   int NUM0_py = NUM9_py;
   cp5.addButton("NUM0")
      .setPosition(NUM0_px, NUM0_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("0")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
  
   int LINE_px = NUM0_px + LARGE_BUTTON + 1;
   int LINE_py = NUM0_py;
   cp5.addButton("LINE")
      .setPosition(LINE_px, LINE_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
   
   int PERIOD_px = LINE_px + LARGE_BUTTON + 1;
   int PERIOD_py = LINE_py;
   cp5.addButton("PERIOD")
      .setPosition(PERIOD_px, PERIOD_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel(".")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
   
   int COMMA_px = PERIOD_px + LARGE_BUTTON + 1;
   int COMMA_py = PERIOD_py;
   cp5.addButton("COMMA")
      .setPosition(COMMA_px, COMMA_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel(",")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
   
   int JOINT1_NEG_px = NUM1_px;
   int JOINT1_NEG_py = NUM1_py + SMALL_BUTTON + 1;
   cp5.addButton("JOINT1_NEG")
      .setPosition(JOINT1_NEG_px, JOINT1_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-X (J1)")
      .setColorBackground(color(127, 127, 255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);
   
   int JOINT1_POS_px = JOINT1_NEG_px + LARGE_BUTTON + 1;
   int JOINT1_POS_py = JOINT1_NEG_py;
   cp5.addButton("JOINT1_POS")
      .setPosition(JOINT1_POS_px, JOINT1_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+X (J1)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
      
   int JOINT2_NEG_px = JOINT1_POS_px + LARGE_BUTTON + 1;
   int JOINT2_NEG_py = JOINT1_POS_py;
   cp5.addButton("JOINT2_NEG")
      .setPosition(JOINT2_NEG_px, JOINT2_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Y (J2)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
     
   int JOINT2_POS_px = JOINT2_NEG_px + LARGE_BUTTON + 1;
   int JOINT2_POS_py = JOINT2_NEG_py;
   cp5.addButton("JOINT2_POS")
      .setPosition(JOINT2_POS_px, JOINT2_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Y (J2)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
    
   int JOINT3_NEG_px = JOINT2_POS_px + LARGE_BUTTON + 1;
   int JOINT3_NEG_py = JOINT2_POS_py;
   cp5.addButton("JOINT3_NEG")
      .setPosition(JOINT3_NEG_px, JOINT3_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Z (J3)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
   
   int JOINT3_POS_px = JOINT3_NEG_px + LARGE_BUTTON + 1;
   int JOINT3_POS_py = JOINT3_NEG_py;
   cp5.addButton("JOINT3_POS")
      .setPosition(JOINT3_POS_px, JOINT3_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Z (J3)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int JOINT4_NEG_px = JOINT3_POS_px + LARGE_BUTTON + 1;
   int JOINT4_NEG_py = JOINT3_POS_py;
   cp5.addButton("JOINT4_NEG")
      .setPosition(JOINT4_NEG_px, JOINT4_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-X (J4)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
     
   int JOINT4_POS_px = JOINT4_NEG_px + LARGE_BUTTON + 1;
   int JOINT4_POS_py = JOINT4_NEG_py;
   cp5.addButton("JOINT4_POS")
      .setPosition(JOINT4_POS_px, JOINT4_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+X (J4)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
      
   int JOINT5_NEG_px = JOINT4_POS_px + LARGE_BUTTON + 1;
   int JOINT5_NEG_py = JOINT4_POS_py;
   cp5.addButton("JOINT5_NEG")
      .setPosition(JOINT5_NEG_px, JOINT5_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Y (J5)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
     
   int JOINT5_POS_px = JOINT5_NEG_px + LARGE_BUTTON + 1;
   int JOINT5_POS_py = JOINT5_NEG_py;
   cp5.addButton("JOINT5_POS")
      .setPosition(JOINT5_POS_px, JOINT5_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Y (J5)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
    
   int JOINT6_NEG_px = JOINT5_POS_px + LARGE_BUTTON + 1;
   int JOINT6_NEG_py = JOINT5_POS_py;
   cp5.addButton("JOINT6_NEG")
      .setPosition(JOINT6_NEG_px, JOINT6_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Z (J6)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
   
   int JOINT6_POS_px = JOINT6_NEG_px + LARGE_BUTTON + 1;
   int JOINT6_POS_py = JOINT6_NEG_py;
   cp5.addButton("JOINT6_POS")
      .setPosition(JOINT6_POS_px, JOINT6_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Z (J6)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
   
   int COORD_px = JOINT6_POS_px + LARGE_BUTTON + 1;
   int COORD_py = JOINT6_POS_py;
   cp5.addButton("COORD")
      .setPosition(COORD_px, COORD_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("COORD")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 
}

/* mouse events */
public void mousePressed(){
  mouseDown += 1;
  if(mouseButton == LEFT){
    if(clickRotate%2 == 1){
      doRotate = !doRotate;
    }
    else if(clickPan%2 == 1){
      doPan = !doPan;
    }
  }
}

public void mouseDragged(MouseEvent e) {
   if (mouseDown == 2){
      panX += mouseX - pmouseX;
      panY += mouseY - pmouseY;
   }
   if (mouseDown == 1 && mouseButton == RIGHT){
      myRotX += (mouseY - pmouseY) * 0.01f;
      myRotY += (mouseX - pmouseX) * 0.01f;
   }
}

public void mouseMoved(){
   if (doPan){
      panX += mouseX - pmouseX;
      panY += mouseY - pmouseY;
   }
   if (doRotate){
      myRotX += (mouseY - pmouseY) * 0.01f;
      myRotY += (mouseX - pmouseX) * 0.01f;
   }
}



public void mouseWheel(MouseEvent event){
  // TODO add textarea check for scrolling
  //if (sb != null && sb.focus) {
  //  sb.increment_slider(event.getCount() / 2f);
  //} else {
    // scroll mouse to zoom in / out
    float e = event.getCount();
    if (e > 0 ) {
       myscale *= 1.1f;
       if(myscale > 2){
         myscale = 2;
       }
    }
    if (e < 0){
       myscale *= 0.9f;
       if(myscale < 0.25f){
         myscale = 0.25f;
       }
    }
  //}
}

public void mouseReleased() {
  mouseDown -= 1;
}

public void keyPressed(){
  if (mode == ENTER_TEXT) {
    
    if (workingText.length() < 10 && ( (key >= 'A' && key <= 'Z') || (key >= 'a' && key <= 'z') )) {
      workingText += key;
    } else if (keyCode == BACKSPACE && workingText.length() > 0) {
      workingText = workingText.substring(0, workingText.length() - 1);
    }
    
    options = new ArrayList<String>();
    options.add("");
    options.add("(ENTER: confirm name)");
    options.add("");
    options.add("");
    options.add("Program Name:   " + workingText);
    which_option = 0;
    updateScreen(color(0), color(0));
    
    return;
  } else if (key == 'e') {
    EE_MAPPING = (EE_MAPPING + 1) % 3;
  } else if(key == 'f'){
    armModel.currentFrame = armModel.getRotationMatrix();
  } else if(key == 'g'){
    armModel.resetFrame();
  } else if (key == 'q') {
    armModel.getQuaternion();
  } else if(key == 'r'){
    panX = 0;
    panY = 0;
    myscale = 0.5f;
    myRotX = 0;
    myRotY = 0;
  } else if(key == 't'){
    // Release an object if it is currently being held
    if (armModel.held != null) {
      armModel.releaseHeldObject();
      armModel.endEffectorStatus = OFF;
    }
    
    float[] rot = {0, 0, 0, 0, 0, 0};
    armModel.setJointRotations(rot);
    intermediatePositions.clear();
  } else if(key == 'w'){
    /*------------Test Quaternion Rotation-------------------*/
    //armModel.currentFrame = armModel.getRotationMatrix();
    //float[] q = rotateQuat(armModel.getQuaternion(), 0, new PVector(1, 1, 1));
    //println("q = " + q[0] + ", " + q[1] + ", " + q[2] + ", " + q[3]);
    //PVector wpr = quatToEuler(q).mult(RAD_TO_DEG);
    //println("ee = " + wpr);
    //println();
    //armModel.resetFrame(); 
    /*------------Test Conversion Functions------------------*/
    //float[] q = armModel.getQuaternion();
    //PVector wpr = armModel.getWPR();
    //float[] qP = eulerToQuat(wpr);
    //PVector wprP = quatToEuler(q);
    //println("converted values:");
    //println(qP);
    //println(wprP.mult(RAD_TO_DEG));
    //println();
  } else if(key == 'y'){
    float[] rot = {PI, 0, 0, 0, 0, PI};
    armModel.setJointRotations(rot);
    intermediatePositions.clear();
  } else if (key == ENTER && (armModel.activeEndEffector == ENDEF_CLAW || 
                              armModel.activeEndEffector == ENDEF_SUCTION)) { 
    // Pick up an object within reach of the EE when the 'ENTER' button is pressed for either
    // the suction or claw EE
    ToolInstruction pickup;
    
    if (armModel.endEffectorStatus == ON) {
      pickup = (armModel.activeEndEffector == ENDEF_CLAW) ? 
                new ToolInstruction("RO", 4, OFF) : 
                new ToolInstruction("DO", 101, OFF);
    } else {
      pickup = (armModel.activeEndEffector == ENDEF_CLAW) ? 
                new ToolInstruction("RO", 4, ON) : 
                new ToolInstruction("DO", 101, ON);
    }
    
    pickup.execute();
  }
  
  if(keyCode == UP){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[0] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(keyCode == DOWN){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[1] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(keyCode == LEFT){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[2] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(keyCode == RIGHT){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[3] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(key == 'z'){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[4] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(key == 'x'){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[5] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  }
  
  
  if (key == ' '){ 
    pan_normal();
  }
   
  if (keyCode == SHIFT){ 
    rotate_normal();
  }
}

public void hide(){
   g1.hide();
   bt_show.show();
   bt_zoomin_shrink.show();
   bt_zoomout_shrink.show();
   bt_pan_shrink.show();
   bt_rotate_shrink.show(); 
   
   // release buttons of pan and rotate
   clickPan = 0;
   clickRotate = 0;
   cursorMode = ARROW;
   PImage[] pan_released = {loadImage("images/pan_35x20.png"), 
                            loadImage("images/pan_over.png"), 
                            loadImage("images/pan_down.png")};
                            
   cp5.getController("pan_normal")
      .setImages(pan_released);
   cp5.getController("pan_shrink")
      .setImages(pan_released);   
   doPan = false;    

   PImage[] rotate_released = {loadImage("images/rotate_35x20.png"), 
                               loadImage("images/rotate_over.png"), 
                               loadImage("images/rotate_down.png")};
                               
   cp5.getController("rotate_normal")
      .setImages(rotate_released);
   cp5.getController("rotate_shrink")
      .setImages(rotate_released);   
   doRotate = false;   
   
   cursor(cursorMode);
}

public void show(){
   g1.show();
   bt_show.hide();
   bt_zoomin_shrink.hide();
   bt_zoomout_shrink.hide();
   bt_pan_shrink.hide();
   bt_rotate_shrink.hide();
   
   // release buttons of pan and rotate
   clickPan = 0;
   clickRotate = 0;
   cursorMode = ARROW;
   PImage[] pan_released = {loadImage("images/pan_35x20.png"), 
                            loadImage("images/pan_over.png"), 
                            loadImage("images/pan_down.png")}; 
                            
   cp5.getController("pan_normal")
      .setImages(pan_released);
   doPan = false;    

   PImage[] rotate_released = {loadImage("images/rotate_35x20.png"), 
                               loadImage("images/rotate_over.png"),
                               loadImage("images/rotate_down.png")}; 
                               
   cp5.getController("rotate_normal")
      .setImages(rotate_released);
   doRotate = false;
   
   cursor(cursorMode);
}


public void mu() {
  contents = new ArrayList<ArrayList<String>>();
  ArrayList<String> line = new ArrayList<String>();
  line.add("1 UTILITIES (NA)");
  contents.add(line);
  line = new ArrayList<String>(); line.add("2 TEST CYCLE (NA)");
  contents.add(line);
  line = new ArrayList<String>(); line.add("3 MANUAL FCTNS (NA)");
  contents.add(line);
  line = new ArrayList<String>(); line.add("4 ALARM (NA)");
  contents.add(line);
  line = new ArrayList<String>(); line.add("5 I/O (NA)");
  contents.add(line);
  line = new ArrayList<String>(); line.add("6 SETUP");
  contents.add(line);
  line = new ArrayList<String>(); line.add("7 FILE (NA)");
  contents.add(line);
  line = new ArrayList<String>(); line.add("8");
  contents.add(line);
  line = new ArrayList<String>(); line.add("9 USER (NA)");
  contents.add(line);
  line = new ArrayList<String>(); line.add("0 --NEXT--");
  contents.add(line);
  active_col = active_row = 0;
  mode = MENU_NAV;
  updateScreen(color(255,0,0), color(0));
  
  if (mode == INSTRUCTION_NAV) { saveState(); }
}


public void NUM0(){
   addNumber("0");
}

public void NUM1(){
   addNumber("1");
}

public void NUM2(){
   addNumber("2");
}

public void NUM3(){
   addNumber("3");
}

public void NUM4(){
   addNumber("4");
}

public void NUM5(){
   addNumber("5");
}

public void NUM6(){
   addNumber("6");
}

public void NUM7(){
   addNumber("7");
}

public void NUM8(){
   addNumber("8");
}

public void NUM9(){
   addNumber("9");
}

public void addNumber(String number) {
  if (mode == SET_INSTRUCTION_REGISTER || mode == SET_INSTRUCTION_TERMINATION ||
      mode == JUMP_TO_LINE || mode == SET_DO_BRACKET || mode == SET_RO_BRACKET)
  {
    workingText += number;
    options.set(1, workingText);
    updateScreen(color(255,0,0), color(0,0,0));
  } else if (mode == SET_INSTRUCTION_SPEED) {
    workingText += number;
    options.set(1, workingText + workingTextSuffix);
    updateScreen(color(255,0,0), color(0,0,0));
  } else if (mode == SET_FRAME_INSTRUCTION) {
    workingText += number;
  } else if (mode == DIRECT_ENTRY_MODE) {
    // TODO add 
  }
}

public void PERIOD() {
   if (NUM_MODE == ON){
      nums.add(-1);
   } else {
     workingText += ".";
   }
   
   updateScreen(color(255,0,0), color(0,0,0));
}

public void LINE() {
  if (workingText != null && workingText.length() > 0) {
    // Mutliply current number by -1
    if (workingText.charAt(0) == '-') {
      workingText = workingText.substring(1);
    } else {
      workingText = "-" + workingText;
    }
    
    updateScreen(color(255,0,0), color(0,0,0));
  }
}

public void se(){
   active_program = 0;
   active_instruction = 0;
   active_row = 0;
   text_render_start = 0;
   mode = PROGRAM_NAV;
   clearScreen();
   loadPrograms();
   updateScreen(color(255,0,0), color(0,0,0));
   // Save when exiting a program
   if (mode == INSTRUCTION_NAV) { saveState(); }
}

public void up(){
   switch (mode){
      case PROGRAM_NAV:
         options = new ArrayList<String>();
         clearOptions();
         if (active_program > 0) {
           if(active_program == text_render_start)
             text_render_start--;
           else
             active_row--;
           active_program--;
           active_col = 0;
         }
         loadPrograms();
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
                             active_row, active_col, active_program, text_render_start);
         }
         
         break;
      case INSTRUCTION_NAV:
         options = new ArrayList<String>();
         clearOptions();
         if (active_instruction > 0) {
           if(active_instruction == text_render_start)
             text_render_start--; 
           else
             active_row--;
           active_instruction--;
           active_col = 0;
         }
         loadInstructions(active_program);
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
                             active_row, active_col, active_instruction, text_render_start);
         }
         
         break;
      case INSTRUCTION_EDIT:
      case PICK_FRAME_MODE:
      case PICK_FRAME_METHOD:
      case SET_DO_STATUS:
      case SET_RO_STATUS:
         which_option = max(0, which_option - 1);
         break;
      case MENU_NAV:
      case SETUP_NAV:
      case NAV_TOOL_FRAMES:
      case NAV_USER_FRAMES:
      case PICK_INSTRUCTION:
      case IO_SUBMENU:
      case SET_FRAME_INSTRUCTION:
      case EDIT_MENU:
         active_row = max(0, active_row - 1);
         break;
      case ACTIVE_FRAMES:
         active_row = max(1, active_row - 1);
         break;
   }
   
   updateScreen(color(255,0,0), color(0,0,0));
}

public void dn(){
   switch (mode){
      case PROGRAM_NAV:
         options = new ArrayList<String>();
         clearOptions();
         if (active_program < programs.size()-1) {
           if(active_program - text_render_start == ITEMS_TO_SHOW - 1)
             text_render_start++;
           else
             active_row++;
           
           active_program++;
           active_col = 0;
         }
         loadPrograms();
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
                             active_row, active_col, active_program, text_render_start);
         }
         
         break;
      case INSTRUCTION_NAV:
         options = new ArrayList<String>();
         clearOptions();
         int size = programs.get(active_program).getInstructions().size();
         if (active_instruction < size-1) {
           if(active_instruction - text_render_start == ITEMS_TO_SHOW - 4)
             text_render_start++;
           else
             active_row++;
           active_instruction++;
           active_col = 0;
         }
         loadInstructions(active_program);
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
                             active_row, active_col, active_instruction, text_render_start);
         }
         
         break;
      case INSTRUCTION_EDIT:
      case PICK_FRAME_MODE:
      case PICK_FRAME_METHOD:
      case SET_DO_STATUS:
      case SET_RO_STATUS:
         which_option = min(which_option + 1, options.size() - 1);
         break;
      case MENU_NAV:
      case SETUP_NAV:
      case NAV_TOOL_FRAMES:
      case NAV_USER_FRAMES:
      case ACTIVE_FRAMES:
      case PICK_INSTRUCTION:
      case IO_SUBMENU:
      case SET_FRAME_INSTRUCTION:
      case EDIT_MENU:
         active_row = min(active_row  + 1, contents.size() - 1);
         break;
   }  
   updateScreen(color(255,0,0), color(0,0,0));
}

public void lt(){
   switch (mode){
      case PROGRAM_NAV:
          break;
      case INSTRUCTION_NAV:
          options = new ArrayList<String>();
          clearOptions();
          
          active_col = max(0, active_col - 1);
          
          updateScreen(color(255,0,0), color(0,0,0));
          break;
      case INSTRUCTION_EDIT:
          mode = INSTRUCTION_NAV;
          lt();
          break;
   }
   
}


public void rt(){
  switch (mode){
      case PROGRAM_NAV:
          break;
      case INSTRUCTION_NAV:
          options = new ArrayList<String>();
          clearOptions();
          
          active_col = min(active_col + 1, contents.get(active_row).size() - 1);
          
          updateScreen(color(255,0,0), color(0,0,0));
          break;
      case INSTRUCTION_EDIT:
          mode = INSTRUCTION_NAV;
          rt();
          break;
      case MENU_NAV:
          if (active_row == 5) { // SETUP
            contents = new ArrayList<ArrayList<String>>();
            ArrayList<String> line = new ArrayList<String>();
            line.add("1 Prog Select (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("2 General (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("3 Call Guard (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("4 Frames");
            contents.add(line);
            line = new ArrayList<String>(); line.add("5 Macro (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("6 Ref Position (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("7 Port Init (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("8 Ovrd Select (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("9 User Alarm (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("0 --NEXT--");
            contents.add(line);
            active_col = active_row = 0;
            mode = SETUP_NAV;
            updateScreen(color(255,0,0), color(0));
          }
          break;
       case PICK_INSTRUCTION:
          if (active_row == 0) { // I/O
            contents = new ArrayList<ArrayList<String>>();
            ArrayList<String> line = new ArrayList<String>();
            line.add("1 Cell Intface (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("2 Custom (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("3 Digital");
            contents.add(line);
            line = new ArrayList<String>(); line.add("4 Analog (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("5 Group (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("6 Robot");
            contents.add(line);
            line = new ArrayList<String>(); line.add("7 UOP (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("8 SOP (NA)");
            contents.add(line);
            line = new ArrayList<String>(); line.add("9 Interconnect (NA)");
            contents.add(line);
            active_col = active_row = 0;
            mode = IO_SUBMENU;
            updateScreen(color(255,0,0), color(0));
          } else if (active_row == 1) { // Offset/Frames
            contents = new ArrayList<ArrayList<String>>();
            ArrayList<String> line = new ArrayList<String>();
            line.add("1 UTOOL_NUM=()");
            contents.add(line);
            line = new ArrayList<String>(); line.add("2 UFRAME_NUM=()");
            contents.add(line);
            active_col = active_row = 0;
            mode = SET_FRAME_INSTRUCTION;
            workingText="0";
            updateScreen(color(255,0,0), color(0));
          }
          break;
   }
}

//toggle shift state and button highlight
public void sf(){
   if (shift == OFF){ 
	 shift = ON;
     ((Button)cp5.get("sf")).setColorBackground(color(255, 0, 0));
   }
   else{
     shift = OFF;
     ((Button)cp5.get("sf")).setColorBackground(color(127, 127, 255));
   }
}

public void st() {
   if (step == OFF){ 
     step = ON;
     ((Button)cp5.get("st")).setColorBackground(color(255, 0, 0));
   }
   else{
     step = OFF;
     ((Button)cp5.get("st")).setColorBackground(color(127, 127, 255));
   }
}

public void pr(){
   se();
}


public void goToEnterTextMode() {
    clearScreen();
    options = new ArrayList<String>();
    options.add("");
    options.add("(ENTER: confirm name)");
    options.add("");
    options.add("");
    options.add("Program Name:   " + workingText);
    super_mode = mode;
    mode = ENTER_TEXT;
    which_option = 0;
    updateScreen(color(0), color(0));
}


public void f1(){
   if (shift == ON) {
     
     if (mode == NAV_TOOL_FRAMES || mode == NAV_USER_FRAMES) {
        
       super_mode = mode;
        if (super_mode == NAV_TOOL_FRAMES) {
          currentFrame = toolFrames[active_row];
        } else if (super_mode == NAV_USER_FRAMES) {
          currentFrame = userFrames[active_row];
        }
        
        loadFrameDetails();
      } else if ( mode == ACTIVE_FRAMES) {
        
       if (active_row == 1) {
         loadFrames(COORD_TOOL);
       } else if (active_row == 2) {
         loadFrames(COORD_USER);
       }
       
       updateScreen(color(255,0,0), color(0));
     }
     
     return;
   }
   
   switch (mode) {
      case PROGRAM_NAV:
         //shift = OFF;
         break;
      case INSTRUCTION_NAV:
         if (shift == OFF) {
           contents = new ArrayList<ArrayList<String>>();
           ArrayList<String> line = new ArrayList<String>();
           line.add("1 I/O");
           contents.add(line);
           line = new ArrayList<String>(); line.add("2 Offset/Frames");
           contents.add(line);
           line = new ArrayList<String>(); line.add("(Others not yet implemented)");
           contents.add(line);
           active_col = active_row = 0;
           mode = PICK_INSTRUCTION;
           updateScreen(color(255,0,0), color(0));
         } else { // shift+f1 = add new motion instruction
           PVector eep = armModel.getEEPos();
           eep = convertNativeToWorld(eep);
           Program prog = programs.get(active_program);
           int reg = prog.nextRegister();
           PVector r = armModel.getWPR();
           float[] j = armModel.getJointRotations();
           prog.addRegister(new Point(eep.x, eep.y, eep.z, r.x, r.y, r.z,
                                      j[0], j[1], j[2], j[3], j[4], j[5]), reg);
           MotionInstruction insert = new MotionInstruction(
             (curCoordFrame == COORD_JOINT ? MTYPE_JOINT : MTYPE_LINEAR),
             reg,
             false,
             (curCoordFrame == COORD_JOINT ? liveSpeed : liveSpeed*armModel.motorSpeed),
             0,
             activeUserFrame,
             activeToolFrame);
           prog.addInstruction(insert);
           
           active_instruction = prog.getInstructions().size() - 1;
           active_col = 0;
           /* 13 is the maximum number of instructions that can be displayed at one point in time */
           active_row = min(active_instruction, ITEMS_TO_SHOW - 4);
           text_render_start = active_instruction - active_row;
           
           loadInstructions(active_program);
           updateScreen(color(255,0,0), color(0,0,0));
         }
         //shift = OFF;
         break;
      case NAV_TOOL_FRAMES:
        // Set the current tool frame
        if (active_row >= 0) {
          activeToolFrame = active_row;
        }
        break;
      case NAV_USER_FRAMES:
        // Set the current user frame
        if (active_row >= 0) {
          activeUserFrame = active_row;
        }
        break;
      case INSTRUCTION_EDIT:
         //shift = OFF;
         break;
   }
}


public void f2() {
  if (shift == ON) {
    
    if (mode == ACTIVE_FRAMES) {
      // Reset the active frames for the User or Tool Coordinate Frames
      if (active_row == 1) {
        activeToolFrame = -1;
      } else if (active_row == 2) {
        activeUserFrame = -1;
      }
      
      loadActiveFrames();
      updateScreen(color(255,0,0), color(0));
    }
  } else {
    
    if (mode == PROGRAM_NAV) {
      workingText = "";
      active_program = -1;
      goToEnterTextMode();
    } else if (mode == FRAME_DETAIL) {
      options = new ArrayList<String>();
      
      if (super_mode == NAV_USER_FRAMES) {
        options.add("1.Three Point");
        options.add("2.Four Point");
        options.add("3.Direct Entry");
      } else if (super_mode == NAV_TOOL_FRAMES) {
        options.add("1.Three Point");
        options.add("2.Six Point");
        options.add("3.Direct Entry");
      }
      mode = PICK_FRAME_METHOD;
      which_option = 0;
      updateScreen(color(255,0,0), color(0));
    } if (mode == NAV_TOOL_FRAMES) {
       
       // Reset the highlighted frame in the tool frame list
       if (active_row >= 0) {
          toolFrames[active_row] = new Frame();
          saveState();
        }
     } else if (mode == NAV_USER_FRAMES) {
       
       // Reset the highlighted frame in the user frames list
       if (active_row >= 0) {
         userFrames[active_row] = new Frame();
         saveState();
       }
     } 
  }
}


public void f3() {
  if (mode == PROGRAM_NAV) {
    int progIdx = active_program;
    if (progIdx >= 0 && progIdx < programs.size()) {
      programs.remove(progIdx);
      
      if (active_program >= programs.size()) {
        active_program = programs.size() - 1;
        /* 13 is the maximum number of instructions that can be displayed at one point in time */
        active_row = min(active_program, ITEMS_TO_SHOW - 4);
        text_render_start = active_program - active_row;
      }
      
      loadPrograms();
      updateScreen(color(255,0,0), color(0));
      saveState();
    }
  }
}


public void f4() {
   switch (mode){
      case INSTRUCTION_NAV:
         Instruction ins = programs.get(active_program).getInstructions().get(active_instruction);
         if (ins instanceof MotionInstruction) {
           switch (active_col){
             case 1: // motion type
                options = new ArrayList<String>();
                options.add("1.JOINT");
                options.add("2.LINEAR");
                options.add("3.CIRCULAR");
                //NUM_MODE = ON;
                mode = INSTRUCTION_EDIT;
                which_option = 0;
                break;
             case 2: // register type
                options = new ArrayList<String>();
                options.add("1.LOCAL(P)");
                options.add("2.GLOBAL(PR)");
                //NUM_MODE = ON;
                mode = INSTRUCTION_EDIT;
                which_option = 0;
                break;
             case 3: // register
                options = new ArrayList<String>();
                options.add("Use number keys to enter a register number (0-999)");
                workingText = "";
                options.add(workingText);
                mode = SET_INSTRUCTION_REGISTER;
                which_option = 0;
                break;
             case 4: // speed
                options = new ArrayList<String>();
                options.add("Use number keys to enter a new speed");
                MotionInstruction castIns = getActiveMotionInstruct();
                if (castIns.getMotionType() == MTYPE_JOINT) {
                  speedInPercentage = true;
                  workingTextSuffix = "%";
                } else {
                  workingTextSuffix = "mm/s";
                  speedInPercentage = false;
                }
                workingText = "";
                options.add(workingText + workingTextSuffix);
                mode = SET_INSTRUCTION_SPEED;
                which_option = 0;
                break;
             case 5: // termination type
                options = new ArrayList<String>();
                options.add("Use number keys to enter termination percentage (0-100; 0=FINE)");
                workingText = "";
                options.add(workingText);
                mode = SET_INSTRUCTION_TERMINATION;
                which_option = 0;
                break;
           }
         } 
         break;
     case CONFIRM_DELETE:
         Program prog = programs.get(active_program);
         prog.getInstructions().remove(active_instruction);
         deleteInstEpilogue();
         break;
   }
   //println("mode="+mode+" active_col"+active_col);
   updateScreen(color(255,0,0), color(0,0,0));
}

public void f5() {
  if (mode == INSTRUCTION_NAV) {
    if (shift == OFF) {
      if (active_col == 0) {
        // if you're on the line number, bring up a list of instruction editing options
        contents = new ArrayList<ArrayList<String>>();
        ArrayList<String> line = new ArrayList<String>();
        line.add("1 Insert (NA)");
        contents.add(line);
        line = new ArrayList<String>(); line.add("2 Delete");
        contents.add(line);
        line = new ArrayList<String>(); line.add("3 Copy (NA)");
        contents.add(line);
        line = new ArrayList<String>(); line.add("4 Find (NA)");
        contents.add(line);
        line = new ArrayList<String>(); line.add("5 Replace (NA)");
        contents.add(line);
        line = new ArrayList<String>(); line.add("6 Renumber (NA)");
        contents.add(line);
        line = new ArrayList<String>(); line.add("7 Comment (NA)");
        contents.add(line);
        line = new ArrayList<String>(); line.add("8 Undo (NA)");
        contents.add(line);
        active_col = active_row = 0;
        mode = EDIT_MENU;
        updateScreen(color(255,0,0), color(0));
      } else if (active_col == 2 || active_col == 3) { 
        // show register contents if you're highlighting a register
        Instruction ins = programs.get(active_program).getInstructions().get(active_instruction);
         if (ins instanceof MotionInstruction) {
         MotionInstruction castIns = (MotionInstruction)ins;
          Point p = castIns.getVector(programs.get(active_program));
          options = new ArrayList<String>();
          options.add("Data of the point in this register (press ENTER to exit):");
          if (castIns.getMotionType() != MTYPE_JOINT) {
            options.add("x: " + p.c.x + "  y: " + p.c.y + "  z: " + p.c.z);
            options.add("w: " + p.a.x + "  p: " + p.a.y + "  r: " + p.a.z);
          } else {
            options.add("j1: " + p.j[0] + "  j2: " + p.j[1] + "  j3: " + p.j[2]);
            options.add("j4: " + p.j[3] + "  j5: " + p.j[4] + "  j6: " + p.j[5]);
          }
          mode = VIEW_REGISTER;
          which_option = 0;
          loadInstructions(active_program);
          updateScreen(color(255,0,0), color(0,0,0));
        }
      }
    } else {
      // overwrite current instruction
      PVector eep = armModel.getEEPos();
      eep = convertNativeToWorld(eep);
      Program prog = programs.get(active_program);
      int reg = prog.nextRegister();
      PVector r = armModel.getWPR();
      float[] j = armModel.getJointRotations();
      prog.addRegister(new Point(eep.x, eep.y, eep.z, r.x, r.y, r.z,
                                 j[0], j[1], j[2], j[3], j[4], j[5]), reg);
      MotionInstruction insert = new MotionInstruction(
        (curCoordFrame == COORD_JOINT ? MTYPE_JOINT : MTYPE_LINEAR),
        reg,
        false,
        (curCoordFrame == COORD_JOINT ? liveSpeed : liveSpeed*armModel.motorSpeed),
        0,
        activeUserFrame,
        activeToolFrame);
      prog.overwriteInstruction(active_instruction, insert);
      active_col = 0;
      loadInstructions(active_program);
      updateScreen(color(255,0,0), color(0,0,0));
      saveState();
    }
  } else if (mode == THREE_POINT_MODE) {
    
    if (teachPointTMatrices != null) {
      
      pushMatrix();
      resetMatrix();
      applyModelRotation(armModel, false);
      // Save current position of the EE
      float[][] tMatrix = getTransformationMatrix();
      teachPointTMatrices.add(tMatrix);
      
      popMatrix();
      
      /* Calculate the New Tool Frame after the third point has been recorded */
      if (teachPointTMatrices.size() == 3) {
          /****************************************************************
             Three Point Method Calculation
             
             ------------------------------------------------------------
             A, B, C      transformation matrices
             Ar, Br, Cr   rotational portions of A, B, C respectively
             At, Bt, Ct   translational portions of A, B, C repectively
             x            TCP point with respect to the EE
             ------------------------------------------------------------
             
             Ax = Bx = Cx
             Ax = (Ar)x + At
             
             (A - B)x = 0
             (Ar - Br)x + At - Bt = 0
             
             Ax + Bx - 2Cx = 0
             (Ar + Br - 2Cr)x + At + Bt - 2Ct = 0
             (Ar + Br - 2Cr)x = 2Ct - At - Bt
             x = (Ar + Br - 2Cr) ^ -1 * (2Ct - At - Bt)
             
           ****************************************************************/
          RealVector avg_TCP = new ArrayRealVector(new double[] {0.0f, 0.0f, 0.0f} , false);
          
          for (int idxC = 0; idxC < teachPointTMatrices.size(); ++idxC) {
            
            int idxA = (idxC + 1) % teachPointTMatrices.size(),
                idxB = (idxA + 1) % teachPointTMatrices.size();
            System.out.printf("\nA = %d\nB = %d\nC = %d\n\n", idxA, idxB, idxC);
            
            RealMatrix Ar = new Array2DRowRealMatrix(floatToDouble(teachPointTMatrices.get(idxA), 3, 3));
            RealMatrix Br = new Array2DRowRealMatrix(floatToDouble(teachPointTMatrices.get(idxB), 3, 3));
            RealMatrix Cr = new Array2DRowRealMatrix(floatToDouble(teachPointTMatrices.get(idxC), 3, 3));
            
            double [] t = new double[3];
            for (int idx = 0; idx < 3; ++idx) {
              // Build a double from the result of the translation portions of the transformation matrices
              t[idx] = 2 * teachPointTMatrices.get(idxC)[idx][3] - ( teachPointTMatrices.get(idxA)[idx][3] + teachPointTMatrices.get(idxB)[idx][3] );
            }
            
            /* 2Ct - At - Bt */
            RealVector b = new ArrayRealVector(t, false);
            /* Ar + Br - 2Cr */
            RealMatrix R = ( Ar.add(Br) ).subtract( Cr.scalarMultiply(2) );
            
            /*System.out.printf("R:\n%s\n", matrixToString( doubleToFloat(R.getData(), 3, 3) ));
            System.out.printf("t:\n\n[%5.4f]\n[%5.4f]\n[%5.4f]\n\n", b.getEntry(0), b.getEntry(1), b.getEntry(2));*/
            
            /* (R ^ -1) * b */
            avg_TCP = avg_TCP.add( (new SingularValueDecomposition(R)).getSolver().getInverse().operate(b) );
          }
          
           /* Take the average of the three cases: where C = the first point, the second point, and the third point */
          avg_TCP = avg_TCP.mapMultiply( 1.0f / 3.0f );
          
          for (int pt = 0; pt < teachPointTMatrices.size(); ++pt) {
            // Print out each matrix
            System.out.printf("Point %d:\n", pt);
            println( matrixToString(teachPointTMatrices.get(pt)) );
          }
          
          System.out.printf("(Ar + Br - 2Cr) ^ -1 * (2Ct - At - Bt):\n\n[%5.4f]\n[%5.4f]\n[%5.4f]\n\n", avg_TCP.getEntry(0), avg_TCP.getEntry(1), avg_TCP.getEntry(2));
          
          PVector origin = new PVector((float)avg_TCP.getEntry(0), (float)avg_TCP.getEntry(1), (float)avg_TCP.getEntry(2)),
                  wpr = new PVector(0.0f, 0.0f, 0.0f);
          
          if (active_row >= 0 && active_row < toolFrames.length) {
            println("Frame set");
            toolFrames[active_row] = new Frame();
            toolFrames[active_row].setOrigin(origin);
            toolFrames[active_row].setWpr(wpr);
          }
          
          // Leave Three Point Method menu
          if (super_mode == NAV_TOOL_FRAMES) {
            loadFrames(COORD_TOOL);
          } else if (super_mode == NAV_USER_FRAMES) {
            loadFrames(COORD_USER);
          } else {
            mode = MENU_NAV;
            mu();
          }
          
          saveState();
          return;
      }
      
      loadThreePointMethod();
    }
  } else if (mode == CONFIRM_DELETE) {
     deleteInstEpilogue();
  }
}

/* Stops all of the Robot's movement */
public void hd() {
  
  for (Model model : armModel.segments) {
    model.jointsMoving[0] = 0;
    model.jointsMoving[1] = 0;
    model.jointsMoving[2] = 0;
  }
  
  for (int idx = 0; idx < armModel.mvLinear.length; ++idx) {
    armModel.mvLinear[idx] = 0;
  }
  
  for (int idx = 0; idx < armModel.mvRot.length; ++idx) {
    armModel.mvRot[idx] = 0;
  }
}

public void fd() {
  if (shift == ON) {
    currentProgram = programs.get(active_program);
    if (step == OFF){
      currentInstruction = 0;
      executingInstruction = false;
      execSingleInst = false;
      doneMoving = false;
    }
    else {
      currentInstruction = active_instruction;
      executingInstruction = false;
      execSingleInst = true;
      doneMoving = false;
      //Instruction ins = programs.get(active_program).getInstructions().get(active_instruction);
      //if (ins instanceof MotionInstruction) {
      //  singleInstruction = (MotionInstruction)ins;
      //  setUpInstruction(programs.get(active_program), armModel, singleInstruction);
        
      //  if (active_instruction < programs.get(active_program).getInstructions().size()-1){
      //    active_instruction = (active_instruction+1);
      //  }
        
      //  loadInstructions(active_program);
      //  updateScreen(color(255,0,0), color(0));
      //}
    }
  }
  //shift = OFF;
}

public void bd(){
  
  if (shift == ON && step == ON && active_instruction > 0) {
    
    currentProgram = programs.get(active_program);
    Instruction ins = programs.get(active_program).getInstructions().get(active_instruction - 1);
    
    if (ins instanceof MotionInstruction) {
      
      singleInstruction = (MotionInstruction)ins;
      setUpInstruction(programs.get(active_program), armModel, singleInstruction);
      
      if (active_instruction > 0)
        active_instruction = (active_instruction-1);
      
      loadInstructions(active_program);
      updateScreen(color(255,0,0), color(0));
    }
  }
}

public void ENTER(){
   switch (mode){
      case NONE:
         break;
      case PROGRAM_NAV:
         active_instruction = 0;
         text_render_start = 0;
         mode = INSTRUCTION_NAV;
         clearScreen();
         loadInstructions(active_program);
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case INSTRUCTION_NAV:
         if (active_col == 2 || active_col == 3){
            mode = INSTRUCTION_EDIT;
            NUM_MODE = ON;
            num_info.setText(" ");
         }
         break;
      case INSTRUCTION_EDIT:
         MotionInstruction m = getActiveMotionInstruct();
         switch (active_col){
            case 1: // motion type
               if (which_option == 0){
                  if (m.getMotionType() != MTYPE_JOINT) m.setSpeed(m.getSpeed()/armModel.motorSpeed);
                  m.setMotionType(MTYPE_JOINT);
               }else if (which_option == 1){
                 if (m.getMotionType() == MTYPE_JOINT) m.setSpeed(armModel.motorSpeed*m.getSpeed());
                  m.setMotionType(MTYPE_LINEAR);
               }else if(which_option == 2){
                 if (m.getMotionType() == MTYPE_JOINT) m.setSpeed(armModel.motorSpeed*m.getSpeed());
                  m.setMotionType(MTYPE_CIRCULAR);
               }
               break;
            case 2: // register type
               if (which_option == 0) m.setGlobal(false);
               else m.setGlobal(true);
               break;
            case 3: // register
               break;
            case 4: // speed
               break;
            case 5: // termination type
               break;   
         }
         loadInstructions(active_program);
         mode = INSTRUCTION_NAV;
         NUM_MODE = OFF;
         options = new ArrayList<String>();
         which_option = -1;
         clearOptions();
         nums = new ArrayList<Integer>();
         clearNums();
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case SET_INSTRUCTION_SPEED:
         float tempSpeed = Float.parseFloat(workingText);
         if (tempSpeed >= 5.0f) {
           if (speedInPercentage) {
             if (tempSpeed > 100) tempSpeed = 10; 
             tempSpeed /= 100.0f;
           } else if (tempSpeed > armModel.motorSpeed) {
             tempSpeed = armModel.motorSpeed;
           }
           MotionInstruction castIns = getActiveMotionInstruct();
           castIns.setSpeed(tempSpeed);
           saveState();
         }
         loadInstructions(active_program);
         mode = INSTRUCTION_NAV;
         options = new ArrayList<String>();
         which_option = -1;
         clearOptions();
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case SET_INSTRUCTION_REGISTER:
         try {
           int tempRegister = Integer.parseInt(workingText);
           if (tempRegister >= 0 && tempRegister < pr.length) {
             MotionInstruction castIns = getActiveMotionInstruct();
             castIns.setRegister(tempRegister);
           }
         } catch (NumberFormatException NFEx){ /* Ignore invalid numbers */ }
         
         loadInstructions(active_program);
         mode = INSTRUCTION_NAV;
         options = new ArrayList<String>();
         which_option = -1;
         clearOptions();
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case SET_INSTRUCTION_TERMINATION:
         float tempTerm = Float.parseFloat(workingText);
         if (tempTerm > 0.0f) {
           tempTerm /= 100.0f;
           MotionInstruction castIns = getActiveMotionInstruct();
           castIns.setTermination(tempTerm);
         }
         
         loadInstructions(active_program);
         mode = INSTRUCTION_NAV;
         options = new ArrayList<String>();
         which_option = -1;
         clearOptions();
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case JUMP_TO_LINE:
         active_instruction = Integer.parseInt(workingText)-1;
         if (active_instruction < 0) active_instruction = 0;
         if (active_instruction >= programs.get(active_program).getInstructions().size())
           active_instruction = programs.get(active_program).getInstructions().size()-1;
         mode = INSTRUCTION_NAV;
         options = new ArrayList<String>();
         which_option = -1;
         clearOptions();
         loadInstructions(active_program);
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case VIEW_REGISTER:
         mode = INSTRUCTION_NAV;
         options = new ArrayList<String>();
         which_option = -1;
         clearOptions();
         loadInstructions(active_program);
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case ENTER_TEXT:
         if (workingText.length() > 0) {
           int new_prog = addProgram(new Program(workingText));
           workingText = "";
           active_program = new_prog;
           active_instruction = 0;
           mode = INSTRUCTION_NAV;
           super_mode = NONE;
           clearScreen();
           options = new ArrayList<String>();
           loadInstructions(active_program);
           updateScreen(color(255,0,0), color(0,0,0));
         } else {
           mode = super_mode;
           super_mode = NONE;
           clearScreen();
           options = new ArrayList<String>();
           loadPrograms();
           updateScreen(color(255,0,0), color(0,0,0));
         }
         
         break;
      case SETUP_NAV:
         options = new ArrayList<String>();
         options.add("1.Tool Frame");
         options.add("2.User Frame");
         //options.add("3.Jog Frame");
         mode = PICK_FRAME_MODE;
         which_option = 0;
         updateScreen(color(255,0,0), color(0));
         /*if (active_row == 3) {
           if (curCoordFrame == COORD_TOOL) {
             loadFrames(COORD_TOOL);
           } else if (curCoordFrame == COORD_USER) {
             loadFrames(COORD_USER);
           } else {
             loadActiveFrames();
           }
         }*/
         break;
      case PICK_FRAME_MODE:
         options = new ArrayList<String>();
         clearOptions();
         
         if (which_option == 0) {
           loadFrames(COORD_TOOL);
         } else if (which_option == 1) {
           loadFrames(COORD_USER);
         } // Jog Frame not implemented
         
         which_option = -1;
         break;
      case PICK_FRAME_METHOD:
         if (which_option == 0) {
           options = new ArrayList<String>();
           which_option = -1;
           teachPointTMatrices = new ArrayList<float[][]>();
           loadThreePointMethod();
         } else if (which_option == 1) {
           /* 6-Point Method not implemented */
         } else if (which_option == 2) {
           // TODO direct entry setup
           //loadDirectEntryMethod();
         }
         
         break;
      case IO_SUBMENU:
         if (active_row == 2) { // digital
            options = new ArrayList<String>();
            options.add("Use number keys to enter DO[X]");
            workingText = "";
            options.add(workingText);
            mode = SET_DO_BRACKET;
            which_option = 0;
            updateScreen(color(255,0,0), color(0));
         } else if (active_row == 5) { // robot
            options = new ArrayList<String>();
            options.add("Use number keys to enter RO[X]");
            workingText = "";
            options.add(workingText);
            mode = SET_RO_BRACKET;
            which_option = 0;
            updateScreen(color(255,0,0), color(0));
         }
         break;
      case SET_DO_BRACKET:
      case SET_RO_BRACKET:
         options = new ArrayList<String>();
         options.add("ON");
         options.add("OFF");
         if (mode == SET_DO_BRACKET) mode = SET_DO_STATUS;
         else if (mode == SET_RO_BRACKET) mode = SET_RO_STATUS;
         which_option = 0;
         updateScreen(color(255,0,0), color(0));
         break;
      case SET_DO_STATUS:
      case SET_RO_STATUS:
         Program prog = programs.get(active_program);
         
         try {
           int bracketNum = Integer.parseInt(workingText);
           if (bracketNum >= 0) {
             ToolInstruction insert = new ToolInstruction(
                (mode == SET_DO_STATUS ? "DO" : "RO"),
                bracketNum,
                (which_option == 0 ? ON : OFF));
             prog.addInstruction(insert);
           }
         } catch (NumberFormatException NFEx) { /* Ignore invalid numbers */ }
         
         active_instruction = prog.getInstructions().size() - 1;
         active_col = 0;
         /* 13 is the maximum number of instructions that can be displayed at one point in time */
         active_row = min(active_instruction, ITEMS_TO_SHOW - 4);
         text_render_start = active_instruction - active_row;
         
         loadInstructions(active_program);
         active_row = contents.size()-1;
         mode = INSTRUCTION_NAV;
         options.clear();
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case SET_FRAME_INSTRUCTION:
         prog = programs.get(active_program);
         
         try {
           int num = Integer.parseInt(workingText)-1;
           if (num < -1) num = -1;
           else if (num >= userFrames.length) num = userFrames.length-1;
           
           int type = 0;
           if (active_row == 0) type = FTYPE_TOOL;
           else if (active_row == 1) type = FTYPE_USER;
           prog.addInstruction(new FrameInstruction(type, num));
         } catch (NumberFormatException NFEx) { /* Ignore invalid numbers */ }
         
         active_instruction = prog.getInstructions().size() - 1;
         active_col = 0;
         /* 13 is the maximum number of instructions that can be displayed at one point in time */
         active_row = min(active_instruction, ITEMS_TO_SHOW - 4);
         text_render_start = active_instruction - active_row;
         
         loadInstructions(active_program);
         mode = INSTRUCTION_NAV;
         which_option = -1;
         active_row = 0;
         active_col = 0;
         options.clear();
         updateScreen(color(255,0,0), color(0,0,0));
         break;
      case EDIT_MENU:
         if (active_row == 1) { // delete
            options = new ArrayList<String>();
            options.add("Delete this line? F4 = YES, F5 = NO");
            mode = CONFIRM_DELETE;
            which_option = 0;
            updateScreen(color(255,0,0), color(0,0,0));
         }
         break;
   }
}


public void ITEM() {
  if (mode == INSTRUCTION_NAV) {
    options = new ArrayList<String>();
    options.add("Use number keys to enter line number to jump to");
    workingText = "";
    options.add(workingText);
    mode = JUMP_TO_LINE;
    which_option = 0;
    updateScreen(color(255,0,0), color(0,0,0));
  }
}


public void COORD() {
  if (shift == ON) {
    // Show frame indices in the pendant window
    active_row = 1;
    active_col = 0;
    workingText = "";
    loadActiveFrames();
  } else {  
    // Update the coordinate mode
    updateCoordinateMode(armModel);
    liveSpeed = 0.1f;
  }
}

public void SPEEDUP() {
  if (liveSpeed == 0.01f) liveSpeed += 0.04f; 
  else if (liveSpeed < 0.5f) liveSpeed += 0.05f;
  else if (liveSpeed < 1) liveSpeed += 0.1f;
  if (liveSpeed > 1) liveSpeed = 1;
}


public void SLOWDOWN() {
  if (liveSpeed > 0.5f) liveSpeed -= 0.1f;
  else if (liveSpeed > 0) liveSpeed -= 0.05f;
  if (liveSpeed < 0.01f) liveSpeed = 0.01f;
}


/* navigation buttons */
// zoomin button when interface is at full size
public void zoomin_normal(){
   myscale *= 1.1f;
}

// zoomin button when interface is minimized
public void zoomin_shrink(){
   zoomin_normal();
}

// zoomout button when interface is at full size
public void zoomout_normal(){
   myscale *= 0.9f;
}

// zoomout button when interface is minimized
public void zoomout_shrink(){
   zoomout_normal();
}

// pan button when interface is at full size
public void pan_normal(){
  clickPan += 1;
  if ((clickPan % 2) == 1){
     if((clickRotate % 2) == 1){
       rotate_normal();
     }
     
     cursorMode = HAND;
     PImage[] pressed = {loadImage("images/pan_down.png"), 
                         loadImage("images/pan_down.png"), 
                         loadImage("images/pan_down.png")};
                         
     cp5.getController("pan_normal")
        .setImages(pressed);
  }
  else{
     cursorMode = ARROW;
     PImage[] released = {loadImage("images/pan_35x20.png"), 
                          loadImage("images/pan_over.png"), 
                          loadImage("images/pan_down.png")};
                          
     cp5.getController("pan_normal")
        .setImages(released);
     doPan = false;   
  }
  
  cursor(cursorMode);
}

// pan button when interface is minimized
public void pan_shrink(){
  pan_normal();
}

// rotate button when interface is at full size
public void rotate_normal(){
   clickRotate += 1;
   if ((clickRotate % 2) == 1){
     if((clickPan % 2) == 1){
       pan_normal();
     }
     
     cursorMode = MOVE;
     PImage[] pressed = {loadImage("images/rotate_down.png"), 
                         loadImage("images/rotate_down.png"), 
                         loadImage("images/rotate_down.png")};
                         
     cp5.getController("rotate_normal")
        .setImages(pressed);
  }
  else{
     cursorMode = ARROW;
     PImage[] released = {loadImage("images/rotate_35x20.png"), 
                          loadImage("images/rotate_over.png"), 
                          loadImage("images/rotate_down.png")};
                          
     cp5.getController("rotate_normal")
        .setImages(released);
     doRotate = false;   
  }
  
  cursor(cursorMode);
}

// rotate button when interface is minized
public void rotate_shrink(){
  rotate_normal();
}

public void record_normal(){
   if (record == OFF){
      record = ON;
      PImage[] record = {loadImage("images/record-on.png"), 
                         loadImage("images/record-on.png"),
                         loadImage("images/record-on.png")};   
      bt_record_normal.setImages(record);
      new Thread(new RecordScreen()).start();
   }else{
      record = OFF;
      PImage[] record = {loadImage("images/record-35x20.png"), 
                         loadImage("images/record-over.png"), 
                         loadImage("images/record-on.png")};   
      bt_record_normal.setImages(record);
      
   }
}

public void EE(){
  armModel.activeEndEffector++;
  if (armModel.activeEndEffector > ENDEF_CLAW) armModel.activeEndEffector = 0;
  // Drop an object if held by the Robot currently
  armModel.releaseHeldObject();
  // TODO collision checking if an object was held by the Robot
}

/**
 * Updates the motion of one of the Robot's joints based on
 * the joint index given and the value of dir (-/+ 1). The
 * Robot's joint indices range from 0 to 5. If the joint
 * Associate with the given index is already in motion,
 * in either direction, then calling this method for that
 * joint index will stop that joint's motion.
 */
public void activateLiveJointMotion(int joint, int dir) {
  
  if (armModel.segments.size() >= joint+1) {

    Model model = armModel.segments.get(joint);
    // Checks all rotational axes
    for (int n = 0; n < 3; n++) {
    
      if (model.rotations[n]) {
      
        if (model.jointsMoving[n] == 0) {
          model.jointsMoving[n] = dir;
        } else {
          model.jointsMoving[n] = 0;
        }
      }
    }
  }
}

/**
 * Updates the motion of the Robot with respect to one of the World axes for
 * either linear or rotational motion around the axis. Similiar to the
 * activateLiveJointMotion() method, calling this method for an axis, in which
 * the Robot is already moving, will result in the termination of the Robot's
 * motion in that axis. Rotational and linear motion for an axis are mutually
 * independent in this regard.
 * 
 * @param axis        The axis of movement for the robotic arm:
                      x - 0, y - 2, z - 1, w - 3, p - 5, r - 4
 * @pararm dir        +1 or -1: indicating the direction of motion
 *
 */
public void activateLiveWorldMotion(int axis, int dir) {
  armModel.tgtPos = armModel.getEEPos();
  armModel.tgtRot = armModel.getQuaternion();
  
  if (axis >= 0 && axis < 3) {
    if (armModel.mvLinear[axis] == 0) {
      //Begin movement on the given axis in the given direction
      armModel.mvLinear[axis] = dir;
    } else {
      //Halt movement
      armModel.mvLinear[axis] = 0;
    }
  }
  else if(axis >= 3 && axis < 6){
    axis -= 3;
    if(armModel.mvRot[axis] == 0){
      armModel.mvRot[axis] = dir;
    }
    else{
      armModel.mvRot[axis] = 0;
    }
  }
}

public void JOINT1_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(0, -1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(0, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT1_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT1_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT1_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT1_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT1_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT1_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(0, 1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(0, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT1_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT1_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT1_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    //stopping movement, set both buttons to default
    ((Button)cp5.get("JOINT1_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT1_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT2_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(1, -1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(2, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT2_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT2_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT2_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT2_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT2_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT2_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(1, 1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(2, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT2_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT2_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT2_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT2_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT2_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT3_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(2, -1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(1, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT3_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT3_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT3_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT3_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT3_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT3_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(2, 1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(1, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT3_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT3_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT3_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT3_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT3_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT4_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(3, -1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(3, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT4_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT4_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT4_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else {
    ((Button)cp5.get("JOINT4_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT4_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT4_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(3, 1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(3, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT4_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT4_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT4_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT4_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT4_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT5_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(4, -1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(5, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT5_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT5_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT5_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT5_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT5_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT5_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(4, 1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(5, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT5_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT5_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT5_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT5_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT5_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT6_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(5, -1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(4, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT6_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT6_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT6_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT6_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT6_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT6_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(5, 1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(4, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT6_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT6_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT6_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT6_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT6_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

//turn of highlighting on all active movement buttons
public void resetButtonColors(){
  for(int i = 1; i <= 6; i += 1){
    ((Button)cp5.get("JOINT"+i+"_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT"+i+"_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void updateButtonColors(){
  for(int i = 0; i < 6; i += 1){
    Model m = armModel.segments.get(i);
    for(int j = 0; j < 3; j += 1){
      if(m.rotations[j] && m.jointsMoving[j] == 0){
        ((Button)cp5.get("JOINT"+(i+1)+"_NEG")).setColorBackground(COLOR_DEFAULT);
        ((Button)cp5.get("JOINT"+(i+1)+"_POS")).setColorBackground(COLOR_DEFAULT);
      }
    }
  }
}

// update what displayed on screen
public void updateScreen(int active, int normal){
   int next_px = display_px;
   int next_py = display_py;
   
   if (cp5.getController("-1") != null) cp5.getController("-1").remove();
   
   // display the name of the program that is being edited 
   switch (mode){
      case INSTRUCTION_NAV:
         cp5.addTextlabel("-1")
            .setText(programs.get(active_program).getName())
            .setPosition(next_px, next_py)
            .setColorValue(normal)
            .show()
            .moveTo(g1)
            ;
         next_px = display_px;
         next_py += 14;
         break;
      case INSTRUCTION_EDIT:
      case SET_INSTRUCTION_SPEED:
      case SET_INSTRUCTION_REGISTER:
      case SET_INSTRUCTION_TERMINATION:
         cp5.addTextlabel("-1")
            .setText(programs.get(active_program).getName()) 
            .setPosition(next_px, next_py)
            .setColorValue(normal)
            .show()
            .moveTo(g1)
            ;
         next_px = display_px;
         next_py += 14;
         break;
   }
   
   // clear main list
   for (int i = 0; i < ITEMS_TO_SHOW*7; i++) {
     if (cp5.getController(Integer.toString(i)) != null){
           cp5.getController(Integer.toString(i))
              .remove()
              ;
      }
   }

   // display the main list on screen
   index_contents = 0;
   for(int i=0;i<contents.size();i++){
      ArrayList<String> temp = contents.get(i);
      for (int j=0;j<temp.size();j++){
          if (i == active_row && j == active_col){
             cp5.addTextlabel(Integer.toString(index_contents))
                .setText(temp.get(j))
                .setPosition(next_px, next_py)
                .setColorValue(active)
                .moveTo(g1)
                ;
          }else{
             cp5.addTextlabel(Integer.toString(index_contents))
                .setText(temp.get(j))
                .setPosition(next_px, next_py)
                .setColorValue(normal)
                .moveTo(g1)
                ;  
          }
          index_contents++;
          next_px += temp.get(j).length() * 6 + 5; 
      }
      next_px = display_px;
      next_py += 14;     
   }
   
   // display options for an element being edited
   next_py += 14;
   index_options = 100;
   if (options.size() > 0){
      for(int i=0;i<options.size();i++){
        if (i==which_option){
           cp5.addTextlabel(Integer.toString(index_options))
              .setText(options.get(i))
              .setPosition(next_px, next_py)
              .setColorValue(active)
              .moveTo(g1)
              ;
        }else{
            cp5.addTextlabel(Integer.toString(index_options))
               .setText(options.get(i))
               .setPosition(next_px, next_py)
               .setColorValue(normal)
               .moveTo(g1)
               ;
        }
        
         index_options++;
         next_px = display_px;
         next_py += 14;    
      }
   }
   
   // display the numbers that the user has typed
   next_py += 14;
   index_nums = 1000;
   if (nums.size() > 0){
      for(int i=0;i<nums.size();i++){
         if (nums.get(i) == -1){
            cp5.addTextlabel(Integer.toString(index_nums))
               .setText(".")
               .setPosition(next_px, next_py)
               .setColorValue(normal)
               .moveTo(g1)
               ;
         }else{
            cp5.addTextlabel(Integer.toString(index_nums))
               .setText(Integer.toString(nums.get(i)))
               .setPosition(next_px, next_py)
               .setColorValue(normal)
               .moveTo(g1)
               ;
         }
         
         index_nums++;
         next_px += 5;   
      }
   }
   
   // display the comment for the user's input
   num_info.setPosition(next_px, next_py)
           .setColorValue(normal) 
           .show()
           ;
   next_px = display_px;
   next_py += 14;   
   
   // display hints for function keys
   next_py += 100;
   if (mode == PROGRAM_NAV) {
          fn_info.setText("F2: CREATE     F3: DELETE")
                 .setPosition(next_px, display_py+display_height-15)
                 .setColorValue(normal)
                 .show()
                 .moveTo(g1)
                 ;
   } else if (mode == INSTRUCTION_NAV) {
          fn_info.setText("SHIFT+F1: NEW PT     F4: CHOICE     F5: VIEW REG     SHIFT+F5: OVERWRITE")
                 .setPosition(next_px, display_py+display_height-15)
                 .setColorValue(normal)
                 .show()
                 .moveTo(g1)
                 ;
   } else if (mode == NAV_TOOL_FRAMES || mode == NAV_USER_FRAMES) {
     fn_info.setText("F1: SET     SHIFT+F1: DETAIL     F2: RESET")
                 .setPosition(next_px, display_py+display_height-15)
                 .setColorValue(normal)
                 .show()
                 .moveTo(g1)
                 ;
   } else if (mode == FRAME_DETAIL) {
     fn_info.setText("F2: METHOD")
                 .setPosition(next_px, display_py+display_height-15)
                 .setColorValue(normal)
                 .show()
                 .moveTo(g1)
                 ;
   } else if (mode == THREE_POINT_MODE) {
     fn_info.setText("SHIFT+F5: RECORD")
                 .setPosition(next_px, display_py+display_height-15)
                 .setColorValue(normal)
                 .show()
                 .moveTo(g1)
                 ;
   } else if (mode == ACTIVE_FRAMES) {
     fn_info.setText("SHIFT+F1: LIST     SHIFT+F2: RESET")
                 .setPosition(next_px, display_py+display_height-15)
                 .setColorValue(normal)
                 .show()
                 .moveTo(g1)
                 ;
   } else {
          fn_info.show()
                 .moveTo(g1)
                 ;
   }
   
} // end updateScreen()

// clear screen
public void clearScreen(){
   clearContents();
   clearOptions();
   
   // hide the text labels that show the start and end of a program
   if (mode == INSTRUCTION_NAV){
      
   } else if (mode == INSTRUCTION_EDIT){
     
   }else{
      if (cp5.getController("-1") != null){
           cp5.getController("-1")
              .remove()
              ;
      }     
      if (cp5.getController("-2") != null){
           cp5.getController("-2")
              .remove()
              ;   
      }
      fn_info.remove();
   }
   
   clearNums();
   
   cp5.update();
   active_row = 0;
   active_col = 0;
   contents = new ArrayList<ArrayList<String>>();
}

public void clearContents(){
   for(int i=0;i<index_contents;i++){
      cp5.getController(Integer.toString(i)).remove();
   }
   index_contents = 0;
}

public void clearOptions(){
   for(int i=100;i<index_options;i++){
      cp5.getController(Integer.toString(i)).remove();
   }
   index_options = 100;
}

public void clearNums(){
   for(int i=1000;i<index_nums;i++){
      cp5.getController(Integer.toString(i)).remove();
   }
   index_nums = 1000;
}

/* Loads the set of Frames that correspond to the given coordinate frame.
 * Only COORD_TOOL and COOR_USER have Frames sets as of now.
 * 
 * @param coorFrame  the integer value representing the coordinate frame
 *                   of te desired frame set
 */
public void loadFrames(int coordFrame) {
  
  Frame[] frames = null;
  
  if (coordFrame == COORD_TOOL) {
    frames = toolFrames;
    mode = NAV_TOOL_FRAMES;
  } else if (coordFrame == COORD_USER) {
    frames = userFrames;
    mode = NAV_USER_FRAMES;
  }
  // Only the Tool and User Frame lists have been implemented
  if (frames != null) {
    contents = new ArrayList<ArrayList<String>>();
    
    for (int idx = 0; idx < frames.length; ++idx) {
      // Display each frame on its own line
      Frame frame = frames[idx];
      ArrayList<String> line = new ArrayList<String>();
      String str = String.format("%d) %s", idx + 1, frame.getOrigin());
      
      line.add(str);
      contents.add(line);
    }
    
    active_col = active_row = 0;
    updateScreen(color(255,0,0), color(0));
  }
}

public void loadThreePointMethod() {
  contents = new ArrayList<ArrayList<String>>();
  
  contents.add(new ArrayList<String>());
  
  if (teachPointTMatrices != null) {
    
    contents.add(new ArrayList<String>());
    contents.add(new ArrayList<String>());
  
    String[] limbo = new String[3];
    
    if (super_mode == NAV_TOOL_FRAMES) {
      
      limbo[0] = "First Approach Point: ";
      limbo[1] = "Second Approach Point: ";
      limbo[2] = "Third Approach Point: ";
    } else if (super_mode == NAV_TOOL_FRAMES) {
      
      limbo[0] = "Orient Origin Point: ";
      limbo[1] = "X Direction Point: ";
      limbo[2] = "Y Direction Point: ";
    } else {
      
      for (int idx = 0; idx < limbo.length; ++idx) { limbo[idx] = ""; }
      return;
    }
    
    int size = teachPointTMatrices.size();
    
    for (int idx = 0; idx < limbo.length; ++idx) {
      // Add each line to contents
      limbo[idx] += ((size > idx) ? "RECORDED" : "UNINIT");
      contents.get(idx).add(limbo[idx]);
    }
  } else {
    // ArrayList is null
    contents.get(0).add("Error: teachPointTMatrices not set!");
  }
  
  mode = THREE_POINT_MODE;
  updateScreen(color(0), color(0));
}

public void loadFrameDetails() {
  contents = new ArrayList<ArrayList<String>>();
  ArrayList<String> line = new ArrayList<String>();
  String str = "";
  if (super_mode == NAV_TOOL_FRAMES) str = "TOOL FRAME " + (active_row+1);
  else if (super_mode == NAV_USER_FRAMES) str = "USER FRAME " + (active_row+1);
  line.add(str);
  contents.add(line);
  
  line = new ArrayList<String>();
  str = "X: " + currentFrame.getOrigin().x;
  line.add(str);
  contents.add(line);
  line = new ArrayList<String>();
  str = "Y: " + currentFrame.getOrigin().y;
  line.add(str);
  contents.add(line);
  line = new ArrayList<String>();
  str = "Z: " + currentFrame.getOrigin().z;
  line.add(str);
  contents.add(line);
  line = new ArrayList<String>();
  str = "W: " + currentFrame.getWpr().x;
  line.add(str);
  contents.add(line);
  line = new ArrayList<String>();
  str = "P: " + currentFrame.getWpr().y;
  line.add(str);
  contents.add(line);
  line = new ArrayList<String>();
  str = "R: " + currentFrame.getWpr().z;
  line.add(str);
  contents.add(line);  
  mode = FRAME_DETAIL;
  updateScreen(color(0), color(0));
}

// prepare for displaying motion instructions on screen
public void loadInstructions(int programID){
   Program p = programs.get(programID);
   contents = new ArrayList<ArrayList<String>>();
   int size = p.getInstructions().size();
   
   int start = text_render_start;
   int end = min(start + ITEMS_TO_SHOW - 3, size);
   if (end >= size) end = size;
   for(int i=start;i<end;i++){
      ArrayList<String> m = new ArrayList<String>();
      m.add(Integer.toString(i+1) + ")");
      Instruction instruction = p.getInstructions().get(i);
      if (instruction instanceof MotionInstruction) {
        MotionInstruction a = (MotionInstruction)instruction;
        // add motion type
        switch (a.getMotionType()){
           case MTYPE_JOINT:
              m.add("J");
              break;
           case MTYPE_LINEAR:
              m.add("L");
              break;
           case MTYPE_CIRCULAR:
              m.add("C");
              break; 
        }
        // load register no, speed and termination type
        if (a.getGlobal()) m.add("PR[");
        else m.add("P[");
        m.add(a.getRegister()+"]");
        if (a.getMotionType() == MTYPE_JOINT) m.add((a.getSpeed() * 100) + "%");
        else m.add((int)(a.getSpeed()) + "mm/s");
        if (a.getTermination() == 0) m.add("FINE");
        else m.add("CONT" + (int)(a.getTermination()*100));
        contents.add(m);
      } else if (instruction instanceof ToolInstruction ||
                 instruction instanceof FrameInstruction)
      {
        m.add(instruction.toString());
        contents.add(m);
      }
   } 
}

/* Deals with updating the UI after confirming/canceling a deletion */
public void deleteInstEpilogue() {
  Program prog = programs.get(active_program);
  
  active_instruction = min(active_instruction,  prog.getInstructions().size() - 1);
  /* 13 is the maximum number of instructions that can be displayed at one point in time */
  active_row = min(active_instruction, ITEMS_TO_SHOW - 4);
  active_col = 0;
  text_render_start = active_instruction - active_row;
  
  loadInstructions(active_program);
  mode = INSTRUCTION_NAV;
  options.clear();
  updateScreen(color(255,0,0), color(0,0,0));
}

public void loadActiveFrames() {
  options = new ArrayList<String>();
  contents = new ArrayList<ArrayList<String>>();
  ArrayList<String> line = new ArrayList<String>();
  active_row = 1;
  
  line.add("ACTIVE FRAMES");
  contents.add(line);
  
  line = new ArrayList<String>();
  line.add("Tool: " + (activeToolFrame + 1));
  contents.add(line);
  
  line = new ArrayList<String>();
  line.add("User: " + (activeUserFrame + 1));
  contents.add(line);
  
  // Currently not implemented
  /*line = new ArrayList<String>();
  line.add("Jog:  " + (activeJogFrame + 1));
  contents.add(line);*/
  
  mode = ACTIVE_FRAMES;
  updateScreen(color(255,0,0), color(0));
}

public void loadPrograms() {
   options = new ArrayList<String>(); // clear options
   nums = new ArrayList<Integer>(); // clear numbers
   
   if (cp5.getController("-2") != null) cp5.getController("-2").remove();
   fn_info.setText("");
   
   int size = programs.size();
   /*if (size <= 0){
      programs.add(new Program("My Program 1"));
   }/* */
   
   active_instruction = 0;
   
   contents.clear();  
   int start = text_render_start;
   int end = min(start + ITEMS_TO_SHOW, size);
   for(int i=start;i<end;i++){
      ArrayList<String> temp = new ArrayList<String>();
      temp.add(programs.get(i).getName());
      contents.add(temp);
   }
}
/* Transforms the given vector from the coordinate system defined by the given
 * transformation matrix. */
public PVector transform(PVector v, float[][] tMatrix) {
  if (tMatrix.length != 4 || tMatrix[0].length != 4) {
    return null;
  }

  PVector u = new PVector();

  u.x = v.x * tMatrix[0][0] + v.y * tMatrix[0][1] + v.z * tMatrix[0][2] + tMatrix[0][3];
  u.y = v.x * tMatrix[1][0] + v.y * tMatrix[1][1] + v.z * tMatrix[1][2] + tMatrix[1][3];
  u.z = v.x * tMatrix[2][0] + v.y * tMatrix[2][1] + v.z * tMatrix[2][2] + tMatrix[2][3];

  return u;
}

/**
 * Find the inverse of the given 4x4 Homogeneous Coordinate Matrix. 
 * 
 * This method is based off of the algorithm found on this webpage:
 *    https://web.archive.org/web/20130806093214/http://www-graphics.stanford.edu/
 *      courses/cs248-98-fall/Final/q4.html
 */
public float[][] invertHCMatrix(float[][] m) {
  if (m.length != 4 || m[0].length != 4) {
    return null;
  }

  float[][] inverse = new float[4][4];

  /* [ ux vx wx tx ] -1       [ ux uy uz -dot(u, t) ]
   * [ uy vy wy ty ]     =    [ vx vy vz -dot(v, t) ]
   * [ uz vz wz tz ]          [ wx wy wz -dot(w, t) ]
   * [  0  0  0  1 ]          [  0  0  0      1     ]
   */
  inverse[0][0] = m[0][0];
  inverse[0][1] = m[1][0];
  inverse[0][2] = m[2][0];
  inverse[0][3] = -(m[0][0] * m[0][3] + m[1][0] * m[1][3] + m[2][0] * m[2][3]);
  inverse[1][0] = m[0][1];
  inverse[1][1] = m[1][1];
  inverse[1][2] = m[2][1];
  inverse[1][3] = -(m[0][1] * m[0][3] + m[1][1] * m[1][3] + m[2][1] * m[2][3]);
  inverse[2][0] = m[0][2];
  inverse[2][1] = m[1][2];
  inverse[2][2] = m[2][2];
  inverse[2][3] = -(m[0][2] * m[0][3] + m[1][2] * m[1][3] + m[2][2] * m[2][3]);
  inverse[3][0] = 0;
  inverse[3][1] = 0;
  inverse[3][2] = 0;
  inverse[3][3] = 1;

  return inverse;
}

/* Returns a 4x4 vector array which reflects the current transform matrix on the top
 * of the stack */
public float[][] getTransformationMatrix() {
  float[][] transform = new float[4][4];

  // Caculate four vectors corresponding to the four columns of the transform matrix
  PVector col_4 = getCoordFromMatrix(0, 0, 0);
  PVector col_1 = getCoordFromMatrix(1, 0, 0).sub(col_4);
  PVector col_2 = getCoordFromMatrix(0, 1, 0).sub(col_4);
  PVector col_3 = getCoordFromMatrix(0, 0, 1).sub(col_4);

  // Place the values of each vector in the correct cells of the transform  matrix
  transform[0][0] = col_1.x;
  transform[1][0] = col_1.y;
  transform[2][0] = col_1.z;
  transform[3][0] = 0;
  transform[0][1] = col_2.x;
  transform[1][1] = col_2.y;
  transform[2][1] = col_2.z;
  transform[3][1] = 0;
  transform[0][2] = col_3.x;
  transform[1][2] = col_3.y;
  transform[2][2] = col_3.z;
  transform[3][2] = 0;
  transform[0][3] = col_4.x;
  transform[1][3] = col_4.y;
  transform[2][3] = col_4.z;
  transform[3][3] = 1;

  return transform;
}

/* This method transforms the given coordinates into a vector
 * in the Processing's native coordinate system. */
public PVector getCoordFromMatrix(float x, float y, float z) {
  PVector vector = new PVector();

  vector.x = modelX(x, y, z);
  vector.y = modelY(x, y, z);
  vector.z = modelZ(x, y, z);

  return vector;
}

//calculates rotation matrix from euler angles
public float[][] eulerToMatrix(PVector wpr) {
  float[][] r = new float[3][3];
  float xRot = wpr.x;
  float yRot = wpr.y;
  float zRot = wpr.z;

  r[0][0] = cos(yRot)*cos(zRot);
  r[0][1] = sin(xRot)*sin(yRot)*cos(zRot) - cos(xRot)*sin(zRot);
  r[0][2] = cos(xRot)*sin(yRot)*cos(zRot) + sin(xRot)*sin(zRot);
  r[1][0] = cos(yRot)*sin(zRot);
  r[1][1] = sin(xRot)*sin(yRot)*sin(zRot) + cos(xRot)*cos(zRot);
  r[1][2] = cos(xRot)*sin(yRot)*sin(zRot) - sin(xRot)*cos(zRot);
  r[2][0] = -sin(yRot);
  r[2][1] = sin(xRot)*cos(yRot);
  r[2][2] = cos(xRot)*cos(yRot);

  //println("matrix: ");
  //  for(int i = 0; i < 3; i += 1){
  //    for(int j = 0; j < 3; j += 1){
  //      print(String.format("  %4.3f", r[i][j]));
  //    }
  //  println();
  //}
  //println();

  return r;
}

//calculates quaternion from euler angles
public float[] eulerToQuat(PVector wpr) {
  //float[][] r = eulerToMatrix(wpr);
  //float[] q = matrixToQuat(r);

  /*Alternate computation method; produces equivalent result to above, but may
   *not have the same sign (certain quaternions are equivalent when negated).
   */
  float[] q = new float[4];
  float xRot = wpr.x;
  float yRot = wpr.y;
  float zRot = wpr.z;

  q[0] = sin(zRot/2)*sin(yRot/2)*sin(xRot/2) + cos(zRot/2)*cos(yRot/2)*cos(xRot/2);
  q[1] = -sin(zRot/2)*sin(yRot/2)*cos(xRot/2) + sin(xRot/2)*cos(zRot/2)*cos(yRot/2);
  q[2] = sin(zRot/2)*sin(xRot/2)*cos(yRot/2) + sin(yRot/2)*cos(zRot/2)*cos(zRot/2);
  q[3] = sin(zRot/2)*cos(yRot/2)*cos(xRot/2) - sin(yRot/2)*sin(xRot/2)*cos(xRot/2);

  return q;
}

//calculates euler angles from rotation matrix
public PVector matrixToEuler(float[][] r) {
  float yRot1, yRot2, xRot1, xRot2, zRot1, zRot2;
  PVector wpr, wpr2;

  if (r[2][0] != 1 && r[2][0] != -1) {
    //rotation about y-axis
    yRot1 = -asin(r[2][0]);
    yRot2 = PI - yRot1;
    //rotation about x-axis
    xRot1 = atan2(r[2][1]/cos(yRot1), r[2][2]/cos(yRot1));
    xRot2 = atan2(r[2][1]/cos(yRot2), r[2][2]/cos(yRot2));
    //rotation about z-axis
    zRot1 = atan2(r[1][0]/cos(yRot1), r[0][0]/cos(yRot1));
    zRot2 = atan2(r[1][0]/cos(yRot2), r[0][0]/cos(yRot2));
  } else {
    zRot1 = zRot2 = 0;
    if (r[2][0] == -1) {
      yRot1 = yRot2 = PI/2;
      xRot1 = xRot2 = zRot1 + atan2(r[0][1], r[0][2]);
    } else {
      yRot1 = yRot2 = -PI/2;
      xRot1 = xRot2 = -zRot1 + atan2(-r[0][1], -r[0][2]);
    }
  }

  wpr = new PVector(xRot1, yRot1, zRot1);
  wpr2 = new PVector(xRot2, yRot2, zRot2);

  return wpr;
}

//calculates quaternion from rotation matrix
public float[] matrixToQuat(float[][] r) {
  float[] q = new float[4];
  float tr = r[0][0] + r[1][1] + r[2][2];

  if (tr > 0) {
    float S = sqrt(1.0f + tr) * 2; // S=4*q[0] 
    q[0] = S / 4;
    q[1] = (r[2][1] - r[1][2]) / S;
    q[2] = (r[0][2] - r[2][0]) / S; 
    q[3] = (r[1][0] - r[0][1]) / S;
  } else if ((r[0][0] > r[1][1]) & (r[0][0] > r[2][2])) {
    float S = sqrt(1.0f + r[0][0] - r[1][1] - r[2][2]) * 2; // S=4*q[1] 
    q[0] = (r[2][1] - r[1][2]) / S;
    q[1] = S / 4;
    q[2] = (r[0][1] + r[1][0]) / S; 
    q[3] = (r[0][2] + r[2][0]) / S;
  } else if (r[1][1] > r[2][2]) {
    float S = sqrt(1.0f + r[1][1] - r[0][0] - r[2][2]) * 2; // S=4*q[2]
    q[0] = (r[0][2] - r[2][0]) / S;
    q[1] = (r[0][1] + r[1][0]) / S; 
    q[2] = S / 4;
    q[3] = (r[1][2] + r[2][1]) / S;
  } else {
    float S = sqrt(1.0f + r[2][2] - r[0][0] - r[1][1]) * 2; // S=4*q[3]
    q[0] = (r[1][0] - r[0][1]) / S;
    q[1] = (r[0][2] + r[2][0]) / S;
    q[2] = (r[1][2] + r[2][1]) / S;
    q[3] = S / 4;
  }

  return q;
}

//calculates euler angles from quaternion
public PVector quatToEuler(float[] q) {
  float[][] r = quatToMatrix(q);
  PVector wpr = matrixToEuler(r);
  return wpr;
}

//calculates rotation matrix from quaternion
public float[][] quatToMatrix(float[] q) {
  float[][] r = new float[3][3];

  r[0][0] = 1 - 2*(q[2]*q[2] + q[3]*q[3]);
  r[0][1] = 2*(q[1]*q[2] - q[0]*q[3]);
  r[0][2] = 2*(q[0]*q[2] + q[1]*q[3]);
  r[1][0] = 2*(q[1]*q[2] + q[0]*q[3]);
  r[1][1] = 1 - 2*(q[1]*q[1] + q[3]*q[3]);
  r[1][2] = 2*(q[2]*q[3] - q[0]*q[1]);
  r[2][0] = 2*(q[1]*q[3] - q[0]*q[2]);
  r[2][1] = 2*(q[0]*q[1] + q[2]*q[3]);
  r[2][2] = 1 - 2*(q[1]*q[1] + q[2]*q[2]);

  //println("matrix: ");
  //for(int i = 0; i < 3; i += 1){
  //  for(int j = 0; j < 3; j += 1){
  //    print(String.format("  %4.3f", m[i][j]));
  //  }
  //  println();
  //}
  //println();

  return r;
}

//converts a float array to a double array
public double[][] floatToDouble(float[][] m, int l, int w) {
  double[][] r = new double[l][w];

  for (int i = 0; i < l; i += 1) {
    for (int j = 0; j < w; j += 1) {
      r[i][j] = (double)m[i][j];
    }
  }

  return r;
}

//converts a double array to a float array
public float[][] doubleToFloat(double[][] m, int l, int w) {
  float[][] r = new float[l][w];

  for (int i = 0; i < l; i += 1) {
    for (int j = 0; j < w; j += 1) {
      r[i][j] = (float)m[i][j];
    }
  }

  return r;
}

//calculates the change in x, y, and z from p1 to p2
public float[] calculateVectorDelta(PVector p1, PVector p2) {
  float[] d = {p1.x - p2.x, p1.y - p2.y, p1.z - p2.z};
  return d;
}

//calculates the difference between each corresponding pair of
//elements for two vectors of n elements
public float[] calculateVectorDelta(float[] v1, float[] v2, int n) {
  float[] d = new float[n];
  for (int i = 0; i < n; i += 1) {
    d[i] = v1[i] - v2[i];
  }

  return d;
}

//produces a rotation matrix given a rotation 'theta' around
//a given axis
public float[][] rotateAxisVector(float[][] m, float theta, PVector axis) {
  float s = sin(theta);
  float c = cos(theta);
  float t = 1-c;

  if (c > 0.9f)
    t = 2*sin(theta/2)*sin(theta/2);

  float x = axis.x;
  float y = axis.y;
  float z = axis.z;
  
  float[][] r = new float[3][3];

  r[0][0] = x*x*t+c;
  r[0][1] = x*y*t-z*s;
  r[0][2] = x*z*t+y*s;
  r[1][0] = y*x*t+z*s;
  r[1][1] = y*y*t+c;
  r[1][2] = y*z*t-x*s;
  r[2][0] = z*x*t-y*s;
  r[2][1] = z*y*t+x*s;
  r[2][2] = z*z*t+c;
  
  RealMatrix M = new Array2DRowRealMatrix(floatToDouble(m, 3, 3));
  RealMatrix R = new Array2DRowRealMatrix(floatToDouble(r, 3, 3));
  RealMatrix MR = M.multiply(R);

  return doubleToFloat(MR.getData(), 3, 3);
}

/* Calculates the result of a rotation of quaternion 'p'
 * about axis 'u' by 'theta' degrees
 */
public float[] rotateQuat(float[] p, float theta, PVector u) {
  float[] q = new float[4];
  
  q[0] = cos(theta/2);
  q[1] = sin(theta/2)*u.x;
  q[2] = sin(theta/2)*u.y;
  q[3] = sin(theta/2)*u.z;
  
  float[] qp = quaternionMult(q, p);

  return qp;
}

/* Given 2 quaternions, calculates the quaternion representing the 
 * rotation from 'q1' to 'q2' such that 'qr'*'q1' = 'q2'. Note that 
 * the multiply operation should be taken to mean quaternion
 * multiplication, which is non-commutative.
 */
public float[] calculateQuatOffset(float[] q1, float[] q2){
  float[] q1_inv = new float[4];
  q1_inv[0] = q1[0];
  q1_inv[1] = -q1[1];
  q1_inv[2] = -q1[2];
  q1_inv[3] = -q1[3];
  
  float[] qr = quaternionMult(q2, q1_inv);
  
  for(int i = 0; i < 4; i += 1){
    if(qr[i] < 0.00001f)
      qr[i] = 0;
  }
  
  return qr;
}

public float[] quaternionMult(float[] q1, float[] q2) {
  float[] r = new float[4];
  r[0] = q1[0]*q2[0] - q1[1]*q2[1] - q1[2]*q2[2] - q1[3]*q2[3];
  r[1] = q1[0]*q2[1] + q1[1]*q2[0] + q1[2]*q2[3] - q1[3]*q2[2];
  r[2] = q1[0]*q2[2] - q1[1]*q2[3] + q1[2]*q2[0] + q1[3]*q2[1];
  r[3] = q1[0]*q2[3] + q1[1]*q2[2] - q1[2]*q2[1] + q1[3]*q2[0];

  return r;
}

//returns the magnitude of the input quaternion 'q'
public float calculateQuatMag(float[] q){
  return sqrt(pow(q[0], 2) + pow(q[1], 2) + pow(q[2], 2) + pow(q[3], 2));
}

/* Displays the contents of a 4x4 matrix in the command line */
public void printHCMatrix(float[][] m) {
  if (m.length != 4 || m[0].length != 4) { 
    return;
  }

  for (int r = 0; r < m.length; ++r) {
    String row = String.format("[ %5.4f %5.4f %5.4f %5.4f ]\n", m[r][0], m[r][1], m[r][2], m[r][3]);
    print(row);
  }
}

/* Returns a string represenation of the given matrix.
 * 
 * @param matrixx  A non-null matrix
 */
public String matrixToString(float[][] matrix) {
  String mStr = "";
  
  for (int row = 0; row < matrix.length; ++row) {
    mStr += "\n[";

    for (int col = 0; col < matrix[0].length; ++col) {
      // Account for the negative sign character
      if (matrix[row][col] >= 0) { mStr += " "; }
      
      mStr += String.format(" %5.6f", matrix[row][col]);
    }

    mStr += "  ]";
  }
  
  return (mStr + "\n");
}


//To-do list:
//Collision detection

public class Triangle {
  // normal, vertex 1, vertex 2, vertex 3
  public PVector[] components = new PVector[4];
}

public class Model {
  public PShape mesh;
  public String name;
  public boolean[] rotations = new boolean[3]; // is rotating on this joint valid?
  // Joint ranges follow a clockwise format running from the PVector.x to PVector.y, where PVector.x and PVector.y range from [0, TWO_PI]
  public PVector[] jointRanges = new PVector[3];
  public float[] currentRotations = new float[3]; // current rotation value
  public float[] targetRotations = new float[3]; // we want to be rotated to this value
  public int[] rotationDirections = new int[3]; // control rotation direction so we
                                                // don't "take the long way around"
  public float rotationSpeed;
  public float[] jointsMoving = new float[3]; // for live control using the joint buttons
  
  public Model(String filename, int col) {
    for (int n = 0; n < 3; n++) {
      rotations[n] = false;
      currentRotations[n] = 0;
      jointRanges[n] = null;
    }
    rotationSpeed = 0.01f;
    name = filename;
    loadSTLModel(filename, col);
  }
  
  public void loadSTLModel(String filename, int col) {
    ArrayList<Triangle> triangles = new ArrayList<Triangle>();
    byte[] data = loadBytes(filename);
    int n = 84; // skip header and number of triangles
    
    while (n < data.length) {
      Triangle t = new Triangle();
      for (int m = 0; m < 4; m++) {
        byte[] bytesX = new byte[4];
        bytesX[0] = data[n+3]; bytesX[1] = data[n+2];
        bytesX[2] = data[n+1]; bytesX[3] = data[n];
        n += 4;
        byte[] bytesY = new byte[4];
        bytesY[0] = data[n+3]; bytesY[1] = data[n+2];
        bytesY[2] = data[n+1]; bytesY[3] = data[n];
        n += 4;
        byte[] bytesZ = new byte[4];
        bytesZ[0] = data[n+3]; bytesZ[1] = data[n+2];
        bytesZ[2] = data[n+1]; bytesZ[3] = data[n];
        n += 4;
        t.components[m] = new PVector(
          ByteBuffer.wrap(bytesX).getFloat(),
          ByteBuffer.wrap(bytesY).getFloat(),
          ByteBuffer.wrap(bytesZ).getFloat()
        );
      }
      triangles.add(t);
      n += 2; // skip meaningless "attribute byte count"
    }
    mesh = createShape();
    mesh.beginShape(TRIANGLES);
    mesh.noStroke();
    mesh.fill(col);
    for (Triangle t : triangles) {
      mesh.normal(t.components[0].x, t.components[0].y, t.components[0].z);
      mesh.vertex(t.components[1].x, t.components[1].y, t.components[1].z);
      mesh.vertex(t.components[2].x, t.components[2].y, t.components[2].z);
      mesh.vertex(t.components[3].x, t.components[3].y, t.components[3].z);
    }
    mesh.endShape();
  } // end loadSTLModel
    
  public boolean anglePermitted(int idx, float angle) {
    
    if (jointRanges[idx].x < jointRanges[idx].y) {
      // Joint range does not overlap TWO_PI
      return angle >= jointRanges[idx].x && angle < jointRanges[idx].y;
    } else {
      // Joint range overlaps TWO_PI
      return !(angle >= jointRanges[idx].y && angle < jointRanges[idx].x);
    }
  }
  
  public void draw() {
    shape(mesh);
  }
  
} // end Model class

// The apporximate center of the base of the robot
public static final PVector base_center = new PVector(404, 137, -212);

public class ArmModel {
  
  public int activeEndEffector = ENDEF_NONE;
  public int endEffectorStatus = OFF;

  public ArrayList<Model> segments = new ArrayList<Model>();
  public int type;
  //public boolean calculatingArms = false, movingArms = false;
  public float motorSpeed;
  // Indicates translational motion in the World Frame
  public float[] mvLinear = new float[3];
  // Indicates rotational motion in the World Frame
  public float[] mvRot = new float[3];
  public float[] tgtRot = new float[4];
  public PVector tgtPos = new PVector();
  public float[][] currentFrame = {{ 1, 0, 0},
                                   { 0, 1, 0},
                                   { 0, 0, 1}};
  
  public Box[] bodyHitBoxes;
  private ArrayList<Box>[] eeHitBoxes;
      
  public Object held;
  public float[][] oldEETMatrix;
  
  public ArmModel() {
    
    motorSpeed = 4000.0f; // speed in mm/sec
    // Joint 1
    Model base = new Model("ROBOT_MODEL_1_BASE.STL", color(200, 200, 0));
    base.rotations[1] = true;
    base.jointRanges[1] = new PVector(0, TWO_PI);
    base.rotationSpeed = radians(350)/60.0f;
    // Joint 2
    Model axis1 = new Model("ROBOT_MODEL_1_AXIS1.STL", color(40, 40, 40));
    axis1.rotations[2] = true;
    axis1.jointRanges[2] = new PVector(4.34f, 2.01f);
    axis1.rotationSpeed = radians(350)/60.0f;
    // Joint 3
    Model axis2 = new Model("ROBOT_MODEL_1_AXIS2.STL", color(200, 200, 0));
    axis2.rotations[2] = true;
    axis2.jointRanges[2] = new PVector(12f * PI / 20f, 8f * PI / 20f);
    axis2.rotationSpeed = radians(400)/60.0f;
    // Joint 4
    Model axis3 = new Model("ROBOT_MODEL_1_AXIS3.STL", color(40, 40, 40));
    axis3.rotations[0] = true;
    axis3.jointRanges[0] = new PVector(0, TWO_PI);
    axis3.rotationSpeed = radians(450)/60.0f;
    // Joint 5
    Model axis4 = new Model("ROBOT_MODEL_1_AXIS4.STL", color(40, 40, 40));
    axis4.rotations[2] = true;
    axis4.jointRanges[2] = new PVector(59f * PI / 40f, 11f * PI / 20f);
    axis4.rotationSpeed = radians(450)/60.0f;
    // Joint 6
    Model axis5 = new Model("ROBOT_MODEL_1_AXIS5.STL", color(200, 200, 0));
    axis5.rotations[0] = true;
    axis5.jointRanges[0] = new PVector(0, TWO_PI);
    axis5.rotationSpeed = radians(720)/60.0f;
    Model axis6 = new Model("ROBOT_MODEL_1_AXIS6.STL", color(40, 40, 40));
    segments.add(base);
    segments.add(axis1);
    segments.add(axis2);
    segments.add(axis3);
    segments.add(axis4);
    segments.add(axis5);
    segments.add(axis6);
    
    for(int idx = 0; idx < mvLinear.length; ++idx){
      mvLinear[idx] = 0;
    }
    
    for(int idx = 0; idx < mvRot.length; ++idx){
      mvRot[idx] = 0;
    }
    
    /* Initialies dimensions of the Robot Arm's hit boxes */
    bodyHitBoxes = new Box[7];
    
    bodyHitBoxes[0] = new Box(420, 115, 420, color(0, 255, 0));
    bodyHitBoxes[1] = new Box(317, 85, 317, color(0, 255, 0));
    bodyHitBoxes[2] = new Box(130, 185, 170, color(0, 255, 0));
    bodyHitBoxes[3] = new Box(74, 610, 135, color(0, 255, 0));
    bodyHitBoxes[4] = new Box(165, 165, 165, color(0, 255, 0));
    bodyHitBoxes[5] = new Box(160, 160, 160, color(0, 255, 0));
    bodyHitBoxes[6] = new Box(128, 430, 128, color(0, 255, 0));
    
    eeHitBoxes = (ArrayList<Box>[])new ArrayList[4]; 
    // Face plate
    eeHitBoxes[0] = new ArrayList<Box>();
    eeHitBoxes[0].add( new Box(102, 102, 36, color(0, 255, 0)) );
    // Claw Gripper (closed)
    eeHitBoxes[1] = new ArrayList<Box>();
    eeHitBoxes[1].add( new Box(102, 102, 46, color(0, 255, 0)) );
    eeHitBoxes[1].add( new Box(89, 43, 31, color(0, 255, 0)) );
    // Claw Gripper (open)
    eeHitBoxes[2] = new ArrayList<Box>();
    eeHitBoxes[2].add( new Box(102, 102, 46, color(0, 255, 0)) );
    eeHitBoxes[2].add( new Box(89, 21, 31, color(0, 255, 0)) );
    eeHitBoxes[2].add( new Box(89, 21, 31, color(0, 255, 0)) );
    // Suction 
    eeHitBoxes[3] = new ArrayList<Box>();
    eeHitBoxes[3].add( new Box(102, 102, 46, color(0, 255, 0)) );
    eeHitBoxes[3].add( new Box(37, 37, 87, color(0, 255, 0)) );
    eeHitBoxes[3].add( new Box(37, 67, 37, color(0, 255, 0)) );
     
    held = null;
    // Initializes the old transformation matrix for the arm model
    pushMatrix();
    applyModelRotation(this, false);
    oldEETMatrix = getTransformationMatrix();
    popMatrix();
  } // end ArmModel constructor
  
  public void draw() {
    
    noStroke();
    fill(200, 200, 0);
    
    translate(600, 200, 0);

    rotateZ(PI);
    rotateY(PI/2);
    segments.get(0).draw();
    rotateY(-PI/2);
    rotateZ(-PI);
    
    fill(50);
  
    translate(-50, -166, -358); // -115, -213, -413
    rotateZ(PI);
    translate(150, 0, 150);
    rotateY(segments.get(0).currentRotations[1]);
    translate(-150, 0, -150);
    segments.get(1).draw();
    rotateZ(-PI);
  
    fill(200, 200, 0);
  
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    rotateX(segments.get(1).currentRotations[2]);
    translate(0, -62, -62);
    segments.get(2).draw();
    rotateY(-PI/2);
    rotateZ(-PI);
  
    fill(50);
 
    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    rotateX(segments.get(2).currentRotations[2]);
    translate(0, -75, -75);
    segments.get(3).draw();
    rotateY(PI/2);
    rotateZ(-PI);
  
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    rotateY(segments.get(3).currentRotations[0]);
    translate(-70, 0, -70);
    segments.get(4).draw();
    rotateY(-PI/2);
    rotateZ(-PI/2);
  
    fill(200, 200, 0);
  
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    rotateX(segments.get(4).currentRotations[2]);
    translate(0, -50, -50);
    segments.get(5).draw();
    rotateY(PI/2);
    rotateZ(-PI);
  
    fill(50);
  
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    rotateZ(segments.get(5).currentRotations[0]);
    translate(-45, -45, 0);
    segments.get(6).draw();
          
    // next, the end effector
    if (activeEndEffector == ENDEF_SUCTION) {
      rotateY(PI);
      translate(-88, -37, 0);
      eeModelSuction.draw();
    } else if (activeEndEffector == ENDEF_CLAW) {
      rotateY(PI);
      translate(-88, 0, 0);
      eeModelClaw.draw();
      rotateZ(PI/2);
      if (endEffectorStatus == OFF) {
        translate(10, -85, 30);
        eeModelClawPincer.draw();
        translate(55, 0, 0);
        eeModelClawPincer.draw();
      } else if (endEffectorStatus == ON) {
        translate(28, -85, 30);
        eeModelClawPincer.draw();
        translate(20, 0, 0);
        eeModelClawPincer.draw();
      }
    }
  }//end draw arm model
  
  /* Updates the position and orientation of the hit boxes related
   * to the Robot Arm. */
  private void updateBoxes() { 
    noFill();
    stroke(0, 255, 0);
    
    pushMatrix();
    resetMatrix();
    translate(600, 200, 0);

    rotateZ(PI);
    rotateY(PI/2);
    translate(200, 50, 200);
    // Segment 0
    bodyHitBoxes[0].setTransform(getTransformationMatrix());
    
    translate(0, 100, 0);
    bodyHitBoxes[1].setTransform(getTransformationMatrix());
    
    translate(-200, -150, -200);
    
    rotateY(-PI/2);
    rotateZ(-PI);
  
    translate(-50, -166, -358);
    rotateZ(PI);
    translate(150, 0, 150);
    rotateY(segments.get(0).currentRotations[1]);
    translate(10, 95, 0);
    rotateZ(-0.1f * PI);
    // Segment 1
    bodyHitBoxes[2].setTransform(getTransformationMatrix());
    
    rotateZ(0.1f * PI);
    translate(-160, -95, -150);
    rotateZ(-PI);
  
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    rotateX(segments.get(1).currentRotations[2]);
    translate(30, 240, 0);
    // Segment 2
    bodyHitBoxes[3].setTransform(getTransformationMatrix());
    
    translate(-30, -302, -62);
    rotateY(-PI/2);
    rotateZ(-PI);
    
    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    rotateX(segments.get(2).currentRotations[2]);
    translate(75, 0, 0);
    // Segment 3
    bodyHitBoxes[4].setTransform(getTransformationMatrix());
    
    translate(-75, -75, -75);
    rotateY(PI/2);
    rotateZ(-PI);
  
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    rotateY(segments.get(3).currentRotations[0]);
    translate(5, 75, 5);
    // Segment 4
    bodyHitBoxes[5].setTransform(getTransformationMatrix());
    
    translate(0, 295, 0);
    bodyHitBoxes[6].setTransform(getTransformationMatrix());
    
    translate(-75, -370, -75);
    
    rotateY(-PI/2);
    rotateZ(-PI/2);
  
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    rotateX(segments.get(4).currentRotations[2]);
    translate(0, -50, -50);
    // Segment 5
    rotateY(PI/2);
    rotateZ(-PI);
  
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    rotateZ(segments.get(5).currentRotations[0]);
    
    // End Effector
    // Face Plate EE
    translate(0, 0, 10);
    eeHitBoxes[0].get(0).setTransform(getTransformationMatrix());
    translate(0, 0, -10);
    
    // Claw Gripper EE
    float[][] transform = getTransformationMatrix();
    eeHitBoxes[1].get(0).setTransform(transform);
    eeHitBoxes[2].get(0).setTransform(transform);
    eeHitBoxes[3].get(0).setTransform(transform);
    
    translate(-2, 0, -54);
    eeHitBoxes[1].get(1).setTransform(getTransformationMatrix());
    translate(2, 0, 54);
    // The Claw EE has two separate hit box lists: one for the open claw and another for the closed claw
    translate(-2, 27, -54);
    eeHitBoxes[2].get(1).setTransform(getTransformationMatrix());
    translate(0, -54, 0);
    eeHitBoxes[2].get(2).setTransform(getTransformationMatrix());
    translate(2, 27, 54);
    
    // Suction EE
    translate(-2, 0, -66);
    eeHitBoxes[3].get(1).setTransform(getTransformationMatrix());
    translate(0, -52, 21);
    eeHitBoxes[3].get(2).setTransform(getTransformationMatrix());
    translate(2, 52, 35);
    
    translate(-45, -45, 0);
    popMatrix();
  }
  
  /* Returns one of the Arraylists for the End Effector hit boxes depending on the
   * current active End Effector and the status of the End Effector. */
  public ArrayList<Box> currentEEHitBoxList() {
    // Determine which set of hit boxes to display based on the active End Effector
    if (activeEndEffector == ENDEF_CLAW) {
        return (endEffectorStatus == ON) ? eeHitBoxes[1] : eeHitBoxes[2];
    } else if (activeEndEffector == ENDEF_SUCTION) {
      return eeHitBoxes[3];
    }
    
    return eeHitBoxes[0];
  }
  
  /* Changes all the Robot Arm's hit boxes to green */
  public void resetBoxColors() {
    for (Box b : bodyHitBoxes) {
      b.outline = color(0, 255, 0);
    }
    
    ArrayList<Box> eeHB = currentEEHitBoxList();
    
    for (Box b : eeHB) {
      b.outline = color(0, 255, 0);
    }
  }
  
  /* Determine if select pairs of hit boxes of the Robot Arm are colliding */
  public boolean checkSelfCollisions() {
    boolean collision = false;
    
    // Pairs of indices corresponding to two of the Arm body hit boxes, for which to check collisions
    int[] check_pairs = new int[] { 0, 3, 0, 4, 0, 5, 0, 6, 1, 5, 1, 6, 2, 5, 2, 6, 3, 5 };
    
    /* Check select collisions between the body segments of the Arm:
     * The base segment and the four upper arm segments
     * The base rotating segment and lower long arm segment as well as the upper long arm and
     *   upper rotating end segment
     * The second base rotating hit box and the upper long arm segment as well as the upper
     *   rotating end segment
     * The lower long arm segment and the upper rotating end segment
     */
    for (int idx = 0; idx < check_pairs.length - 1; idx += 2) {
      if ( collision3D(bodyHitBoxes[ check_pairs[idx] ], bodyHitBoxes[ check_pairs[idx + 1] ]) ) {
        bodyHitBoxes[ check_pairs[idx] ].outline = color(255, 0, 0);
        bodyHitBoxes[ check_pairs[idx + 1] ].outline = color(255, 0, 0);
        collision = true;
      }
    }
    
    ArrayList<Box> eeHB = currentEEHitBoxList();
    
    // Check collisions between all EE hit boxes and base as well as the first long arm hit boxes
    for (Box hb : eeHB) {
      for (int idx = 0; idx < 4; ++idx) {
        if (collision3D(hb, bodyHitBoxes[idx]) ) {
          hb.outline = color(255, 0, 0);
          bodyHitBoxes[idx].outline = color(255, 0, 0);
          collision = true;
        }
      }
    }
    
    return collision;
  }
  
  /* Determine if the given ojbect is collding with any part of the Robot. */
  public boolean checkObjectCollision(Object obj) {
    Box ohb = (Box)obj.hit_box;
    boolean collision = false;
    
    for (Box b : bodyHitBoxes) {
      if ( collision3D(ohb, b) ) {
        b.outline = color(255, 0, 0);
        collision = true;
      }
    }
    
    ArrayList<Box> eeHBs = currentEEHitBoxList();
    
    for (Box b : eeHBs) {
      // Special case for held objects
      if ( (activeEndEffector != ENDEF_CLAW || activeEndEffector != ENDEF_SUCTION || endEffectorStatus != ON || b != eeHitBoxes[1].get(1) || obj != armModel.held) && collision3D(ohb, b) ) {
        b.outline = color(255, 0, 0);
        collision = true;
      }
    }
    
    return collision;
  }
  
  /* Draws the Robot Arm's hit boxes in the world */
  public void drawBoxes() {
    // Draw hit boxes of the body poriotn of the Robot Arm
    for (Box b : bodyHitBoxes) {
      pushMatrix();
      b.applyTransform();
      b.draw();
      popMatrix();
    }
    
    int eeIdx = 0;
    // Determine which set of hit boxes to display based on the active End Effector
    if (activeEndEffector == ENDEF_CLAW) {
      if (endEffectorStatus == ON) {
        eeIdx = 1;
      } else {
        eeIdx = 2;
      }
    } else if (activeEndEffector == ENDEF_SUCTION) {
      eeIdx = 3;
    }
    // Draw End Effector hit boxes
    for (Box b : eeHitBoxes[eeIdx]) {
      pushMatrix();
      b.applyTransform();
      b.draw();
      popMatrix();
    }
  }
  
  //returns the rotational values for each arm joint
  public float[] getJointRotations() {
    float[] rot = new float[6];
    for (int i = 0; i < segments.size(); i += 1) {
      for (int j = 0; j < 3; j += 1) {
        if (segments.get(i).rotations[j]) {
          rot[i] = segments.get(i).currentRotations[j];
          break;
        }
      }
    }
    return rot;
  }//end get joint rotations
  
  /* Resets the robot's current reference frame to that of the
   * default world frame.
   */
  public void resetFrame(){
    currentFrame[0][0] = 1;
    currentFrame[0][1] = 0;
    currentFrame[0][2] = 0;
    
    currentFrame[1][0] = 0;
    currentFrame[1][1] = 1;
    currentFrame[1][2] = 0;
    
    currentFrame[2][0] = 0;
    currentFrame[2][1] = 0;
    currentFrame[2][2] = 1;
  }
  
  /* Calculate and returns a 3x3 matrix whose columns are the unit vectors of
   * the end effector's current x, y, z axes with respect to the current frame.
   */
  public float[][] getRotationMatrix() {
    pushMatrix();
    resetMatrix();
    // Switch to End Effector reference Frame
    applyModelRotation(armModel, true);
    /* Define vectors { 0, 0, 0 }, { 1, 0, 0 }, { 0, 1, 0 }, and { 0, 0, 1 }
     * Swap vectors:
     *   x' = z
     *   y' = x
     *   z' = y
     */
    PVector origin = new PVector(modelX(0, 0, 0), modelY(0, 0, 0), modelZ(0, 0, 0)),
            x = new PVector(modelX(0, 0, -1), modelY(0, 0, -1), modelZ(0, 0, -1)),
            y = new PVector(modelX(0, 1, 0), modelY(0, 1, 0), modelZ(0, 1, 0)),
            z = new PVector(modelX(1, 0, 0), modelY(1, 0, 0), modelZ(1, 0, 0));
            
    float[][] matrix = new float[3][3];
    // Calcualte Unit Vectors form difference between each axis vector and the origin
  
    matrix[0][0] = x.x - origin.x;
    matrix[0][1] = x.y - origin.y;
    matrix[0][2] = x.z - origin.z;
    matrix[1][0] = y.x - origin.x;
    matrix[1][1] = y.y - origin.y;
    matrix[1][2] = y.z - origin.z;
    matrix[2][0] = z.x - origin.x;
    matrix[2][1] = z.y - origin.y;
    matrix[2][2] = z.z - origin.z;
    
    popMatrix();
    
    return matrix;
  }
  
  /* Calculate and returns a 3x3 matrix whose columns are the unit vectors of
   * the end effector's current x, y, z axes with respect to an arbitrary coordinate
   * system specified by the rotation matrix 'frame.'
   */
  public float[][] getRotationMatrix(float[][] frame){
    float[][] m = getRotationMatrix();
    RealMatrix A = new Array2DRowRealMatrix(floatToDouble(m, 3, 3));
    RealMatrix B = new Array2DRowRealMatrix(floatToDouble(frame, 3, 3));
    RealMatrix AB = A.multiply(B.transpose());
    
    //println(AB);
    
    return doubleToFloat(AB.getData(), 3, 3);
  }
  
  /* Applies the transformation for the current tool frame.
   * NOTE: This method only works in the TOOL or WORLD frame! */
  public void applyToolFrame(int list_idx) {
    // If a tool Frame is active, then it overrides the World Frame
    if (list_idx >= 0 && list_idx < toolFrames.length) {
      
      // Apply a custom tool frame
      PVector tr = toolFrames[list_idx].getOrigin();
      translate(tr.x, tr.y, tr.z);
    } else {
      
      // Apply a default tool frame based on the current EE
      if (activeEndEffector == ENDEF_CLAW) {
        translate(0, 0, -54);
      } else if (activeEndEffector == ENDEF_SUCTION) {
        translate(0, 0, -105);
      }
    }
  }
  
 /* This method calculates the Euler angular rotations: roll, pitch and yaw of the Robot's
  * End Effector in the form of a vector array.
  *
  * @param axesMatrix  A 3x3 matrix containing unti vectors representing the Robot's End
  *                    Effector's x, y, z axes in respect of the World Coordinate Frame;
  * @returning         A array containing the End Effector's roll, pitch, and yaw, in that
  *                    order
  *
  *  Method based off of procedure outlined in the pdf at this location:
  *     http://www.staff.city.ac.uk/~sbbh653/publications/euler.pdf
  *     rotation about: x - psi, y - theta, z - phi
  */
  public PVector getWPR() {
    float[][] m = getRotationMatrix(currentFrame);
    PVector wpr = matrixToEuler(m);
    
    return wpr;
  }
  
  public PVector getWPR(float[] testAngles){
    float[] origAngles = getJointRotations();
    setJointRotations(testAngles);
    
    PVector ret = getWPR();
    setJointRotations(origAngles);
    return ret;
  }
  
  //returns the rotational value of the robot as a quaternion
  public float[] getQuaternion(){
    float[][] m = getRotationMatrix(currentFrame);
    float[] q = matrixToQuat(m);
    
    return q;
  }
  
  public float[] getQuaternion(float[] testAngles){
    float[] origAngles = getJointRotations();
    setJointRotations(testAngles);
    
    float[] ret = getQuaternion();
    setJointRotations(origAngles);
    return ret;
  }
  
  /**
   * Gives the current position of the end effector in
   * Processing native coordinates.
   * @param model Arm model whose end effector position to calculate
   * @param test Determines whether to use arm segments' actual
   *             rotation values or if we're checking trial rotations
   * @return The current end effector position
   */
  public PVector getEEPos() {
    pushMatrix();
    resetMatrix();
    
    translate(600, 200, 0);
    translate(-50, -166, -358); // -115, -213, -413
    rotateZ(PI);
    translate(150, 0, 150);
    
    rotateY(getJointRotations()[0]);
    
    translate(-150, 0, -150);
    rotateZ(-PI);    
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    
    rotateX(getJointRotations()[1]);
    
    translate(0, -62, -62);
    rotateY(-PI/2);
    rotateZ(-PI);   
    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    
    rotateX(getJointRotations()[2]);
    
    translate(0, -75, -75);
    rotateY(PI/2);
    rotateZ(-PI);
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    
    rotateY(getJointRotations()[3]);
    
    translate(-70, 0, -70);
    rotateY(-PI/2);
    rotateZ(-PI/2);    
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    
    rotateX(getJointRotations()[4]);
    
    translate(0, -50, -50);
    rotateY(PI/2);
    rotateZ(-PI);    
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    
    rotateZ(getJointRotations()[5]);
    
    if (curCoordFrame == COORD_TOOL) { applyToolFrame(activeToolFrame); }
    
    PVector ret = new PVector(
      modelX(0, 0, 0),
      modelY(0, 0, 0),
      modelZ(0, 0, 0));
    
    popMatrix();
    return ret;
  } // end calculateEndEffectorPosition
  
  public PVector getEEPos(float[] testAngles) {
    float[] origAngles = getJointRotations();
    setJointRotations(testAngles);
    
    PVector ret = getEEPos();
    setJointRotations(origAngles);
    return ret;
    
  }
  
  //convenience method to set all joint rotation values of the robot arm
  public void setJointRotations(float[] rot){
    for(int i = 0; i < segments.size(); i += 1){
      for(int j = 0; j < 3; j += 1){
        if(segments.get(i).rotations[j]){
          segments.get(i).currentRotations[j] = rot[i];
          segments.get(i).currentRotations[j] %= TWO_PI;
          if(segments.get(i).currentRotations[j] < 0){
            segments.get(i).currentRotations[j] += TWO_PI;
          }
        }
      }
    }
    
    if (COLLISION_DISPLAY) { updateBoxes(); }
  }//end set joint rotations
  
  public boolean interpolateRotation(float speed) {
    boolean done = true;
    for (Model a : segments){
      for (int r = 0; r < 3; r++){
        if (a.rotations[r]){
          if (abs(a.currentRotations[r] - a.targetRotations[r]) > a.rotationSpeed*speed){
            done = false;
            a.currentRotations[r] += a.rotationSpeed * a.rotationDirections[r] * speed;
            a.currentRotations[r] = clampAngle(a.currentRotations[r]);
          }
        }
      } // end loop through rotation axes
    } // end loop through arm segments
    if (COLLISION_DISPLAY) { updateBoxes(); }
    return done;
  } // end interpolate rotation
  
  public void updateOrientation(){
    PVector u = new PVector(0, 0, 0);
    RealMatrix frameInverse = new Array2DRowRealMatrix(floatToDouble(currentFrame, 3, 3));
    frameInverse = MatrixUtils.inverse(frameInverse);
    float theta = DEG_TO_RAD*10*liveSpeed;
    
    //if not in user frame mode
    for(int i = 0; i < 3; i += 1){
      u.x += mvRot[i]*frameInverse.getEntry(i, 0);
      u.y += mvRot[i]*frameInverse.getEntry(i, 1);
      u.z += mvRot[i]*frameInverse.getEntry(i, 2);
    }
    
    if(u.x != 0 || u.y != 0 || u.z != 0){
      //tgtRot = rotateQuat(tgtRot, DEG_TO_RAD, u);
      float[][] tgtMatrix = rotateAxisVector(getRotationMatrix(currentFrame), theta, u.normalize());
      tgtRot = matrixToQuat(tgtMatrix);
    }
  }

  public void executeLiveMotion() {
    if (curCoordFrame == COORD_JOINT) {
      for (int i = 0; i < segments.size(); i += 1) {
        Model model = segments.get(i);
        
        for (int n = 0; n < 3; n++) {
          if (model.rotations[n]) {
            float trialAngle = model.currentRotations[n] +
              model.rotationSpeed * model.jointsMoving[n] * liveSpeed;
              trialAngle = clampAngle(trialAngle);
            
            if (model.anglePermitted(n, trialAngle)) {
              
              float old_angle = model.currentRotations[n];
              model.currentRotations[n] = trialAngle;
              if (COLLISION_DISPLAY) { updateBoxes(); }
              
              if (armModel.checkSelfCollisions()) {
                // end robot arm movement
                model.currentRotations[n] = old_angle;
                updateBoxes();
                model.jointsMoving[n] = 0;
              }
            } 
            else {
              model.jointsMoving[n] = 0;
            }
          }
        }
      }
      updateButtonColors();
    } else {
      //only move if our movement vector is non-zero
      if(mvLinear[0] != 0 || mvLinear[1] != 0 || mvLinear[2] != 0 || 
         mvRot[0] != 0 || mvRot[1] != 0 || mvRot[2] != 0) {
        PVector move = new PVector(mvLinear[0], mvLinear[1], mvLinear[2]);
        //convert to user frame coordinates if currently in a user frame
        if (activeUserFrame >= 0 && activeUserFrame < userFrames.length) {
          PVector[] frame = userFrames[activeUserFrame].axes;
          move.y = -move.y;
          move.z = -move.z;
          move = vectorConvertTo(move, frame[0], frame[1], frame[2]);
        }
        
        float distance = motorSpeed/60.0f * liveSpeed;
        tgtPos.x += move.x * distance;
        tgtPos.y += move.y * distance;
        tgtPos.z += move.z * distance;
        updateOrientation();
        
        //println(lockOrientation);
        int r = calculateIKJacobian(tgtPos, tgtRot);
        if(r == EXEC_FAILURE){
          updateButtonColors();
          mvLinear[0] = 0;
          mvLinear[1] = 0;
          mvLinear[2] = 0;
          mvRot[0] = 0;
          mvRot[1] = 0;
          mvRot[2] = 0;
        }
      }
    }
  } // end execute live motion
  
  public boolean checkAngles(float[] angles) {
    float[] oldAngles = new float[6];
    /* Save the original angles of the Robot and apply the new set of angles */
    for(int i = 0; i < segments.size(); i += 1) {
      for(int j = 0; j < 3; j += 1) {
        if (segments.get(i).rotations[j]) {
          oldAngles[i] = segments.get(i).currentRotations[j];
          segments.get(i).currentRotations[j] = angles[i];
        }
      }
    }
    
    updateBoxes();
    // Check a collision of the Robot with itself
    boolean collision = checkSelfCollisions();
    
    /* Check for a collision between the Robot Arm and any world object as well as an object
     * held by the Robot Arm and any other world object */
    for (Object obj : objects) {
      if (checkObjectCollision(obj) || (held != null && held != obj && held.collision(obj))) {
        collision = true;
      }
    }
    
    if (collision) {
      // Reset the original position in the case of a collision
      setJointRotations(oldAngles);
    }
    
    return collision;
  }
  
  
  /* If an object is currently being held by the Robot arm, then release it */
  public void releaseHeldObject() {
    armModel.held = null;
  }
  
  /* Indicates that the Robot Arm is in Motion */
  public boolean modelInMotion() {
    for (Model m : segments) {
      for (int idx = 0; idx < m.jointsMoving.length; ++idx) {
        if (m.jointsMoving[idx] != 0) {
          return true;
        }
      }
    }
    
    return mvLinear[0] != 0 || mvLinear[1] != 0 || mvLinear[2] != 0 ||
           mvRot[0] != 0 || mvRot[1] != 0 || mvRot[2] != 0;
  }
  
} // end ArmModel class

public void printCurrentModelCoordinates(String msg) {
  print(msg + ": " );
  print(modelX(0, 0, 0) + " ");
  print(modelY(0, 0, 0) + " ");
  print(modelZ(0, 0, 0));
  println();
}

final int MTYPE_JOINT = 0, MTYPE_LINEAR = 1, MTYPE_CIRCULAR = 2;
final int FTYPE_TOOL = 0, FTYPE_USER = 1;
Point[] pr = new Point[1000]; // global registers
Frame[] toolFrames = new Frame[10]; // tool frames
Frame[] userFrames = new Frame[10];


public class Point  {
  public PVector c; // coordinates
  public PVector a; // angles
  public float[] j = new float[6]; // joint values
  
  public Point() {
    c = new PVector(0,0,0);
    a = new PVector(0,0,0);
    for (int n = 0; n < j.length; n++) j[n] = 0;
  }
  
  public Point(float x, float y, float z, float w, float p, float r,
               float j1, float j2, float j3, float j4, float j5, float j6)
  {
    c = new PVector(x,y,z);
    a = new PVector(w,p,r);
    j[0] = j1;
    j[1] = j2;
    j[2] = j3;
    j[3] = j4;
    j[4] = j5;
    j[5] = j6;
  }
  
  public Point clone() {
    return new Point(c.x, c.y, c.z, a.x, a.y, a.z, j[0], j[1], j[2], j[3], j[4], j[5]);
  }
  
  public String toExport(){
     String ret = "<Point> ";
     ret += Float.toString(c.x);
     ret += " ";
     ret += Float.toString(c.y);
     ret += " ";
     ret += Float.toString(c.z);
     ret += " ";
     ret += Float.toString(a.x);
     ret += " ";
     ret += Float.toString(a.y);
     ret += " ";
     ret += Float.toString(a.z);
     ret += " ";
     for (int i=0;i<j.length-1;i++){
        ret += Float.toString(j[i]);
        ret += " ";
     }
     ret += Float.toString(j[j.length-1]);
     ret += " ";
     ret += "</Point>";     
     return ret;
  }
} // end Point class

public class Frame {
  private PVector origin;
  private PVector wpr;
  private PVector[] axes = new PVector[3];
  
  public Frame() {
    origin = new PVector(0,0,0);
    wpr = new PVector(0,0,0);
    for (int n = 0; n < axes.length; n++) axes[n] = new PVector(0,0,0);
  }
  
  /* Used for loading Frames from a file */
  public Frame(PVector origin, PVector wpr, PVector[] axes) {
    this.origin = origin;
    this.wpr = wpr;
    this.axes = new PVector[axes.length];
    
    for (int idx = 0; idx < this.axes.length; ++idx) {
      this.axes[idx] = axes[idx];
     }
  }
  
  public PVector getOrigin() { return origin; }
  public void setOrigin(PVector in) { origin = in; }
  public PVector getWpr() { return wpr; }
  public void setWpr(PVector in) { wpr = in; }
  
  public PVector getAxis(int idx) {
    if (idx >= 0 && idx < axes.length) return axes[idx];
    else return null;
  }
  
  public void setAxis(int idx, PVector in) {
    if (idx >= 0 && idx < axes.length) axes[idx] = in;
    if (idx == 2) wpr = vectorConvertTo(new PVector(1,1,1), axes[0], axes[1], axes[2]);
  }
  
  /* Used for saving the Frame to a file */
  public String toExport() {
    String str = "<Frame>";
    str += " ";
    
    str += Float.toString(origin.x) + " " + Float.toString(origin.y) + " " + Float.toString(origin.z) + " ";
    str += Float.toString(wpr.x) + " " + Float.toString(wpr.y) + " "  + Float.toString(wpr.z) + " ";
    
    for (int idx = 0; idx < axes.length; ++idx) {
      str += Float.toString(axes[idx].x) + " " + Float.toString(axes[idx].y) + " "  + Float.toString(axes[idx].z) + " ";
    }
    
    str+= "</Frame>";
    return str;
  }
} // end Frame class

public class Program  {
  private String name;
  private int nextRegister;
  private Point[] p = new Point[1000]; // local registers
  private ArrayList<Instruction> instructions;
  
  public Program(String theName) {
    instructions = new ArrayList<Instruction>();
    for (int n = 0; n < p.length; n++) p[n] = new Point();
    name = theName;
    nextRegister = 0;
  }
  
  public ArrayList<Instruction> getInstructions() {
    return instructions;
  }
  
  public void setName(String n) { name = n; }
  
  public String getName(){
    return name;
  }
  
  // added by Judy
  public String toExport(){
     String ret = "<Program> ";
     ret += name.replace(' ', '_');
     ret += " ";
     ret += Integer.toString(nextRegister);
     ret += " ";
     for(int i=0; i<1000; i++){
        ret += p[i].toExport();
        ret += " ";
     }
     for(int i=0;i<instructions.size();i++){
        Instruction ins = instructions.get(i);
        if (ins instanceof MotionInstruction){
           MotionInstruction tmp = (MotionInstruction) ins;
           ret += tmp.toExport();
           ret += " ";
        }else if (ins instanceof FrameInstruction){
           FrameInstruction tmp = (FrameInstruction) ins;
           ret += tmp.toExport();
           ret += " ";
        }else if (ins instanceof ToolInstruction){
           ToolInstruction tmp = (ToolInstruction) ins;
           ret += tmp.toExport();
           ret += " ";
        }
     }
     ret += "</Program> ";
     return ret;
  }
  
  public void loadNextRegister(int next){
     nextRegister = next;
  }
  
  public int getRegistersLength(){
     return p.length;
  }
  /**** end ****/
  
  public void addInstruction(Instruction i) {
    instructions.add(i);
    if (i instanceof MotionInstruction ) {
      MotionInstruction castIns = (MotionInstruction)i;
      if (!castIns.getGlobal() && castIns.getRegister() >= nextRegister) {
        nextRegister = castIns.getRegister()+1;
        if (nextRegister >= p.length) nextRegister = p.length-1;
      }
    }
  }
  
  public void overwriteInstruction(int idx, Instruction i) {
    instructions.set(idx, i);
    nextRegister++;
  }
  
  public void addInstruction(int idx, Instruction i) {
    instructions.add(idx, i);
  }
  
  public void addRegister(Point in, int idx) {
    if (idx >= 0 && idx < p.length) p[idx] = in;
  }
  
  public int nextRegister() {
    return nextRegister;
  }
  
  public Point getRegister(int idx) {
    if (idx >= 0 && idx < p.length) return p[idx];
    else return null;
  }
} // end Program class


public int addProgram(Program p) {
  if (p == null) {
    return -1;
  } else {
    int idx = 0;
    
    if (programs.size() < 1) {
       programs.add(p);
     } else {
       while (idx < programs.size() && programs.get(idx).name.compareTo(p.name) < 0) { ++idx; }
       programs.add(idx, p);
     }
    
    return idx;
  }
}

public  class Instruction  {
}


public final class MotionInstruction extends Instruction  {
  private int motionType;
  private int register;
  private boolean globalRegister;
  private float speed;
  private float termination;
  private int userFrame, toolFrame;
  
  public MotionInstruction(int m, int r, boolean g, float s, float t,
                           int uf, int tf)
  {
    motionType = m;
    register = r;
    globalRegister = g;
    speed = s;
    termination = t;
    userFrame = uf;
    toolFrame = tf;
  }
  
  public MotionInstruction(int m, int r, boolean g, float s, float t) {
    motionType = m;
    register = r;
    globalRegister = g;
    speed = s;
    termination = t;
    userFrame = -1;
    toolFrame = -1;
  }
  
  public int getMotionType() { return motionType; }
  public void setMotionType(int in) { motionType = in; }
  public int getRegister() { return register; }
  public void setRegister(int in) { register = in; }
  public boolean getGlobal() { return globalRegister; }
  public void setGlobal(boolean in) { globalRegister = in; }
  public float getSpeed() { return speed; }
  public void setSpeed(float in) { speed = in; }
  public float getTermination() { return termination; }
  public void setTermination(float in) { termination = in; }
  public float getUserFrame() { return userFrame; }
  public void setUserFrame(int in) { userFrame = in; }
  public float getToolFrame() { return toolFrame; }
  public void setToolFrame(int in) { toolFrame = in; }
  
  public float getSpeedForExec(ArmModel model) {
    if (motionType == MTYPE_JOINT) return speed;
    else return (speed / model.motorSpeed);
  }
  
  public Point getVector(Program parent) {
    if (motionType != COORD_JOINT) {
      Point out;
      if (globalRegister) out = pr[register].clone();
      else out = parent.p[register].clone();
      out.c = convertWorldToNative(out.c);
      return out;
    } else {
      Point ret;
      if (globalRegister) ret = pr[register].clone();
      else ret = parent.p[register].clone();
      if (userFrame != -1) {
        PVector[] frame = userFrames[userFrame].axes;
        ret.c = vectorConvertFrom(ret.c, frame[0], frame[1], frame[2]);
      }
      return ret;
    }
  } // end getVector()
  
  public String toString(){
     String me = "";
     switch (motionType){
        case MTYPE_JOINT:
           me += "J ";
           break;
        case MTYPE_LINEAR:
           me += "L ";
           break;
        case MTYPE_CIRCULAR:
           me += "C ";
           break;
     }
     if (globalRegister) me += "PR[";
     else me += "P[";
     me += Integer.toString(register)+"] ";
     if (motionType == MTYPE_JOINT) me += Float.toString(speed * 100) + "%";
     else me += Integer.toString((int)speed) + "mm/s";
     if (termination == 0) me += "FINE";
     else me += "CONT" + (int)(termination*100);
     return me;
  } // end toString()
  
  public String toExport(){
     String ret = "<MotionInstruction> ";
     ret += Integer.toString(motionType);
     ret += " ";
     ret += Integer.toString(register);
     ret += " ";
     ret += Boolean.toString(globalRegister);
     ret += " ";
     ret += Float.toString(speed);
     ret += " ";
     ret += Float.toString(termination);
     ret += " ";
     ret += Integer.toString(userFrame);
     ret += " ";
     ret += Integer.toString(toolFrame);
     ret += " ";
     ret += "</MotionInstruction>";
     return ret;
  }
  
} // end MotionInstruction class



public class FrameInstruction extends Instruction {
  private int frameType;
  private int idx;
  
  public FrameInstruction(int f, int i) {
    frameType = f;
    idx = i;
  }
  
  public void execute() {
    if (frameType == FTYPE_TOOL) activeToolFrame = idx;
    else if (frameType == FTYPE_USER) activeUserFrame = idx;
  }
  
  public String toString() {
    String ret = "";
    if (frameType == FTYPE_TOOL) ret += "UTOOL_NUM=";
    else if (frameType == FTYPE_USER) ret += "UFRAME_NUM=";
    ret += idx+1;
    return ret;
  }
  
  public String toExport(){
     String ret = "<FrameInstruction> ";
     ret += Integer.toString(frameType);
     ret += " ";
     ret += Integer.toString(idx);
     ret += " ";
     ret += "</FrameInstruction>";
     return ret;
  }
} // end FrameInstruction class



public class ToolInstruction extends Instruction {
  private String type;
  private int bracket;
  private int setToolStatus;
  
  public ToolInstruction(String d, int b, int t) {
    type = d;
    bracket = b;
    setToolStatus = t;
  }
  
  public void execute() {
    if ((type.equals("RO") && bracket == 4 && armModel.activeEndEffector == ENDEF_CLAW) ||
        (type.equals("DO") && bracket == 101 && armModel.activeEndEffector == ENDEF_SUCTION))
    {
      
      armModel.endEffectorStatus = setToolStatus;
      
      // Check if the Robot is placing an object or picking up and object
      if (armModel.activeEndEffector == ENDEF_CLAW || armModel.activeEndEffector == ENDEF_SUCTION) {
        
        if (setToolStatus == ON & armModel.held == null) {
          
          PVector ee_pos = armModel.getEEPos();
          
          // Determine if an object in the world can be picked up by the Robot
          for (Object s : objects) {
            
            if (s.collision(ee_pos)) {
              armModel.held = s;
              break;
            }
          }
        } else if (setToolStatus == OFF && armModel.held != null) {
          // Release the object
          armModel.releaseHeldObject();
        }
      }
    }
  }
  
  public String toString() {
    return type + "[" + bracket + "]=" + (setToolStatus == ON ? "ON" : "OFF");
  }
  
  public String toExport(){
     String ret = "<ToolInstruction> ";
     ret += type;
     ret += " ";
     ret += Integer.toString(bracket);
     ret += " ";
     ret += Integer.toString(setToolStatus);
     ret += " ";
     ret += "</ToolInstruction>";
     return ret;
  }
  
} // end ToolInstruction class



public class CoordinateFrame {
  private PVector origin = new PVector();
  private PVector rotation = new PVector();
  
  public PVector getOrigin() { return origin; }
  public void setOrigin(PVector in) { origin = in; }
  public PVector getRotation() { return rotation; }
  public void setRotation(PVector in) { rotation = in; }
} // end FrameInstruction class

public class RecordScreen implements Runnable{
   public RecordScreen(){
     System.out.format("Record screen...\n");
   }
    public void run(){
       try{ 
            // create a timestamp and attach it to the filename
            Calendar calendar = Calendar.getInstance();
            java.util.Date now = calendar.getTime();
            java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());
            String filename = "output_" + currentTimestamp.toString() + ".flv"; 
            filename = filename.replace(' ', '_');
            filename = filename.replace(':', '_');   

            // record screen
            System.out.format("run script to record screen...\n");
            Runtime rt = Runtime.getRuntime();
            Process proc = rt.exec("ffmpeg -f dshow -i " + 
                           "video=\"screen-capture-recorder\":audio=\"Microphone" + 
                           " (Conexant SmartAudio HD)\" " + filename );
            //Process proc = rt.exec(script);
            while(record == ON){
              Thread.sleep(4000);
            }
            rt.exec("taskkill /F /IM ffmpeg.exe"); // close ffmpeg
            System.out.format("finish recording\n");
            
        }catch (Throwable t){
            t.printStackTrace();
        }
        
    }
}



/**
 * This method saves the program state.
 */
public void saveState() {
  try{
       Path p1 = Paths.get(sketchPath("tmp/programs.ser")); 
       Path p2 = Paths.get(sketchPath("tmp/currentProgram.ser"));
       Path p3 = Paths.get(sketchPath("tmp/singleInstruction.ser"));
       Path p4 = Paths.get(sketchPath("tmp/frames"));
       
       println("Path: " + Paths.get(sketchPath("tmp/programs.ser")).toString());
       if (Files.exists(p1)) Files.delete(p1);
       if (Files.exists(p2)) Files.delete(p2);
       if (Files.exists(p3)) Files.delete(p3);
       if (Files.exists(p4)) Files.delete(p4);
      /* 
      out = new FileOutputStream(sketchPath("tmp/currentProgram.ser"));
      if (currentProgram == null){
         String tmp = "null";
         out.write(tmp.getBytes(Charset.forName("UTF-8")));
      }else{
         out.write(currentProgram.toExport().getBytes(Charset.forName("UTF-8")));
      }
      out.close();
      */
      out = new FileOutputStream(sketchPath("tmp/programs.ser"));
      if (programs.size() == 0){
         String tmp = "null";
         out.write(tmp.getBytes(Charset.forName("UTF-8")));
      }else{
         for(int i=0;i<programs.size();i++){
           out.write(programs.get(i).toExport().getBytes(Charset.forName("UTF-8")));
           //String blank = "\n";
           //out.write(blank.getBytes(Charset.forName("UTF-8")));
         }
      }
      out.close();

      /*
      out = new FileOutputStream(sketchPath("tmp/singleInstruction.ser"));
      if (singleInstruction == null ) {
         String tmp = "null";
         out.write(tmp.getBytes(Charset.forName("UTF-8")));
      }else{
         out.write(singleInstruction.toExport().getBytes(Charset.forName("UTF-8")));
      }
      out.close();
      */
      
      // Save the Tool and User Frames to the path /tmp/frames.ser
      out = new FileOutputStream(sketchPath("tmp/frames.ser"));
      
      // Save Tool Frames
      out.write( ("<FrameSet> ").getBytes( Charset.forName("UTF-8") ) );
      String size = toolFrames.length + " ";
      out.write(size.getBytes("UTF-8"));
      
      for (int idx = 0; idx < toolFrames.length; ++idx) {
        println(idx);
        out.write( toolFrames[idx].toExport().getBytes( Charset.forName("UTF-8") ) );
        out.write( (" ").getBytes( Charset.forName("UTF-8") ) );
      }
      
      // Save User Frames
      out.write( ("</FrameSet> <FrameSet> ").getBytes( Charset.forName("UTF-8") ) );
      size = userFrames.length + " ";
      out.write(size.getBytes("UTF-8"));
      
      for (int idx = 0; idx < userFrames.length; ++idx) {
        out.write( userFrames[idx].toExport().getBytes( Charset.forName("UTF-8") ) );
        out.write( (" ").getBytes( Charset.forName("UTF-8") ) );
      }
      
      out.write( ("</FrameSet>").getBytes( Charset.forName("UTF-8") ) );
      out.close();
      
  }catch(IOException e){
     e.printStackTrace();
     println("which class caused the exception? " + e.getClass().toString());
  }
}

// this will automatically called when program starts
/**
 * Load the program state that is previously stored. 
 * @return: 1 if sucess, otherwise return 0;
 */
public int loadState() {
  Path p1 = Paths.get(sketchPath("tmp/programs.ser")); 
  if (!Files.exists(p1)) return 0;
  if(loadPrograms(p1)==0) return 0;
  
  // If loading fails that create all new Frames
  Path p2 = Paths.get(sketchPath("tmp/frames.ser"));
  if (!Files.exists(p2)) {
    
    toolFrames = new Frame[10];
    userFrames = new Frame[10];
    
    for (int n = 0; n < toolFrames.length; ++n) {
      toolFrames[n] = new Frame();
      userFrames[n] = new Frame();
    }
    
    return 0;
  }
  if (loadFrames(p2) == 0) return 0;
  
  return 1;
}

/**
 * This method loads built-in programs and user-defined programs 
 *
 * @PARAM:path - where to find the file that stores program state
 * @return: 1 if success, otherwise 0.
 */
public int loadPrograms(Path path){
   try{
        Scanner s = new Scanner(path);
        while (s.hasNext()){
            Program aProgram;
            String curr = s.next();
            if (curr.equals("null")){
               programs = new ArrayList<Program>();
               s.close();
               return 1;
            }else{
               String name = s.next();
               name = name.replace('_', ' ');
               aProgram = new Program(name);
               int nextRegister = s.nextInt();
               aProgram.loadNextRegister(nextRegister);
               for(int i=0;i<aProgram.getRegistersLength();i++){
                  s.next(); // consume token: <Point>
                  Point p = new Point(s.nextFloat(), s.nextFloat(), s.nextFloat(), s.nextFloat(), s.nextFloat(), s.nextFloat(),
                   s.nextFloat(), s.nextFloat(), s.nextFloat(), s.nextFloat(), s.nextFloat(), s.nextFloat());
                  s.next(); // consume token: </Point> 
                  aProgram.addRegister(p, i);
               }

               while(s.hasNext()){
                  curr = s.next();
                  if (curr.equals("<MotionInstruction>")){
                     // load a motion instruction
                     MotionInstruction instruction = new MotionInstruction(s.nextInt(), s.nextInt(), Boolean.valueOf(s.next()), s.nextFloat(), s.nextFloat(), s.nextInt(), s.nextInt()); //1.0
                     aProgram.addInstruction(instruction);
                     s.next(); // consume token: </MotionInstruction>
                  }else if (curr.equals("<FrameInstruction>")){
                     // load a Frame instruction
                     FrameInstruction instruction = new FrameInstruction(s.nextInt(), s.nextInt());
                     aProgram.addInstruction(instruction);
                     s.next(); // consume token: </FrameInstruction>
                  }else if(curr.equals("<ToolInstruction>")){
                     // load a tool instruction
                     ToolInstruction instruction = new ToolInstruction(s.next(), s.nextInt(), s.nextInt());
                     aProgram.addInstruction(instruction);
                     s.next(); // consume token: </ToolInstruction>
                  }else{ // has scanned </Program>
                     // that's the end of program
                     addProgram(aProgram);
                     break;
                     
                  }
               } // end of while
            } // end of if
            
         } // end of while
        s.close();
        return 1; 
   }catch(IOException e){
        e.printStackTrace();
        //return 0;
   }     
   return 1;
}

/**
 * This method loads all saved Tool and User Frames form /tmp/frames.ser
 * 
 * @param path  the path from which to load the Frames from
 * @return      1 if loading was successful, 0 otherwise
 */
public int loadFrames(Path path) {
  
  try {
    Scanner reader = new Scanner(path);
    // Consume "<FrameSet>"
    reader.next();
    // Read Tool Frame Set length
    toolFrames = new Frame[reader.nextInt()];
   
    String token;
    // Read each Tool Frame one Vector at a time
    for (int idx = 0; idx < toolFrames.length; ++idx) {
      // Consume "<Frame>"
      reader.next();
      
      token = reader.next();
      float x = Float.parseFloat(token);
      token = reader.next();
      float y = Float.parseFloat(token);
      token = reader.next();
      float z = Float.parseFloat(token);
      // Create origin point
      PVector o = new PVector(x, y ,z);
      
      token = reader.next();
      x = Float.parseFloat(token);
      token = reader.next();
      y = Float.parseFloat(token);
      token = reader.next();
      z = Float.parseFloat(token);
      // Create w, p, and r
      PVector wpr = new PVector(x, y ,z);
      
      PVector[] axes = new PVector[3];
      // Create axes points
      for (int a = 0; a < axes.length; ++a) {
        token = reader.next();
        x = Float.parseFloat(token);
        token = reader.next();
        y = Float.parseFloat(token);
        token = reader.next();
        z = Float.parseFloat(token);
        
        axes[a] = new PVector(x, y, z);
      }
      
      toolFrames[idx] = new Frame(o, wpr, axes);
      
      reader.next();
    }
    
    // Consume "</FrameSet>"
    reader.next();
    
    // Consume "<FrameSet>"
    reader.next();
    // Read User Frame Set length
    userFrames = new Frame[reader.nextInt()];
    
    // Read each User Frame one Vector at a time
    for (int idx = 0; idx < toolFrames.length; ++idx) {
      // Consume "<Frame>"
      reader.next();
      
      token = reader.next();
      float x = Float.parseFloat(token);
      token = reader.next();
      float y = Float.parseFloat(token);
      token = reader.next();
      float z = Float.parseFloat(token);
      // Create origin point
      PVector o = new PVector(x, y ,z);
      
      token = reader.next();
      x = Float.parseFloat(token);
      token = reader.next();
      y = Float.parseFloat(token);
      token = reader.next();
      z = Float.parseFloat(token);
      // Create w, p, and r
      PVector wpr = new PVector(x, y ,z);
      
      PVector[] axes = new PVector[3];
      // Create axes points
      for (int a = 0; a < axes.length; ++a) {
        token = reader.next();
        x = Float.parseFloat(token);
        token = reader.next();
        y = Float.parseFloat(token);
        token = reader.next();
        z = Float.parseFloat(token);
        
        axes[a] = new PVector(x, y, z);
      }
      
      userFrames[idx] = new Frame(o, wpr, axes);
      
      reader.next();
    }
    
    // Consume "</FrameSet>"
    reader.next();
    
    reader.close();
    
  } catch (IOException IOEx) {
    IOEx.printStackTrace();
    return 0;
  }
  
  return 1;
}
/**
 * A dynamic scrollbar object that allows for the scrolling of a text area, whose contents are stored in 2D ArrayList.
 *
 * TODO: add textarea data (x, y, length, height)
 *
 * 12 April 2016
 */
public class Scrollbar {
  // The position of the top-left corner of the scroll bar
  public float pos_x, pos_y,
               // The length and height of the scrolbar
               s_len, s_height;
  // The current position of the slider on the scroll bar
  private float slider_pos_y;
  // If the scroll bar is selected by the mouse
  public boolean focus;
  // The normal coloring of the scroll bar
  private int n_outline, n_fill,
  // The color of the scroll bar when selected by the mouse
                h_outline, h_fill;
  
  /* Creates a scroll bar */
  public Scrollbar() {
    pos_x = 0;
    pos_y = 0;
    slider_pos_y = pos_y;
    s_len = 5;
    s_height = 25;
    
    focus = false;
    // default colors
    n_outline = color(0, 0, 0);
    n_fill = color(255, 255, 255);
    h_outline = color(255, 255, 255);
    h_fill = color(0, 0, 0);
  }
  
  /* Set the position of the scroll bar's top-left corner */
  public void setPosition(float x, float y) {
    pos_x = x;
    pos_y = y;
    // Keep the slider within the bounds of the scroll bar
    slider_pos_y = max( pos_y, min( (pos_y + s_height - 1), slider_pos_y ) );
  }
  
  /* Define the scroll bar's length and height */
  public void setDim(float len, float hgt) {
    s_len = len;
    s_height = hgt;
    // Keep the slider within the bounds of the scroll bar
    slider_pos_y = max( pos_y, min( (pos_y + s_height - 1), slider_pos_y ) );
  }
  
  /**
   * Define the color scheme for the scroll bar's normal coloring and
   * highlighted coloring.
   *
   * @param n_o  the normal outline color of the scroll bar
   * @param n_f  the normal fill color of the scroll bar
   * @param h_o  the highlighted outline color of the scroll bar
   * @param h_F  the highlighted fill color of the scroll bar
   */
  public void setColorScheme(int n_o, int n_f, int h_o, int h_f) {
    // normal
    n_outline = n_o;
    n_fill = n_f;
    // highlighted
    h_outline = h_o;
    h_fill = h_f;
  }
  
  /* Update the current position of the scroll bar's slider. */
  public void update() {
    if (focus) {
      
      slider_pos_y = mouseY;
      // Keep the slider within the bounds of the scroll bar
      slider_pos_y = max( pos_y, min( (pos_y + s_height - 1), slider_pos_y ) );
      
      updateScreen(color(255,0,0), color(0,0,0));
    }
  }
  
  public void checkMousePosition(int mx, int my) {
    focus = mouseX >= pos_x && mouseX <= (pos_x + s_len) && mouseY >= slider_pos_y && mouseY <= (slider_pos_y + s_len);
  }
  
  /* Draw the scrollbar on the screen */
  public void draw() {
    // Draw midline of the scroll bar
    stroke(n_outline);
    line(pos_x + (s_len / 2), pos_y + (s_len / 2), pos_x + (s_len / 2), pos_y + s_height);
    // Draw slider
    stroke( (focus) ? h_outline : n_outline );
    fill( (focus) ? h_fill : n_fill );
    rect(pos_x, slider_pos_y, s_len, s_len);
  }
  
  /* Given the size of the list of contents to display and the maximum
   * number of lines that can appear on the screen at one time, compute
   * the index of the element that should appear at the top of the
   * window.
   * 
   * @param size         the total number of line elements for the
   *                     given window
   * @param display-cap  the maximum number of elements that can
   *                     appear on the screen at one time
   * @return             The index of the first element to display on
   *                     the screen
   */
  public int slider_ratio(int size, int display_cap) {
    if (size < display_cap) {
      // Number of elements display is less than the display cap
      return 0;
    } else {
      return (int)( ((slider_pos_y - pos_y) / (s_height - 1)) * (size - display_cap) );
    }
  }
  
  /* Increment the position of the slider based on a float value: utilized by
   * the mouse's scroll wheel.
   *
   * @param value  the amount to add to the slider's current position on the
   *               scroll bar
   */
  public void increment_slider(float value) {
    slider_pos_y += value;
    // Keep the slider within the bounds of the scroll bar
    slider_pos_y = max( pos_y, min( (pos_y + s_height - 1), slider_pos_y ) );
  }
}
/**
 * A basic definition of a shape in processing that has a fill and outline color.
 */
public abstract class Shape {
  protected int fill;
  protected int outline;
  protected final boolean no_fill;
  
  /* Create a shpae with the given outline/fill colors */
  public Shape(int f, int o) {
    fill = f;
    outline = o;
    no_fill = false;
  }
  
  /* Creates a shape with no fill */
  public Shape(int o) {
    outline = o;
    no_fill = true;
  } 
  
  /* Returns the x, y, z values of the shape's center point */
  public abstract float[] position();
  
  /* Applies necessary rotations and translations to convert the Native cooridinate
   * system into the cooridnate system relative to the center of the Shape */
  public abstract void applyTransform();
  
  /* Define the transformation matrix for the coordinate system of the shape */
  public abstract void setTransform(float[][] tMatrix);
  
  /* Returns the Homogeneous Coordinate Matrix repesenting the conversion from
   * the object's coordinate frame to the Native coordinate frame */
  public abstract float[][] getTransform();
  
  /* Returns a 3x3 matrix, whose rows contain the x, y, z axes of the Shape's relative
   * coordinate frame in native coordinates */
  public abstract float[][] getRelativeAxes();
  
  /* Define how a shape is drawn in the window */
  public abstract void draw();
}

/**
 * A shape that resembles a cube or rectangle
 */
public class Box extends Shape {
  public final PVector dimensions;
  public float[][] transform;
  
  /* Create a normal box */
  public Box(float wdh, float hgt, float dph, int f, int o) {
    super(f, o);
    
    transform = getTransformationMatrix();
    dimensions = new PVector(wdh, hgt, dph);
  }
  
  /* Create an empty box */
  public Box(float wdh, float hgt, float dph, int o) {
    super(o);
    
    transform = getTransformationMatrix();
    dimensions = new PVector(wdh, hgt, dph);
  }
  
  public float[] position() {
    pushMatrix();
    resetMatrix();
    applyTransform();
    float[] origin = new float[] { modelX(0, 0, 0), modelY(0, 0, 0), modelZ(0, 0, 0) };
    popMatrix();
    
    return origin;
  }
  
  /* This method modifies the transform matrix! */
  public void applyTransform() {
    applyMatrix(transform[0][0], transform[0][1], transform[0][2], transform[0][3],
                transform[1][0], transform[1][1], transform[1][2], transform[1][3],
                transform[2][0], transform[2][1], transform[2][2], transform[2][3],
                transform[3][0], transform[3][1], transform[3][2], transform[3][3]);
  }
  
  public void setTransform(float[][] tMatrix) { transform = tMatrix.clone(); }
  
  public float[][] getTransform() {return transform.clone(); }
  
  public void draw() {
    stroke(outline);
    
    if (no_fill) {
      noFill();
    } else {
      fill(fill);
    }
    
    box(dimensions.x, dimensions.y, dimensions.z);
  }
  
  public float[][] getRelativeAxes() {
    float[][] Axes = new float[3][3];
    
    for(int r = 0; r < Axes[0].length; ++r) {
      for(int c = 0; c < Axes.length; ++c) {
        Axes[c][r] = transform[r][c];
      }
    }
    
    return Axes;
  }
  
  /* Returns the dimension of the box corresponding to the
   * axes index given; the axi indices are as follows:
   * 
   * 0 -> x
   * 1 -> y
   * 2 -> z
   */
  public float getDim(int axes) {
    
    switch (axes) {
      case 0:   return dimensions.x;
      case 1:   return dimensions.y;
      case 2:   return dimensions.z;
      default:  return -1f;
    }
  }
  
  /* Check if the given point is within the dimensions of the box */
  public boolean within(PVector pos) {
    
    boolean is_inside = pos.x >= -(dimensions.x / 2f) && pos.x <= (dimensions.x / 2f)
                     && pos.y >= -(dimensions.y / 2f) && pos.y <= (dimensions.y / 2f)
                     && pos.z >= -(dimensions.z / 2f) && pos.z <= (dimensions.z / 2f);
    
    return is_inside;
  }
}

public class Object {
  // The actual object
  public final Shape form;
  // The area around an object used for collision handling
  public final Shape hit_box;
  
  public Object(float wdh, float hgt, float dph, int f, int o) {
    form = new Box(wdh, hgt, dph, f, o);
    // green outline for hitboxes
    hit_box = new Box(wdh + 20f, hgt + 20f, dph + 20f, color(0, 255, 0));
  }
  
  public void draw() {
    pushMatrix();
    
    form.applyTransform();
    
    noFill();
    stroke(255, 0, 0);
    //line(5000, 0, 0, -5000, 0, 0);
    stroke(0, 255, 0);
    //line(0, 5000, 0, 0, -5000, 0);
    stroke(0, 0, 255);
    //line(0, 0, 5000, 0, 0, -5000);
    
    form.draw();
    if (COLLISION_DISPLAY) { hit_box.draw(); }
    
    popMatrix();
  }
  
  public boolean collision(PVector pos) {
    // Convert the point to the current reference frame
    pos = transform(pos, invertHCMatrix(hit_box.getTransform()));
    
    return ((Box)hit_box).within(pos);
  }
  
  /* Determines if the collider boxes of this object
   * and the given object intersect. */
  public boolean collision(Object obj) {
    Box A = (Box)hit_box;
    Box B = (Box)obj.hit_box;
    
    return collision3D(A, B);
  }
}

/*
 * This algorithm uses the Separating Axis Theorm to project radi of each Box on to several 
 * axes to determine if a there is any overlap between the boxes. The method strongy resembles 
 * the method outlined in Section 4.4 of "Real Time Collision Detection" by Christer Ericson
 */
public boolean collision3D(Box A, Box B) {
  // Rows are x, y, z axis vectors for A and B: Ax, Ay, Az, Bx, By, and Bz
  float[][] axes_A = A.getRelativeAxes();
  float[][] axes_B = B.getRelativeAxes();
  
  // Rotation matrices to convert B into A's coordinate system
  float[][] rotMatrix = new float[3][3];
  float[][] absRotMatrix = new float[3][3];
  
  for(int v = 0; v < axes_A.length; v += 1){
    for (int u = 0; u < axes_B.length; u += 1) {
      // PLEASE do not change to matrix mutliplication
      rotMatrix[v][u] = axes_A[v][0] * axes_B[u][0] +  axes_A[v][1] * axes_B[u][1] +  axes_A[v][2] * axes_B[u][2];
      // Add offset for valeus close to zero (parallel axes)
      absRotMatrix[v][u] = abs(rotMatrix[v][u]) + 0.00000000175f;
    }
  }
  
  // T = B's position - A's
  PVector posA = new PVector().set(A.position());
  PVector posB = new PVector().set(B.position());
  PVector limbo = posB.sub(posA);
  // Convert T into A's coordinate frame
  float[] T = new float[] { limbo.dot(new PVector().set(axes_A[0])), 
                            limbo.dot(new PVector().set(axes_A[1])), 
                            limbo.dot(new PVector().set(axes_A[2])) };
  
  float radiA, radiB;
  
  for(int idx = 0; idx < absRotMatrix.length; ++idx){
    radiA = (A.getDim(idx) / 2);
    radiB = (B.getDim(0) / 2) * absRotMatrix[idx][0] + 
            (B.getDim(1) / 2) * absRotMatrix[idx][1] + 
            (B.getDim(2) / 2) * absRotMatrix[idx][2];
    
    // Check Ax, Ay, and Az
    if (abs(T[idx]) > (radiA + radiB)) { return false; }
  }
  
  for(int idx = 0; idx < absRotMatrix[0].length; ++idx){
    radiA = (A.getDim(0) / 2) * absRotMatrix[0][idx] + 
            (A.getDim(1) / 2) * absRotMatrix[1][idx] + 
            (A.getDim(2) / 2) * absRotMatrix[2][idx];
    radiB = (B.getDim(idx) / 2);
    
    float check = abs(T[0]*rotMatrix[0][idx] + 
                      T[1]*rotMatrix[1][idx] + 
                      T[2]*rotMatrix[2][idx]);
    
    // Check Bx, By, and Bz
    if(check > (radiA + radiB)) { return false; }
  }
    
  radiA = (A.getDim(1) / 2) * absRotMatrix[2][0] + (A.getDim(2) / 2) * absRotMatrix[1][0];
  radiB = (B.getDim(1) / 2) * absRotMatrix[0][2] + (B.getDim(2) / 2) * absRotMatrix[0][1];
  // Check axes Ax x Bx
  if(abs(T[2] * rotMatrix[1][0] - T[1] * rotMatrix[2][0]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(1) / 2) * absRotMatrix[2][1] + (A.getDim(2) / 2) * absRotMatrix[1][1];
  radiB = (B.getDim(0) / 2) * absRotMatrix[0][2] + (B.getDim(2) / 2) * absRotMatrix[0][0];
  // Check axes Ax x By
  if(abs(T[2] * rotMatrix[1][1] - T[1] * rotMatrix[2][1]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(1) / 2) * absRotMatrix[2][2] + (A.getDim(2) / 2) * absRotMatrix[1][2];
  radiB = (B.getDim(0) / 2) * absRotMatrix[0][1] + (B.getDim(1) / 2) * absRotMatrix[0][0];
  // Check axes Ax x Bz
  if(abs(T[2] * rotMatrix[1][2] - T[1] * rotMatrix[2][2]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[2][0] + (A.getDim(2) / 2) * absRotMatrix[0][0];
  radiB = (B.getDim(1) / 2) * absRotMatrix[1][2] + (B.getDim(2) / 2) * absRotMatrix[1][1];
  // Check axes Ay x Bx
  if(abs(T[0] * rotMatrix[2][0] - T[2] * rotMatrix[0][0]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[2][1] + (A.getDim(2) / 2) * absRotMatrix[0][1];
  radiB = (B.getDim(0) / 2) * absRotMatrix[1][2] + (B.getDim(2) / 2) * absRotMatrix[1][0];
  // Check axes Ay x By
  if(abs(T[0] * rotMatrix[2][1] - T[2] * rotMatrix[0][1]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[2][2] + (A.getDim(2) / 2) * absRotMatrix[0][2];
  radiB = (B.getDim(0) / 2) * absRotMatrix[1][1] + (B.getDim(1) / 2) * absRotMatrix[1][0];
  // Check axes Ay x Bz
  if(abs(T[0] * rotMatrix[2][2] - T[2] * rotMatrix[0][2]) > (radiA + radiB)) { return false; }
  
  
  radiA = (A.getDim(0) / 2) * absRotMatrix[1][0] + (A.getDim(1) / 2) * absRotMatrix[0][0];
  radiB = (B.getDim(1) / 2) * absRotMatrix[2][2] + (B.getDim(2) / 2) * absRotMatrix[2][1];
  // Check axes Az x Bx
  if(abs(T[1] * rotMatrix[0][0] - T[0] * rotMatrix[1][0]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(0) / 2) * absRotMatrix[1][1] + (A.getDim(1) / 2) * absRotMatrix[0][1];
  radiB = (B.getDim(0) / 2) * absRotMatrix[2][2] + (B.getDim(2) / 2) * absRotMatrix[2][0];
  // Check axes Az x By
  if(abs(T[1] * rotMatrix[0][1] - T[0] * rotMatrix[1][1]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[1][2] + (A.getDim(1) / 2) * absRotMatrix[0][2];
  radiB = (B.getDim(0) / 2) * absRotMatrix[2][1] + (B.getDim(1) / 2) * absRotMatrix[2][0];
  // Check axes Az x Bz
  if(abs(T[1] * rotMatrix[0][2] - T[0] * rotMatrix[1][2]) > (radiA + radiB)) { return false; }
    
  return true;
}
  public void settings() {  size(1200, 800, P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "RobotRun" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
