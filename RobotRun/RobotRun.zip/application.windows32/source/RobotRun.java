import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import org.apache.commons.math3.linear.*; 
import java.util.*; 
import java.util.regex.Pattern; 
import java.nio.*; 
import java.nio.file.*; 
import java.io.*; 
import java.awt.event.KeyEvent; 
import java.util.concurrent.ArrayBlockingQueue; 

import org.apache.commons.math3.ml.neuralnet.*; 
import org.apache.commons.math3.ml.neuralnet.twod.*; 
import org.apache.commons.math3.ml.neuralnet.twod.util.*; 
import org.apache.commons.math3.ml.neuralnet.oned.*; 
import org.apache.commons.math3.ml.neuralnet.sofm.*; 
import org.apache.commons.math3.ml.neuralnet.sofm.util.*; 
import org.apache.commons.math3.ml.clustering.*; 
import org.apache.commons.math3.ml.clustering.evaluation.*; 
import org.apache.commons.math3.ml.distance.*; 
import org.apache.commons.math3.analysis.*; 
import org.apache.commons.math3.analysis.differentiation.*; 
import org.apache.commons.math3.analysis.integration.*; 
import org.apache.commons.math3.analysis.integration.gauss.*; 
import org.apache.commons.math3.analysis.function.*; 
import org.apache.commons.math3.analysis.polynomials.*; 
import org.apache.commons.math3.analysis.solvers.*; 
import org.apache.commons.math3.analysis.interpolation.*; 
import org.apache.commons.math3.stat.interval.*; 
import org.apache.commons.math3.stat.ranking.*; 
import org.apache.commons.math3.stat.clustering.*; 
import org.apache.commons.math3.stat.*; 
import org.apache.commons.math3.stat.inference.*; 
import org.apache.commons.math3.stat.correlation.*; 
import org.apache.commons.math3.stat.descriptive.*; 
import org.apache.commons.math3.stat.descriptive.rank.*; 
import org.apache.commons.math3.stat.descriptive.summary.*; 
import org.apache.commons.math3.stat.descriptive.moment.*; 
import org.apache.commons.math3.stat.regression.*; 
import org.apache.commons.math3.linear.*; 
import org.apache.commons.math3.*; 
import org.apache.commons.math3.distribution.*; 
import org.apache.commons.math3.distribution.fitting.*; 
import org.apache.commons.math3.complex.*; 
import org.apache.commons.math3.ode.*; 
import org.apache.commons.math3.ode.nonstiff.*; 
import org.apache.commons.math3.ode.events.*; 
import org.apache.commons.math3.ode.sampling.*; 
import org.apache.commons.math3.random.*; 
import org.apache.commons.math3.primes.*; 
import org.apache.commons.math3.optim.*; 
import org.apache.commons.math3.optim.linear.*; 
import org.apache.commons.math3.optim.nonlinear.vector.*; 
import org.apache.commons.math3.optim.nonlinear.vector.jacobian.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.gradient.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.noderiv.*; 
import org.apache.commons.math3.optim.univariate.*; 
import org.apache.commons.math3.exception.*; 
import org.apache.commons.math3.exception.util.*; 
import org.apache.commons.math3.fitting.leastsquares.*; 
import org.apache.commons.math3.fitting.*; 
import org.apache.commons.math3.dfp.*; 
import org.apache.commons.math3.fraction.*; 
import org.apache.commons.math3.special.*; 
import org.apache.commons.math3.geometry.*; 
import org.apache.commons.math3.geometry.hull.*; 
import org.apache.commons.math3.geometry.enclosing.*; 
import org.apache.commons.math3.geometry.spherical.twod.*; 
import org.apache.commons.math3.geometry.spherical.oned.*; 
import org.apache.commons.math3.geometry.euclidean.threed.*; 
import org.apache.commons.math3.geometry.euclidean.twod.*; 
import org.apache.commons.math3.geometry.euclidean.twod.hull.*; 
import org.apache.commons.math3.geometry.euclidean.oned.*; 
import org.apache.commons.math3.geometry.partitioning.*; 
import org.apache.commons.math3.geometry.partitioning.utilities.*; 
import org.apache.commons.math3.optimization.*; 
import org.apache.commons.math3.optimization.linear.*; 
import org.apache.commons.math3.optimization.direct.*; 
import org.apache.commons.math3.optimization.fitting.*; 
import org.apache.commons.math3.optimization.univariate.*; 
import org.apache.commons.math3.optimization.general.*; 
import org.apache.commons.math3.util.*; 
import org.apache.commons.math3.genetics.*; 
import org.apache.commons.math3.transform.*; 
import org.apache.commons.math3.filter.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class RobotRun extends PApplet {











private static final int OFF = 0, ON = 1;
PFont fnt_con14, fnt_con12, fnt_conB;

private Camera camera;
// The position at which the Robot is drawn
private final PVector ROBOT_POSITION = new PVector(200, 300, 200);
ArmModel armModel;

ControlP5 cp5;
WindowManager manager;
Stack<Screen> display_stack;

ArrayList<Program> programs = new ArrayList<Program>();

/*******************************/
/*      Global Variables       */
/*******************************/

// for Execution
public boolean execSingleInst = false; 
public boolean robotFault = false; //indicates robot error
int EXEC_SUCCESS = 0, EXEC_FAILURE = 1, EXEC_PARTIAL = 2;

/*******************************/
/*      Debugging Stuff        */
/*******************************/

private ArrayList<String> buffer;
private Point displayPoint;


public void setup() {
  //size(1200, 800, P3D);
  
  
  //create font and text display background
  fnt_con14 = createFont("data/Consolas.ttf", 14);
  fnt_con12 = createFont("data/Consolas.ttf", 12);
  fnt_conB = createFont("data/ConsolasBold.ttf", 12);
  
  camera = new Camera();
  
  //load model and save data
  armModel = new ArmModel();
  intermediatePositions = new ArrayList<Point>();
  activeScenario = null;
  
  loadState();
  
  //set up UI
  cp5 = new ControlP5(this);
  // Expllicitly draw the ControlP5 elements
  cp5.setAutoDraw(false);
  manager = new WindowManager(cp5, fnt_con12, fnt_con14);
  display_stack = new Stack<Screen>();
  gui();
  
  buffer = new ArrayList<String>();
  displayPoint = null;
}

public void draw() {
  // Apply the camera for drawing objects
  directionalLight(255, 255, 255, 1, 1, 0);
  ambientLight(150, 150, 150);

  background(127);
  
  hint(ENABLE_DEPTH_TEST);
  background(255);
  noStroke();
  noFill();
  
  pushMatrix();
  camera.apply();
  
  Program p = activeProgram();
  
  updateAndDrawObjects(activeScenario, p, armModel);
  displayAxes();
  displayTeachPoints();
  
  WorldObject wldObj = manager.getActiveWorldObject();
  
  if (wldObj != null) {
    pushMatrix();
    
    if (wldObj instanceof Part) {
      Fixture reference = ((Part)wldObj).getFixtureRef();
      
      if (reference != null) {
        // Draw part's orientation with reference to its fixture
        reference.applyCoordinateSystem();
      }
    }
    
    displayOriginAxes(wldObj.getLocalCenter(), wldObj.getLocalOrientationAxes(), 500f, color(0));
    
    popMatrix();
  }
  
  if (displayPoint != null) {
    // Display the point with its local orientation axes
    displayOriginAxes(displayPoint.position, quatToMatrix(displayPoint.orientation), 100f, color(0, 100, 15));
  }
  
  //TESTING CODE: DRAW INTERMEDIATE POINTS
  noLights();
  noStroke();
  pushMatrix();
  //if(intermediatePositions != null) {
  //  int count = 0;
  //  for(Point pt : intermediatePositions) {
  //    if(count % 20 == 0) {
  //      pushMatrix();
  //      stroke(0);
  //      translate(pt.position.x, pt.position.y, pt.position.z);
  //      sphere(5);
  //      popMatrix();
  //    }
  //    count += 1;
  //  }
  //}
  popMatrix();
  popMatrix();
  
  hint(DISABLE_DEPTH_TEST);
  // Apply the camera for drawing text and windows
  ortho();
  showMainDisplayText();
  cp5.draw();
  //println(frameRate + " fps");
}

/*****************************************************************************************************************
 NOTE: All the below methods assume that current matrix has the camrea applied!
 *****************************************************************************************************************/

/**
 * Updates the position and orientation of the Robot as well as all the World
 * Objects associated with the current scenario. Updates the bounding box color,
 * position and oientation of the Robot and all World Objects as well. Finally,
 * all the World Objects and the Robot are drawn.
 * 
 * @param s       The currently active scenario
 * @param active  The currently selected program
 * @param model   The Robot Arm model
 */
public void updateAndDrawObjects(Scenario s, Program active, ArmModel model) {
  model.updateRobot(active);
  
  if (s != null) {
    s.resetObjectHitBoxColors();
  }
  
  model.resetOBBColors(); 
  model.checkSelfCollisions();
  
  if (s != null) {
    s.updateAndDrawObjects(model);
  }
  model.draw();
  
  model.updatePreviousEEOrientation();
}

/**
 * Display any currently taught points during the processes of either the 3-Point, 4-Point, or 6-Point Methods.
 */
public void displayTeachPoints() {
  // Teach points are displayed only while the Robot is being taught a frame
  if(teachFrame != null && mode.getType() == ScreenType.TYPE_TEACH_POINTS) {
    
    int size = 3;

    if (mode == Screen.TEACH_6PT && teachFrame instanceof ToolFrame) {
      size = 6;
    } else if (mode == Screen.TEACH_4PT && teachFrame instanceof UserFrame) {
      size = 4;
    }
    
    for (int idx = 0; idx < size; ++idx) {
      Point pt = teachFrame.getPoint(idx);
      
      if (pt != null) {
        pushMatrix();
        // Applies the point's position
        translate(pt.position.x, pt.position.y, pt.position.z);
        
        // Draw color-coded sphere for the point
        noFill();
        int pointColor = color(255, 0, 255);
        
        if (teachFrame instanceof ToolFrame) {
          
          if (idx < 3) {
            // TCP teach points
            pointColor = color(130, 130, 130);
          } else if (idx == 3) {
            // Orient origin point
            pointColor = color(255, 130, 0);
          } else if (idx == 4) {
            // Axes X-Direction point
            pointColor = color(255, 0, 0);
          } else if (idx == 5) {
            // Axes Y-Diretion point
            pointColor = color(0, 255, 0);
          }
        } else if (teachFrame instanceof UserFrame) {
          
          if (idx == 0) {
            // Orient origin point
            pointColor = color(255, 130, 0);
          } else if (idx == 1) {
            // Axes X-Diretion point
            pointColor = color(255, 0, 0);
          } else if (idx == 2) {
            // Axes Y-Diretion point
            pointColor = color(0, 255, 0);
          } else if (idx == 3) {
            // Axes Origin point
            pointColor = color(0, 0, 255);
          }
        }
        
        stroke(pointColor);
        sphere(3);
        
        popMatrix();
      }
    }
  }
}

/**
 * Displays coordinate frame associated with the current Coordinate frame. The active User frame is displayed in the User and Tool
 * Coordinate Frames. The World frame is display in the World Coordinate frame and the Tool Coordinate Frame in the case that no
 * active User frame is set. The active Tool frame axes are displayed in the Tool frame in addition to the current User (or World)
 * frame. Nothing is displayed in the Joint Coordinate Frame.
 */
public void displayAxes() {
  
  Point eePoint = nativeRobotEEPoint(armModel.getJointAngles());
  
  if (axesState == AxesDisplay.NONE && curCoordFrame != CoordFrame.JOINT) {
    // Draw axes of the Robot's End Effector frame for testing purposes
    displayOriginAxes(eePoint.position, quatToMatrix( eePoint.orientation ), 200f, color(255, 0, 255));
    
  } else if (axesState == AxesDisplay.AXES) {
    // Display axes
    if (curCoordFrame != CoordFrame.JOINT) {
      Frame activeTool = getActiveFrame(CoordFrame.TOOL),
            activeUser = getActiveFrame(CoordFrame.USER);
      
      if (curCoordFrame == CoordFrame.TOOL) {
        /* Draw the axes of the active Tool frame at the Robot End Effector */
        displayOriginAxes(eePoint.position, activeTool.getWorldAxisVectors(), 200f, color(255, 0, 255));
        
      } else {
        // Draw axes of the Robot's End Effector frame for testing purposes
        displayOriginAxes(eePoint.position, quatToMatrix( eePoint.orientation ), 200f, color(255, 0, 255));
      }
      
      if(curCoordFrame != CoordFrame.WORLD && activeUser != null) {
        /* Draw the axes of the active User frame */
        displayOriginAxes(activeUser.getOrigin(), activeUser.getWorldAxisVectors(), 10000f, color(0));
        
      } else {
        /* Draw the axes of the World frame */
        displayOriginAxes(new PVector(0f, 0f, 0f), WORLD_AXES, 10000f, color(0));
      }
    }
    
  } else if (axesState == AxesDisplay.GRID) {
    // Display gridlines spanning from axes of the current frame
    Frame active;
    float[][] displayAxes;
    PVector displayOrigin;
    
    switch(curCoordFrame) {
      case JOINT:
      case WORLD:
        displayAxes = new float[][] { {1f, 0f, 0f}, {0f, 1f, 0f}, {0f, 0f, 1f} };
        displayOrigin = new PVector(0f, 0f, 0f);
        break;
      case TOOL:
        active = getActiveFrame(CoordFrame.TOOL);
        displayAxes = active.getNativeAxisVectors();
        displayOrigin = eePoint.position;
        break;
      case USER:
        active = getActiveFrame(CoordFrame.USER);
        displayAxes = active.getNativeAxisVectors();
        displayOrigin = active.getOrigin();
        break;
      default:
        // No gridlines are displayed in the Joint Coordinate Frame
        return;
    }
    
    // Draw grid lines every 100 units, from -3500 to 3500, in the x and y plane, on the floor plane
    displayGridlines(displayAxes, displayOrigin, 35, 100);
  }
}

/**
 * Given a set of 3 orthogonal unit vectors a point in space, lines are
 * drawn for each of the three vectors, which intersect at the origin point.
 *
 * @param origin       A point in space representing the intersection of the
 *                     three unit vectors
 * @param axesVectors  A set of three orthogonal unti vectors
 * @param axesLength   The length, to which the all axes, will be drawn
 * @param originColor  The color of the point to draw at the origin
 */
public void displayOriginAxes(PVector origin, float[][] axesVectors, float axesLength, int originColor) {
  
  pushMatrix();    
  // Transform to the reference frame defined by the axes vectors
  applyMatrix(axesVectors[0][0], axesVectors[1][0], axesVectors[2][0], origin.x,
              axesVectors[0][1], axesVectors[1][1], axesVectors[2][1], origin.y,
              axesVectors[0][2], axesVectors[1][2], axesVectors[2][2], origin.z,
              0, 0, 0, 1);
  
  // X axis
  stroke(255, 0, 0);
  line(-axesLength, 0, 0, axesLength, 0, 0);
  // Y axis
  stroke(0, 255, 0);
  line(0, -axesLength, 0, 0, axesLength, 0);
  // Z axis
  stroke(0, 0, 255);
  line(0, 0, -axesLength, 0, 0, axesLength);
  
  // Draw a sphere on the positive direction for each axis
  stroke(originColor);
  sphere(4);
  stroke(0);
  translate(100, 0, 0);
  sphere(4);
  translate(-100, 100, 0);
  sphere(4);
  translate(0, -100, 100);
  sphere(4);
  
  popMatrix();
}

/**
 * Gridlines are drawn, spanning from two of the three axes defined by the given axes vector set. The two axes that form a
 * plane that has the lowest offset of the xz-plane (hence the two vectors with the minimum y-values) are chosen to be
 * mapped to the xz-plane and their reflection on the xz-plane are drawn the along with a grid is formed from the the two
 * reflection axes at the base of the Robot.
 * 
 * @param axesVectors     A rotation matrix (in row major order) that defines the axes of the frame to map to the xz-plane
 * @param origin          The xz-origin at which to drawn the reflection axes
 * @param halfNumOfLines  Half the number of lines to draw for one of the axes
 * @param distBwtLines    The distance between each gridline
 */
public void displayGridlines(float[][] axesVectors, PVector origin, int halfNumOfLines, float distBwtLines) {
  int vectorPX = -1, vectorPZ = -1;
  
  // Find the two vectors with the minimum y values
  for (int v = 0; v < axesVectors.length; ++v) {
    int limboX = (v + 1) % axesVectors.length,
        limboY = (limboX + 1) % axesVectors.length;
    // Compare the y value of the current vector to those of the other two vectors
    if (abs(axesVectors[v][1]) >= abs(axesVectors[limboX][1]) && abs(axesVectors[v][1]) >= abs(axesVectors[limboY][1])) {
      vectorPX = limboX;
      vectorPZ = limboY;
      break;
    }
  }
  
  if (vectorPX == -1 || vectorPZ == -1) {
    println("Invalid axes-origin pair for grid lines!");
    return;
  }
  
  pushMatrix();
  // Map the chosen two axes vectors to the xz-plane at the y-position of the Robot's base
  applyMatrix(axesVectors[vectorPX][0], 0, axesVectors[vectorPZ][0], origin.x,
                                     0, 1,                        0, ROBOT_POSITION.y,
              axesVectors[vectorPX][2], 0, axesVectors[vectorPZ][2], origin.z,
                                     0, 0,                        0,        1);
  
  float lineLen = halfNumOfLines * distBwtLines;
  
  // Draw axes lines in red
  stroke(255, 0, 0);
  line(-lineLen, 0, 0, lineLen, 0, 0);
  line(0, 0, -lineLen, 0, 0, lineLen);
  // Draw remaining gridlines in black
  stroke(25, 25, 25);
  for(int linePosScale = 1; linePosScale <= halfNumOfLines; ++linePosScale) {
    line(distBwtLines * linePosScale, 0, -lineLen, distBwtLines * linePosScale, 0, lineLen);
    line(-lineLen, 0, distBwtLines * linePosScale, lineLen, 0, distBwtLines * linePosScale);
    
    line(-distBwtLines * linePosScale, 0, -lineLen, -distBwtLines * linePosScale, 0, lineLen);
    line(-lineLen, 0, -distBwtLines * linePosScale, lineLen, 0, -distBwtLines * linePosScale);
  }
  
  popMatrix();
  mapToRobotBasePlane();
}

/**
 * This method will draw the End Effector grid mapping based on the value of EE_MAPPING:
 *
 *  0 -> a line is drawn between the EE and the grid plane
 *  1 -> a point is drawn on the grid plane that corresponds to the EE's xz coordinates
 *  For any other value, nothing is drawn
 */
public void mapToRobotBasePlane() {
  
  PVector ee_pos = nativeRobotEEPoint(armModel.getJointAngles()).position;
  
  // Change color of the EE mapping based on if it lies below or above the ground plane
  int c = (ee_pos.y <= ROBOT_POSITION.y) ? color(255, 0, 0) : color(150, 0, 255);
  
  // Toggle EE mapping type with 'e'
  switch (mappingState) {
  case LINE:
    stroke(c);
    // Draw a line, from the EE to the grid in the xy plane, parallel to the xy plane
    line(ee_pos.x, ee_pos.y, ee_pos.z, ee_pos.x, ROBOT_POSITION.y, ee_pos.z);
    break;
    
  case DOT:
    noStroke();
    fill(c);
    // Draw a point, which maps the EE's position to the grid in the xy plane
    pushMatrix();
    rotateX(PI / 2);
    translate(0, 0, -ROBOT_POSITION.y);
    ellipse(ee_pos.x, ee_pos.z, 10, 10);
    popMatrix();
    break;
    
  default:
    // No EE grid mapping
  }
}
/* The possible values for the current Coordinate Frame */
private enum CoordFrame { JOINT, WORLD, TOOL, USER }
/* The possible types of End Effectors for the Robot */
private enum EEType { NONE, SUCTION, CLAW, POINTER, GLUE_GUN, WIELDER; }
/* The different motion types for the Robot to when moving to specific joint angles, or positon and orientation. */
private enum RobotMotion { HALTED, MT_JOINT, MT_LINEAR; }
/* The states for displaying the current frame as axes */
private enum AxesDisplay { AXES, GRID, NONE };
/* The states for mapping the Robot's End Effector to the grid */
private enum EEMapping { LINE, DOT, NONE };
/* Define the relative points of an object drawn in a GUI */
private enum RelativePoint { TOP_RIGHT, TOP_LEFT, BOTTOM_LEFT, BOTTOM_RIGHT; }
/* Set of valid shape types that a fixture or part can have */
private enum ShapeType { BOX, CYLINDER, MODEL };
/* Set of valid dimension types for a shape */
private enum DimType { LENGTH, WIDTH, HEIGHT, RADIUS, SCALE };

/* These are used to store the operators used in register statement expressions in the ExpressionSet Object */
private enum Operator implements ExpressionElement {
  ADDTN("+", ARITH_OP), 
  SUBTR("-", ARITH_OP), 
  MULT("*", ARITH_OP), 
  DIV("/", ARITH_OP), 
  MOD("%", ARITH_OP), 
  INTDIV("|", ARITH_OP),
  PAR_OPEN("(", -1),
  PAR_CLOSE(")", -1),
  EQUAL("=", BOOL_OP),
  NEQUAL("<>", BOOL_OP),
  GRTR(">", BOOL_OP),
  LESS("<", BOOL_OP),
  GREQ(">=", BOOL_OP),
  LSEQ("<=", BOOL_OP),
  AND("&&", BOOL_OP),
  OR("||", BOOL_OP),
  NOT("!", BOOL_OP),
  UNINIT("_", -1);
  
  public final String symbol;
  public final int type;
  
  private Operator(String s, int t) {
    symbol = s;
    type = t;
  }
  
  public int getLength() {
    return 1;
  }
  
  public String toString() {
    return symbol;
  }
  
  public String[] toStringArray() {
    return new String[] { toString() };
  }
}

/* The type of the position register to use in a register statement */
public enum PositionType { GLOBAL, LOCAL }

public interface DisplayMode {}

public static enum ScreenType implements DisplayMode {
  TYPE_DEFAULT,
  TYPE_OPT_MENU,
  TYPE_LINE_SELECT,
  TYPE_LIST_CONTENTS,
  TYPE_CONFIRM_CANCEL,
  TYPE_INSTRUCT_EDIT,
  TYPE_EXPR_EDIT,
  TYPE_TEACH_POINTS,
  TYPE_TEXT_ENTRY,
  TYPE_NUM_ENTRY,
  TYPE_POINT_ENTRY;
}

public static enum Screen implements DisplayMode {
   
  /* 
  * The "Home" screen, default root screen state displayed on startup
  */
  DEFAULT(ScreenType.TYPE_DEFAULT), 
  
  /*
  * Set of screens used to manipulate instruction parameters with a finite number of states
  */
  SET_BOOL_CONST(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_CALL_PROG(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_FRM_INSTR_TYPE(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_IF_STMT_ACT(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_IO_INSTR_STATE(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_MV_INSTR_TYPE(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_MV_INSTR_REG_TYPE(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_REG_EXPR_TYPE(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_SELECT_STMT_ARG(ScreenType.TYPE_INSTRUCT_EDIT),
  SET_SELECT_STMT_ACT(ScreenType.TYPE_INSTRUCT_EDIT),
  
  /*
  * Set of screens used to edit expression elements
  */
  SET_BOOL_EXPR_ARG(ScreenType.TYPE_EXPR_EDIT),
  SET_EXPR_ARG(ScreenType.TYPE_EXPR_EDIT),
  SET_EXPR_OP(ScreenType.TYPE_EXPR_EDIT),
  
  /*
  * Screens used to display a sereal list of contents for the user to
  * examine and interact with
  */
  NAV_PROG_INSTR(ScreenType.TYPE_LIST_CONTENTS),
  NAV_TOOL_FRAMES(ScreenType.TYPE_LIST_CONTENTS),
  NAV_USER_FRAMES(ScreenType.TYPE_LIST_CONTENTS),
  NAV_PROGRAMS(ScreenType.TYPE_LIST_CONTENTS),
  //Cartesian
  NAV_PREGS_C(ScreenType.TYPE_LIST_CONTENTS),
  //Joint
  NAV_PREGS_J(ScreenType.TYPE_LIST_CONTENTS),
  NAV_DREGS(ScreenType.TYPE_LIST_CONTENTS),
  
  /*
  * Screens used to perform arbitrary line-wise selection on a list of
  * elements displayed on a screen of type 'TYPE_LIST_CONTENTS'
  */
  SELECT_COMMENT(ScreenType.TYPE_LINE_SELECT),
  SELECT_CUT_COPY(ScreenType.TYPE_LINE_SELECT),
  SELECT_INSTR_DELETE(ScreenType.TYPE_LINE_SELECT),
  
  /*
  * Screens used to confirm or cancel the execution of a selected function
  */
  CONFIRM_PROG_DELETE(ScreenType.TYPE_CONFIRM_CANCEL),
  CONFIRM_RENUM(ScreenType.TYPE_CONFIRM_CANCEL),
  CONFIRM_UNDO(ScreenType.TYPE_CONFIRM_CANCEL),
  
  /*
  * Screens used to display a context-based list of options to the user
  */
  FRAME_METHOD_TOOL(ScreenType.TYPE_OPT_MENU),
  FRAME_METHOD_USER(ScreenType.TYPE_OPT_MENU),
  NAV_INSTR_MENU(ScreenType.TYPE_OPT_MENU),
  NAV_MAIN_MENU(ScreenType.TYPE_OPT_MENU),
  NAV_SETUP(ScreenType.TYPE_OPT_MENU),
  SELECT_COND_STMT(ScreenType.TYPE_OPT_MENU),
  SELECT_FRAME_INSTR_TYPE(ScreenType.TYPE_OPT_MENU),
  SELECT_FRAME_MODE(ScreenType.TYPE_OPT_MENU),
  SELECT_INSTR_INSERT(ScreenType.TYPE_OPT_MENU),
  SELECT_IO_INSTR_REG(ScreenType.TYPE_OPT_MENU),
  SELECT_JMP_LBL(ScreenType.TYPE_OPT_MENU),
    
  /*
  * Screens involving the entry of text, either via keyboard input or function buttons
  */
  FIND_REPL(ScreenType.TYPE_TEXT_ENTRY),
  EDIT_DREG_COM(ScreenType.TYPE_TEXT_ENTRY),
  EDIT_PREG_COM(ScreenType.TYPE_TEXT_ENTRY),
  PROG_COPY(ScreenType.TYPE_TEXT_ENTRY),
  PROG_CREATE(ScreenType.TYPE_TEXT_ENTRY),
  PROG_RENAME(ScreenType.TYPE_TEXT_ENTRY),
    
  /*
  * Screens involving the entry of numeric values via either a physical num pad or
  * the virtual numpad included in the simulator UI
  */
  ACTIVE_FRAMES(ScreenType.TYPE_NUM_ENTRY),
  CONFIRM_INSERT(ScreenType.TYPE_NUM_ENTRY),
  EDIT_DREG_VAL(ScreenType.TYPE_NUM_ENTRY),
  INPUT_DREG_IDX(ScreenType.TYPE_NUM_ENTRY),
  INPUT_IOREG_IDX(ScreenType.TYPE_NUM_ENTRY),
  INPUT_PREG_IDX1(ScreenType.TYPE_NUM_ENTRY),
  INPUT_PREG_IDX2(ScreenType.TYPE_NUM_ENTRY),
  INPUT_CONST(ScreenType.TYPE_NUM_ENTRY),
  JUMP_TO_LINE(ScreenType.TYPE_NUM_ENTRY),
  SET_FRAME_INSTR_IDX(ScreenType.TYPE_NUM_ENTRY),
  SET_IO_INSTR_IDX(ScreenType.TYPE_NUM_ENTRY),
  SET_JUMP_TGT(ScreenType.TYPE_NUM_ENTRY),
  SET_LBL_NUM(ScreenType.TYPE_NUM_ENTRY),
  SET_REG_EXPR_IDX1(ScreenType.TYPE_NUM_ENTRY),
  SET_REG_EXPR_IDX2(ScreenType.TYPE_NUM_ENTRY),
  SET_SELECT_ARGVAL(ScreenType.TYPE_NUM_ENTRY),
  SET_MV_INSTR_IDX(ScreenType.TYPE_NUM_ENTRY),
  SET_MV_INSTR_OFFSET(ScreenType.TYPE_NUM_ENTRY),
  SET_MV_INSTR_SPD(ScreenType.TYPE_NUM_ENTRY),
  SET_MV_INSTR_TERM(ScreenType.TYPE_NUM_ENTRY),
  CP_DREG_COM(ScreenType.TYPE_NUM_ENTRY),
  CP_DREG_VAL(ScreenType.TYPE_NUM_ENTRY),
  CP_PREG_COM(ScreenType.TYPE_NUM_ENTRY),
  CP_PREG_PT(ScreenType.TYPE_NUM_ENTRY),
    
  /*
   * Frame input methods
   */
  TEACH_3PT_TOOL(ScreenType.TYPE_TEACH_POINTS),
  TEACH_3PT_USER(ScreenType.TYPE_TEACH_POINTS),
  TEACH_4PT(ScreenType.TYPE_TEACH_POINTS),
  TEACH_6PT(ScreenType.TYPE_TEACH_POINTS),
  
  /*
   * Screens involving direct entry of point values
   */
  DIRECT_ENTRY_TOOL(ScreenType.TYPE_POINT_ENTRY),
  DIRECT_ENTRY_USER(ScreenType.TYPE_POINT_ENTRY),
  EDIT_PREG_C(ScreenType.TYPE_POINT_ENTRY),
  EDIT_PREG_J(ScreenType.TYPE_POINT_ENTRY),
  
  /*
  * Miscelanious screens/ not otherwise categorized
  */
  SWAP_PT_TYPE,
  EDIT_RSTMT,
  UFRAME_DETAIL,
  TFRAME_DETAIL,
  INPUT_CONSTANT,
  INPUT_OPERATOR,
  INPUT_PRDX,
  INPUT_PRVDX,
  INPUT_RDX,
  SELECT_REG_STMT,
  PICK_LETTER,
  NAV_DATA,
  VIEW_INST_REG;
  
  private final ScreenType type;
  
  private Screen(){
    type = null;
  }
  
  private Screen(ScreenType t){
    type = t;
  }
  
  public ScreenType getType(){
    return type;
  } 
}
ArrayList<Point> intermediatePositions;
int motionFrameCounter = 0;
float distanceBetweenPoints = 5.0f;
int interMotionIdx = -1;

int liveSpeed = 10;
boolean executingInstruction = false;

// Determines what End Effector mapping should be display
private EEMapping mappingState = EEMapping.LINE;
// Deterimes what type of axes should be displayed
private static AxesDisplay axesState = AxesDisplay.AXES;

private static final boolean COLLISION_DISPLAY = true,
                             DISPLAY_TEST_OUTPUT = true;

/**
 * Displays important information in the upper-right corner of the screen.
 */
public void showMainDisplayText() {
  fill(0);
  textAlign(RIGHT, TOP);
  int lastTextPositionX = width - 20,
      lastTextPositionY = 20;
  String coordFrame = "Coordinate Frame: ";
  
  switch(curCoordFrame) {
    case JOINT:
      coordFrame += "Joint";
      break;
    case WORLD:
      coordFrame += "World";
      break;
    case TOOL:
      coordFrame += "Tool";
      break;
    case USER:
      coordFrame += "User";
      break;
    default:
  }
  
  Point RP = nativeRobotEEPoint(armModel.getJointAngles());
  Frame active = getActiveFrame(null);
  
  if (active != null) {
    // Convert into currently active frame
    RP = applyFrame(RP, active.getOrigin(), active.getOrientation());
  }
  
  String[] cartesian = RP.toLineStringArray(true),
           joints = RP.toLineStringArray(false);
  // Display the current Coordinate Frame name
  text(coordFrame, lastTextPositionX, lastTextPositionY);
  lastTextPositionY += 20;
  // Display the Robot's speed value as a percent
  text(String.format("Speed: %d%%", liveSpeed), lastTextPositionX, lastTextPositionY);
  lastTextPositionY += 20;
  // Display the title of the currently active scenario
  String scenarioTitle;
  
  if (activeScenario != null) {
    scenarioTitle = "Scenario: " + activeScenario.getName();
  } else {
    scenarioTitle = "No active scenario";
  }
  
  text(scenarioTitle, lastTextPositionX, lastTextPositionY);
  lastTextPositionY += 40;
  // Display the Robot's current XYZWPR values
  text("Robot Position and Orientation", lastTextPositionX, lastTextPositionY);
  lastTextPositionY += 20;
  for (String line : cartesian) {
    text(line, lastTextPositionX, lastTextPositionY);
    lastTextPositionY += 20;
  }
  
  lastTextPositionY += 20;
  // Display the Robot's current joint angle values
  text("Robot Joint Angles", lastTextPositionX, lastTextPositionY);
  lastTextPositionY += 20;
  for (String line : joints) {
    text(line, lastTextPositionX, lastTextPositionY);
    lastTextPositionY += 20;
  }
  
  WorldObject toEdit = manager.getActiveWorldObject();
  // Display the position and orientation of the active world object
  if (toEdit != null) {
    String[] dimFields = toEdit.dimFieldsToStringArray();
    // Convert the values into the World Coordinate System
    PVector position = convertNativeToWorld(toEdit.getLocalCenter());
    PVector wpr = convertNativeToWorld( matrixToEuler(toEdit.getLocalOrientationAxes()) ).mult(RAD_TO_DEG);
    // Create a set of uniform Strings
    String[] fields = new String[] { String.format("X: %4.3f", position.x), String.format("Y: %4.3f", position.y),
                                     String.format("Z: %4.3f", position.z), String.format("W: %4.3f", wpr.x),
                                     String.format("P: %4.3f", wpr.y), String.format("R: %4.3f", wpr.z) };
    
    lastTextPositionY += 20;
    text(toEdit.getName(), lastTextPositionX, lastTextPositionY);
    lastTextPositionY += 20;
    String dimDisplay = "";
    // Display the dimensions of the world object (if any)
    for (int idx = 0; idx < dimFields.length; ++idx) {
      if ((idx + 1) < dimFields.length) {
        dimDisplay += String.format("%-12s", dimFields[idx]);
        
      } else {
        dimDisplay += String.format("%s", dimFields[idx]);
      }
    }
    
    text(dimDisplay, lastTextPositionX, lastTextPositionY);
    
    lastTextPositionY += 20;
    // Add space patting
    text(String.format("%-12s %-12s %s", fields[0], fields[1], fields[2]), lastTextPositionX, lastTextPositionY);
    lastTextPositionY += 20;
    text(String.format("%-12s %-12s %s", fields[3], fields[4], fields[5]), lastTextPositionX, lastTextPositionY);
    lastTextPositionY += 20;
  }
  
  lastTextPositionY += 20;
  // Display the current axes display state
  text(String.format("Axes Display: %s", axesState.name()),  lastTextPositionX, height - 50);
  
  if (axesState == AxesDisplay.GRID) {
    // Display the current ee mapping state
    text(String.format("EE Mapping: %s", mappingState.name()),  lastTextPositionX, height - 30);
  }
   
  if (DISPLAY_TEST_OUTPUT) {
    String[] cameraFields = camera.toStringArray();
    // Display camera position, orientation, and scale
    for (String field : cameraFields) {
      lastTextPositionY += 20;
      text(field, lastTextPositionX, lastTextPositionY);
    }
    lastTextPositionY += 40;
    
    fill(215, 0, 0);
    
    // Display a message when there is an error with the Robot's movement
    if (robotFault) {
      text("Robot Fault (press SHIFT + Reset)", lastTextPositionX, lastTextPositionY);
      lastTextPositionY += 20;
    }
    
    // Display a message if the Robot is in motion
    if (armModel.modelInMotion()) {
      text("Robot is moving", lastTextPositionX, lastTextPositionY);
      lastTextPositionY += 20;
    }
    
    if (programRunning) {
      text("Program executing", lastTextPositionX, lastTextPositionY);
      lastTextPositionY += 20;
    }
    
    // Display a message while the robot is carrying an object
    if(armModel.held != null) {
      text("Object held", lastTextPositionX, lastTextPositionY);
      lastTextPositionY += 20;
      
      PVector held_pos = armModel.held.getLocalCenter();
      String obj_pos = String.format("(%f, %f, %f)", held_pos.x, held_pos.y, held_pos.z);
      text(obj_pos, lastTextPositionX, lastTextPositionY);
      lastTextPositionY += 20;
    }
  }
  
  manager.updateWindowDisplay();
}

/** 
 * Transitions to the next Coordinate frame in the cycle, updating the Robot's current frame
 * in the process and skipping the Tool or User frame if there are no active frames in either
 * one. Since the Robot's frame is potentially reset in this method, all Robot motion is halted.
 *
 * @param model  The Robot Arm, for which to switch coordinate frames
 */
public void coordFrameTransition() {
  // Stop Robot movement
  armModel.halt();
  
  // Increment the current coordinate frame
  switch (curCoordFrame) {
    case JOINT:
      curCoordFrame = CoordFrame.WORLD;
      break;
      
    case WORLD:
      curCoordFrame = CoordFrame.TOOL;
      break;
     
    case TOOL:
      curCoordFrame = CoordFrame.USER;
      break;
     
    case USER:
      curCoordFrame = CoordFrame.JOINT;
      break;
  }
  
  // Skip the Tool Frame, if there is no active frame
  if(curCoordFrame == CoordFrame.TOOL && !(activeToolFrame >= 0 && activeToolFrame < toolFrames.length)) {
    curCoordFrame = CoordFrame.USER;
  }
  
  // Skip the User Frame, if there is no active frame
  if(curCoordFrame == CoordFrame.USER && !(activeUserFrame >= 0 && activeUserFrame < userFrames.length)) {
    curCoordFrame = CoordFrame.JOINT;
  }
  
  updateCoordFrame();
}

/**
 * Transition back to the World Frame, if the current Frame is Tool or User and there are no active frame
 * set for that Coordinate Frame. This method will halt the motion of the Robot if the active frame is changed.
 */
public void updateCoordFrame() {
  
  // Return to the World Frame, if no User Frame is active
  if(curCoordFrame == CoordFrame.TOOL && !(activeToolFrame >= 0 && activeToolFrame < toolFrames.length)) {
    curCoordFrame = CoordFrame.WORLD;
    // Stop Robot movement
    armModel.halt();
  }
  
  // Return to the World Frame, if no User Frame is active
  if(curCoordFrame == CoordFrame.USER && !(activeUserFrame >= 0 && activeUserFrame < userFrames.length)) {
    curCoordFrame = CoordFrame.WORLD;
    // Stop Robot movement
    armModel.halt();
  }
}

/**
 * Returns a point containing the Robot's faceplate position and orientation
 * corresponding to the given joint angles, as well as the given joint angles.
 * 
 * @param jointAngles  A valid set of six joint angles (in radians) for the
 *                     Robot
 * @returning          The Robot's faceplate position and orientation
 *                     corresponding to the given joint angles
 */
public Point nativeRobotPoint(float[] jointAngles) {
  // Return a point containing the faceplate position, orientation, and joint angles
  return nativeRobotPointOffset(jointAngles, new PVector(0f, 0f, 0f));
}

/**
 * Returns a point containing the Robot's End Effector position and orientation
 * corresponding to the given joint angles, as well as the given joint angles.
 * 
 * @param jointAngles  A valid set of six joint angles (in radians) for the Robot
 * @param offset       The End Effector offset in the form of a vector
 * @returning          The Robot's EE position and orientation corresponding to
 *                     the given joint angles
 */
public Point nativeRobotPointOffset(float[] jointAngles, PVector offset) {
  pushMatrix();
  resetMatrix();
  applyModelRotation(jointAngles);
  // Apply offset
  PVector ee = getCoordFromMatrix(offset.x, offset.y, offset.z);
  float[][] orientationMatrix = getRotationMatrix();
  popMatrix();
  // Return a Point containing the EE position, orientation, and joint angles
  return new Point(ee, matrixToQuat(orientationMatrix), jointAngles);
}

/**
 * Returns the Robot's End Effector position according to the active Tool Frame's
 * offset in the native Coordinate System.
 * 
 * @param jointAngles  A valid set of six joint angles (in radians) for the Robot
 * @returning          The Robot's End Effector position
 */
public Point nativeRobotEEPoint(float[] jointAngles) {
  Frame activeTool = getActiveFrame(CoordFrame.TOOL);
  PVector offset;
  
  if (activeTool != null) {
    // Apply the Tool Tip
    offset = ((ToolFrame)activeTool).getTCPOffset();
  } else {
    offset = new PVector(0f, 0f, 0f);
  }
  
  return nativeRobotPointOffset(jointAngles, offset);
}

/**
 * Takes a vector and a (probably not quite orthogonal) second vector
 * and computes a vector that's truly orthogonal to the first one and
 * pointing in the direction closest to the imperfect second vector
 * @param in First vector
 * @param second Second vector
 * @return A vector perpendicular to the first one and on the same side
 *         from first as the second one.
 */
public PVector computePerpendicular(PVector in, PVector second) {
  PVector[] plane = createPlaneFrom3Points(in, second, new PVector(in.x*2, in.y*2, in.z*2));
  PVector v1 = vectorConvertTo(in, plane[0], plane[1], plane[2]);
  PVector v2 = vectorConvertTo(second, plane[0], plane[1], plane[2]);
  PVector perp1 = new PVector(v1.y, -v1.x, v1.z);
  PVector perp2 = new PVector(-v1.y, v1.x, v1.z);
  PVector orig = new PVector(v2.x*5, v2.y*5, v2.z);
  PVector p1 = new PVector(perp1.x*5, perp1.y*5, perp1.z);
  PVector p2 = new PVector(perp2.x*5, perp2.y*5, perp2.z);
  
  if(dist(orig.x, orig.y, orig.z, p1.x, p1.y, p1.z) <
      dist(orig.x, orig.y, orig.z, p2.x, p2.y, p2.z))
  return vectorConvertFrom(perp1, plane[0], plane[1], plane[2]);
  else return vectorConvertFrom(perp2, plane[0], plane[1], plane[2]);
}

/**
 * Calculate the Jacobian matrix for the robotic arm for
 * a given set of joint rotational values using a 1 DEGREE
 * offset for each joint rotation value. Each cell of the
 * resulting matrix will describe the linear approximation
 * of the robot's motion for each joint in units per radian. 
 */
public float[][] calculateJacobian(float[] angles, boolean posOffset) {
  float dAngle = DEG_TO_RAD;
  if (!posOffset){ dAngle *= -1; }
  
  float[][] J = new float[7][6];
  //get current ee position
  Point curRP = nativeRobotEEPoint(angles);
  
  //examine each segment of the arm
  for(int i = 0; i < 6; i += 1) {
    //test angular offset
    angles[i] += dAngle;
    //get updated ee position
    Point newRP = nativeRobotEEPoint(angles);
    
    if (quaternionDotProduct(curRP.orientation, newRP.orientation) < 0f) {
      // Use -q instead of q
      newRP.orientation = vectorScalarMult(newRP.orientation, -1);
    }
    
    //get translational delta
    J[0][i] = (newRP.position.x - curRP.position.x) / DEG_TO_RAD;
    J[1][i] = (newRP.position.y - curRP.position.y) / DEG_TO_RAD;
    J[2][i] = (newRP.position.z - curRP.position.z) / DEG_TO_RAD;
    //get rotational delta        
    J[3][i] = (newRP.orientation[0] - curRP.orientation[0]) / DEG_TO_RAD;
    J[4][i] = (newRP.orientation[1] - curRP.orientation[1]) / DEG_TO_RAD;
    J[5][i] = (newRP.orientation[2] - curRP.orientation[2]) / DEG_TO_RAD;
    J[6][i] = (newRP.orientation[3] - curRP.orientation[3]) / DEG_TO_RAD;
    //replace the original rotational value
    angles[i] -= dAngle;
  }
  
  return J;
}

/**
 * Attempts to calculate the joint angles that would place the Robot in the given target position and
 * orientation. The srcAngles parameter defines the position of the Robot from which to move, since
 * this inverse kinematics uses a relative conversion formula. There is no guarantee that the target
 * position and orientation can be reached; in the case that inverse kinematics fails, then null is
 * returned. Otherwise, a set of six angles will be returned, though there is no guarantee that these
 * angles are valid!
 * 
 * @param srcAngles       The initial position of the Robot
 * @param tgtPosition     The desired position of the Robot
 * @param tgtOrientation  The desited orientation of the Robot
 */
public float[] inverseKinematics(float[] srcAngles, PVector tgtPosition, float[] tgtOrientation) {
  final int limit = 1000;  // Max number of times to loop
  int count = 0;
  
  float[] angles = srcAngles.clone();
  
  while(count < limit) {
    Point cPoint = nativeRobotEEPoint(angles);
    
    if (quaternionDotProduct(tgtOrientation, cPoint.orientation) < 0f) {
      // Use -q instead of q
      tgtOrientation = vectorScalarMult(tgtOrientation, -1);
    }
    
    //calculate our translational offset from target
    PVector tDelta = PVector.sub(tgtPosition, cPoint.position);
    //calculate our rotational offset from target
    float[] rDelta = calculateVectorDelta(tgtOrientation, cPoint.orientation, 4);
    float[] delta = new float[7];
    
    delta[0] = tDelta.x;
    delta[1] = tDelta.y;
    delta[2] = tDelta.z;
    delta[3] = rDelta[0];
    delta[4] = rDelta[1];
    delta[5] = rDelta[2];
    delta[6] = rDelta[3];
    
    float dist = PVector.dist(cPoint.position, tgtPosition);
    float rDist = getVectorMag(rDelta);
    //check whether our current position is within tolerance
    if ( (dist < (liveSpeed / 100f)) && (rDist < (0.00005f * liveSpeed)) ) { break; }
    
    //calculate jacobian, 'J', and its inverse
    float[][] J = calculateJacobian(angles, true);
    RealMatrix m = new Array2DRowRealMatrix(floatToDouble(J, 7, 6));
    RealMatrix JInverse = new SingularValueDecomposition(m).getSolver().getInverse();
    
    //calculate and apply joint angular changes
    float[] dAngle = {0, 0, 0, 0, 0, 0};
    for(int i = 0; i < 6; i += 1) {
      for(int j = 0; j < 7; j += 1) {
        dAngle[i] += JInverse.getEntry(i, j)*delta[j];
      }
      
      //update joint angles
      angles[i] += dAngle[i];
      angles[i] += TWO_PI;
      angles[i] %= TWO_PI;
    }
    
    count += 1;
    if (count == limit) {
      // IK failure
      if (DISPLAY_TEST_OUTPUT) {
        System.out.printf("\nDelta: %s\nAngles: %s\n%s\n%s -> %s\n", arrayToString(delta), arrayToString(angles),
                            matrixToString(J), arrayToString(cPoint.orientation), arrayToString(tgtOrientation));
      }
      
      return null;
    }
  }
  
  return angles;
}

/**
 * Determine how close together intermediate points between two points
 * need to be based on current speed
 */
public void calculateDistanceBetweenPoints() {
  MotionInstruction instruction = activeMotionInst();
  if(instruction != null && instruction.getMotionType() != MTYPE_JOINT)
  distanceBetweenPoints = instruction.getSpeed() / 60.0f;
  else if(curCoordFrame != CoordFrame.JOINT)
  distanceBetweenPoints = armModel.motorSpeed * liveSpeed / 6000f;
  else distanceBetweenPoints = 5.0f;
}

/**
 * Calculate a "path" (series of intermediate positions) between two
 * points in a straight line.
 * @param start Start point
 * @param end Destination point
 */
public void calculateIntermediatePositions(Point start, Point end) {
  calculateDistanceBetweenPoints();
  intermediatePositions.clear();
  
  PVector p1 = start.position;
  PVector p2 = end.position;
  float[] q1 = start.orientation;
  float[] q2 = end.orientation;
  float[] qi = new float[4];
  
  float mu = 0;
  int numberOfPoints = (int)(dist(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z) / distanceBetweenPoints);
  float increment = 1.0f / (float)numberOfPoints;
  for(int n = 0; n < numberOfPoints; n++) {
    mu += increment;
    
    qi = quaternionSlerp(q1, q2, mu);
    intermediatePositions.add(new Point(new PVector(
    p1.x * (1 - mu) + (p2.x * mu),
    p1.y * (1 - mu) + (p2.y * mu),
    p1.z * (1 - mu) + (p2.z * mu)),
    qi));
  }
  
  interMotionIdx = 0;
} // end calculate intermediate positions

/**
 * Calculate a "path" (series of intermediate positions) between two
 * points in a a curved line. Need a third point as well, or a curved
 * line doesn't make sense.
 * Here's how this works:
 *   Assuming our current point is P1, and we're moving to P2 and then P3:
 *   1 Do linear interpolation between points P2 and P3 FIRST.
 *   2 Begin interpolation between P1 and P2.
 *   3 When you're (cont% / 1.5)% away from P2, begin interpolating not towards
 *     P2, but towards the points defined between P2 and P3 in step 1.
 *   The mu for this is from 0 to 0.5 instead of 0 to 1.0.
 *
 * @param p1 Start point
 * @param p2 Destination point
 * @param p3 Third point, needed to figure out how to curve the path
 * @param percentage Intensity of the curve
 */
public void calculateContinuousPositions(Point start, Point end, Point next, float percentage) {
  //percentage /= 2;
  calculateDistanceBetweenPoints();
  percentage /= 1.5f;
  percentage = 1 - percentage;
  percentage = constrain(percentage, 0, 1);
  intermediatePositions.clear();
  
  PVector p1 = start.position;
  PVector p2 = end.position;
  PVector p3 = next.position;
  float[] q1 = start.orientation;
  float[] q2 = end.orientation;
  float[] q3 = next.orientation;
  float[] qi = new float[4];
  
  ArrayList<Point> secondaryTargets = new ArrayList<Point>();
  float d1 = dist(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z);
  float d2 = dist(p2.x, p2.y, p2.z, p3.x, p3.y, p3.z);
  int numberOfPoints = 0;
  if(d1 > d2) {
    numberOfPoints = (int)(d1 / distanceBetweenPoints);
  } 
  else {
    numberOfPoints = (int)(d2 / distanceBetweenPoints);
  }
  
  float mu = 0;
  float increment = 1.0f / (float)numberOfPoints;
  for(int n = 0; n < numberOfPoints; n++) {
    mu += increment;
    qi = quaternionSlerp(q2, q3, mu);
    secondaryTargets.add(new Point(new PVector(
    p2.x * (1 - mu) + (p3.x * mu),
    p2.y * (1 - mu) + (p3.y * mu),
    p2.z * (1 - mu) + (p3.z * mu)),
    qi));
  }
  
  mu = 0;
  int transitionPoint = (int)((float)numberOfPoints * percentage);
  for(int n = 0; n < transitionPoint; n++) {
    mu += increment;
    qi = quaternionSlerp(q1, q2, mu);
    intermediatePositions.add(new Point(new PVector(
    p1.x * (1 - mu) + (p2.x * mu),
    p1.y * (1 - mu) + (p2.y * mu),
    p1.z * (1 - mu) + (p2.z * mu)),
    qi));
  }
  
  int secondaryIdx = 0; // accessor for secondary targets
  
  mu = 0;
  increment /= 2.0f;
  
  Point currentPoint;
  if(intermediatePositions.size() > 0) {
    currentPoint = intermediatePositions.get(intermediatePositions.size()-1);
  }
  else {
    // NOTE orientation is in Native Coordinates!
    currentPoint = nativeRobotEEPoint(armModel.getJointAngles());
  }
  
  for(int n = transitionPoint; n < numberOfPoints; n++) {
    mu += increment;
    Point tgt = secondaryTargets.get(secondaryIdx);
    qi = quaternionSlerp(currentPoint.orientation, tgt.orientation, mu);
    intermediatePositions.add(new Point(new PVector(
    currentPoint.position.x * (1 - mu) + (tgt.position.x * mu),
    currentPoint.position.y * (1 - mu) + (tgt.position.y * mu),
    currentPoint.position.z * (1 - mu) + (tgt.position.z * mu)), 
    qi));
    currentPoint = intermediatePositions.get(intermediatePositions.size()-1);
    secondaryIdx++;
  }
  interMotionIdx = 0;
} // end calculate continuous positions

/**
 * Creates an arc from 'start' to 'end' that passes through the point specified
 * by 'inter.'
 * @param start First point
 * @param inter Second point
 * @param end Third point
 */
public void calculateArc(Point start, Point inter, Point end) {  
  calculateDistanceBetweenPoints();
  intermediatePositions.clear();
  
  PVector a = start.position;
  PVector b = inter.position;
  PVector c = end.position;
  float[] q1 = start.orientation;
  float[] q2 = end.orientation;
  float[] qi = new float[4];
  
  // Calculate arc center point
  PVector[] plane = new PVector[3];
  plane = createPlaneFrom3Points(a, b, c);
  PVector center = circleCenter(vectorConvertTo(a, plane[0], plane[1], plane[2]),
  vectorConvertTo(b, plane[0], plane[1], plane[2]),
  vectorConvertTo(c, plane[0], plane[1], plane[2]));
  center = vectorConvertFrom(center, plane[0], plane[1], plane[2]);
  // Now get the radius (easy)
  float r = dist(center.x, center.y, center.z, a.x, a.y, a.z);
  // Calculate a vector from the center to point a
  PVector u = new PVector(a.x-center.x, a.y-center.y, a.z-center.z);
  u.normalize();
  // get the normal of the plane created by the 3 input points
  PVector tmp1 = new PVector(a.x-b.x, a.y-b.y, a.z-b.z);
  PVector tmp2 = new PVector(a.x-c.x, a.y-c.y, a.z-c.z);
  PVector n = tmp1.cross(tmp2);
  tmp1.normalize();
  tmp2.normalize();
  n.normalize();
  // calculate the angle between the start and end points
  PVector vec1 = new PVector(a.x-center.x, a.y-center.y, a.z-center.z);
  PVector vec2 = new PVector(c.x-center.x, c.y-center.y, c.z-center.z);
  vec1.normalize();
  vec2.normalize();
  float theta = atan2(vec1.cross(vec2).mag(), vec1.dot(vec2));

  // finally, draw an arc through all 3 points by rotating the u
  // vector around our normal vector
  float angle = 0, mu = 0;
  int numPoints = (int)(r*theta/distanceBetweenPoints);
  float inc = 1/(float)numPoints;
  float angleInc = (theta)/(float)numPoints;
  for(int i = 0; i < numPoints; i += 1) {
    PVector pos = rotateVectorQuat(u, n, angle).mult(r).add(center);
    if(i == numPoints-1) pos = end.position;
    qi = quaternionSlerp(q1, q2, mu);
    println(pos + ", " + end.position);
    intermediatePositions.add(new Point(pos, qi));
    angle += angleInc;
    mu += inc;
  }
}

/**
 * Initiate a new continuous (curved) motion instruction.
 * @param model Arm model to use
 * @param start Start point
 * @param end Destination point
 * @param next Point after the destination
 * @param percentage Intensity of the curve
 */
public void beginNewContinuousMotion(Point start, Point end, Point next, float p) {
  calculateContinuousPositions(start, end, next, p);
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0) {
    Point tgtPoint = intermediatePositions.get(interMotionIdx);
    armModel.jumpTo(tgtPoint.position, tgtPoint.orientation);
  }
}

/**
 * Initiate a new fine (linear) motion instruction.
 * @param start Start point
 * @param end Destination point
 */
public void beginNewLinearMotion(Point start, Point end) {
  calculateIntermediatePositions(start, end);
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0) {
    Point tgtPoint = intermediatePositions.get(interMotionIdx);
    armModel.jumpTo(tgtPoint.position, tgtPoint.orientation);
  }
}

/**
 * Initiate a new circular motion instruction according to FANUC methodology.
 * @param p1 Point 1
 * @param p2 Point 2
 * @param p3 Point 3
 */
public void beginNewCircularMotion(Point start, Point inter, Point end) {
  calculateArc(start, inter, end);
  interMotionIdx = 0;
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0) {
    Point tgtPoint = intermediatePositions.get(interMotionIdx);
    armModel.jumpTo(tgtPoint.position, tgtPoint.orientation);
  }
}

/**
 * Move the arm model between two points according to its current speed.
 * @param model The arm model
 * @param speedMult Speed multiplier
 */
public boolean executeMotion(ArmModel model, float speedMult) {
  motionFrameCounter++;
  // speed is in pixels per frame, multiply that by the current speed setting
  // which is contained in the motion instruction
  float currentSpeed = model.motorSpeed * speedMult;
  if(currentSpeed * motionFrameCounter > distanceBetweenPoints) {
    interMotionIdx++;
    motionFrameCounter = 0;
    if(interMotionIdx >= intermediatePositions.size()) {
      interMotionIdx = -1;
      return true;
    }
    
    int ret = EXEC_SUCCESS;
    if(intermediatePositions.size() > 0) {
      Point tgtPoint = intermediatePositions.get(interMotionIdx);
      ret = armModel.jumpTo(tgtPoint.position, tgtPoint.orientation);
    }
    
    if(ret == EXEC_FAILURE) {
      triggerFault();
      return true;
    }
  }
  
  return false;
} // end execute linear motion

/**
 * Convert a point based on a coordinate system defined as
 * 3 orthonormal vectors.
 * @param point Point to convert
 * @param xAxis X axis of target coordinate system
 * @param yAxis Y axis of target coordinate system
 * @param zAxis Z axis of target coordinate system
 * @return Coordinates of point after conversion
 */
public PVector vectorConvertTo(PVector point, PVector xAxis,
PVector yAxis, PVector zAxis)
{
  PMatrix3D matrix = new PMatrix3D(xAxis.x, xAxis.y, xAxis.z, 0,
  yAxis.x, yAxis.y, yAxis.z, 0,
  zAxis.x, zAxis.y, zAxis.z, 0,
  0,       0,       0,       1);
  PVector result = new PVector();
  matrix.mult(point, result);
  return result;
}


/**
 * Convert a point based on a coordinate system defined as
 * 3 orthonormal vectors. Reverse operation of vectorConvertTo.
 * @param point Point to convert
 * @param xAxis X axis of target coordinate system
 * @param yAxis Y axis of target coordinate system
 * @param zAxis Z axis of target coordinate system
 * @return Coordinates of point after conversion
 */
public PVector vectorConvertFrom(PVector point, PVector xAxis,
PVector yAxis, PVector zAxis)
{
  PMatrix3D matrix = new PMatrix3D(xAxis.x, yAxis.x, zAxis.x, 0,
  xAxis.y, yAxis.y, zAxis.y, 0,
  xAxis.z, yAxis.z, zAxis.z, 0,
  0,       0,       0,       1);
  PVector result = new PVector();
  matrix.mult(point, result);
  return result;
}


/**
 * Create a plane (2D coordinate system) out of 3 input points.
 * @param a First point
 * @param b Second point
 * @param c Third point
 * @return New coordinate system defined by 3 orthonormal vectors
 */
public PVector[] createPlaneFrom3Points(PVector a, PVector b, PVector c) {  
  PVector n1 = new PVector(a.x-b.x, a.y-b.y, a.z-b.z);
  n1.normalize();
  PVector n2 = new PVector(a.x-c.x, a.y-c.y, a.z-c.z);
  n2.normalize();
  PVector x = n1.copy();
  PVector z = n1.cross(n2);
  PVector y = x.cross(z);
  y.normalize();
  z.normalize();
  PVector[] coordinateSystem = new PVector[3];
  coordinateSystem[0] = x;
  coordinateSystem[1] = y;
  coordinateSystem[2] = z;
  return coordinateSystem;
}

/**
 * Finds the circle center of 3 points. (That is, find the center of
 * a circle whose circumference intersects all 3 points.)
 * The points must all lie
 * on the same plane (all have the same Z value). Should have a check
 * for colinear case, currently doesn't.
 * @param a First point
 * @param b Second point
 * @param c Third point
 * @return Position of circle center
 */
public PVector circleCenter(PVector a, PVector b, PVector c) {
  float h = calculateH(a.x, a.y, b.x, b.y, c.x, c.y);
  float k = calculateK(a.x, a.y, b.x, b.y, c.x, c.y);
  return new PVector(h, k, a.z);
}

// TODO: Add error check for colinear case (denominator is zero)
public float calculateH(float x1, float y1, float x2, float y2, float x3, float y3) {
  float numerator = (x2*x2+y2*y2)*y3 - (x3*x3+y3*y3)*y2 - 
  ((x1*x1+y1*y1)*y3 - (x3*x3+y3*y3)*y1) +
  (x1*x1+y1*y1)*y2 - (x2*x2+y2*y2)*y1;
  float denominator = (x2*y3-x3*y2) -
  (x1*y3-x3*y1) +
  (x1*y2-x2*y1);
  denominator *= 2;
  return numerator / denominator;
}

public float calculateK(float x1, float y1, float x2, float y2, float x3, float y3) {
  float numerator = x2*(x3*x3+y3*y3) - x3*(x2*x2+y2*y2) -
  (x1*(x3*x3+y3*y3) - x3*(x1*x1+y1*y1)) +
  x1*(x2*x2+y2*y2) - x2*(x1*x1+y1*y1);
  float denominator = (x2*y3-x3*y2) -
  (x1*y3-x3*y1) +
  (x1*y2-x2*y1);
  denominator *= 2;
  return numerator / denominator;
}

/**
 * Executes a program. Returns true when done.
 * @param program - Program to execute
 * @param model   - Arm model to use
 * @return        - True if done executing, false if otherwise.
 */
public boolean executeProgram(Program program, ArmModel model, boolean singleInstr) {
  Instruction activeInstr = activeInstruction();
  int nextInstr = active_instr + 1;
  
  //stop executing if no valid program is selected or we reach the end of the program
  if(robotFault || activeInstr == null) {
    return true;
  } 
  else if (!activeInstr.isCommented()){
    if (activeInstr instanceof MotionInstruction) {
      MotionInstruction motInstr = (MotionInstruction)activeInstr;
      
      //start a new instruction
      if(!executingInstruction) {
        executingInstruction = setUpInstruction(program, model, motInstr);
        
        if (!executingInstruction) {
          // Motion Instruction failed
          nextInstr = -1;
        }
      }
      //continue current motion instruction
      else {
        if(motInstr.getMotionType() == MTYPE_JOINT) {
          executingInstruction = !(model.interpolateRotation(motInstr.getSpeedForExec(model)));  
        }
        else {  
          executingInstruction = !(executeMotion(model, motInstr.getSpeedForExec(model)));
        }
      }
    } 
    else if (activeInstr instanceof JumpInstruction) {
      executingInstruction = false;
      nextInstr = activeInstr.execute();
      
      if(nextInstr == -1) {
        triggerFault();
        return true;
      }
    } 
    else {
      executingInstruction = false;
      
      if(activeInstr.execute() != 0) {
        triggerFault();
        return true;
      }
    }//end of instruction type check
  } //skip commented instructions
  
  // Move to next instruction after current is finished
  if(!executingInstruction) {
    if(nextInstr == activeProgram().size() && !call_stack.isEmpty()) {
      // Return from called program
      int[] p = call_stack.pop();
      active_prog = p[0];
      active_instr = p[1];
      
      row_select = active_instr;
      col_select = 0;
      start_render = 0;
      programRunning = !executeProgram(activeProgram(), armModel, false);
    } 
    else {
      // Move to nextInstruction
      int size = activeProgram().getInstructions().size() + 1;      
      active_instr = max(0, min(nextInstr, size - 1));
      row_select = getInstrLine(active_instr);
    }
    
    updateScreen();
  }
  
  return (!executingInstruction && singleInstr);
}//end executeProgram

/**
 * Sets up an instruction for execution.
 *
 * @param program Program that the instruction belongs to
 * @param model Arm model to use
 * @param instruction The instruction to execute
 * @return Returns false on failure (invalid instruction), true on success
 */
public boolean setUpInstruction(Program program, ArmModel model, MotionInstruction instruction) {
  Point start = nativeRobotEEPoint(model.getJointAngles());
  
  if(instruction.getMotionType() == MTYPE_JOINT) {
    armModel.setupRotationInterpolation(instruction.getVector(program).angles);
  } // end joint movement setup
  else if(instruction.getMotionType() == MTYPE_LINEAR) {
    if (!instruction.checkFrames(activeToolFrame, activeUserFrame)) {
      // Current Frames must match the instruction's frames
      System.out.printf("Tool frame: %d : %d\nUser frame: %d : %d\n\n", instruction.getToolFrame(),
                                      activeToolFrame, instruction.getUserFrame(), activeUserFrame);
      return false;
    }
    
    if(instruction.getTermination() == 0) {
      beginNewLinearMotion(start, instruction.getVector(program));
    } 
    else {
      Point nextPoint = null;
      for(int n = active_instr+1; n < program.getInstructions().size(); n++) {
        Instruction nextIns = program.getInstructions().get(n);
        if(nextIns instanceof MotionInstruction) {
          MotionInstruction castIns = (MotionInstruction)nextIns;
          nextPoint = castIns.getVector(program);
          break;
        }
      }
      if(nextPoint == null) {
        beginNewLinearMotion(start, instruction.getVector(program));
      } 
      else {
        beginNewContinuousMotion(start, 
        instruction.getVector(program),
        nextPoint, 
        instruction.getTermination() / 100f);
      }
    } // end if termination type is continuous
  } // end linear movement setup
  else if(instruction.getMotionType() == MTYPE_CIRCULAR) {
    MotionInstruction nextIns = instruction.getSecondaryPoint();
    Point nextPoint = nextIns.getVector(program);
    
    beginNewCircularMotion(start, instruction.getVector(program), nextPoint);
  } // end circular movement setup
  
  return true;
} // end setUpInstruction

/**
 * Stop robot motion, program execution
 */
public void triggerFault() {
  armModel.halt();
  robotFault = true;
}

/**
 * Returns a string represenation of the given matrix.
 * 
 * @param matrix  A non-null matrix
 */
public String matrixToString(float[][] matrix) {
  String mStr = "";
  
  for(int row = 0; row < matrix.length; ++row) {
    mStr += "\n[";

    for(int col = 0; col < matrix[0].length; ++col) {
      // Account for the negative sign character
      if(matrix[row][col] >= 0) { mStr += " "; }
      
      mStr += String.format(" %5.6f", matrix[row][col]);
    }

    mStr += "  ]";
  }
  
  return (mStr + "\n");
}

public String arrayToString(float[] array) {
  String s = "[";
  
  for(int i = 0; i < array.length; i += 1) {
    s += String.format("%5.4f", array[i]);
    if(i != array.length-1) s += ", ";
  }
  
  return s + "]";
}
/**
 * This class is designed to save an arithmetic expression for a register statement instruction. Register statements include the
 * folllowing operands: floating-point constants, Register values, Position Register points, and Position Register values. Legal
 * operators for these statements include addition(+), subtraction(-), multiplication(*), division(/), modulus(%), integer
 * division(|), and parenthesis(). An expression is evaluated left to right, ignoring any operation prescendence, save for
 * parenthesis, whose contents are evaluated first. An expression will have a maximum of 5 operators (discluding closing parenthesis).
 * 
 * All valid operands should extend the Operand interface, which simply has a method to get the value of the operand. Constant operands
 * hold a single floating-point constants. Register operands holds an index for a specific Data register entry. Position operands hold
 * and index for a specific position (or Position register), a position index, and a position type. A Position operands type determines
 * if the operands represents a global Position register entry, or a local position entry of the active program. The position index
 * determines if the entire position value will be used, or if a specific value of the position will be used.
 * 
 * -1    -> use the Point itself
 * 0 - 6 -> use specific value of the Point corresponding to the poisition index
 *
 * Robot Point operands are a place holder for the Robot's current position/orientaion or joint anhles and function similar to a Position
 * operand, whose position index is -1. SubExpression operands hold an entirely inidependent expression.
 *
 *
 * ConstantOp       ->  Constants
 * RobotPositionOp  ->  Robot's current position
 * RegisterOp       ->  Register values
 * PositionOp       ->  Position Register points/values
 */
public class RegisterExpression {
  private final ArrayList<Object> parameters;
  
  /**
   * Creates an empty expression
   */
  public RegisterExpression() {
    parameters = new ArrayList<Object>();
  }
  
  /**
   * Creates an expression from a String. THe format of the String must strictly
   * include only the following substrings, wach separating by only spaces:
   * 
   * '+', '-', '*', '/',
   * '%', '|', ')', or '('  -> operators
   * R[x]                   -> Register operand
   * P[x]
   * P[x, y]
   * PR[x]
   * PR[x, y]               -> Position operand
   * LPos
   * JPos
   * LPos[x]
   * JPos[x]                -> Robot Point operand
   * z                      -> Floating-point value
   * 
   * where x and y are positive integer values and
   * z is a valid Floating-point value
   * 
   * @parameter exprString  A String, which contains a valid set of the above
   *                        substrings, each separated by only spaces
   * @throws IllegalArgumentException  If anything aside from the parameters
   *                                   defined above exists in the string
   */
  public RegisterExpression(String exprString) throws IllegalArgumentException {
    parameters = new ArrayList<Object>();
    // Split all the parameters into individual Strings
    String[] paramList = exprString.split(" ");
    
    for (String param : paramList) {
      // Parse operator
      if (Pattern.matches("[^0123456789]", param)) {
        switch (param) {
          case "+":
            parameters.add(Operator.ADDTN);
            break;
          case "-":
            parameters.add(Operator.SUBTR);
            break;
          case "*":
            parameters.add(Operator.MULT);
            break;
          case "/":
            parameters.add(Operator.DIV);
            break;
          case "%":
            parameters.add(Operator.MOD);
            break;
          case "|":
            parameters.add(Operator.INTDIV);
            break;
          case "(":
            parameters.add(Operator.PAR_OPEN);
            break;
          case ")":
            parameters.add(Operator.PAR_CLOSE);
            break;
          default:
            throw new IllegalArgumentException( String.format("'%s' is not a valid operator!", param) );
        }
        
      } else if (Pattern.matches("R\\[[0123456789]+\\]", param)) {
        // Parse Register operand
        String idxVal = param.substring(2, param.length() - 1);
        int idx = Integer.parseInt(idxVal);
        parameters.add(new RegisterOp(idx));
        
      } else if (Pattern.matches("P\\[[0123456789]+\\]", param)) {
        // Parse Position operand (local)
        String idxVal = param.substring(2, param.length() - 1);
        int idx = Integer.parseInt(idxVal);
        parameters.add(new PositionOp(idx, PositionType.LOCAL));
        
      } else if (Pattern.matches("P\\[[0123456789]+,[0123456789]+\\]", param)) {
        // Parse Position operand (local, value)
        int commaIdx = param.indexOf(',');
        String idxVal = param.substring(2, commaIdx),
             pdxVal = param.substring(commaIdx + 1, param.length() - 1);
        int idx = Integer.parseInt(idxVal);
        int pdx = Integer.parseInt(pdxVal);
        parameters.add(new PositionOp(idx, pdx, PositionType.LOCAL));
        
      } else if (Pattern.matches("PR\\[[0123456789]+\\]", param)) {
        // Parse Position operand (global)
        String idxVal = param.substring(3, param.length() - 1);
        int idx = Integer.parseInt(idxVal);
        parameters.add(new PositionOp(idx, PositionType.GLOBAL));
        
      } else if (Pattern.matches("PR\\[[0123456789]+,[0123456789]+\\]", param)) {
        // Parse Position operand (global, value)
        int commaIdx = param.indexOf(',');
        String idxVal = param.substring(3, commaIdx),
             pdxVal = param.substring(commaIdx + 1, param.length() - 1);
        int idx = Integer.parseInt(idxVal);
        int pdx = Integer.parseInt(pdxVal);
        parameters.add(new PositionOp(idx, pdx, PositionType.GLOBAL));
        
      } else if (param.equals("LPos")) {
        // Parse Robot Point operand (cartesian)
        parameters.add(new RobotPositionOp(true));
        
      } else if (param.equals("LPos")) {
        // Parse Robot Point operand (joint)
        parameters.add(new RobotPositionOp(false));
        
      } else if (Pattern.matches("LPos\\[[0123456789]+\\]", param)) {
        // Parse Robot Point operand (cartesian, value)
        String pdxVal = param.substring(5, param.length() - 1);
        int pdx = Integer.parseInt(pdxVal);
        parameters.add(new RobotPositionOp(pdx, true));
        
      } else if (Pattern.matches("JPos\\[[0123456789]+\\]", param)) {
        // Parse Robot Point operand (joint, value)
        String pdxVal = param.substring(5, param.length() - 1);
        int pdx = Integer.parseInt(pdxVal);
        parameters.add(new RobotPositionOp(pdx, false));
        
      } else {
        // Parse Floating-point value
        try {
          float val = Float.parseFloat(param);
          parameters.add(new ConstantOp(val));
          
        } catch (NumberFormatException NFEx) {
          throw new IllegalArgumentException( String.format("'%s' is not valid parameter type!", param.toString()) );
        }
      }
    }
  }
  
  /**
   * Creates an expression with the given set of operands and operators.
   */
  public RegisterExpression(Object... params) {
    parameters = new ArrayList<Object>();
    
    for (Object param : params) {
      addParameter(param);
    }
  }
  
  /**
   * Adds the given parameter to the end of this expression
   */
  public void addParameter(Object param) {
    
    if (param instanceof SubExpression) {
      // Add a copy of the given SubExpression
      parameters.add( ((SubExpression)param).clone() );
    } else if (param instanceof Operand || param instanceof Operator) {
      parameters.add(param);
    }
  }
  
  /**
   * Adds the given parameter to the index in the expression
   */
  public void addParameter(int idx, Object param) {
    
    if (param instanceof SubExpression) {
      // Add a copy of the given SubExpression
      parameters.add(idx, ((SubExpression)param).clone() );
    } else if (param instanceof Operand || param instanceof Operator) {
      parameters.add(idx, param);
    }
  }
  
  /**
   * Sets the parameter at the given index to the given
   * new pararmeter, in the expression.
   */
  public Object setParameter(int idx, Object param) {
    return parameters.set(idx, param);
  }
  
  /**
   * Removes the parameter at the given index from the expression
   */
  public Object removeParameter(int idx) {
    return parameters.remove(idx);
  }
  
  /**
   * This method will calculate the result of the current expression. The
   * expression is evaluated from left to right, ignoring normal order of
   * operations, however, parenthesis do act as normal. Each element is parsed
   * individually, keeping track of a current resulting value for every single
   * operation.
   * If an open parenthesis is found, then the current working
   * result is saved on the stack and the value is reset.
   * If an operator is found, then the next value in the list is taken and the
   * operator's operation is preformed on the current working result and the
   * next value.
   * If a closed parenthesis is found, then the current top of the stack value
   * is taken off of the stack, the next operator is taken from the list of
   * parameters, and its operation is preformed on the popped value and the
   * working result.
   * 
   * @return
   *
   * Once the entire expression is processed and no errors are found, the result
   * of the expression is returned as either a Floating-point value or a RegStmtPoint
   * Object, depending on the nature of the expression.
   *
   * @throw ExpressionEvaluationException
   * 
   * Since, the expressions are only evaluated when a program is executed, it
   * is possible that the expression may contain errors such as mssing arguments,
   * invalid operation arguments, and so on. So, these errors are caught by this
   * method and a new ExpressionEvaluationException is thrown with an error message
   * indicating what the error was. 
   */
  public Object evaluate() throws ExpressionEvaluationException {
    // Empty expression
    if (parameters.size() == 0) { return null; }

    try {
      int pdx = 0,
          len = parameters.size();
      Stack<Object> savedOps = new Stack<Object>();
      Object result = null;
      Operator op = Operator.PAR_OPEN;

      while (true) {
        Object param = parameters.get(pdx++);

        while (param == Operator.PAR_OPEN) {
          // Save current result and operator, when entering parenthesis
          savedOps.push(result);
          savedOps.push(op);
          result = null;
          op = Operator.PAR_OPEN;

          param = parameters.get(pdx++);
        }

        if (op == Operator.PAR_OPEN) {
          // Reset result, when entering parenthesis
          result = ((Operand)param).getValue();
        } else {
          result = evaluateOperation(result, ((Operand)param).getValue(), op);
        }

        if (pdx == len) {
          // Operand ends the expression
          return result;
        }

        op = (Operator)( parameters.get(pdx++) );

        while (op == Operator.PAR_CLOSE) {
          // Remove and evaluate saved value-operator pairs, when exiting parenthesis
          param = savedOps.pop();

          if (param == Operator.PAR_OPEN) {
            // Initial/Nested open parenthesis
            param = savedOps.pop();
          } else {
            // Previous result and operator exists
            result = evaluateOperation(savedOps.pop(), result, (Operator)param);
          }
          
          if (pdx == len) {
            // Parenthesis ends the expression
            return result;
          }

          op = (Operator)( parameters.get(pdx++) );
        }
      }
      
    } catch (NullPointerException NPEx) {
      // Missing a parameter
      throw new ExpressionEvaluationException(0, NPEx.getClass());

    } catch (IndexOutOfBoundsException IOOBEx) {
      // Invalid register index or missing parameter
      throw new ExpressionEvaluationException(0, IOOBEx.getClass());

    } catch (ClassCastException CCEx) {
      // Illegal parameters or operations
      throw new ExpressionEvaluationException(1, CCEx.getClass());

    } catch (ArithmeticException AEx) {
      // Illegal parameters or operations
      throw new ExpressionEvaluationException(2, AEx.getClass());

    } catch (EmptyStackException ESEx) {
      // Invalid parenthesis
      throw new ExpressionEvaluationException(3, ESEx.getClass());
      
    }
  }
  
  /**
   * Evaluate the given parameters with the given operation. The only valid parameters are floating-point values
   * and int arrays. The integer arrays should singeltons (for Registers) or tripletons (for Position Registers
   * and Position Register Values).
   * 
   * @param param1  The first parameter of the opertion
   * @param param2  The second parameter for the operation
   * @param op      The operation to preform on the parameters
   * @return        The result of the operation on param1 and param2
   * 
   * @throws ExpressionEvaluationException  if the given combination of parameters with the given
   *                                        operation is illegal
   */
  private Object evaluateOperation(Object a, Object b, Operator op) {
    if (a instanceof Float && b instanceof Float) {
      // Float-Float operation
      return evaluateFloatOperation((Float)a, (Float)b, op);
    } else if (a instanceof Point && b instanceof Point) {
      // Point-Point operation
      return evaluePointOperation((RegStmtPoint)a, (RegStmtPoint)b, op);
    }
    // Illegal operation
    throw new ExpressionEvaluationException(4);
  }
  
  private Float evaluateFloatOperation(Float a, Float b, Operator op) {
    // Float-to-Float operations
      switch(op) {
        case ADDTN:  return a + b;
        case SUBTR:  return a - b;
        case MULT:   return a * b;
        case DIV:    return a / b;
        case MOD:    return a % b;
        case INTDIV: return new Float(a.intValue() / b.intValue());
        default:
      }
      // Illegal operator
      throw new ExpressionEvaluationException(5);
  }
  
  private RegStmtPoint evaluePointOperation(RegStmtPoint a, RegStmtPoint b, Operator op) {
    // Point-to-Point operations
    switch(op) {
        case ADDTN:
          return a.add(b);
        case SUBTR:
          return a.subtract(b);
        default:
      }
      // Illegal operator
      throw new ExpressionEvaluationException(6);
  }
  
  /**
   * Returns the number of operators AND operands in the expression
   */
  public int parameterSize() { return parameters.size(); }
  
  /**
   * Returns a list of the parameters in the expression, each in the
   * form of a String and occupying individual elements in the list.
   * 
   * @returning  The list of parameters in the form of Strings
   */
  public ArrayList<String> toStringArrayList() {
    ArrayList<String> paramList = new ArrayList<String>();
    
    for (Object param : parameters) {
      
      if (param == null) {
        paramList.add("_");
      } else {
        paramList.add(param.toString());
      }
    }
    
    return paramList;
  }
  
  /**
   * Copies the current expression (cloning sub expressions) and
   * returns the a new Expression with the duplicate set of parameters.
   * 
   * @returning  A copy of the this expression
   */
  public RegisterExpression clone() {
    RegisterExpression copy = new RegisterExpression();
    
    for (Object param : parameters) {
      
      if (param instanceof Operand) {
        copy.addParameter(((Operand)param).clone());
      } else {
        copy.addParameter(param);
      }
    }
    
    return copy;
  }
  
  public String toString() {
    String expressionString = new String();
    ArrayList<String> paramSet = toStringArrayList();
    
    for (int pdx = 0; pdx < paramSet.size(); ++pdx) {
      // Combine the list of parameter Strings, separating each by a single space
      expressionString += paramSet.get(pdx);
      
      if (pdx < (paramSet.size() - 1)) {
        expressionString += " ";
      }
    }
    
    return expressionString;
  }
}

public interface Operand {
  /* Should return either a Float or RegStmtPoint Object */
  public abstract Object getValue();
  /* Return an independent replica of this object */
  public abstract Operand clone();
}

/**
 * A operand that represents a floating-point contant value.
 */
public class ConstantOp implements Operand {
  private final float value;
  
  public ConstantOp() {
    value = 0f;
  }
  
  public ConstantOp(float val) {
    value = val;
  }
  
  public Object getValue() { return new Float(value); }
  
  public Operand clone() {
    return new ConstantOp(value);
  }
  
  public String toString() {
    return String.format("%4.3f", value);
  }
}

/**
 * A operand that represents a specific register entry.
 */
public class RegisterOp implements Operand {
  private final int listIdx;
  
  public RegisterOp() {
    listIdx = 0;
  }
  
  public RegisterOp(int i) {
    listIdx = i;
  }
  
  public Object getValue() {
    return DREG[listIdx];
  }
  
  public int getIdx() { return listIdx; }
  
  public Operand clone() {
    return new RegisterOp(listIdx);
  }
  
  public String toString() {
    return String.format("R[%d]", listIdx);
  }
}

/**
 * A operand that can represent either the joint angles or cartesian values
 * stored in a position register entry, or a specific value of that position,
 * from either the global Position Registers or the local positions of the active program.
 */
public class PositionOp extends RegisterOp {
  private final int posIdx;
  /* Determines whether a global Position register or a local position will be used */
  private final PositionType type;
  
  public PositionOp() {
    super(0);
    posIdx = -1;
    type = PositionType.LOCAL;
  }
  
  public PositionOp(int ldx, PositionType t) {
    super(ldx);
    posIdx = -1;
    type = t;
  }
  
  public PositionOp(int ldx, int pdx, PositionType t) {
    super(ldx);
    posIdx = pdx;
    type = t;
  }
  
  public int getPositionIdx() { return posIdx; }
  public PositionType getPositionType() { return type; }
  
  public Object getValue() {
    RegStmtPoint pt;
    
    if (type == PositionType.LOCAL) {
      // Use local position
      Program current = activeProgram();
      // TODO Use joint angles?
      pt = new RegStmtPoint( current.LPosReg[getIdx()], true);
    } else if (type == PositionType.GLOBAL) {
      // global Position register
      pt = new RegStmtPoint( GPOS_REG[getIdx()].point, GPOS_REG[getIdx()].isCartesian );
    } else {
      // Not a valid type
      return null;
    }
    
    if (posIdx == -1) {
      // Use the whole Point
      return pt;
    } else {
      // Use a specific value of the Point
      return pt.getValue(posIdx);
    }
  }
  
  public Operand clone() {
    return new PositionOp(getIdx(), posIdx, type);
  }
  
  public String toString() {
    if (posIdx == -1) {
      
      if (type == PositionType.GLOBAL) {
        return String.format("PR[%d]", getIdx());
      } else {
        return String.format("P[%d]", getIdx());
      }
    } else {
      
      if (type == PositionType.GLOBAL) {
        return String.format("PR[%d]", getIdx());
      } else {
        return String.format("P[%d, %d]", getIdx(), posIdx);
      }
    }
  }
}

/**
 * An operand thaht represents the current position and orientation of the Robot,
 * or its joint Angles, or a specific value of either point.
 */
public class RobotPositionOp implements Operand {
  /**
   * The value of valIdx corresponds to:
   *   -1     ->  The point itself
   *   0 - 5  ->  J1 - J6
   *   6 - 11 ->  X, Y, Z, W, P, R
   */
  private final int valIdx;
  private final boolean isCartesian;

  /**
   * Default to the entire point
   */
  public RobotPositionOp(boolean cartesian) {
    valIdx = -1;
    isCartesian = cartesian;
  }
  
  /**
   * Specific the index of the value of the point
   */
  public RobotPositionOp(int vdx, boolean cartesian) {
    valIdx = vdx;
    isCartesian = cartesian;
  }
  
  /**
   * Return the current position of the Robot or a specific value of the current position of
   * the Robot
   */
  public Object getValue() {
    Point RP = nativeRobotEEPoint(armModel.getJointAngles());
    RegStmtPoint pt = new RegStmtPoint(RP, isCartesian);
    
    if (valIdx == -1) {
      // Return the entire point
      return pt;
    } else {
      // Return a specific value of the point
      return pt.values[ valIdx ];
    }
  }
  
  public Operand clone() {
    return new RobotPositionOp(valIdx, isCartesian);
  }
  
  public String toString() {
    
    if (valIdx == -1) {
      if (isCartesian) {
        return String.format("LPos");
      } else {
        return String.format("JPos");
      }
    } else {
      // Only show index if the whole point is not used
      if (isCartesian) {
        return String.format("LPos[%d]", valIdx);
      } else {
        return String.format("JPos[%d]", valIdx);
      }
    }
  }
}

/**
 * Store a separate expression nested inside another expression as an operand
 */
public class SubExpression implements Operand {
  private final RegisterExpression expr;
  
  public SubExpression() {
    expr = new RegisterExpression();
    expr.addParameter(new ConstantOp(1));
  }
  
  public SubExpression(Object... params) {
    expr = new RegisterExpression(params);
  }
  
  public Object getValue() throws ExpressionEvaluationException { return expr.evaluate(); }
  
  public Operand clone() {
    // Copy the expression into a new Sub Expression
    return new SubExpression(expr.clone());
  }
  
  public String toString() {
    return String.format("[ %s ]", expr.toString());
  }
}

/**
 * This class defines a Point, which stores a position and orientation
 * in space (X, Y, Z, W, P, R) or the joint angles (J1 - J6) necessary
 * for the Robot to reach the position and orientation of the register point.
 * 
 * This class is designed to temporary store the values of a Point object
 * in order to bypass multiple conversion between Euler angles and
 * Quaternions during the evaluation of Register Statement Expressions.
 */
public class RegStmtPoint {
  
  /**
   * The values associated with a register point:
   * 
   * For a Cartesian point:
   *   0, 1, 2 -> X, Y, Z
   *   3. 4, 5 -> W, P, R
   * 
   * For a Joint point:
   *   0 - 5 -> J1 - J6
   */
  private final float[] values;
  private boolean isCartesian;
  
  public RegStmtPoint() {
    values = new float[] { 0f, 0f, 0f, 0f, 0f, 0f };
    isCartesian = false;
  }
  
  public RegStmtPoint(float[] iniValues, boolean cartesian) {
    if (iniValues.length < 6) {
      // Not valid input values
      values = new float[] { 0f, 0f, 0f, 0f, 0f, 0f };
    } else {
      // Copy initial values
      values = Arrays.copyOfRange(iniValues, 0, 6);
    }
    
    isCartesian = cartesian;
  }
  
  public RegStmtPoint(Point initial, boolean cartesian) {
    values = new float[6];
    isCartesian = cartesian;
    // Conver to W, P, R values
    PVector wpr = quatToEuler(initial.orientation);
    // Copy values into this point
    values[0] = initial.position.x;
    values[1] = initial.position.x;
    values[2] = initial.position.x;
    values[3] = wpr.x;
    values[4] = wpr.y;
    values[5] = wpr.z;
  }
  
  public Float getValue(int val) {
    if (val < 0 || val >= values.length) {
      // Not a valid index
      return null;
    }
    // Return value associated with the index
    return new Float(values[val]);
  }
  
  public void setValue(int val, float newVal) {
    if (val >= 0 && val < values.length) {
      // Set the specified entry to the given value
      values[val] = newVal;
    }
  }
  
  public boolean isCartesian() { return isCartesian; }
  
  public RegStmtPoint add(RegStmtPoint pt) {
    if (pt == null || pt.isCartesian() != isCartesian) {
      // Must be the same type of point
      return null;
    }
    
    float[] sums = new float[6];
    // Compute sums
    for (int pdx = 0; pdx < values.length; ++pdx) {
      sums[pdx] = values[pdx] + pt.getValue(pdx);
    }
    
    return new RegStmtPoint(sums, isCartesian);
  }
  
  public RegStmtPoint subtract(RegStmtPoint pt) {
    if (pt == null || pt.isCartesian() != isCartesian) {
      // Must be the same type of point
      return null;
    }
    
    float[] differences = new float[6];
    // Compute sums
    for (int pdx = 0; pdx < values.length; ++pdx) {
      differences[pdx] = values[pdx] - pt.getValue(pdx);
    }
    
    return new RegStmtPoint(differences, isCartesian);
  }
  
  public Point toPoint() {
    
    if (isCartesian) {
      PVector position = new PVector(values[0], values[1], values[2]),
              wpr = new PVector(values[3], values[4], values[5]);
              // Convet back to quaternion
      float[] orientation = eulerToQuat(wpr);
      // TODO initialize angles?
      return new Point(position, orientation);
    } else {
      // Use forward kinematics to find the position and orientation of the joint angles
      return nativeRobotEEPoint(values);
    }
  }
  
  /**
   * Returns an independent replica of this point object.
   */
  public RegStmtPoint clone() {
    return new RegStmtPoint(values, isCartesian);
  }
  
  public String toString() {
    if (isCartesian) {
      // X, Y, Z, W, P, R
      return String.format("[ %4.3f, %4.3f, %4.3f], [ %4.3f, %4.3f, %4.3f ]",
          values[0], values[1], values[2],
          Math.toDegrees(values[3]), Math.toDegrees(values[4]), Math.toDegrees(values[5]));
    } else {
      // J1 - J6
      return String.format("[ %4.3f, %4.3f, %4.3f, %4.3f, %4.3f, %4.3f ]",
          Math.toDegrees(values[0]), Math.toDegrees(values[1]), Math.toDegrees(values[2]),
          Math.toDegrees(values[3]), Math.toDegrees(values[4]), Math.toDegrees(values[5]));
    }
  }
}

/**
 * This class defines an error that occurs during the evaluation process of an ExpressionSet Object.
 */
public class ExpressionEvaluationException extends RuntimeException {
  
  public ExpressionEvaluationException(int flag, Class exception) {
    super( String.format("Error: %d (%s)", flag, exception.toString()) );
  }
  
  /**
   * TODO constructor comment
   */
  public ExpressionEvaluationException(int flag) {
    // TODO develop message for expression parsing error
    super( String.format("Error: %d", flag) );
  }
}

public interface ExpressionElement {
  //operator types
  public static final int ARITH_OP = 0;
  public static final int BOOL_OP = 1;
  
  //operand types
  public static final int UNINIT = -2;
  public static final int SUBEXP = -1;
  public static final int FLOAT = 0;
  public static final int BOOL = 1;
  public static final int DREG = 2;
  public static final int IOREG = 3;
  public static final int PREG = 4;
  public static final int PREG_IDX = 5;
  public static final int POSTN = 6;
  
  public abstract int getLength();
  public abstract String toString();
  public abstract String[] toStringArray();
}

public class ExprOperand implements ExpressionElement {
  protected int type;
  
  Float dataVal = null;
  Boolean boolVal = null;
  int regIdx = -1;
  int posIdx = 0;
  Register regVal = null;
  Point pointVal = null;
  
  //default constructor
  public ExprOperand() {
    type = ExpressionElement.UNINIT;
  }
  
  //initialize all fields, useful for cloning
  public ExprOperand(int t, float d, boolean b, int rIdx, int pIdx, Register reg, Point p) {
    type = t;
    dataVal = d;
    boolVal = b;
    regIdx = rIdx;
    posIdx = pIdx;
    regVal = reg;
    pointVal = p;
  }
  
  //create floating point operand
  public ExprOperand(float d) {
    type = ExpressionElement.FLOAT;
    dataVal = d;
  }
  
  //create boolean operand
  public ExprOperand(boolean b) {
    type = ExpressionElement.BOOL;
    boolVal = b;
  }
  
  //create data register operand
  public ExprOperand(DataRegister dReg, int i) {
    type = ExpressionElement.DREG;
    regIdx = i;
    regVal = dReg;
  }
  
  //create IO register operand
  public ExprOperand(IORegister ioReg, int i) {
    type = ExpressionElement.IOREG;
    regIdx = i;
    regVal = ioReg;
  }
  
  //create position register operand
  public ExprOperand(PositionRegister pReg, int i){
    type = ExpressionElement.PREG;
    regIdx = i;
    regVal = pReg;
  }
  
  //create position register operand on a given value of the register's position
  public ExprOperand(PositionRegister pReg, int i, int j){
    type = ExpressionElement.PREG_IDX;
    regIdx = i;
    posIdx = j;
    regVal = pReg;
  }
  
  //create point operand (used during evaulation only) 
  public ExprOperand(Point p) {
    type = ExpressionElement.POSTN;
    pointVal = p;
  }
  
  public Float getDataVal() {
    if(type == ExpressionElement.FLOAT) {
      return dataVal;
    } else if(type == ExpressionElement.DREG) {
      return ((DataRegister)regVal).value;
    } else if(type == ExpressionElement.PREG_IDX) {
      return ((PositionRegister)regVal).getPointValue(posIdx);
    } else {
      return null;
    }
  }
  
  public Boolean getBoolVal() {
    if(type == ExpressionElement.BOOL) {
      return boolVal;
    } else if(type == ExpressionElement.IOREG) {
      return (((IORegister)regVal).state == ON);
    } else {
      return null;
    }
  }
  
  public Point getPointVal() {
    if(type == ExpressionElement.PREG) {
      return ((PositionRegister)regVal).point;
    } else if(type == ExpressionElement.POSTN) {
      return pointVal;
    } else {
      return null;
    }
  }
  
  public ExprOperand set(float d) {
    type = ExpressionElement.FLOAT;
    dataVal = d;
    return this;
  }
  
  public ExprOperand set(boolean b) {
    type = ExpressionElement.BOOL;
    boolVal = b;
    return this;
  }
  
  public ExprOperand set(DataRegister dReg, int i) {
    type = ExpressionElement.DREG;
    regIdx = i;
    regVal = dReg;
    return this;
  }
  
  public ExprOperand set(IORegister ioReg, int i) {
    type = ExpressionElement.IOREG;
    regIdx = i;
    regVal = ioReg;    
    return this;
  }
  
  public ExprOperand set(PositionRegister pReg, int i) {
    type = ExpressionElement.PREG;
    regIdx = i;
    regVal = pReg;
    return this;
  }

  public ExprOperand set(PositionRegister pReg, int i, int j) {
    type = ExpressionElement.PREG;
    regIdx = i;
    posIdx = j;
    regVal = pReg;
    return this;
  }
  
  public ExprOperand set(Point p) {
    type = ExpressionElement.POSTN;
    pointVal = p;
    return this;
  }
  
  public ExprOperand reset() {
    type = ExpressionElement.UNINIT;
    regIdx = -1;
    regVal = null;
    pointVal = null;
    return this;
  }
  
  public int getLength() {
    return (type == PREG_IDX) ? 2 : 1;
  }
  
  public ExprOperand clone() {
    return new ExprOperand(type, dataVal, boolVal, regIdx, posIdx, regVal, pointVal);
  }
  
  public String toString(){
    String s = "";
    switch(type){
      case UNINIT:
        s = "...";
        break;
      case SUBEXP: 
        s = ((AtomicExpression)this).toString();
        break;
      case FLOAT:
        s += dataVal;
        break;
      case BOOL:
        s += boolVal ? "TRUE" : "FALSE";
        break;
      case DREG:
        String rNum = (regIdx == -1) ? "..." : ""+regIdx;
        s += "R[" + rNum + "]";
        break;
      case IOREG:
        rNum = (regIdx == -1) ? "..." : ""+regIdx;
        s += "IO[" + rNum + "]";
        break;
      case PREG:
        rNum = (regIdx == -1) ? "..." : ""+regIdx;
        s += "PR[" + rNum + "]";
        break;
      case PREG_IDX:
        rNum = (regIdx == -1) ? "..." : ""+regIdx;
        String pIdx = (posIdx == -1) ? "..." : ""+posIdx;
        s += "PR[" + rNum + ", " + pIdx + "]";
        break;
    }
    
    return s;
  }
  
  public String[] toStringArray() {
    if(type == PREG_IDX) {
      String rNum = (regIdx == -1) ? "..." : ""+regIdx;
      String pIdx = (posIdx == -1) ? "..." : ""+posIdx;
      
      return new String[] { "PR[" + rNum, pIdx + "]" };
    } else {
      return new String[] { this.toString() };
    }
  }
}

public class AtomicExpression extends ExprOperand {
  protected ExprOperand arg1;
  protected ExprOperand arg2;
  protected Operator op;
    
  public AtomicExpression(){
    type = ExpressionElement.SUBEXP;
    op = Operator.UNINIT;
    arg1 = new ExprOperand();
    arg2 = new ExprOperand();
  }
  
  public AtomicExpression(Operator o){
    type = ExpressionElement.SUBEXP;
    op = o;
    arg1 = new ExprOperand();
    arg2 = new ExprOperand();
  }
  
  public AtomicExpression(Operator o, ExprOperand a1, ExprOperand a2) {
    type = ExpressionElement.SUBEXP;
    op = o;
    arg1 = a1;
    arg2 = a2;
  }
  
  public ExprOperand getArg1() { return arg1; }
  public ExprOperand setArg1(ExprOperand a) { 
    arg1 = a;
    return arg1;
  }
  
  public ExprOperand getArg2() { return arg2; }
  public ExprOperand setArg2(ExprOperand a) { 
    arg2 = a;
    return arg2;
  }
  
  public ExprOperand setArg(ExprOperand a, int argNo) {
    if(argNo == 1) {
      return setArg1(a);
    } else {
      return setArg2(a);
    }
  }
  
  public Operator getOperator() { return op; }
  public void setOperator(Operator o) {
    op = o;
  }
  
  public int getLength() {
    if(op == Operator.UNINIT) {
      return 1;    
    }
    
    int ret = 1;
    ret += arg1.getLength();
    ret += arg2.getLength();
    ret += (arg1.type == -1) ? 2 : 0;
    ret += (arg2.type == -1) ? 2 : 0;
    return ret;
  }
  
  public ExprOperand evaluate() {
    ExprOperand result;
    int t1 = arg1.type;
    int t2 = arg2.type;
    //operation return type:
    // -1 = uninit, 0 = float,
    // 1 = boolean, 2 = point
    int opType = -1;
    Float o1 = null, o2 = null; //floating point operand values
    Boolean b1 = null, b2 = null; //boolean operand values
    Point p1 = null, p2 = null; //point operand values
    
    //evaluate any sub-expressions
    if(t1 == -1) {
      arg1 = ((AtomicExpression)arg1).evaluate();
      t1 = arg1.type;
    }
    
    if(t2 == -1) {
      arg2 = ((AtomicExpression)arg2).evaluate();
      t2 = arg2.type;
    }
    
    //check for type compatability
    if(t1 == ExpressionElement.UNINIT || t2 == ExpressionElement.UNINIT) {
      return null;
    } 
    else if(t1 == ExpressionElement.FLOAT || t1 == ExpressionElement.DREG || t1 == ExpressionElement.PREG_IDX) {
      opType = 0;
      println(arg1.toString());
      o1 = arg1.getDataVal();
      
      switch(t2) {
        case ExpressionElement.BOOL:
        case ExpressionElement.IOREG:
        case ExpressionElement.PREG:
        case ExpressionElement.POSTN:
          return null;
        default:
          o2 = arg2.getDataVal();
      }
    }
    else if(t1 == ExpressionElement.BOOL || t1 == ExpressionElement.IOREG) {
      opType = 1;
      b1 = arg1.getBoolVal();
      
      switch(t2) {
        case ExpressionElement.FLOAT:
        case ExpressionElement.DREG:
        case ExpressionElement.PREG:
        case ExpressionElement.PREG_IDX:
        case ExpressionElement.POSTN:
          return null;
        default:
          b2 = arg2.getBoolVal();
      }
    }
    else if(t1 == ExpressionElement.PREG || t1 == ExpressionElement.POSTN) {
      opType = 2;
      p1 = arg1.getPointVal();
      
      switch(t2) {
        case ExpressionElement.FLOAT:
        case ExpressionElement.BOOL:
        case ExpressionElement.DREG:
        case ExpressionElement.IOREG:
        case ExpressionElement.PREG_IDX:
          return null;
        default:
          p2 = arg2.getPointVal();
      }
    }
    
    if(opType == 0) {
      if(o1 == null || o2 == null) return null;
      
      //integer operands for integer operations
      int intop1 = Math.round(o1);
      int intop2 = Math.round(o2);
     
      switch(op) {
        case ADDTN:
          result = new ExprOperand(o1 + o2);
          break;
        case SUBTR:
          result = new ExprOperand(o1 - o2);
          break;
        case MULT:
          result = new ExprOperand(o1 * o2);
          break;
        case DIV:
          result = new ExprOperand(o1 / o2);
          break;
        case MOD:
          result = new ExprOperand(o1 % o2);
          break;
        case INTDIV:
          result = new ExprOperand(intop1 / intop2);
          break;
        case EQUAL:
          result = new ExprOperand(o1 == o2);
          break;
        case NEQUAL:
          result = new ExprOperand(o1 != o2);
          break;
        case GRTR:
          result = new ExprOperand(o1 > o2);
          break;
        case LESS:
          result = new ExprOperand(o1 < o2);
          break;
        case GREQ:
          result = new ExprOperand(o1 >= o2);
          break;
        case LSEQ:
          result = new ExprOperand(o1 <= o2);
          break;
        default:
          result = null;
          break;
      }
    }
    else if(opType == 1) {
      if(b1 == null || b2 == null) return null;
      
      switch(op) {
       case EQUAL:
          result = new ExprOperand(b1 == b2);
          break;
        case NEQUAL:
          result = new ExprOperand(b1 != b2);
          break;
        case AND:
          result = new ExprOperand(b1 && b2);
        case OR:
          result = new ExprOperand(b1 || b2);
        default:
          result = null;
          break;
      }
    }
    else if(opType == 2) {
      if(p1 == null || p2 == null) return null;
      
      switch(op) {
       case ADDTN:
          result = new ExprOperand(p1.add(p2));
          break;
        case SUBTR:
          result = new ExprOperand(p1.add(p2.negate()));
          break;
        default:
          result = null;
          break;
      }
    }
    else {
      result = null;
    }
    
    println("from AE:" + o1 + op.toString() + o2 + " = " + result.dataVal);
    return result;
  }
  
  public String toString(){
    String s = "";
    
    if(op == Operator.UNINIT){
      return "...";
    }
    
    if(arg1 instanceof AtomicExpression)
      s += "(" + arg1.toString() + ")";
    else 
      s += arg1.toString();
      
    s += " " + op.symbol + " ";
    
    if(arg2 instanceof AtomicExpression)
      s += "(" + arg2.toString() + ")";
    else 
      s += arg2.toString();
    
    return s;
  }
  
  public String[] toStringArray() {
    String[] s1, s2, ret;
    String opString = "";
    
    if(op == Operator.UNINIT) {
      return new String[]{"..."};
    }
    
    s1 = arg1.toStringArray();
    opString += " " + op.symbol + " ";
    s2 = arg2.toStringArray();
    
    int lm1 = (arg1 != null && arg1.type == -1) ? 2 : 0;
    int lm2 = (arg2 != null && arg2.type == -1) ? 2 : 0;
    ret = new String[s1.length + s2.length + 1 + lm1 + lm2];
    
    if(lm1 != 0) {
      ret[0] = "(";
      ret[s1.length + 1] = ")";
    }
    
    ret[s1.length + lm1] = opString;
    
    if(lm2 != 0) {
      ret[s1.length + lm1 + 1] = "(";
      ret[ret.length - 1] = ")";
    }
    
    for(int i = lm1/2; i < ret.length; i += 1) {
      if(ret[i] == null) {
        if(i < s1.length + lm1/2) {
          ret[i] = s1[i - lm1/2];
        }
        else {
          ret[i] = s2[i - s1.length - lm1 - 1 - lm2/2];
        }
      }
    }
    
    return ret;
  }
}

public class Expression extends AtomicExpression {
  private ArrayList<ExpressionElement> elementList;
  
  public Expression() {
    elementList = new ArrayList<ExpressionElement>();
    elementList.add(new ExprOperand());
  }
  
  public ExpressionElement get(int idx) {
    return elementList.get(idx);
  }
  
  public ExprOperand getOperand(int idx) {
    if(elementList.get(idx) instanceof ExprOperand)
      return (ExprOperand)elementList.get(idx);
    else
      return null;
  }
  
  public Operator getOperator(int idx) {
    if(elementList.get(idx) instanceof Operator)
      return (Operator)elementList.get(idx);
    else
      return null;
  }
  
  public ExprOperand setOperand(int idx, ExprOperand o) {
    if(elementList.get(idx) instanceof ExprOperand) {
      elementList.set(idx, o);
      return (ExprOperand)elementList.get(idx);
    }
    else {
      return null;
    }
  }
  
  public Operator setOperator(int idx, Operator o) {
    if(elementList.get(idx) instanceof Operator) {
      elementList.set(idx, o);
      return (Operator)elementList.get(idx); 
    }
    else {
      return null;
    }
  }
  
  public void insertElement(int edit_idx) {
    //limit number of elements allowed in this expression
    if(getLength() >= 21) return;
    //ensure index is within the bounds of our list of elements
    else if(edit_idx < -1) return;
    else if(edit_idx >= getLength() - 2) return;
    
    if(edit_idx == -1) {
      if(elementList.get(0) instanceof ExprOperand) {
        elementList.add(0, Operator.UNINIT);
      } else {
        elementList.add(0, new ExprOperand());
      }
    }
    else {
      int[] elements = mapToEdit();
      int start_idx = getStartingIdx(elements[edit_idx]);
      ExpressionElement e = elementList.get(elements[edit_idx]);
      
      if(e instanceof Expression && (edit_idx != start_idx + e.getLength() - 1)) {
        edit_idx -= (start_idx + 1);
        ((Expression)e).insertElement(edit_idx);
      } 
      else {
        if(e instanceof ExprOperand) {
          elementList.add(elements[edit_idx] + 1, Operator.UNINIT);
        } else {
          elementList.add(elements[edit_idx] + 1, new ExprOperand());
        }
      }
    }
  }
  
  public void removeElement(int edit_idx) {
    if(elementList.size() > 1) {
      int[] elements = mapToEdit();
      int start_idx = getStartingIdx(elements[edit_idx]);
      ExpressionElement e = elementList.get(elements[edit_idx]);
      
      if(e instanceof Expression) {
        if(edit_idx == start_idx || edit_idx == start_idx + e.getLength() - 1) {
          elementList.remove(elements[edit_idx]);
        } else {
          edit_idx -= (start_idx + 1);
          ((Expression)e).removeElement(edit_idx);
        }
      } 
      else {
        elementList.remove(elements[edit_idx]);
      }
    }
  }
    
  public int getLength() {
    int len = 2;
    for(ExpressionElement e: elementList) {
      len += e.getLength();
    }

    return len;
  }
  
  public ExprOperand evaluate() {
    if(elementList.get(0) instanceof Operator || elementList.size() % 2 != 1) { 
      println("Expression formatting error");
      return null;
    }
    
    ExprOperand result = (ExprOperand)elementList.get(0);    
    for(int i = 1; i < elementList.size(); i += 2) {
      if(!(elementList.get(i) instanceof Operator) || !(elementList.get(i + 1) instanceof ExprOperand)) {
        println("Expression formatting error");
        return null;
      } 
      else {
        Operator op = (Operator) elementList.get(i);
        ExprOperand nextOperand = (ExprOperand) elementList.get(i + 1);
        AtomicExpression expr = new AtomicExpression(op, result, nextOperand);
        
        println(result.getDataVal() + op.toString() + nextOperand.getDataVal() + " = " + expr.evaluate().dataVal);
        result = expr.evaluate();
      }
    }
    
    return result;
  }
  
  public int[] mapToEdit() {
    int[] ret = new int[getLength() - 2];
    int element_start = 0;
    int element_idx = 0;
    
    for(int i = 0; i < ret.length; i += 1) {
      int len = elementList.get(element_idx).getLength();
      ret[i] = element_idx;
      
      if(i - element_start >= len - 1) {
        element_idx += 1;
        element_start = i + 1;
      }
    }
    
    return ret;
  }
  
  public int getStartingIdx(int element) {
    int[] elements = mapToEdit();
    int idx = 0;
    
    while(elements[idx] != element) {
      idx += 1;
    }
    
    return idx;
  }
  
  public String toString() {
    String ret = "(" + elementList.get(0).toString();
    for(int i = 0; i < elementList.size(); i += 1) {
      ret += elementList.get(i).toString();
    }
    
    ret += ")";
    return ret;
  }
  
  public String[] toStringArray() {
    String[] ret = new String[this.getLength()];
    ret[0] = "(";
    
    int idx = 1;
    for(ExpressionElement e: elementList) {
      String[] temp = e.toStringArray();
      for(int i = 0; i < temp.length; i += 1) {
        ret[idx + i] = temp[i];
      }
      idx += temp.length;
    }
    
    ret[ret.length - 1] = ")";
    return ret;
  }
}

public class BooleanExpression extends AtomicExpression {
  public BooleanExpression() {
    super();
  }
  
  public BooleanExpression(Operator o) {
    if(o.type == BOOL) {
      type = -1;
      op = o;
      arg1 = new ExprOperand();
      arg2 = new ExprOperand();
    }
    else {
      type = -1;
      op = Operator.UNINIT;
    }
  }
  
  public void setOperator(Operator o) {
    if(o.type != BOOL) return;
    op = o;
  }
}
private Frame[] toolFrames;
private Frame[] userFrames;

/* The current Coordinate Frame for the Robot */
private CoordFrame curCoordFrame = CoordFrame.JOINT;

private final float[][] WORLD_AXES = new float[][] { { -1,  0,  0 },
                                                     {  0,  0,  1 },
                                                     {  0, -1,  0 } };

public abstract class Frame {
  // The orientation of the frame in the form of a unit quaternion
  private float[] orientation;
  /* The three points used to define a coordinate axis for 6-Point Method
   * of Tool Frames and 3-Point or 4_Point Methods of User Frames */
  protected Point[] axesTeachPoints;
  // For Direct Entry
  protected PVector DEOrigin;
  protected float[] DEOrientation;

  public Frame() {
    orientation = new float[] { 1f, 0f, 0f, 0f };
    axesTeachPoints = new Point[] { null, null, null };
    DEOrigin = null;
    DEOrientation = null;
  }
  
  /**
   * Return the origin of this Frame's coordinate System.
   */
  public abstract PVector getOrigin();
  
  /* Returns a set of axes unit vectors representing the axes
   * of the frame in reference to the Native Coordinate System. */
  public float[][] getNativeAxisVectors() { return quatToMatrix(orientation); }
  /* Returns a set of axes unit vectors representing the axes
   * of the frame in reference to the World Coordinate System. */
  public float[][] getWorldAxisVectors() {
    RealMatrix frameAxes = new Array2DRowRealMatrix(floatToDouble(getNativeAxisVectors(), 3, 3));
    RealMatrix worldAxes = new Array2DRowRealMatrix(floatToDouble(WORLD_AXES, 3, 3));
    
    return doubleToFloat(worldAxes.multiply(frameAxes).getData(), 3, 3);
  }
  
  public float[] getOrientation() { return orientation; }
  
  public float[] getOrientationNegation() {
    return new float[] { orientation[0], -orientation[1], -orientation[2], -orientation[3] };
  }

  public void setOrientation(float[] newAxes) {
    orientation = newAxes;
  }
  
  /**
   * Sets the Frame's point at the given index in its list of taugh points.
   * For a Tool Frame, the list of possible taught points includes the three
   * points for the teaching of the TCP offset as well as the three points
   * for the Coordinate Axes; six points in total. The valid values for indices
   * are as follows:
   * 
   * 0 -> TCP teach point 1
   * 1 -> TCP teach point 2
   * 2 -> TCP teach point 3
   * 3 -> Orient Origin point
   * 4 -> X-Direction point
   * 5 -> Y-Direction point
   * 
   * For a User Frame, the list of possible taugh points includes the three
   * points for the Coordinate Axes as well as the Axes Origin point; four
   * in total. The valid values for index are as follows:
   * 
   * 0 -> Orient Origin point
   * 1 -> X-Direction point
   * 2 -> Y-Direction point
   * 3 -> Axes Origin point
   * 
   * Because the orientation of a point is only necessary for the creation of the
   * TCP offset, the orientation of the given point will be ignored for all other
   * points aside from the TCP teach points and only the position of the point will
   * be recorded.
   * 
   * @param p    A point, which contains the position and orientation of the Robot
   *             at a specific point in space
   * @param idx  The index, at which to save the given point, in the Frame's list
   *             of taught points
   */
  public abstract void setPoint(Point p, int idx);
  
  /**
   * Returns the position of the teach point at the given index in the Frame's list
   * of teach points. Valid indices are described in setPoint().
   */
  public abstract Point getPoint(int idx);
  
  /**
   * Based on value of method, an attempt will be made to set the current origin offset and axes vectors.
   * For the value of method:
   * 0 -> 3-Point Method
   * 1 -> 6-Point Methd for Tool Frames or 4-Point Method for User Frames
   * 2 -> Direct Entry Method
   * 
   * Assuming that all the correct fields have been initialized to values, which will produce valid output,
   * for a given method, then the Frames origin offset and axes vectors are modified to fit the given method.
   * For Tool Frames, the 3-Point method uses the TCPTeacchPoints list exclusively to constuct the TCP offset;
   * the 6-Point Method uses both the TCPTeachPoints list and the axesTeachPoints list. For User Frames, the
   * 3-Point uses the axesTeachPoints list exculsively; the 4-Point Method uses both the axesTeachPoint list
   * as well as the orientOrigin point. For either Tool or User Frames, the Direct Entry Method uses the
   * DEOrigin opint and the DEAxesOffsets array.
   * 
   * @param method  an integer between 0-2, which determines, which teaching method will be used to contruct
   *                the Frame
   * @returning     If the Frame was set or not; it is possible that some of the fields are not initialized or
   *                will not produce valid output.
   */
  public abstract boolean setFrame(int method);
  
  /**
   * This method calculates a TCP offset for the Robot given a valid set of position and orientation values, where each pair ( [pos, ori1],
   * [pos2, ori2], and [pos3, ori3] ) represent a recorded position and orientation of the Robot. A position contains the X, Y, Z values of
   * the Robot at the point, while the orientation matrix is a rotation matrix, which describes the Robot's orientation at a one of the points.
   * Do to the nature of this algorithm, an average TCP value is calculated from three separate calculations.
   *
   * @param pos1  The X, Y, Z position of the Robot's faceplate at first point
   * @param ori1  The orientation of the Robot at the first point
   * @param pos2  The X, Y, Z position of the Robot's faceplate at the second point
   * @param ori2  The orientation of the Robot at the second point
   * @param pos3  the X, Y, Z position of the Robot's faceplate at the third point
   * @param ori3  The orientation of the Robot at the third point
   * @return      The new TCP for the Robot, null is returned if the given points
   *              are invalid
   */
  public double[] calculateTCPFromThreePoints(PVector pos1, float[][] ori1, 
                                              PVector pos2, float[][] ori2, 
                                              PVector pos3, float[][] ori3) {
    
    RealVector avg_TCP = new ArrayRealVector(new double[] {0.0f, 0.0f, 0.0f} , false);
    int counter = 3;
    
    while (counter-- > 0) {
      
      RealMatrix Ar = null, Br = null, Cr = null;
      PVector vt = null;
      
      if (counter == 0) {
        /* Case 3: C = point 1 */
        Ar = new Array2DRowRealMatrix(floatToDouble(ori2, 3, 3));
        Br = new Array2DRowRealMatrix(floatToDouble(ori3, 3, 3));
        Cr = new Array2DRowRealMatrix(floatToDouble(ori1, 3, 3));
        /* 2Ct - At - Bt */
        vt = PVector.sub(PVector.mult(pos1, 2), PVector.add(pos2, pos3));
        
      } else if (counter == 1) {
        /* Case 2: C = point 2 */
        Ar = new Array2DRowRealMatrix(floatToDouble(ori3, 3, 3));
        Br = new Array2DRowRealMatrix(floatToDouble(ori1, 3, 3));
        Cr = new Array2DRowRealMatrix(floatToDouble(ori2, 3, 3));
        /* 2Ct - At - Bt */
        vt = PVector.sub(PVector.mult(pos2, 2), PVector.add(pos3, pos1));
        
      } else if (counter == 2) {
        /* Case 1: C = point 3 */
        Ar = new Array2DRowRealMatrix(floatToDouble(ori1, 3, 3));
        Br = new Array2DRowRealMatrix(floatToDouble(ori2, 3, 3));
        Cr = new Array2DRowRealMatrix(floatToDouble(ori3, 3, 3));
        /* 2Ct - At - Bt */
        vt = PVector.sub(PVector.mult(pos3, 2), PVector.add(pos1, pos2));
        
      }
      
    /****************************************************************
        Three Point Method Calculation
        
        ------------------------------------------------------------
        A, B, C      transformation matrices
        Ar, Br, Cr   rotational portions of A, B, C respectively
        At, Bt, Ct   translational portions of A, B, C repectively
        x            TCP point with respect to the EE
        ------------------------------------------------------------
        
        Ax = Bx = Cx
        Ax = (Ar)x + At
        
        (A - B)x = 0
        (Ar - Br)x + At - Bt = 0
        
        Ax + Bx - 2Cx = 0
        (Ar + Br - 2Cr)x + At + Bt - 2Ct = 0
        (Ar + Br - 2Cr)x = 2Ct - At - Bt
        x = (Ar + Br - 2Cr) ^ -1 * (2Ct - At - Bt)
        
      ****************************************************************/
      
      RealVector b = new ArrayRealVector(new double[] { vt.x, vt.y, vt.z }, false);
      /* Ar + Br - 2Cr */
      RealMatrix R = ( ( Ar.add(Br) ).subtract( Cr.scalarMultiply(2) ) ).transpose();
      
      /* (R ^ -1) * b */
      avg_TCP = avg_TCP.add( (new SingularValueDecomposition(R)).getSolver().getInverse().operate(b) );
      
      if (DISPLAY_TEST_OUTPUT) {
        System.out.printf("\n%s\n\n", matrixToString( doubleToFloat(R.getData(), 3, 3) ));
      }
    }
    
    /* Take the average of the three cases: where C = the first point, the second point, and the third point */
    avg_TCP = avg_TCP.mapMultiply( 1.0f / 3.0f );
    
    if(DISPLAY_TEST_OUTPUT) {
      System.out.printf("(Ar + Br - 2Cr) ^ -1 * (2Ct - At - Bt):\n\n[%5.4f]\n[%5.4f]\n[%5.4f]\n\n", avg_TCP.getEntry(0), avg_TCP.getEntry(1), avg_TCP.getEntry(2));
    }
    
    for(int idx = 0; idx < avg_TCP.getDimension(); ++idx) {
      // Extremely high values may indicate that the given points are invalid
      if(abs((float)avg_TCP.getEntry(idx)) > 1000.0f) {
        return null;
      }
    }
    
    return avg_TCP.toArray();
  }
  
  /**
   * Creates a 3x3 rotation matrix based off of two vectors defined by the
   * given set of three points, which are defined by the three given PVectors.
   * The three points are used to form two vectors. The first vector is treated
   * as the positive x-axis and the second one is the psuedo-positive y-axis.
   * These vectors are crossed to form the z-axis. The x-axis is then crossed
   * with the positive z-axis to form the true y-axis. Finally, the axes are
   * converted from the World frame reference, to Native Coordinates.
   *
   * @param p1      the origin reference point used to form the positive x-
   *                and y-axes
   * @param p2      the point used to create the preliminary positive x-axis
   * @param p3      the point used to create the preliminary positive y-axis
   * @return        a set of three unit vectors that represent an axes (row
   *                major order)
   */
  public float[][] createAxesFromThreePoints(PVector p1, PVector p2, PVector p3) {
    float[][] axesRefWorld = new float[3][3];
    PVector xAxis = PVector.sub(p2, p1);
    PVector yAxis = PVector.sub(p3, p1);
    PVector zAxis = yAxis.cross(xAxis);
    
    yAxis = xAxis.cross(zAxis);
    // Create unit vectors
    xAxis.normalize();
    yAxis.normalize();
    zAxis.normalize();
    
    if ((xAxis.x == 0f && xAxis.y == 0f && xAxis.z == 0f) ||
        (yAxis.x == 0f && yAxis.y == 0f && yAxis.z == 0f) ||
        (zAxis.x == 0f && zAxis.y == 0f && zAxis.z == 0f)) {
      // One of the three axis vectors is the zero vector
      return null;
    }
    
    axesRefWorld[0][0] = xAxis.x;
    axesRefWorld[0][1] = xAxis.y;
    axesRefWorld[0][2] = xAxis.z;
    axesRefWorld[1][0] = yAxis.x;
    axesRefWorld[1][1] = yAxis.y;
    axesRefWorld[1][2] = yAxis.z;
    axesRefWorld[2][0] = zAxis.x;
    axesRefWorld[2][1] = zAxis.y;
    axesRefWorld[2][2] = zAxis.z;
    
    RealMatrix axes = new Array2DRowRealMatrix(floatToDouble(axesRefWorld, 3, 3)),
               worldAxes =  new Array2DRowRealMatrix(floatToDouble(WORLD_AXES, 3, 3)),
               invWorldAxes = (new SingularValueDecomposition(worldAxes)).getSolver().getInverse();
    // Remove the World frame transformation from the axes vectors
    return doubleToFloat(invWorldAxes.multiply(axes).getData(), 3, 3);
  }

  /**
   * Returns a string array, where each entry is one of
   * the Frames six Cartesian values: (X, Y, Z, W, P,
   * and R) and their respective labels.
   *
   * @return  A 6-element String array
   */
  public abstract String[] toStringArray();
  
  /**
   * Converts the original toStringArray into a 2x1 String array, where the origin
   * values are in the first element and the W, P, R values are in the second
   * element (or in the case of a joint angles, J1-J3 on the first and J4-J6 on
   * the second), where each element has space buffers.
   * 
   * @param displayCartesian  whether to display the joint angles or the cartesian
   *                          values associated with the point
   * @returning               A 2-element String array
   */
  public String[] toLineStringArray() {
    String[] entries = toStringArray();
    String[] line = new String[2];
    // X, Y, Z with space buffers
    line[0] = String.format("%-12s %-12s %s", entries[0], entries[1], entries[2]);
    // W, P, R with space buffers
    line[1] = String.format("%-12s %-12s %s", entries[3], entries[4], entries[5]);
    
    return line;
  }
  
  /**
   * Similiar to toStringArray, however, it converts the Frame's direct entry
   * values instead of the current origin and axes of the Frame.
   * 
   * @returning  A 6x2-element String array
   */
  public String[][] directEntryStringArray() {
    String[][] entries = new String[6][2];
    PVector xyz, wpr;
    
    if (DEOrigin == null) {
      xyz = new PVector(0f, 0f, 0f);
    } else {
      // Use previous value if it exists
      if (this instanceof UserFrame) {
        xyz = convertNativeToWorld(DEOrigin);
      } else {
        // Tool Frame origins are an offset of the Robot's End Effector
        xyz = DEOrigin;
      }
    }
    
    if (DEOrientation == null) {
      wpr = new PVector(0f, 0f, 0f);
    } else {
      // Display axes in World Frame Euler angles, in degrees
      wpr = convertWorldToNative(quatToEuler(DEOrientation)).mult(RAD_TO_DEG);
    }
  
    entries[0][0] = "X: ";
    entries[0][1] = String.format("%4.3f", xyz.x);
    entries[1][0] = "Y: ";
    entries[1][1] = String.format("%4.3f", xyz.y);
    entries[2][0] = "Z: ";
    entries[2][1] = String.format("%4.3f", xyz.z);
    entries[3][0] = "W: ";
    entries[3][1] = String.format("%4.3f", wpr.x);
    entries[4][0] = "P: ";
    entries[4][1] = String.format("%4.3f", wpr.y);
    entries[5][0] = "R: ";
    entries[5][1] = String.format("%4.3f", wpr.z);
    
    return entries;
  }
} // end Frame class

public class ToolFrame extends Frame {
  // The TCP offset associated with this frame
  private PVector TCPOffset;
  // For 3-Point and Six-Point Methods
  private Point[] TCPTeachPoints;
  
  /**
   * Initialize all fields
   */
  public ToolFrame() {
    super();
    TCPOffset = new PVector(0f, 0f, 0f);
    TCPTeachPoints = new Point[] { null, null, null };
  }
  
  public void setPoint(Point p, int idx) {
    
    /* Map the index into the 'Point array' to the
     * actual values stored in the frame */
    switch (idx) {
      case 0:
      case 1:
      case 2:
        TCPTeachPoints[idx] = p;
        return;
        
      case 3:
      case 4:
      case 5:
        axesTeachPoints[ idx % 3 ] = p;
        return;
        
      default:
    }
  }
  
  public Point getPoint(int idx) {
        
    /* Map the index into the 'Point array' to the
     * actual values stored in the frame */
    switch (idx) {
      case 0:
      case 1:
      case 2:
        return TCPTeachPoints[idx];
        
      case 3:
      case 4:
      case 5:
        return axesTeachPoints[ idx % 3 ];
        
      default:
    }
    
    return null;
  }
  
  public boolean setFrame(int method) {
    
    if (method == 2) {
      // Direct Entry Method
      
      if (DEOrigin == null || DEOrientation == null) {
        // No direct entry values have been set
        return false;
      }
      
      setTCPOffset(DEOrigin);
      setOrientation( DEOrientation.clone() );
      return true;
    } else if (method >= 0 && method < 2 && TCPTeachPoints[0] != null && TCPTeachPoints[1] != null && TCPTeachPoints[2] != null) {
      // 3-Point or 6-Point Method
      
      if (method == 1 && (axesTeachPoints[0] == null || axesTeachPoints[1] == null || axesTeachPoints[2] == null)) {
        // Missing points for the coordinate axes
        return false;
      }
      
      float[][] pt1_ori = quatToMatrix(TCPTeachPoints[0].orientation),
                pt2_ori = quatToMatrix(TCPTeachPoints[1].orientation),
                pt3_ori = quatToMatrix(TCPTeachPoints[2].orientation);
      
      double[] newTCP = calculateTCPFromThreePoints(TCPTeachPoints[0].position, pt1_ori,
                                                    TCPTeachPoints[1].position, pt2_ori,
                                                    TCPTeachPoints[2].position, pt3_ori);
      
      float[][] newAxesVectors = (method == 1) ? createAxesFromThreePoints(axesTeachPoints[0].position,
                                                                           axesTeachPoints[1].position,
                                                                           axesTeachPoints[2].position)
                                               : new float[][] { {1, 0, 0}, {0, 1, 0}, {0, 0, 1} };
      
      if (newTCP == null || newAxesVectors == null) {
        // Invalid point set for the TCP or the coordinate axes
        return false;
      }
      
      setTCPOffset( new PVector((float)newTCP[0], (float)newTCP[1], (float)newTCP[2]) );
      setOrientation( matrixToQuat(newAxesVectors) );
      return true;
    }
    
    return false;
  }
  
    /**
   * Returns a string array, where each entry is one of
   * the Tool frame's TCP offset or orientation values:
   * (X, Y, Z, W, P, and R) and their respective labels.
   *
   * @return  A 6-element String array
   */
  public String[] toStringArray() {
    
    String[] values = new String[6];
    
    PVector displayOffset;
    // Convert angles to degrees and to the World Coordinate Frame
    PVector wpr = convertWorldToNative(quatToEuler(getOrientation())).mult(RAD_TO_DEG);
    
    displayOffset = getTCPOffset();
    
    values[0] = String.format("X: %4.3f", displayOffset.x);
    values[1] = String.format("Y: %4.3f", displayOffset.y);
    values[2] = String.format("Z: %4.3f", displayOffset.z);
    values[3] = String.format("W: %4.3f", wpr.x);
    values[4] = String.format("P: %4.3f", wpr.y);
    values[5] = String.format("R: %4.3f", wpr.z);
    
    return values;
  }
  
  /**
   * Tool Frames have no origin offset.
   */
  public PVector getOrigin() { return new PVector(0f, 0f, 0f); }
  
  // Getter and Setter for TCP offset value
  public void setTCPOffset(PVector newOffset) { TCPOffset = newOffset; }
  public PVector getTCPOffset() { return TCPOffset; }
}

public class UserFrame extends Frame {
  private PVector origin;
  // For the 4-Point Method
  private Point orientOrigin;
  
  /**
   * Initialize all fields
   */
  public UserFrame() {
    super();
    origin = new PVector(0f, 0f, 0f);
    orientOrigin = null;
  }
  
  public void setPoint(Point p, int idx) {
    
    /* Map the index into the 'Point array' to the
     * actual values stored in the frame */
    switch(idx) {
      case 0:
      case 1:
      case 2:
        axesTeachPoints[idx] = p;
        return;
        
      case 3:
        orientOrigin = p;
        return;
        
      default:
    }
  }
  
  public Point getPoint(int idx) {
        
    /* Map the index into the 'Point array' to the
     * actual values stored in the frame */
    switch (idx) {
      case 0:
      case 1:
      case 2:
        return axesTeachPoints[idx];
        
      case 3:
        return orientOrigin;
        
      default:
    }
    
    return null;
  }
  
  public boolean setFrame(int mode) {
    
    if (mode == 2) {
      // Direct Entry Method
      
      if (DEOrigin == null || DEOrientation == null) {
        // No direct entry values have been set
        return false;
      }
      
      setOrigin(DEOrigin);
      setOrientation( DEOrientation.clone() );
      return true;
    } else if (mode >= 0 && mode < 2 && axesTeachPoints[0] != null && axesTeachPoints[1] != null && axesTeachPoints[2] != null) {
      // 3-Point or 4-Point Method
      
      PVector newOrigin = (mode == 0) ? new PVector(0f, 0f, 0f) : orientOrigin.position;
      float[][] newAxesVectors = createAxesFromThreePoints(axesTeachPoints[0].position,
                                                           axesTeachPoints[1].position,
                                                           axesTeachPoints[2].position);
      
      if (newOrigin == null || newAxesVectors == null) {
        // Invalid points for the coordinate axes or missing orient origin for the 4-Point Method
        return false;
      }
      
      setOrientation( matrixToQuat(newAxesVectors) );
      setOrigin(newOrigin);
      return true;
    }
    
    return false;
  }
  
  /**
   * Returns a string array, where each entry is one of
   * the User frame's origin or orientation values:
   * (X, Y, Z, W, P, and R) and their respective labels.
   *
   * @return  A 6-element String array
   */
  public String[] toStringArray() {
    
    String[] values = new String[6];
    
    PVector displayOrigin;
    // Convert angles to degrees and to the World Coordinate Frame
    PVector wpr = convertWorldToNative(quatToEuler(getOrientation())).mult(RAD_TO_DEG);
    
    // Convert to World frame reference
    displayOrigin = convertNativeToWorld(origin);
    
    values[0] = String.format("X: %4.3f", displayOrigin.x);
    values[1] = String.format("Y: %4.3f", displayOrigin.y);
    values[2] = String.format("Z: %4.3f", displayOrigin.z);
    values[3] = String.format("W: %4.3f", wpr.x);
    values[4] = String.format("P: %4.3f", wpr.y);
    values[5] = String.format("R: %4.3f", wpr.z);
    
    return values;
  }
  
  // Getter and Setters for the User frame's origin
  public PVector getOrigin() { return origin; }
  public void setOrigin(PVector newOrigin) { origin = newOrigin; }
}

/**
 * Returns the active Tool frame TOOL, or the active User frame for USER. For either
 * CoordFrame WORLD or JOINT null is always returned. If null is given as a parameter,
 * then the active Coordinate Frame System is checked.
 * 
 * @param coord  The Coordinate Frame System to check for an active frame,
 *               or null to check the current active Frame System.
 */
public Frame getActiveFrame(CoordFrame coord) {
  if (coord == null) {
    // Use current coordinate Frame
    coord = curCoordFrame;
  }
  
  // Determine if a frame is active in the given Coordinate Frame
  if (coord == CoordFrame.USER && activeUserFrame >= 0 && activeUserFrame < userFrames.length) {
    // active User frame
    return userFrames[activeUserFrame];
  } else if (coord == CoordFrame.TOOL && activeToolFrame >= 0 && activeToolFrame < toolFrames.length) {
    // active Tool frame
    return toolFrames[activeToolFrame];
  } else {
    // no active frame
    return null;
  }
}
final int SMALL_BUTTON = 35,
          LARGE_BUTTON = 50,
          CHAR_WDTH = 8,
          TXT_PAD = 18,
          PAD_OFFSET = 8;
final int BUTTON_DEFAULT = color(70),
          BUTTON_ACTIVE = color(220, 40, 40),
          BUTTON_TEXT = color(240),
          UI_LIGHT = color(240),
          UI_DARK = color(40);

int active_prog = -1; // the currently selected program
int active_instr = -1; // the currently selected instruction
int temp_select = 0;
boolean shift = false; // Is shift button pressed or not?
boolean step = false; // Is step button pressed or not?
int record = OFF;

Screen mode;
int g1_px, g1_py; // the left-top corner of group1
int g1_width, g1_height; // group 1's width and height
int display_px, display_py; // the left-top corner of display screen
int display_width, display_height; // height and width of display screen

Group g1, g2;
Button bt_record_normal, 
       bt_ee_normal;

String workingText; // when entering text or a number
String workingTextSuffix;
boolean speedInPercentage;

final int ITEMS_TO_SHOW = 8, // how many programs/ instructions to display on screen
          NUM_ENTRY_LEN = 16, // Maximum character length for a number input
          TEXT_ENTRY_LEN = 16; // Maximum character length for text entry

// Index of the current frame (Tool or User) selecting when in the Frame menus
int curFrameIdx = -1,
// Indices of currently active frames
    activeUserFrame = -1,
    activeToolFrame = -1;
// The Frame being taught, during a frame teaching process
Frame teachFrame = null;
// Expression operand currently being edited
ExprOperand opEdit = null;
int editIdx = -1;

//variables for keeping track of the last change made to the current program
Instruction lastInstruct;
boolean newInstruct;
int lastLine;

// display list of programs or motion instructions
ArrayList<DisplayLine> contents = new ArrayList<DisplayLine>();
// Display otions for a number of menus
ArrayList<String> options = new ArrayList<String>();
// store numbers pressed by the user
ArrayList<Integer> nums = new ArrayList<Integer>();
// container for instructions being coppied/ cut and pasted
ArrayList<Instruction> clipBoard = new ArrayList<Instruction>();
// string for displaying error message to user
String err = null;
// which element is on focus now?
int row_select = 0; //currently selected display row
int prev_select = -1; //saves row_select value if next screen also utilizes this variable
int col_select = 0; //currently selected display column
int opt_select = 0; //which option is on focus now?
int start_render = 0; //index of the first element in a list to be drawn on screen
int active_index = 0; //index of the cursor with respect to the first element on screen
boolean[] selectedLines; //array whose indecies correspond to currently selected lines
// how many textlabels have been created for display
int index_contents = 0, index_options = 100, index_nums = 1000;

/**
 * Used for comment name input. The user can cycle through the
 * six states for each function button in this mode:
 *
 * F1 -> A-F/a-f
 * F2 -> G-L/g-l
 * F3 -> M-R/m-r
 * F4 -> S-X/s-x
 * F5 -> Y-Z/y-z, _, @, *, .
 */
private int[] letterStates = {0, 0, 0, 0, 0};
private final char[][] letters = {{'a', 'b', 'c', 'd', 'e', 'f'},
                                  {'g', 'h', 'i', 'j', 'k', 'l'},
                                  {'m', 'n', 'o', 'p', 'q', 'r'},
                                  {'s', 't', 'u', 'v', 'w', 'x'},
                                  {'y', 'z', '_', '@', '*', '.'}};

public void gui() {
  g1_px = 0;
  g1_py = (SMALL_BUTTON - 15) + 1;
  g1_width = 440;
  g1_height = 720;
  display_px = 10;
  display_py = 0;//(SMALL_BUTTON - 15) + 1;
  display_width = g1_width - 20;
  display_height = 280;
  
  display_stack.push(Screen.DEFAULT);
  mode = display_stack.peek();
  
  // group 1: display and function buttons
  g1 = cp5.addGroup("DISPLAY")
  .setPosition(g1_px, g1_py)
  .setBackgroundColor(color(127,127,127,100))
  .setWidth(g1_width)
  .setHeight(g1_height)
  .setBackgroundHeight(g1_height)
  .hideBar();
  
  cp5.addTextarea("txt")
  .setPosition(display_px, 0)
  .setSize(display_width, display_height)
  .setColorBackground(UI_LIGHT)
  .moveTo(g1);
  
  /**********************Top row buttons**********************/
  
  //calculate how much space each button will be given
  int button_offsetX = LARGE_BUTTON + 1;
  int button_offsetY = LARGE_BUTTON + 1;  
  
  int record_normal_px = WindowManager.lButtonWidth * 5 + LARGE_BUTTON + 1;
  int record_normal_py = 0;   
  PImage[] record = {loadImage("images/record-35x20.png"), 
    loadImage("images/record-over.png"), 
    loadImage("images/record-on.png")};   
  bt_record_normal = cp5.addButton("record_normal")
  .setPosition(record_normal_px, record_normal_py)
  .setSize(SMALL_BUTTON, SMALL_BUTTON)
  .setImages(record)
  .updateSize();     
  
  int EE_normal_px = record_normal_px + LARGE_BUTTON + 1;
  int EE_normal_py = 0;   
  PImage[] EE = {loadImage("images/EE_35x20.png"), 
    loadImage("images/EE_over.png"), 
    loadImage("images/EE_down.png")};   
  bt_ee_normal = cp5.addButton("EE")
  .setPosition(EE_normal_px, EE_normal_py)
  .setSize(SMALL_BUTTON, SMALL_BUTTON)
  .setImages(EE)
  .updateSize();

  /********************Function Row********************/
  
  int f1_px = display_px;
  int f1_py = display_py + display_height + 2;
  int f_width = display_width/5 - 1;
  cp5.addButton("f1")
  .setPosition(f1_px, f1_py)
  .setSize(f_width, LARGE_BUTTON)
  .setCaptionLabel("F1")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);     
  
  int f2_px = f1_px + f_width + 1;
  int f2_py = f1_py;
  cp5.addButton("f2")
  .setPosition(f2_px, f2_py)
  .setSize(f_width, LARGE_BUTTON)
  .setCaptionLabel("F2")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);  
  
  int f3_px = f2_px + f_width + 1;
  int f3_py = f2_py;
  cp5.addButton("f3")
  .setPosition(f3_px, f3_py)
  .setSize(f_width, LARGE_BUTTON)
  .setCaptionLabel("F3")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);    
  
  int f4_px = f3_px + f_width + 1;
  int f4_py = f3_py;   
  cp5.addButton("f4")
  .setPosition(f4_px, f4_py)
  .setSize(f_width, LARGE_BUTTON)
  .setCaptionLabel("F4")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);   
  
  int f5_px = f4_px + f_width + 1;
  int f5_py = f4_py;   
  cp5.addButton("f5")
  .setPosition(f5_px, f5_py)
  .setSize(f_width, LARGE_BUTTON)
  .setCaptionLabel("F5")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  /**********************Step/Shift Row**********************/
  
  int st_px = f1_px;
  int st_py = f1_py + button_offsetY + 10;   
  cp5.addButton("st")
  .setPosition(st_px, st_py)
  .setSize(LARGE_BUTTON, LARGE_BUTTON)
  .setCaptionLabel("STEP")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int mu_px = st_px + LARGE_BUTTON + 19;
  int mu_py = st_py;   
  cp5.addButton("mu")
  .setPosition(mu_px, mu_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("MENU")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int se_px = mu_px + LARGE_BUTTON + 15;
  int se_py = mu_py;
  cp5.addButton("se")
  .setPosition(se_px, se_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("SELECT")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);     
  
  int ed_px = se_px + button_offsetX;
  int ed_py = se_py;   
  cp5.addButton("ed")
  .setPosition(ed_px, ed_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("EDIT")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);      
  
  int da_px = ed_px + button_offsetX;
  int da_py = ed_py;   
  cp5.addButton("da")
  .setPosition(da_px, da_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("DATA")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int fn_px = da_px + LARGE_BUTTON + 15;
  int fn_py = da_py;   
  cp5.addButton("Fn")
  .setPosition(fn_px, fn_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("FCTN")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int sf_px = fn_px + LARGE_BUTTON + 19;
  int sf_py = fn_py;
  cp5.addButton("sf")
  .setPosition(sf_px, sf_py)
  .setSize(LARGE_BUTTON, LARGE_BUTTON)
  .setCaptionLabel("SHIFT")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int pr_px = mu_px;
  int pr_py = mu_py + button_offsetY;   
  cp5.addButton("pr")
  .setPosition(pr_px, pr_py + 15)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("PREV")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int ne_px = fn_px;
  int ne_py = mu_py + button_offsetY;
  cp5.addButton("ne")
  .setPosition(ne_px, ne_py + 15)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("NEXT")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  /***********************Arrow Keys***********************/
  button_offsetY = SMALL_BUTTON + 1;
  
  PImage[] imgs_arrow_up = {loadImage("images/arrow-up.png"), 
    loadImage("images/arrow-up_over.png"), 
    loadImage("images/arrow-up_down.png")};   
  int up_px = ed_px + 5;
  int up_py = ed_py + button_offsetY + 10;
  cp5.addButton("up")
  .setPosition(up_px, up_py)
  .setSize(SMALL_BUTTON, SMALL_BUTTON)
  .setImages(imgs_arrow_up)
  .updateSize()
  .moveTo(g1);     
  
  PImage[] imgs_arrow_down = {loadImage("images/arrow-down.png"), 
    loadImage("images/arrow-down_over.png"), 
    loadImage("images/arrow-down_down.png")};   
  int dn_px = up_px;
  int dn_py = up_py + button_offsetY;
  cp5.addButton("dn")
  .setPosition(dn_px, dn_py)
  .setSize(SMALL_BUTTON, SMALL_BUTTON)
  .setImages(imgs_arrow_down)
  .updateSize()
  .moveTo(g1);    
  
  PImage[] imgs_arrow_l = {loadImage("images/arrow-l.png"), 
    loadImage("images/arrow-l_over.png"), 
    loadImage("images/arrow-l_down.png")};
  int lt_px = dn_px - button_offsetX;
  int lt_py = dn_py - button_offsetY/2;
  cp5.addButton("lt")
  .setPosition(lt_px, lt_py)
  .setSize(SMALL_BUTTON, SMALL_BUTTON)
  .setImages(imgs_arrow_l)
  .updateSize()
  .moveTo(g1);  
  
  PImage[] imgs_arrow_r = {loadImage("images/arrow-r.png"), 
    loadImage("images/arrow-r_over.png"), 
    loadImage("images/arrow-r_down.png")};
  int rt_px = dn_px + button_offsetX;
  int rt_py = lt_py;
  cp5.addButton("rt")
  .setPosition(rt_px, rt_py)
  .setSize(SMALL_BUTTON, SMALL_BUTTON)
  .setImages(imgs_arrow_r)
  .updateSize()
  .moveTo(g1);      
  
  //--------------------------------------------------------------//
  //                           Group 2                            //
  //--------------------------------------------------------------//
  int g2_offsetY = display_py + display_height + 4*LARGE_BUTTON - 10;
  
  /**********************Numpad Block*********************/
  
  int LINE_px = ed_px - 7*button_offsetX/2;
  int LINE_py = g2_offsetY + 5*button_offsetY;
  cp5.addButton("LINE")
  .setPosition(LINE_px, LINE_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("-")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);    
  
  int PERIOD_px = LINE_px + button_offsetX;
  int PERIOD_py = LINE_py - button_offsetY;
  cp5.addButton("PERIOD")
  .setPosition(PERIOD_px, PERIOD_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel(".")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);   
  
  int COMMA_px = PERIOD_px + button_offsetX;
  int COMMA_py = PERIOD_py;
  cp5.addButton("COMMA")
  .setPosition(COMMA_px, COMMA_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel(",")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int POSN_px = LINE_px + button_offsetX;
  int POSN_py = LINE_py;
  cp5.addButton("POSN")
  .setPosition(POSN_px, POSN_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("POSN")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int IO_px = POSN_px + button_offsetX;
  int IO_py = POSN_py;
  cp5.addButton("IO")
  .setPosition(IO_px, IO_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("I/O")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int NUM_px = LINE_px;
  int NUM_py = LINE_py - button_offsetY;
  for(int i = 0; i < 10; i += 1) {
    cp5.addButton("NUM"+i)
    .setPosition(NUM_px, NUM_py)
    .setSize(LARGE_BUTTON, SMALL_BUTTON)
    .setCaptionLabel(""+i)
    .setColorBackground(BUTTON_DEFAULT)
    .setColorCaptionLabel(BUTTON_TEXT)
    .moveTo(g1);
    
    if(i % 3 == 0) {
      NUM_px = LINE_px;
      NUM_py -= button_offsetY;
    }
    else {
      NUM_px += button_offsetX;
    }
  }
  
  int RESET_px = LINE_px;
  int RESET_py = NUM_py;
  cp5.addButton("RESET")
  .setPosition(RESET_px, RESET_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("RESET")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);   

  int BKSPC_px = RESET_px + button_offsetX;
  int BKSPC_py = RESET_py;
  cp5.addButton("BKSPC")
  .setPosition(BKSPC_px, BKSPC_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("BKSPC")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);      
  
  int ITEM_px = BKSPC_px + button_offsetX;
  int ITEM_py = BKSPC_py;
  cp5.addButton("ITEM")
  .setPosition(ITEM_px, ITEM_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("ITEM")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  /***********************Util Block*************************/
  
  int ENTER_px = ed_px;
  int ENTER_py = g2_offsetY;
  cp5.addButton("ENTER")
  .setPosition(ENTER_px, ENTER_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("ENTER")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);    
  
  int TOOL1_px = ENTER_px;
  int TOOL1_py = ENTER_py + button_offsetY;
  cp5.addButton("TOOL1")
  .setPosition(TOOL1_px, TOOL1_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("TOOL1")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);   
  
  int TOOL2_px = TOOL1_px;
  int TOOL2_py = TOOL1_py + button_offsetY;
  cp5.addButton("TOOL2")
  .setPosition(TOOL2_px, TOOL2_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("TOOL2")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);

  int MOVEMENU_px = TOOL2_px;
  int MOVEMENU_py = TOOL2_py + button_offsetY;
  cp5.addButton("MOVEMENU")
  .setPosition(MOVEMENU_px, MOVEMENU_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("MVMU")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1); 
  
  int SETUP_px = MOVEMENU_px;
  int SETUP_py = MOVEMENU_py + button_offsetY;
  cp5.addButton("SETUP")
  .setPosition(SETUP_px, SETUP_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("SETUP")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);    
  
  int STATUS_px = SETUP_px;
  int STATUS_py = SETUP_py + button_offsetY;
  cp5.addButton("STATUS")
  .setPosition(STATUS_px, STATUS_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("STATUS")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  /********************Joint Control Block*******************/
  
  int hd_px = STATUS_px + 3*button_offsetX/2;
  int hd_py = g2_offsetY;   
  cp5.addButton("hd")
  .setPosition(hd_px, hd_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("HOLD")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);    
  
  int fd_px = hd_px;
  int fd_py = hd_py + button_offsetY;   
  cp5.addButton("fd")
  .setPosition(fd_px, fd_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("FWD")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);   
  
  int bd_px = fd_px;
  int bd_py = fd_py + button_offsetY;   
  cp5.addButton("bd")
  .setPosition(bd_px, bd_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("BWD")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int COORD_px = bd_px;   
  int COORD_py = bd_py + button_offsetY;
  cp5.addButton("COORD")
  .setPosition(COORD_px, COORD_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("COORD")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)
  .moveTo(g1);
  
  int SPEEDUP_px = COORD_px;
  int SPEEDUP_py = COORD_py + button_offsetY;
  cp5.addButton("SPEEDUP")
  .setPosition(SPEEDUP_px, SPEEDUP_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("+%")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);   
  
  int SLOWDOWN_px = SPEEDUP_px;
  int SLOWDOWN_py = SPEEDUP_py + button_offsetY;
  cp5.addButton("SLOWDOWN")
  .setPosition(SLOWDOWN_px, SLOWDOWN_py)
  .setSize(LARGE_BUTTON, SMALL_BUTTON)
  .setCaptionLabel("-%")
  .setColorBackground(BUTTON_DEFAULT)
  .setColorCaptionLabel(BUTTON_TEXT)  
  .moveTo(g1);
  
  int JOINT_px = SLOWDOWN_px + button_offsetX;
  int JOINT_py = g2_offsetY;
  String[] labels = {" -X\n(J1)", " +X\n(J1)",
    " -Y\n(J2)", " +Y\n(J2)",
    " -Z\n(J3)", " +Z\n(J3)",
    "-XR\n(J4)", "+XR\n(J4)",
    "-YR\n(J5)", "+YR\n(J5)",
    "-ZR\n(J6)", "+ZR\n(J6)"};
  
  for(int i = 1; i <= 6; i += 1) {
    cp5.addButton("JOINT"+i+"_NEG")
    .setPosition(JOINT_px, JOINT_py)
    .setSize(LARGE_BUTTON, SMALL_BUTTON)
    .setCaptionLabel(labels[(i-1)*2])
    .setColorBackground(BUTTON_DEFAULT)
    .setColorCaptionLabel(BUTTON_TEXT)  
    .moveTo(g1)
    .getCaptionLabel()
    .alignY(TOP);
    
    JOINT_px += LARGE_BUTTON + 1; 
    cp5.addButton("JOINT"+i+"_POS")
    .setPosition(JOINT_px, JOINT_py)
    .setSize(LARGE_BUTTON, SMALL_BUTTON)
    .setCaptionLabel(labels[(i-1)*2 + 1])
    .setColorBackground(BUTTON_DEFAULT)
    .setColorCaptionLabel(BUTTON_TEXT)  
    .moveTo(g1)
    .getCaptionLabel()
    .alignY(TOP);
    
    JOINT_px = SLOWDOWN_px + button_offsetX;
    JOINT_py += SMALL_BUTTON + 1;
  }
  
  List<Button> buttons = cp5.getAll(Button.class);
  for(Button b : buttons) {
    b.getCaptionLabel().setFont(fnt_conB);
  }
}// End UI setup

/* mouse events */

public void mouseDragged(MouseEvent e) {
  if (mouseButton == CENTER) {
    // Drag the center mouse button to pan the camera
    float transScale = camera.getScale();
    camera.move(transScale * (mouseX - pmouseX), transScale * (mouseY - pmouseY), 0);
  }
  
  if (mouseButton == RIGHT) {
    // Drag right mouse button to rotate the camera
    float rotScale = DEG_TO_RAD / 4f;
    camera.rotate(rotScale * (mouseY - pmouseY), rotScale * (mouseX - pmouseX), 0);
  }
}

public void mouseWheel(MouseEvent event) {
  
  if (manager != null && manager.isMouseOverADropdownList()) {
    // Disable zomming when selecting an element from a dropdown list
    return;
  }
  
  float e = event.getCount();
  // Control scaling of the camera with the mouse wheel
  if (e > 0) {
    camera.changeScale(1.05f);
  } else if (e < 0) {
    camera.changeScale(0.95f);
  }
}

/*Keyboard events*/

public void keyPressed() {
  
  if (manager != null && manager.isATextFieldActive()) {
    // Disable other key events when typing in a text field
    return;
  }
  
  if(mode == Screen.PROG_CREATE) {
    // Modify the input name for the new program
    if(key == BACKSPACE && workingText.length() > 0) {
      
      if(workingText.length() > 1) {
        workingText = workingText.substring(0, workingText.length() - 1);
        col_select = min(col_select, workingText.length() - 1);
      }  else {
        workingText = "\0";
      }
      
      updateScreen();
    } else if(key == DELETE && workingText.length() > 0) {
      
      if(workingText.length() > 1) {
        workingText = workingText.substring(1, workingText.length());
        col_select = min(col_select, workingText.length() - 1);
      }  else {
        workingText = "\0";
      }
      
      updateScreen();
    // Valid characters in a program name or comment
    } else if(workingText.length() < TEXT_ENTRY_LEN && (key >= 'a' && key <= 'z') || (key >= 'A' && key <= 'Z')
          || (key >= '0' && key <= '9') || key == '.' || key == '@' || key == '*' || key == '_') {
      StringBuilder temp;
      // Insert the typed character
      if (workingText.length() > 0 && workingText.charAt(col_select) != '\0') {
        temp = new StringBuilder(workingText.substring(0, col_select) + "\0" + workingText.substring(col_select, workingText.length()));
      } else {
        temp = new StringBuilder(workingText); 
      }
        
      temp.setCharAt(col_select, key);
      workingText = temp.toString();
      
      // Add an insert element if the length of the current comment is less than 16
      int len = workingText.length();
      if(len <= TEXT_ENTRY_LEN && col_select == workingText.length() - 1 && workingText.charAt(len - 1) != '\0') {
        workingText += '\0';
      }
      
      col_select = min(col_select + 1, workingText.length() - 1);
      // Update contents to the new string
      updateScreen();
    }
    
    return;
  } else if (key == 'a') {
    // Cycle through Axes display states
    switch (axesState) {
      case NONE:
        axesState = AxesDisplay.AXES;
        break;
      case AXES:
        axesState = AxesDisplay.GRID;
        break;
      default:
        axesState = AxesDisplay.NONE;
    }
    
  } else if(key == 'e') {
    // Cycle through EE Mapping states
    switch (mappingState) {
      case NONE:
        mappingState = EEMapping.LINE;
        break;
      case LINE:
        mappingState = EEMapping.DOT;
        break;
      default:
        mappingState = EEMapping.NONE;
    }
    
  } else if (key == 'f' ) {
    // Display the User and Tool frames associated with the current motion instruction
    if (DISPLAY_TEST_OUTPUT && mode == Screen.NAV_PROG_INSTR && (col_select == 3 || col_select == 4)) {
      Instruction inst = activeInstruction();
      
      if (inst instanceof MotionInstruction) {
        MotionInstruction mInst = (MotionInstruction)inst;
        System.out.printf("\nUser frame: %d\nTool frame: %d\n", mInst.userFrame, mInst.toolFrame);
      }
    }
    
  } else if (key == 'm') {
    // Print the current mode to the console
    println(mode.toString());
    
  } else if (key == 'p') {
    // Toggle the Robot's End Effector state
    if (!programRunning) {
      armModel.toggleEEState();
    }
    
  } else if (key == 's') {
    // Save EVERYTHING!
    saveState();
    
  } else if (key == 't') {
    // Restore default Robot joint angles
    float[] rot = {0, 0, 0, 0, 0, 0};
    armModel.setJointAngles(rot);
    intermediatePositions.clear();
    
  } else if(key == 'w') {
    // Write anything stored in the String buffer to a text file
    writeBuffer();
    
  } else if (key == 'y') {
    // Apply another set of default Robot joint angles
    float[] rot = {PI, 0, 0, 0, 0, PI};
    armModel.setJointAngles(rot);
    intermediatePositions.clear();
    
  }
}

/* Button events */

public void FrontView() {
  // Default view
  camera.reset();
}

public void BackView() {
  // Back view
  camera.reset();
  camera.rotate(0, PI, 0);
}

public void LeftView() {
  // Left view
  camera.reset();
  camera.rotate(0, PI / 2f, 0);
}

public void RightView() {
  // Right view
  camera.reset();
  camera.rotate(0, 3f * PI / 2f, 0);
}

public void TopView() {
  // Top view
  camera.reset();
  camera.rotate(3f * PI / 2f, 0, 0);
}

public void BottomView() {
  // Bottom view
  camera.reset();
  camera.rotate(PI / 2f, 0, 0);
}

public void CreateWldObj() {
  /* Create a world object from the input fields in the Create window. */
  if (activeScenario != null) {
    WorldObject newObject = manager.createWorldObject();
    
    if (newObject != null) {
      newObject.setLocalCenter( new PVector(-500f, 0f, 0f) );
      activeScenario.addWorldObject(newObject);
    }
  }
}

public void ClearFields() {
  /* Clear all input fields for creating and editing world objects. */
  manager.clearCreateInputFields();
}

public void UpdateWldObj() {
  /* Confirm changes made to the orientation and
  * position of the selected world object. */
  manager.editWorldObject();
}

public void DeleteWldObj() {
  // Delete focused world object
  int ret = manager.deleteActiveWorldObject();
  if (DISPLAY_TEST_OUTPUT) { System.out.printf("World Object removed: %d\n", ret); }
}

public void NewScenario() {
  Scenario newScenario = manager.initializeScenario();
  
  if (newScenario != null) {
    // Add the new scenario
    SCENARIOS.add(newScenario);
  }
}

public void SaveScenario() {
  // Save all scenarios
  saveScenarioBytes( new File(sketchPath("tmp/scenarios.bin")) );
}

public void SetScenario() {
  // Set the active scenario to a copy of the scenario associated with te scenario dropdown list
  activeScenario = (Scenario)manager.getActiveScenario().clone();
}

// Menu button
public void mu() {
  resetStack();
  nextScreen(Screen.NAV_MAIN_MENU);
}

// Select button
public void se() {
  // Save when exiting a program
  saveProgramBytes( new File(sketchPath("tmp/programs.bin")) ); 
  
  active_prog = 0;
  active_instr = -1;
  
  resetStack();
  nextScreen(Screen.NAV_PROGRAMS);
}

// Data button
public void da() {
  resetStack();
  nextScreen(Screen.NAV_DATA);
}

public void NUM0() {
  addNumber("0");
}

public void NUM1() {
  addNumber("1");
}

public void NUM2() {
  addNumber("2");
}

public void NUM3() {
  addNumber("3");
}

public void NUM4() {
  addNumber("4");
}

public void NUM5() {
  addNumber("5");
}

public void NUM6() {
  addNumber("6");
}

public void NUM7() {
  addNumber("7");
}

public void NUM8() {
  addNumber("8");
}

public void NUM9() {
  addNumber("9");
}

public void addNumber(String number) {
  if(mode.getType() == ScreenType.TYPE_NUM_ENTRY) {
    if (workingText.length() < NUM_ENTRY_LEN) {
      workingText += number;
    }
  }
  else if(mode == Screen.SET_MV_INSTR_SPD) {
    workingText += number;
    options.set(1, workingText + workingTextSuffix);
  } 
  else if(mode.getType() == ScreenType.TYPE_POINT_ENTRY) {
    if(row_select >= 0 && row_select < contents.size()) {
      String value = contents.get(row_select).get(1) + number;
      
      if(value.length() > 9) {
        // Max length of a an input value
        value = value.substring(0,  9);
      }
      
      // Concatenate the new digit
      contents.get(row_select).set(1, value);
    }
  }
  else if(mode.type == ScreenType.TYPE_TEXT_ENTRY) {
    // Replace current entry with a number
    StringBuilder temp = new StringBuilder(workingText);
    temp.setCharAt(col_select, number.charAt(0));
    workingText = temp.toString();
  }
  
  updateScreen();
}

public void RESET() {
  if (shift) {
    // Reset robot fault
    armModel.halt();
    robotFault = false;
  }
}

public void PERIOD() {
  if(mode.getType() == ScreenType.TYPE_POINT_ENTRY) {

    if(row_select >= 0 && row_select < contents.size()) {

      // Add decimal point
      String value = contents.get(row_select).get(1) + ".";

      if(value.length() > 9) {
        // Max length of a an input value
        value = value.substring(0,  9);
      }
      
      contents.get(row_select).set(1, value);
    }
  } else if(mode.type == ScreenType.TYPE_NUM_ENTRY) {
    
    if(workingText.length() < NUM_ENTRY_LEN) {
      workingText += ".";
    }
  } else if(mode != Screen.EDIT_DREG_COM) {
    workingText += ".";
  }
  
  updateScreen();
}

public void LINE() {
  if(mode.getType() == ScreenType.TYPE_POINT_ENTRY) {
    
    if(row_select >= 0 && row_select < contents.size()) {
      String value = contents.get(row_select).get(1);
      
      // Mutliply current number by -1
      if(value.length() > 0 && value.charAt(0) == '-') {
        contents.get(row_select).set(1, value.substring(1, value.length()));
      } else {
        contents.get(row_select).set(1, "-" + value);
      }
    }
    
  } else if(mode.type == ScreenType.TYPE_NUM_ENTRY) {
    
    // Mutliply current number by -1
    if(workingText.length() > 0 && workingText.charAt(0) == '-') {
      workingText = workingText.substring(1);
    } else {
      workingText = "-" + workingText;
    }
    
  }
  
  updateScreen();
}

public void IO() {
  if (!programRunning) {
    /* Do not allow the Robot's End Effector state to be changed
     * when a program is executing */
    armModel.toggleEEState();
  }
}

/*Arrow keys*/

public void up() {
  switch(mode) {
    case NAV_PROGRAMS:
      active_prog = moveUp(shift);
            
      if(DISPLAY_TEST_OUTPUT) {
        System.out.printf("\nOpt: %d\nProg: %d\nTRS: %d\n\n",
        opt_select, active_prog, start_render);
      }
      break;
    case NAV_PROG_INSTR:
    case SELECT_COMMENT:
    case SELECT_CUT_COPY:
    case SELECT_INSTR_DELETE:
      if (!programRunning) {
        // Lock movement when a program is running
        Instruction i = activeInstruction();
        int prevLine = getSelectedLine();
        active_instr = moveUpInstr(shift);
        int curLine = getSelectedLine();
        
        //special case for select statement column navigation
        if((i instanceof SelectStatement || i instanceof MotionInstruction) && curLine == 0) {
          if(prevLine == 1) {
            col_select += 3;
          }
        }

            
        if(DISPLAY_TEST_OUTPUT) {
          System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
          row_select, col_select, active_instr, start_render);
        }
      }
      break;
    case NAV_DREGS:
    case NAV_PREGS_J:
    case NAV_PREGS_C:
    case NAV_TOOL_FRAMES:
    case NAV_USER_FRAMES:
      active_index = moveUp(shift);
      
      if(DISPLAY_TEST_OUTPUT) {
        System.out.printf("\nRow: %d\nColumn: %d\nIdx: %d\nTRS: %d\n\n",
        row_select, col_select, active_index, start_render);
      }
      break;
    case SET_CALL_PROG:
    case DIRECT_ENTRY_TOOL:
    case DIRECT_ENTRY_USER:
    case EDIT_PREG_C:
    case EDIT_PREG_J:
      moveUp(shift);
      break;
    case NAV_MAIN_MENU:
    case NAV_INSTR_MENU:
    case SELECT_FRAME_MODE:
    case FRAME_METHOD_USER:
    case FRAME_METHOD_TOOL:
    case SELECT_INSTR_INSERT:
    case SELECT_IO_INSTR_REG:
    case SELECT_FRAME_INSTR_TYPE:
    case SELECT_REG_STMT:
    case SELECT_COND_STMT:
    case SELECT_JMP_LBL:
    case TFRAME_DETAIL:
    case UFRAME_DETAIL:
    case TEACH_3PT_USER:
    case TEACH_3PT_TOOL:
    case TEACH_4PT:
    case TEACH_6PT:
    case NAV_DATA:
    case SWAP_PT_TYPE:
    case SET_MV_INSTR_TYPE:
    case SET_MV_INSTR_REG_TYPE:
    case SET_FRM_INSTR_TYPE:
    case SET_REG_EXPR_TYPE:
    case SET_IF_STMT_ACT:
    case SET_SELECT_STMT_ACT:
    case SET_SELECT_STMT_ARG:
    case SET_EXPR_ARG:
    case SET_BOOL_EXPR_ARG:
    case SET_EXPR_OP:
    case SET_IO_INSTR_STATE:
    case NAV_SETUP:
      opt_select = max(0, opt_select - 1);
      break;
    case ACTIVE_FRAMES:
      updateActiveFramesDisplay();
      workingText = Integer.toString(activeToolFrame + 1);
      row_select = max(0, row_select - 1);
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        opt_select = max(0, opt_select - 1); 
        // Reset function key states
        for(int idx = 0; idx < letterStates.length; ++idx) { letterStates[idx] = 0; }
      }
  }
  
  updateScreen();
}

public void dn() {
  switch(mode) {
    case NAV_PROGRAMS:
      active_prog = moveDown(shift);
            
      if(DISPLAY_TEST_OUTPUT) {
        System.out.printf("\nRow: %d\nProg: %d\nTRS: %d\n\n",
        row_select, active_prog, start_render);
      }
      break;
    case NAV_PROG_INSTR:
    case SELECT_COMMENT:
    case SELECT_CUT_COPY:
    case SELECT_INSTR_DELETE:
      if (!programRunning) {
        // Lock movement when a program is running
        Instruction i = activeInstruction();
        int prevIdx = getSelectedIdx();
        active_instr = moveDownInstr(shift);
        int curLine = getSelectedLine();
        
        //special case for select statement column navigation
        if((i instanceof SelectStatement || i instanceof MotionInstruction) && curLine == 1) {
          if(prevIdx >= 3) {
            col_select = prevIdx - 3;
          } else {
            col_select = 0;
          }
        }
      
        if(DISPLAY_TEST_OUTPUT) {
          System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
          row_select, col_select, active_instr, start_render);
        }
      }
      break;
    case NAV_TOOL_FRAMES:
    case NAV_USER_FRAMES:
    case NAV_DREGS:
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      active_index = moveDown(shift);
      
      if(DISPLAY_TEST_OUTPUT) {
        System.out.printf("\nRow: %d\nColumn: %d\nIdx: %d\nTRS: %d\n\n",
        row_select, col_select, active_index, start_render);
      }
      break;
    case SET_CALL_PROG:
    case DIRECT_ENTRY_TOOL:
    case DIRECT_ENTRY_USER:
    case EDIT_PREG_C:
    case EDIT_PREG_J:
      moveDown(shift);
      break;
    case NAV_MAIN_MENU:
    case NAV_INSTR_MENU:
    case SELECT_FRAME_MODE:
    case FRAME_METHOD_USER:
    case FRAME_METHOD_TOOL:
    case SELECT_INSTR_INSERT:
    case SELECT_IO_INSTR_REG:
    case SELECT_FRAME_INSTR_TYPE:
    case SELECT_REG_STMT:
    case SELECT_COND_STMT:
    case SELECT_JMP_LBL:
    case TFRAME_DETAIL:
    case UFRAME_DETAIL:
    case TEACH_3PT_USER:
    case TEACH_3PT_TOOL:
    case TEACH_4PT:
    case TEACH_6PT:
    case NAV_DATA:
    case SWAP_PT_TYPE:
    case SET_MV_INSTR_TYPE:
    case SET_MV_INSTR_REG_TYPE:
    case SET_FRM_INSTR_TYPE:
    case SET_REG_EXPR_TYPE:
    case SET_IF_STMT_ACT:
    case SET_SELECT_STMT_ACT:
    case SET_SELECT_STMT_ARG:
    case SET_EXPR_ARG:
    case SET_BOOL_EXPR_ARG:
    case SET_EXPR_OP:
    case SET_IO_INSTR_STATE:
    case NAV_SETUP:
      opt_select = min(opt_select + 1, options.size() - 1);
      break; 
    case ACTIVE_FRAMES:
      updateActiveFramesDisplay();
      workingText = Integer.toString(activeUserFrame + 1);
      row_select = min(row_select + 1, contents.size() - 1);
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        opt_select = min(opt_select + 1, options.size() - 1);
        // Reset function key states
        for(int idx = 0; idx < letterStates.length; ++idx) { letterStates[idx] = 0; }
      }
  }  
  
  updateScreen();
}

public void lt() { 
  switch(mode) { 
    case NAV_PROG_INSTR:
      if (!programRunning) {
        // Lock movement when a program is running
        moveLeft();
      }
      break;
    case NAV_DREGS:
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      col_select = max(0, col_select - 1);
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        col_select = max(0, col_select - 1);
        // Reset function key states
        for(int idx = 0; idx < letterStates.length; ++idx) { letterStates[idx] = 0; }
      } else if(mode.type == ScreenType.TYPE_EXPR_EDIT) {
        col_select -= (col_select - 4 >= options.size()) ? 4 : 0;
      }
  }
  
  updateScreen();
}


public void rt() {
  switch(mode) {
    case NAV_PROG_INSTR:
      if (!programRunning) {
        // Lock movement when a program is running
        moveRight();
      }
      break;
    case DIRECT_ENTRY_USER:
    case DIRECT_ENTRY_TOOL:
    case EDIT_PREG_C:
    case EDIT_PREG_J:
      // Delete a digit from the beginning of the number entry
      if(shift) {
        String entry = contents.get(row_select).get(1);
        
        if (entry.length() > 1 && !(entry.length() == 2 && entry.charAt(0) == '-')) {
          
          if(entry.charAt(0) == '-') {
            // Keep negative sign until the last digit is removed
            contents.get(row_select).set(1, "-" + entry.substring(2, entry.length()));
          } else {
            contents.get(row_select).set(1, entry.substring(1, entry.length()));
          }
        } else {
          contents.get(row_select).set(1, "");
        }
      }
      
      break;
    case NAV_DREGS:
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      col_select = min(col_select + 1, contents.get(row_select).size() - 1);
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        
        if(shift) {
          // Delete key function
          if(workingText.length() > 1) {
            workingText = workingText.substring(1, workingText.length());
            col_select = min(col_select, workingText.length() - 1);
          }  else {
            workingText = "\0";
          }
          
          col_select = max(0, min(col_select, contents.get(row_select).size() - 1));
        } else if (mode.type == ScreenType.TYPE_EXPR_EDIT) {
          col_select += (col_select + 4 < options.size()) ? 4 : 0;
        } else {
          // Add an insert element if the length of the current comment is less than 16
          int len = workingText.length();
          if(len <= TEXT_ENTRY_LEN && col_select == workingText.length() - 1 && workingText.charAt(len - 1) != '\0') {
            workingText += '\0';
            // Update contents to the new string
            updateScreen();
          }
          
          col_select = min(col_select + 1, contents.get(row_select).size() - 1);
        }
        
        // Reset function key states
        for(int idx = 0; idx < letterStates.length; ++idx) { letterStates[idx] = 0; }
      }
  }
  
  updateScreen();
}

//toggle shift on/ off and button highlight
public void sf() {
  if(!shift) {
    ((Button)cp5.get("sf")).setColorBackground(BUTTON_ACTIVE);
  } else {
    // Stop Robot jog movement when shift is off
    armModel.halt();
    ((Button)cp5.get("sf")).setColorBackground(BUTTON_DEFAULT);
  }
  
  shift = !shift;
  updateScreen();
}

//toggle step on/ off and button highlight
public void st() {
  if(!step) {
    ((Button)cp5.get("st")).setColorBackground(BUTTON_ACTIVE);
  }
  else {
    ((Button)cp5.get("st")).setColorBackground(BUTTON_DEFAULT);
  }
  
  
  step = !step;
  updateScreen();
}

public void pr() {
  lastScreen();
}

public void f1() {
  switch(mode) {
    case NAV_PROGRAMS:
      nextScreen(Screen.PROG_CREATE);
      break;
    case NAV_PROG_INSTR:
      if(shift) {
        newMotionInstruction();
        col_select = 0;
        
        if(getSelectedLine() == 0) {
          row_select += 1;
          updateScreen();
          if(getSelectedLine() == 0) {
            active_instr += 1;
          }
        }
      }
      break;
    case NAV_TOOL_FRAMES:
      if(shift) {
        // Reset the highlighted frame in the tool frame list
        toolFrames[active_index] = new ToolFrame();
        saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
        updateScreen();
      } else {
        // Set the current tool frame
        activeToolFrame = row_select;
        updateCoordFrame();
      }
      break;
    case NAV_USER_FRAMES:
      if(shift) {
        // Reset the highlighted frame in the user frames list
        userFrames[active_index] = new UserFrame();
        saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
        updateScreen();
      } else {
        // Set the current user frame
        activeUserFrame = active_index;
        updateCoordFrame();
      }
      break;
    case ACTIVE_FRAMES:
      if(row_select == 0) {
        nextScreen(Screen.NAV_TOOL_FRAMES);
      } else if(row_select == 1) {
        nextScreen(Screen.NAV_USER_FRAMES);
      }
      break;
    case NAV_DREGS:
      // Clear Data Register entry
      DREG[active_index] = new DataRegister(active_index);
      saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      break;
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      // Clear Position Register entry
      GPOS_REG[active_index] = new PositionRegister(active_index);
      saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        editTextEntry(0);
      }
  }
  
  updateScreen();
}

public void f2() {
  switch(mode) {
    case NAV_PROGRAMS:
      if(programs.size() > 0) {
        nextScreen(Screen.PROG_RENAME);
      }
      break;
    case NAV_PROG_INSTR:
      nextScreen(Screen.SELECT_INSTR_INSERT);
      break;
    case TFRAME_DETAIL:
      switchScreen(Screen.FRAME_METHOD_TOOL);
      //nextScreen(Screen.TOOL_FRAME_METHODS);
      break;
    case TEACH_3PT_TOOL:
    case TEACH_6PT:
    case DIRECT_ENTRY_TOOL:
      lastScreen();
      break;
    case UFRAME_DETAIL:
      switchScreen(Screen.FRAME_METHOD_USER);
      //nextScreen(Screen.USER_FRAME_METHODS);
      break;
    case TEACH_3PT_USER:
    case TEACH_4PT:
    case DIRECT_ENTRY_USER:
      lastScreen();
      break;
    case NAV_DREGS:
      // Data Register copy menus
      if (col_select == 0) {
        nextScreen(Screen.CP_DREG_COM);
      } else if (col_select == 1) {
        nextScreen(Screen.CP_DREG_VAL);
      }
      break;
    case NAV_PREGS_J:
    case NAV_PREGS_C:
    // Position Register copy menus
      if (col_select == 0) {
        nextScreen(Screen.CP_PREG_COM);
      } else if (col_select == 1) {
        nextScreen(Screen.CP_PREG_PT);
      }
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        editTextEntry(1);
        updateScreen();
      }
  }
}

public void f3() {
  switch(mode){
    case NAV_PROGRAMS:
      if(programs.size() > 0) {
        nextScreen(Screen.CONFIRM_PROG_DELETE);
      }
      break;
    case NAV_PROG_INSTR:
      int selectIdx = getSelectedIdx();
      if(activeInstruction() instanceof IfStatement) {
        IfStatement stmt = (IfStatement)activeInstruction();
                
        if(stmt.expr instanceof Expression && selectIdx >= 2) {
          ((Expression)stmt.expr).insertElement(selectIdx - 3);
          updateScreen();
          rt();
        }
      } 
      else if(activeInstruction() instanceof SelectStatement) {
        SelectStatement stmt = (SelectStatement)activeInstruction();
        
        if(selectIdx >= 3) {
          stmt.addCase();
          updateScreen();
          dn();
        }
      }
      else if(activeInstruction() instanceof RegisterStatement) {
        RegisterStatement stmt = (RegisterStatement)activeInstruction();
        int rLen = (stmt.posIdx == -1) ? 2 : 3;
        
        if(selectIdx > rLen) {
          stmt.expr.insertElement(selectIdx - (rLen + 2));
          updateScreen();
          rt();
        }
      }
      
      updateScreen();
      break;
    case SELECT_CUT_COPY:
      ArrayList<Instruction> inst = activeProgram().getInstructions();
      clipBoard = new ArrayList<Instruction>();
      
      int remIdx = 0;
      for(int i = 0; i < selectedLines.length; i += 1){
        if(selectedLines[i]){
          clipBoard.add(inst.get(remIdx));
          inst.remove(remIdx);
        } else{
          remIdx += 1;
        }
      }
      
      updateInstructions();
      break;
    case NAV_TOOL_FRAMES:
      active_index = 0;
      switchScreen(Screen.NAV_USER_FRAMES);
      break;
    case NAV_USER_FRAMES:
      active_index = 0;
      switchScreen(Screen.NAV_TOOL_FRAMES);
      break;
    case NAV_DREGS:
      // Switch to Position Registers
      nextScreen(Screen.NAV_PREGS_C);
      break;
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      if (shift) {
        switchScreen(Screen.SWAP_PT_TYPE);
      } else {
        // Switch to Data Registers
        nextScreen(Screen.NAV_DREGS);
      }
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        editTextEntry(2);
        updateScreen();
      }
  }
}


public void f4() {
  Program p = activeProgram();
  
  switch(mode) {
  case NAV_PROGRAMS:
    if(programs.size() > 0) {
      nextScreen(Screen.PROG_COPY);
    }
    break;
  case NAV_PROG_INSTR:
    Instruction ins = activeInstruction();
    
    if (ins != null) {
      int selectIdx = getSelectedIdx();
      getInstrEdit(ins, selectIdx);
    }
    break;
  case CONFIRM_INSERT:
    try {
      int lines_to_insert = Integer.parseInt(workingText);
      for(int i = 0; i < lines_to_insert; i += 1)
        p.getInstructions().add(active_instr, new Instruction());
      
      updateInstructions();
    }
    catch(Exception e){
      e.printStackTrace();
    }
    
    lastScreen();
    break;
  case CONFIRM_PROG_DELETE:
    int progIdx = active_prog;
    
    if(progIdx >= 0 && progIdx < programs.size()) {
      programs.remove(progIdx);
      
      if(active_prog >= programs.size()) {
        active_prog = programs.size() - 1;
        
        row_select = min(active_prog, ITEMS_TO_SHOW - 1);
        start_render = active_prog - row_select;
      }
      
      lastScreen();
      saveProgramBytes( new File(sketchPath("tmp/programs.bin")) );
    }
    break;
  case SELECT_INSTR_DELETE:
    ArrayList<Instruction> inst = p.getInstructions();
      
    int remIdx = 0;
    for(int i = 0; i < selectedLines.length; i += 1){
      if(selectedLines[i]){
        inst.remove(remIdx);
      } else{
        remIdx += 1;
      }
    }
    
    display_stack.pop();
    updateInstructions();
    break;
  case SELECT_CUT_COPY:
    inst = p.getInstructions();
    clipBoard = new ArrayList<Instruction>();
    
    for(int i = 0; i < selectedLines.length; i += 1){
      if(selectedLines[i])
        clipBoard.add(inst.get(i));
    }
    
    display_stack.pop();
    display_stack.pop();
    updateInstructions();
    break;
  case FIND_REPL:
    int lineIdx = 0;
    String s;
        
    for(Instruction instruct: p.getInstructions()){
      s = (lineIdx + 1) + ") " + instruct.toString();
      
      if(s.toUpperCase().contains(workingText.toUpperCase())){
        break;
      }
      
      lineIdx += 1;
    }
    
    display_stack.pop();
    active_instr = lineIdx;
    updateInstructions();
    break;
  case SELECT_COMMENT:
    display_stack.pop();
    updateInstructions();
    break;
  case CONFIRM_RENUM:
    Point[] pTemp = new Point[1000];
    int posIdx = 0;
    
    //make a copy of the current positions in p
    for(int i = 0; i < 1000; i += 1){
      pTemp[i] = p.getPosition(i);
    }
    
    p.clearPositions();
    
    //rearrange positions
    for(int i = 0; i < p.getInstructions().size(); i += 1) {
      Instruction instr = p.getInstruction(i);
      if(instr instanceof MotionInstruction) {
        int instructPos = ((MotionInstruction)instr).getPosition();
        p.setPosition(posIdx, pTemp[instructPos]);
        ((MotionInstruction)instr).setPosition(posIdx);
        posIdx += 1;
      }
    }
    
    display_stack.pop();
    updateInstructions();
    break;
  case NAV_PREGS_J:
  case NAV_PREGS_C:
    if (shift && !programRunning) {
      // Stop any prior jogging motion
      armModel.halt();
      
      // Move To function
      Point pt = GPOS_REG[active_index].point.clone();
      
      if (pt != null) {
        // Move the Robot to the select point
        if (mode == Screen.NAV_PREGS_C) {
          Frame active = getActiveFrame(CoordFrame.USER);
          
          if (active != null) {
            pt = removeFrame(pt, active.getOrigin(), active.getOrientation());
            if (DISPLAY_TEST_OUTPUT) {
              System.out.printf("pt: %s\n", pt.position.toString());
            }
          }
          
          armModel.moveTo(pt.position, pt.orientation);
        } else {
          armModel.moveTo(pt.angles);
        }
      } else {
        println("Position register is uninitialized!");
      }
    }
    
    break;
  default:
    if (mode.type == ScreenType.TYPE_TEACH_POINTS) {
      
      if (shift && teachFrame != null) {
        Point tgt = teachFrame.getPoint(opt_select);
        
        if (tgt != null && tgt.angles != null) {
          // Move the Robot to the select point
          armModel.moveTo(tgt.angles);
        }
      }
    } else if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
      editTextEntry(3);
    }
    
  }
  
  updateScreen();
}

public void f5() {
  switch(mode) {
    case NAV_PROG_INSTR:
      Instruction i = activeInstruction();
      int selectLine = getSelectedLine();
      int selectIdx = getSelectedIdx();
      
      if(selectIdx == 0) {
        nextScreen(Screen.NAV_INSTR_MENU);
      }
      else if(i instanceof MotionInstruction) {
        if(selectIdx == 3 || (col_select == 0 && selectLine == 1)) {
          nextScreen(Screen.VIEW_INST_REG); 
        }
      }
      else if(i instanceof IfStatement) {
        IfStatement stmt = (IfStatement)i;
        if(stmt.expr instanceof Expression) {
          ((Expression)stmt.expr).removeElement(selectIdx - 3);
        }
      }
      else if(i instanceof SelectStatement) {
        SelectStatement stmt = (SelectStatement)i;
        if(selectIdx >= 3) {
          stmt.deleteCase((selectIdx - 3)/3);
        }
      }
      else if(i instanceof RegisterStatement) {
        RegisterStatement stmt = (RegisterStatement)i;
        int rLen = (stmt.posIdx == -1) ? 2 : 3;
        if(selectIdx > (rLen + 1) && selectIdx < stmt.expr.getLength() + rLen) {
          stmt.expr.removeElement(selectIdx - (rLen + 2));
        }
      }
      break;
    case VIEW_INST_REG:
      MotionInstruction m = (MotionInstruction)activeInstruction();
      
      if(getSelectedIdx() == 3) {
        m.toggleOffsetActive();
      } else {
        m.getSecondaryPoint().toggleOffsetActive();
      }
      
      switchScreen(Screen.SET_MV_INSTR_OFFSET);
      break;      
    case TEACH_3PT_USER:
    case TEACH_3PT_TOOL:
    case TEACH_4PT:
    case TEACH_6PT:
      if (shift) {
        // Save the Robot's current position and joint angles
        teachFrame.setPoint(nativeRobotPoint(armModel.getJointAngles()), opt_select);
        saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
        updateScreen();
      }
      break;
    case CONFIRM_PROG_DELETE:
      opt_select = 0;
      
      lastScreen();
      break;
    case SELECT_INSTR_DELETE:
    case CONFIRM_INSERT:
    case CONFIRM_RENUM:
    case FIND_REPL:
    case SELECT_CUT_COPY:
      display_stack.pop();
      display_stack.pop();
      updateInstructions();
      break;
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      
      if (shift && active_index >= 0 && active_index < GPOS_REG.length) {
        // Save the Robot's current position and joint angles
        Point curRP = nativeRobotEEPoint(armModel.getJointAngles());
        Frame active = getActiveFrame(CoordFrame.USER);
        
        if (active != null) {
          // Save Cartesian values in terms of the active User frame
          curRP = applyFrame(curRP, active.getOrigin(), active.getOrientation());
        } 
  
        GPOS_REG[active_index].point = curRP;
        GPOS_REG[active_index].isCartesian = (mode == Screen.NAV_PREGS_C);
        saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      }
      break;
    default:
       if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
         editTextEntry(4);
       }
  }
  
  updateScreen();
}

public void editTextEntry(int fIdx) {
  char newChar = letters[fIdx][letterStates[fIdx]];
  if(opt_select == 0 && !(fIdx == 4 && letterStates[fIdx] > 1)) {
      // Use uppercase character
      newChar = (char)(newChar - 32);
  }
  
  StringBuilder temp = new StringBuilder(workingText);
  temp.setCharAt(col_select, newChar);
  workingText = temp.toString();
  
  // Update current letter state
  letterStates[fIdx] = (letterStates[fIdx] + 1) % 6;
  for(int idx = 0; idx < letterStates.length; idx += 1) {
    // Reset all other letter states
    if (idx != fIdx) {
      letterStates[idx] = 0;
    }
  }
}

/* Stops all of the Robot's movement */
public void hd() {
  armModel.halt();
}

public void fd() {  
  if(mode == Screen.NAV_PROG_INSTR && !programRunning && shift) {
    // Stop any prior Robot movement
    armModel.halt();
    // Safeguard against editing a program while it is running
    col_select = 0;
    
    executingInstruction = false;
    // Run single instruction when step is set
    execSingleInst = step;
    programRunning = !executeProgram(activeProgram(), armModel, execSingleInst);
  }
}

public void bd() {
  // If there is a previous instruction, then move to it and reverse its affects
  if(mode == Screen.NAV_PROG_INSTR && !programRunning && shift && step) {
    // Stop any prior Robot movement
    armModel.halt();
    // Safeguard against editing a program while it is running
    col_select = 0;
    // TODO fix backwards
  }
}

public void ENTER() {
  Program p = activeProgram();
  
  switch(mode) {
    //Main menu
    case NAV_MAIN_MENU:
      if(opt_select == 5) { // SETUP
        nextScreen(Screen.NAV_SETUP);
      }
      break;
    //Setup menu
    case NAV_SETUP:
      nextScreen(Screen.SELECT_FRAME_MODE);
      break;
    //Frame nav and edit
    case SELECT_FRAME_MODE:
      if(opt_select == 0) {
        nextScreen(Screen.NAV_TOOL_FRAMES);
      }
      else if(opt_select == 1) {
        nextScreen(Screen.NAV_USER_FRAMES);
      }
      break;
    case ACTIVE_FRAMES:
      updateActiveFramesDisplay();
      break;
    case NAV_TOOL_FRAMES:
      curFrameIdx = contents.get(row_select).itemIdx;
      nextScreen(Screen.TFRAME_DETAIL);
      break;
    case NAV_USER_FRAMES:
      curFrameIdx = contents.get(row_select).itemIdx;
      nextScreen(Screen.UFRAME_DETAIL);
      break;
    case FRAME_METHOD_USER:
      // User Frame teaching methods
      teachFrame = userFrames[curFrameIdx];
      if(opt_select == 0) {
        nextScreen(Screen.TEACH_3PT_USER);
      } 
      else if(opt_select == 1) {
        nextScreen(Screen.TEACH_4PT);
      } 
      else if(opt_select == 2) {
        nextScreen(Screen.DIRECT_ENTRY_USER);
      }
      break;
    case FRAME_METHOD_TOOL:
      teachFrame = toolFrames[curFrameIdx];
      // Tool Frame teaching methods
      if(opt_select == 0) {
        nextScreen(Screen.TEACH_3PT_TOOL);
      } 
      else if(opt_select == 1) {
        nextScreen(Screen.TEACH_6PT);
      } 
      else if(opt_select == 2) {
        nextScreen(Screen.DIRECT_ENTRY_TOOL);
      }
      break;
    case TEACH_3PT_TOOL:
    case TEACH_3PT_USER:
      createFrame(teachFrame, 0);
      lastScreen();
      break;
    case TEACH_4PT:
    case TEACH_6PT:
      createFrame(teachFrame, 1);
      lastScreen();
      break;
    case DIRECT_ENTRY_TOOL:
    case DIRECT_ENTRY_USER:
      // User defined x, y, z, w, p, and r values
      float[] inputs = new float[] { 0f, 0f, 0f, 0f, 0f, 0f };
      
      try {
        // Parse each input value
        for(int val = 0; val < inputs.length; ++val) {
          String str = contents.get(val).get(1);
          
          if(str.length() < 0) {
            // No value entered
            updateScreen();
            println("All entries must have a value!");
            return;
          }
          
          // Remove prefix
          inputs[val] = Float.parseFloat(str);
          // Bring within range of values
          inputs[val] = max(-9999f, min(inputs[val], 9999f));
        }
        
        createFrameDirectEntry(teachFrame, inputs);
      } catch (NumberFormatException NFEx) {
        // Invalid number
        println("Entries must be real numbers!");
        return;
      }
      
      if (teachFrame instanceof UserFrame) {
        nextScreen(Screen.UFRAME_DETAIL);
      } else {
        nextScreen(Screen.TFRAME_DETAIL);
      }
      break;  
      
    //Program nav and edit
    case PROG_CREATE:
      if(!workingText.equals("\0")) {
        if (workingText.charAt(workingText.length() - 1) == '\0') {
          // Remove insert character
          workingText = workingText.substring(0, workingText.length() - 1);
        }
        
        int new_prog = addProgram(new Program(workingText));
        active_prog = new_prog;
        active_instr = 0;
        row_select = 0;
        col_select = 0;
        start_render = 0;
        
        saveProgramBytes( new File(sketchPath("tmp/programs.bin")) );    
        switchScreen(Screen.NAV_PROG_INSTR);
      }
      break;
    case PROG_RENAME:
      if(!workingText.equals("\0")) {
        if (workingText.charAt(workingText.length() - 1) == '\0') {
          // Remove insert character
          workingText = workingText.substring(0, workingText.length() - 1);
        }
        // Renmae the program
        activeProgram().setName(workingText);
        active_instr = 0;
        row_select = 0;
        col_select = 0;
        start_render = 0;
        
        saveProgramBytes( new File(sketchPath("tmp/programs.bin")) );
        resetStack();
        nextScreen(Screen.NAV_PROGRAMS);
      }
      break;
    case PROG_COPY:
      if(!workingText.equals("\0")) {
        if (workingText.charAt(workingText.length() - 1) == '\0') {
          // Remove insert character
          workingText = workingText.substring(0, workingText.length() - 1);
        }
        
        Program newProg = activeProgram().clone();
        newProg.setName(workingText);
        int new_prog = addProgram(newProg);
        active_prog = new_prog;
        active_instr = 0;
        row_select = 0;
        col_select = 0;
        start_render = 0;
        
        saveProgramBytes( new File(sketchPath("tmp/programs.bin")) );    
        resetStack();
        nextScreen(Screen.NAV_PROGRAMS);
      }
      break;
    case NAV_PROGRAMS:
      if(programs.size() != 0) {
        active_instr = 0;
        row_select = 0;
        col_select = 0;
        start_render = 0;
        nextScreen(Screen.NAV_PROG_INSTR);
      }
      break;
      
    //Instruction options menu
    case NAV_INSTR_MENU:
      MotionInstruction m;
  
      switch(opt_select) {
        case 0: //Insert
          nextScreen(Screen.CONFIRM_INSERT);
          break;
        case 1: //Delete
          selectedLines = resetSelection(p.getInstructions().size());
          nextScreen(Screen.SELECT_INSTR_DELETE);
          break;
        case 2: //Cut/Copy
          selectedLines = resetSelection(p.getInstructions().size());
          nextScreen(Screen.SELECT_CUT_COPY);
          break;
        case 3: //Paste
          break;
        case 4: //Find/Replace
          nextScreen(Screen.FIND_REPL);
          break;
        case 5: //Renumber
          nextScreen(Screen.CONFIRM_RENUM);
          break;
        case 6: //Comment
          selectedLines = resetSelection(p.getInstructions().size());
          nextScreen(Screen.SELECT_COMMENT);
          break;
        case 7: //Undo
        case 8: //Remark
      }
      
      break;
      
    //Instruction insert menus
    case SELECT_INSTR_INSERT:
      switch(opt_select){
        case 0: // I/O
          nextScreen(Screen.SELECT_IO_INSTR_REG);
          break;
        case 1: // Offset/Frames
          nextScreen(Screen.SELECT_FRAME_INSTR_TYPE);
          break;
        case 2: //Register 
          nextScreen(Screen.SELECT_REG_STMT);
          break;
        case 3: //IF/ SELECT
          nextScreen(Screen.SELECT_COND_STMT);
          break;
        case 4: //JMP/ LBL
          nextScreen(Screen.SELECT_JMP_LBL);
          break;
        case 5: //Call
          newCallInstruction();
          switchScreen(Screen.SET_CALL_PROG);
          break;
      }
      
      break;
    case SELECT_IO_INSTR_REG:
      newIOInstruction();
      display_stack.pop();
      lastScreen();
      break;
    case SELECT_FRAME_INSTR_TYPE:
      if(opt_select == 0){
        newFrameInstruction(FTYPE_TOOL);
      } else {
        newFrameInstruction(FTYPE_USER);
      }
      
      display_stack.pop();
      switchScreen(Screen.SET_FRAME_INSTR_IDX);
      break;
    case SELECT_REG_STMT:
      display_stack.pop();
      display_stack.pop();
      
      if(opt_select == 0) {
        newRegisterStatement(new DataRegister());
      } else if(opt_select == 1){
        newRegisterStatement(new IORegister());
      } else if(opt_select == 2){
        newRegisterStatement(new PositionRegister());
      } else {
        newRegisterStatement(new PositionRegister(), 0);
        display_stack.push(Screen.SET_REG_EXPR_IDX2);
      }
      
      nextScreen(Screen.SET_REG_EXPR_IDX1);
      break;
    case SELECT_COND_STMT:
      if(opt_select == 0) {
        newIfStatement();
        display_stack.pop();
        switchScreen(Screen.SET_EXPR_OP);
      } else if(opt_select == 1) {
        newIfExpression();
        display_stack.pop();
        lastScreen();
      } else {
        newSelectStatement();
        display_stack.pop();
        lastScreen();
      }
      
      break;
    case SELECT_JMP_LBL:
      display_stack.pop();
    
      if(opt_select == 0) {
        newLabel();
        switchScreen(Screen.SET_LBL_NUM);
      } else {
        newJumpInstruction();
        switchScreen(Screen.SET_JUMP_TGT);
      }
            
      break;
    
    //Movement instruction edit
    case SET_MV_INSTR_TYPE:
      m = activeMotionInst();
      if(opt_select == 0) {
        if(m.getMotionType() != MTYPE_JOINT) m.setSpeed(m.getSpeed()/armModel.motorSpeed);
        m.setMotionType(MTYPE_JOINT);
      } else if(opt_select == 1) {
        if(m.getMotionType() == MTYPE_JOINT) m.setSpeed(armModel.motorSpeed*m.getSpeed());
        m.setMotionType(MTYPE_LINEAR);
      } else if(opt_select == 2) {
        if(m.getMotionType() == MTYPE_JOINT) m.setSpeed(armModel.motorSpeed*m.getSpeed());
        m.setMotionType(MTYPE_CIRCULAR);
      }
      
      lastScreen();
      break;
    case SET_MV_INSTR_REG_TYPE:
      int line = getSelectedLine();
      m = line == 0 ? activeMotionInst() : activeMotionInst().getSecondaryPoint();
      
      if(opt_select == 0) {
        m.setGlobalPosRegUse(false);
      } 
      else if(opt_select == 1) {  
        if(GPOS_REG[m.positionNum].point == null) {
          // Invalid register index
          err = "This register is uninitailized!";
          return;
        } else {
          m.setGlobalPosRegUse(true);
        }
      }
      lastScreen();
      break;
    case SET_MV_INSTR_SPD:
      line = getSelectedLine();
      m = line == 0 ? activeMotionInst() : activeMotionInst().getSecondaryPoint();
    
      float tempSpeed = Float.parseFloat(workingText);
      if(tempSpeed >= 5.0f) {
        if(speedInPercentage) {
          if(tempSpeed > 100) tempSpeed = 10; 
          tempSpeed /= 100.0f;
        } else if(tempSpeed > armModel.motorSpeed) {
          tempSpeed = armModel.motorSpeed;
        }
        
        m.setSpeed(tempSpeed);
        saveProgramBytes( new File(sketchPath("tmp/programs.bin")) );
      }
      
      lastScreen();
      break;
    case SET_MV_INSTR_IDX:
      try {
        int tempRegister = Integer.parseInt(workingText) - 1;
        line = getSelectedLine();
        m = line == 0 ? activeMotionInst() : activeMotionInst().getSecondaryPoint();
        
        if(tempRegister < 1 || tempRegister > 1000) {
          // Invalid register index
          err = "Only registers 1 - 1000 are legal!";
          lastScreen();
          return;
        }
        
        if(m.isGPosReg) {
          // Check global register
          if(GPOS_REG[tempRegister].point == null) {
            // Invalid register index
            err = "This register is uninitailized!";
            lastScreen();
            return;
          }
        }
        
        m.setPosition(tempRegister);
      } catch (NumberFormatException NFEx) { /* Ignore invalid numbers */ }
      
      lastScreen();
      break;
    case SET_MV_INSTR_TERM:
      try {
        int tempTerm = Integer.parseInt(workingText);
        line = getSelectedLine();
        m = line == 0 ? activeMotionInst() : activeMotionInst().getSecondaryPoint();
        
        if(tempTerm >= 0 && tempTerm <= 100) {
          m.setTermination(tempTerm);
        }
      } catch (NumberFormatException NFEx) { /* Ignore invalid input */ }
      
      lastScreen();
      break;
    case SET_MV_INSTR_OFFSET:
        try {
        int tempRegister = Integer.parseInt(workingText) - 1;
        line = getSelectedLine();
        m = line == 0 ? activeMotionInst() : activeMotionInst().getSecondaryPoint();
        
        if(tempRegister < 1 || tempRegister > 1000) {
          // Invalid register index
          err = "Only registers 1 - 1000 are legal!";
          lastScreen();
          return;
        } else if(GPOS_REG[tempRegister].point == null) {
          // Invalid register index
          err = "This register is uninitailized!";
          lastScreen();
          return;
        }
        
        m.setOffset(tempRegister);
      } catch (NumberFormatException NFEx) { /* Ignore invalid numbers */ }
      
      lastScreen();
      break;
      
    //Expression edit
    case SET_EXPR_ARG:
      Expression expr = (Expression)opEdit;
    
      if(opt_select == 0) {
        //set arg to new data reg
        ExprOperand operand = new ExprOperand(new DataRegister(), -1);
        opEdit = expr.setOperand(editIdx, operand);
        switchScreen(Screen.INPUT_DREG_IDX);
      } else if(opt_select == 1) {
        //set arg to new io reg
        ExprOperand operand = new ExprOperand(new IORegister(), -1);
        opEdit = expr.setOperand(editIdx, operand);
        switchScreen(Screen.INPUT_IOREG_IDX);
      } else if(opt_select == 2) {
        ExprOperand operand = new ExprOperand(new PositionRegister(), -1);
        opEdit = expr.setOperand(editIdx, operand);
        switchScreen(Screen.INPUT_PREG_IDX1);
      } else if(opt_select == 3) {
        ExprOperand operand = new ExprOperand(new PositionRegister(), -1, 0);
        opEdit = expr.setOperand(editIdx, operand);
        display_stack.pop();
        display_stack.push(Screen.INPUT_PREG_IDX2);
        nextScreen(Screen.INPUT_PREG_IDX1);
      } else if(opt_select == 4) {
        //set arg to new expression
        Expression oper = new Expression();
        expr.setOperand(editIdx, oper);
        lastScreen();
      } else {
        //set arg to new constant
        println(editIdx);
        opEdit = expr.getOperand(editIdx).reset();
        switchScreen(Screen.INPUT_CONST);
      }
      
      break;
    case SET_BOOL_EXPR_ARG:
      if(opt_select == 0) {
        //set arg to new data reg
        opEdit.set(new DataRegister(), -1);
        switchScreen(Screen.INPUT_DREG_IDX);
      } else if(opt_select == 1) {
        //set arg to new io reg
        opEdit.set(new IORegister(), -1);
        switchScreen(Screen.INPUT_IOREG_IDX);
      } else {
        //set arg to new constant
        opEdit.reset();
        switchScreen(Screen.INPUT_CONST);
      }
      break;
    case SET_IF_STMT_ACT:
      IfStatement stmt = (IfStatement)activeInstruction();
      if(opt_select == 0) {
        stmt.instr = new JumpInstruction();
        switchScreen(Screen.SET_JUMP_TGT);
      } else {
        stmt.instr = new CallInstruction();
        switchScreen(Screen.SET_CALL_PROG);
      }
      
      break;
    case SET_EXPR_OP:
      if(opEdit instanceof Expression) {
        expr = (Expression)opEdit;

        switch(opt_select) {
          case 0:
            expr.setOperator(editIdx, Operator.ADDTN);
            break;
          case 1:
            expr.setOperator(editIdx, Operator.SUBTR);
            break;
          case 2:
            expr.setOperator(editIdx, Operator.MULT);
            break;
          case 3:
            expr.setOperator(editIdx, Operator.DIV);
            break;
          case 4:
            expr.setOperator(editIdx, Operator.INTDIV);
            break;
          case 5:
            expr.setOperator(editIdx, Operator.MOD);
            break;
          case 6:
            expr.setOperator(editIdx, Operator.EQUAL);
            break;
          case 7:
            expr.setOperator(editIdx, Operator.NEQUAL);
            break;
          case 8:
            expr.setOperator(editIdx, Operator.GRTR);
            break;
          case 9:
            expr.setOperator(editIdx, Operator.LESS);
            break;
          case 10:
            expr.setOperator(editIdx, Operator.GREQ);
            break;
          case 11:
            expr.setOperator(editIdx, Operator.LSEQ);
            break;
          case 12:
            expr.setOperator(editIdx, Operator.AND);
            break;
          case 13:
            expr.setOperator(editIdx, Operator.OR);
            break;
          case 14:
            expr.setOperator(editIdx, Operator.NOT);
            break;
        }
      }
      else if(opEdit instanceof BooleanExpression) {
        BooleanExpression boolExpr = (BooleanExpression)opEdit;
        
        switch(opt_select) {
          case 0:
            boolExpr.setOperator(Operator.EQUAL);
            break;
          case 1:
            boolExpr.setOperator(Operator.NEQUAL);
            break;
          case 2:
            boolExpr.setOperator(Operator.GRTR);
            break;
          case 3:
            boolExpr.setOperator(Operator.LESS);
            break;
          case 4:
            boolExpr.setOperator(Operator.GREQ);
            break;
          case 5:
            boolExpr.setOperator(Operator.LSEQ);
            break;
        }
      }
      
      lastScreen();
      break;
    case INPUT_DREG_IDX:
    case INPUT_IOREG_IDX:
    case INPUT_PREG_IDX1:
    case INPUT_PREG_IDX2:
      try {
        int idx = Integer.parseInt(workingText);
        
        if(mode == Screen.INPUT_DREG_IDX) {
          opEdit.set(DREG[idx - 1], idx);
        } else if(mode == Screen.INPUT_IOREG_IDX) {
          opEdit.set(IO_REG[idx - 1], idx);
        } else if(mode == Screen.INPUT_PREG_IDX1) {
          opEdit.set(GPOS_REG[idx - 1], idx);
        } else {
          int reg = opEdit.regIdx;
          opEdit.set(GPOS_REG[reg - 1], reg, idx);
        }
        
      } catch(NumberFormatException e) {}
      
      lastScreen();
      break;
    case INPUT_CONST:
      try{
        float data = Float.parseFloat(workingText);
        opEdit.set(data);
      } catch(NumberFormatException e) {}
      
      lastScreen();
      break;
    case SET_BOOL_CONST:
      if(opt_select == 0) {
        opEdit.set(true);
      } else {
        opEdit.set(false);
      }
      
      lastScreen();
      break;
    
    //Select statement edit
    case SET_SELECT_STMT_ACT:
      SelectStatement s = (SelectStatement)activeInstruction();
      int i = (getSelectedIdx() - 3) / 3;
      
      if(opt_select == 0) {
        s.instrList.set(i, new JumpInstruction());
      } else {
        s.instrList.set(i, new CallInstruction());
      }
      
      lastScreen();
      break;
    case SET_SELECT_STMT_ARG:
      if(opt_select == 0) {
        opEdit.set(new DataRegister(), -1);
      } else {
        opEdit.reset();
      }
      
      nextScreen(Screen.SET_SELECT_ARGVAL);
      break;
    case SET_SELECT_ARGVAL:
      try {
        s = (SelectStatement)activeInstruction();
        float f = Float.parseFloat(workingText);
        
        if(opEdit.type == ExpressionElement.UNINIT) {
          opEdit.set(f);
        } else if(opEdit.type == ExpressionElement.DREG) {
          println(DREG[(int)f - 1].value);
          opEdit.set(DREG[(int)f - 1], (int)f);
        }
      } catch(NumberFormatException ex) {}
      
      display_stack.pop();
      lastScreen();
      break;
    
    //IO instruction edit
    case SET_IO_INSTR_STATE:
      IOInstruction ioInst = (IOInstruction)activeInstruction();
    
      if(opt_select == 0) {
        ioInst.setState(ON);
      } else {
        ioInst.setState(OFF);
      }
      
      lastScreen();
      break;
    case SET_IO_INSTR_IDX:
      try {
        int tempReg = Integer.parseInt(workingText);
        
        if(tempReg >= 0 && tempReg < 6){
          ioInst = (IOInstruction)activeInstruction();
          ioInst.setReg(tempReg);
        }
      }
      catch (NumberFormatException NFEx){ /* Ignore invalid input */ }
      
      lastScreen();
      break;
      
    //Frame instruction edit
    case SET_FRM_INSTR_TYPE:
      FrameInstruction fInst = (FrameInstruction)activeInstruction();
      
      if(opt_select == 0)
        fInst.setFrameType(FTYPE_TOOL);
      else
        fInst.setFrameType(FTYPE_USER);
        
      lastScreen();
      break;      
    case SET_FRAME_INSTR_IDX:
      try {
        int frameIdx = Integer.parseInt(workingText) - 1;
        
        if(frameIdx >= -1 && frameIdx < min(toolFrames.length, userFrames.length)){
          fInst = (FrameInstruction)activeInstruction();
          fInst.setReg(frameIdx);
        }
      }
      catch (NumberFormatException NFEx){ /* Ignore invalid input */ }
      
      lastScreen();
      break;
      
    //Register statement edit
    case SET_REG_EXPR_TYPE:
      RegisterStatement regStmt = (RegisterStatement)activeInstruction();
      display_stack.pop();
      
      if(opt_select == 0) {
        regStmt.setRegister(new DataRegister());
      } else if(opt_select == 1) {
        regStmt.setRegister(new IORegister());
      } else if(opt_select == 2) {
        regStmt.setRegister(new PositionRegister());
      } else {
        regStmt.setRegister(new PositionRegister(), 0);
        display_stack.push(Screen.SET_REG_EXPR_IDX2);
      }
      
      nextScreen(Screen.SET_REG_EXPR_IDX1);
      break;
    case SET_REG_EXPR_IDX1:
      try {
        int idx = Integer.parseInt(workingText);
        
        if (idx < 1 || idx > 1000) {
          println("Invalid register index!");
        } else {
          regStmt = (RegisterStatement)activeInstruction(); 
          if(regStmt.reg instanceof DataRegister) {
            (regStmt).setRegister(DREG[idx - 1]);
          } else if(regStmt.reg instanceof IORegister) {
            (regStmt).setRegister(IO_REG[idx - 1]);
          } else if(regStmt.reg instanceof PositionRegister && regStmt.posIdx == -1) { 
            (regStmt).setRegister(GPOS_REG[idx - 1]);
          } else {
            (regStmt).setRegister(GPOS_REG[idx - 1], 0);
          }
        }
      }
      catch (NumberFormatException NFEx){ /* Ignore invalid input */ }
      
      lastScreen();
      break;
    case SET_REG_EXPR_IDX2:
       try {
         int idx = Integer.parseInt(workingText);
         
         if (idx < 1 || idx > 6) {
           println("Invalid position index!"); 
         } else {
           regStmt = (RegisterStatement)activeInstruction();
           if(regStmt.reg instanceof PositionRegister) {
             regStmt.posIdx = idx;
           }
         }
       } catch (NumberFormatException NFEx){ /* Ignore invalid input */ }
       
       lastScreen();
       break;
    
    //Jump/ Label instruction edit
    case SET_LBL_NUM:
      try {
        int idx = Integer.parseInt(workingText);
        
        if (idx < 0 || idx > 99) {
          println("Invalid label index!");
        } else {
          ((LabelInstruction)activeInstruction()).labelNum = idx;
        }
      }
      catch (NumberFormatException NFEx){ /* Ignore invalid input */ }
      
      lastScreen();
      break;
    case SET_JUMP_TGT:
      try {
        int lblNum = Integer.parseInt(workingText);
        int lblIdx = p.findLabelIdx(lblNum);
        
        if(activeInstruction() instanceof IfStatement) {
          IfStatement ifStmt = (IfStatement)activeInstruction();
          ((JumpInstruction)ifStmt.instr).tgtLblNum = lblNum;
        } 
        else if(activeInstruction() instanceof SelectStatement) {
          SelectStatement sStmt = (SelectStatement)activeInstruction();
          ((JumpInstruction)sStmt.instrList.get(editIdx)).tgtLblNum = lblNum;
        }
        else {
          if(lblIdx != -1) {
            JumpInstruction jmp = (JumpInstruction)activeInstruction();
            jmp.tgtLblNum = lblNum;
          } else {
            err = "Invalid label number.";
          }
        }
      }
      catch (NumberFormatException NFEx){ /* Ignore invalid input */ }
      
      lastScreen();
      break;
    
    //Call instruction edit
    case SET_CALL_PROG:
      if(activeInstruction() instanceof IfStatement) {
        IfStatement ifStmt = (IfStatement)activeInstruction();
        ((CallInstruction)ifStmt.instr).callProg = programs.get(row_select);
        ((CallInstruction)ifStmt.instr).progIdx = opt_select;
      }
      else if(activeInstruction() instanceof SelectStatement) {
        SelectStatement sStmt = (SelectStatement)activeInstruction();
        CallInstruction c = (CallInstruction)sStmt.instrList.get(editIdx);
        c.callProg = programs.get(row_select);
        c.progIdx = row_select;
      }
      else {
        CallInstruction call = (CallInstruction)activeInstruction();
        call.callProg = programs.get(row_select);
        call.progIdx = row_select;
      }
      
      lastScreen();
      break;
      
    //Program instruction editing and navigation
    case SELECT_CUT_COPY:
    case SELECT_INSTR_DELETE:
      selectedLines[active_instr] = !selectedLines[active_instr];
      updateScreen();
      break;
    case SELECT_COMMENT:
      activeInstruction().toggleCommented();
      
      updateScreen(); 
      break;
    case VIEW_INST_REG:
      displayPoint = null;
      lastScreen();
      break;
    case FIND_REPL:
      lastScreen();  
      break;
    case JUMP_TO_LINE:
      int jumpToInst = Integer.parseInt(workingText) - 1;
      active_instr = max(0, min(jumpToInst, activeProgram().getInstructions().size() - 1));
      
      lastScreen();
      break;
    case SWAP_PT_TYPE:
      if(opt_select == 0) {
        // View Cartesian values
        nextScreen(Screen.NAV_PREGS_C);
      } else if(opt_select == 1) {
        // View Joint values
        nextScreen(Screen.NAV_PREGS_J);
      }
      break;
      
    //Register navigation/ edit
    case NAV_DATA:
      if(opt_select == 0) {
        // Data Register Menu
        nextScreen(Screen.NAV_DREGS);
      } else if(opt_select == 1) {
        // Position Register Menu
        nextScreen(Screen.NAV_PREGS_C);
      }
      break;
    case CP_DREG_COM:
      int regIdx = -1;
      
      try {
        // Copy the comment of the curent Data register to the Data register at the specified index
        regIdx = Integer.parseInt(workingText) - 1;
        DREG[regIdx].comment = DREG[active_index].comment;
        saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      } catch (NumberFormatException MFEx) {
        println("Only real numbers are valid!");
      } catch (IndexOutOfBoundsException IOOBEx) {
        println("Only positve integers between 0 and 100 are valid!");
      }
      
      lastScreen();
      break;
    case CP_DREG_VAL:
      regIdx = -1;
      
      try {
        // Copy the value of the curent Data register to the Data register at the specified index
        regIdx = Integer.parseInt(workingText) - 1;
        DREG[regIdx].value = DREG[active_index].value;
        saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      } catch (NumberFormatException MFEx) {
        println("Only real numbers are valid!");
      } catch (IndexOutOfBoundsException IOOBEx) {
        println("Only positve integers between 0 and 100 are valid!");
      }
      
      lastScreen();
      break;
    case CP_PREG_COM:
      regIdx = -1;
      
      try {
        // Copy the comment of the curent Position register to the Position register at the specified index
        regIdx = Integer.parseInt(workingText) - 1;
        GPOS_REG[regIdx].comment = GPOS_REG[active_index].comment;
        saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      } catch (NumberFormatException MFEx) {
        println("Only real numbers are valid!");
      } catch (IndexOutOfBoundsException IOOBEx) {
        println("Only positve integers between 0 and 100 are valid!");
      }
      
      lastScreen();
      break;
    case CP_PREG_PT:
      regIdx = -1;
      
      try {
        // Copy the point of the curent Position register to the Position register at the specified index
        regIdx = Integer.parseInt(workingText) - 1;
        GPOS_REG[regIdx].point = GPOS_REG[active_index].point.clone();
        saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      } catch (NumberFormatException MFEx) {
        println("Only real numbers are valid!");
      } catch (IndexOutOfBoundsException IOOBEx) {
        println("Only positve integers between 0 and 100 are valid!");
      }
      
      lastScreen();
      break;
    case EDIT_DREG_VAL:   
      Float f = null;
      
      try {
        // Read inputted Float value
        f = Float.parseFloat(workingText);
        // Clamp the value between -9999 and 9999, inclusive
        f = max(-9999f, min(f, 9999f));
        System.out.printf("Index; %d\n", active_index);
        if(active_index >= 0 && active_index < DREG.length) {
          // Save inputted value
          DREG[active_index].value = f;
          saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
        }
      } catch (NumberFormatException NFEx) {
        // Invalid input value
        println("Value must be a real number!");
      }
      
      lastScreen();
      break;
    case NAV_DREGS:
      if(col_select == 0) {
        // Edit register comment
        nextScreen(Screen.EDIT_DREG_COM);
      } else if(col_select >= 1) {
        // Edit Data Register value
        nextScreen(Screen.EDIT_DREG_VAL);
      }
      break;
    case NAV_PREGS_J:
    case NAV_PREGS_C:   
      if(col_select == 0) {
        // Edit register comment
        nextScreen(Screen.EDIT_PREG_COM);
      } else if(col_select >= 1) {
        // Edit Position Register value
        nextScreen((mode == (Screen.NAV_PREGS_C)) ? Screen.EDIT_PREG_C : Screen.EDIT_PREG_J);
      }
      break;
    case EDIT_PREG_C:
      createRegisterPoint(false);  
      lastScreen();
      break;
    case EDIT_PREG_J:      
      createRegisterPoint(true);
      lastScreen();
      break;
    case EDIT_PREG_COM:
      if (!workingText.equals("\0")) {
        if(workingText.charAt(  workingText.length() - 1  ) == '\0') {
          workingText = workingText.substring(0, workingText.length() - 1);
        }
        // Save the inputted comment to the selected register
        GPOS_REG[active_index].comment = workingText;
        saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
        workingText = "";
        lastScreen();
      }
      break;
    case EDIT_DREG_COM:
      if (!workingText.equals("\0")) {
        if(workingText.charAt(  workingText.length() - 1  ) == '\0') {
          workingText = workingText.substring(0, workingText.length() - 1);
        }
        // Save the inputted comment to the selected register\
        DREG[active_index].comment = workingText;
        saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
        workingText = "";
        lastScreen();
      }
      break;
  }
}//End enter

public void ITEM() {
  if(mode == Screen.NAV_PROG_INSTR) {
    opt_select = 0;
    workingText = "";
    nextScreen(Screen.JUMP_TO_LINE);
  }
}

public void BKSPC() {
  if(mode.type == ScreenType.TYPE_NUM_ENTRY) {
    // Functions as a backspace key
    if(workingText.length() > 1) {
      workingText = workingText.substring(0, workingText.length() - 1);
    } 
    else {
      workingText = "";
    }
    
  } else if(mode.getType() == ScreenType.TYPE_POINT_ENTRY) {
    
    // backspace function for current row
    if(row_select >= 0 && row_select < contents.size()) {
      String value = contents.get(row_select).get(1);
      
      if (value.length() == 1) {
        contents.get(row_select).set(1, "");
      } else if(value.length() > 1) {
        
        if (value.length() == 2 && value.charAt(0) == '-') {
          // Do not remove line prefix until the last digit is removed
          contents.get(row_select).set(1, "");
        } else {
          contents.get(row_select).set(1, value.substring(0, value.length() - 1));
        }
      }
    }
  } else if(mode.type == ScreenType.TYPE_TEXT_ENTRY) {
    // Backspace function
    if(workingText.length() > 1) {
      // ifan insert space exists, preserve it
      if(workingText.charAt(workingText.length() - 1) == '\0') {
        workingText = workingText.substring(0, workingText.length() - 2) + "\0";
      } 
      else {
        workingText = workingText.substring(0, workingText.length() - 1);
      }
      
      col_select = min(col_select, workingText.length() - 1);
    } else {
      workingText = "\0";
    }
    
    for(int idx = 0; idx < letterStates.length; ++idx) { letterStates[idx] = 0; }
  }
  
  updateScreen();
}

public void COORD() {
  if(shift) {
    nextScreen(Screen.ACTIVE_FRAMES);
  } else {  
    // Update the coordinate mode
    coordFrameTransition();
    updateScreen();
  }
}

public void SPEEDUP() {
  // Increase the speed at which the Robot jogs
  if (shift) {
    
    if (liveSpeed < 5) {
      liveSpeed = 5;
    } else if (liveSpeed < 50) {
      liveSpeed = 50;
    } else {
      liveSpeed = 100;
    }
  } else if (liveSpeed < 100) {
    
    if (liveSpeed < 5) {
      ++liveSpeed;
    } else if (liveSpeed < 50) {
      liveSpeed += 5;
    } else if (liveSpeed < 100) {
      liveSpeed += 10f;
    }
  }
  
  // The Robot's speed multiplier is bounded to the range 1% to 100%
  liveSpeed = min(liveSpeed, 100);
}


public void SLOWDOWN() {
  // Reduce the speed at which the Robot jogs
  if (shift) {
    
    if (liveSpeed > 50) {
      liveSpeed = 50;
    } else if (liveSpeed > 5) {
      liveSpeed = 5;
    } else {
      liveSpeed = 1;
    }
  } else if (liveSpeed > 1) {
    
    if (liveSpeed <= 5f) {
      --liveSpeed;
    } else if (liveSpeed <= 50) {
      liveSpeed -= 5;
    } else {
      liveSpeed -= 10;
    }
  }
  
  // The Robot's speed multiplier is bounded to the range 1% to 100%
  liveSpeed = max(1, liveSpeed);
}

public void EE() {
  armModel.cycleEndEffector();
}

public void JOINT1_NEG() {
  updateRobotJogMotion(0, -1);
}

public void JOINT1_POS() {
  updateRobotJogMotion(0, 1);
}

public void JOINT2_NEG() {
  updateRobotJogMotion(1, -1);
}

public void JOINT2_POS() {
  updateRobotJogMotion(1, 1);
}

public void JOINT3_NEG() {
  if (shift) {
    updateRobotJogMotion(2, -1);
  }
}

public void JOINT3_POS() {
  updateRobotJogMotion(2, 1);
}

public void JOINT4_NEG() {
  updateRobotJogMotion(3, -1);
}

public void JOINT4_POS() {
  updateRobotJogMotion(3, 1);
}

public void JOINT5_NEG() {
  updateRobotJogMotion(4, -1);
}

public void JOINT5_POS() {
  updateRobotJogMotion(4, 1);
}

public void JOINT6_NEG() {updateRobotJogMotion(5, -1);
}

public void JOINT6_POS() {
  updateRobotJogMotion(5, 1);
}

public void updateRobotJogMotion(int button, int direction) {
  // Only six jog button pairs exist
  if (button >= 0 && button < 6) {
    float newDir;
    
    if(curCoordFrame == CoordFrame.JOINT) {
      // Move single joint
      newDir = activateLiveJointMotion(button, direction);
    } else {
      // Move entire robot in a single axis plane
      newDir = activateLiveWorldMotion(button, direction);
    }
    
    Button negButton = ((Button)cp5.get("JOINT" + (button + 1) + "_NEG")),
           posButton = ((Button)cp5.get("JOINT" + (button + 1) + "_POS"));
    
    if (newDir > 0) {
      // Positive motion
      negButton.setColorBackground(BUTTON_DEFAULT);
      posButton.setColorBackground(BUTTON_ACTIVE);
    } else if (newDir < 0) {
      // Negative motion
      negButton.setColorBackground(BUTTON_ACTIVE);
      posButton.setColorBackground(BUTTON_DEFAULT);
    } else {
      // No motion
      negButton.setColorBackground(BUTTON_DEFAULT);
      posButton.setColorBackground(BUTTON_DEFAULT);
    }
  }
}

/**
 * Updates the motion of one of the Robot's joints based on
 * the joint index given and the value of dir (-/+ 1). The
 * Robot's joint indices range from 0 to 5. ifthe joint
 * Associate with the given index is already in motion,
 * in either direction, then calling this method for that
 * joint index will stop that joint's motion.
 * 
 * @returning  The new motion direction of the Robot
 */
public float activateLiveJointMotion(int joint, int dir) {
  
  if (!shift || robotFault) {
    // Only move when shift is set and there is no error
    return 0f;
  }
  
  if(armModel.segments.size() >= joint+1) {

    Model model = armModel.segments.get(joint);
    // Checks all rotational axes
    for(int n = 0; n < 3; n++) {
      
      if(model.rotations[n]) {
        
        if(model.jointsMoving[n] == 0) {
          model.jointsMoving[n] = dir;
          return dir;
        } else {
          model.jointsMoving[n] = 0;
        }
      }
    }
  }
  
  return 0f;
}

/**
 * Updates the motion of the Robot with respect to one of the World axes for
 * either linear or rotational motion around the axis. Similiar to the
 * activateLiveJointMotion() method, calling this method for an axis, in which
 * the Robot is already moving, will result in the termination of the Robot's
 * motion in that axis. Rotational and linear motion for an axis are mutually
 * independent in this regard.
 * 
 * @param axis        The axis of movement for the robotic arm:
                      x - 0, y - 1, z - 2, w - 3, p - 4, r - 5
 * @pararm dir        +1 or -1: indicating the direction of motion
 * @returning         The new direction of motion in the given axis
 *
 */
public float activateLiveWorldMotion(int axis, int dir) {
  if (!shift || robotFault) {
    // Only move when shift is set and there is no error
    return 0f;
  }
  
  // Initiaize the Robot's destination
  Point RP = nativeRobotEEPoint(armModel.getJointAngles());
  armModel.tgtPosition = RP.position;
  armModel.tgtOrientation = RP.orientation;
  
  
  if(axis >= 0 && axis < 3) {
    if(armModel.jogLinear[axis] == 0) {
      // Begin movement on the given axis in the given direction
      armModel.jogLinear[axis] = dir;
    } else {
      // Halt movement
      armModel.jogLinear[axis] = 0;
    }
    
    return armModel.jogLinear[axis];
  }
  else if(axis >= 3 && axis < 6) {
    axis %= 3;
    if(armModel.jogRot[axis] == 0) {
      // Begin movement on the given axis in the given direction
      armModel.jogRot[axis] = dir;
    }
    else {
      // Halt movement
      armModel.jogRot[axis] = 0;
    }
    
    return armModel.jogRot[axis];
  }
  
  return 0f;
}

//turn of highlighting on all active movement buttons
public void resetButtonColors() {
  for(int i = 1; i <= 6; i += 1) {
    ((Button)cp5.get("JOINT"+i+"_NEG")).setColorBackground(BUTTON_DEFAULT);
    ((Button)cp5.get("JOINT"+i+"_POS")).setColorBackground(BUTTON_DEFAULT);
  }
}

/**
 * Transitions the display to the given screen and pushes that screen
 * onto the stack.
 * 
 * @param next    The new screen mode
 */
public void nextScreen(Screen next) {
  // Stop a program from executing when transition screens
  programRunning = false;
  if (DISPLAY_TEST_OUTPUT) { System.out.printf("%s => %s\n", mode, next);  }
  
  mode = next;
  display_stack.push(mode);
  loadScreen();
}

/**
 * Transitions to the given screen without saving the current screen on the stack.
 * 
 * @param nextScreen  The new screen mode
 */
public void switchScreen(Screen nextScreen) {
  // Stop a program from executing when transition screens
  programRunning = false;
  if (DISPLAY_TEST_OUTPUT) { System.out.printf("%s => %s\n", mode, nextScreen);  }
  
  mode = nextScreen;
  display_stack.pop();
  display_stack.push(mode);
  loadScreen();
}

/**
 * Transitions the display to the previous screen that the user was on.
 */
public boolean lastScreen() {
  // Stop a program from executing when transition screens
  programRunning = false;
  if (display_stack.peek() == Screen.DEFAULT) {
    if (DISPLAY_TEST_OUTPUT) { System.out.printf("%s\n", mode); }
    return false;
  }
  else{
    display_stack.pop();
    if (DISPLAY_TEST_OUTPUT) { System.out.printf("%s => %s\n", mode, display_stack.peek()); }
    mode = display_stack.peek();
    
    loadScreen();
    return true;
  }
}

public void resetStack(){
  // Stop a program from executing when transition screens
  programRunning = false;
  display_stack.clear();
  
  mode = Screen.DEFAULT;
  display_stack.push(mode);
}

public void loadScreen() {  
  switch(mode){
    //Main menu
    case NAV_MAIN_MENU:
      opt_select = 0;
      break;
      
    //Frames
    case NAV_SETUP:
      opt_select = 0;
      break;
    case ACTIVE_FRAMES:
      row_select = 0;
      col_select = 1;
      workingText = Integer.toString(activeToolFrame + 1);
      break;
    case SELECT_FRAME_MODE:
      active_index = 0;
      opt_select = 0;
      break;
    case NAV_TOOL_FRAMES:
    case NAV_USER_FRAMES:
      row_select = active_index*2;
      col_select = 0;
      break;
    case TFRAME_DETAIL:
    case UFRAME_DETAIL:
      row_select = -1;
      col_select = -1;
      start_render = 0;
      opt_select = -1;
      break;
    case TEACH_3PT_TOOL:
    case TEACH_3PT_USER:
    case TEACH_4PT:
    case TEACH_6PT:
      opt_select = 0;
      break;
    case FRAME_METHOD_TOOL:
    case FRAME_METHOD_USER:
      row_select = -1;
      col_select = -1;
      opt_select = 0;
      break;
    
    //Programs and instructions
    case NAV_PROGRAMS:
      // Stop Robot movement (i.e. program execution)
      armModel.halt();
      row_select = active_prog;
      col_select = 0;
      active_instr = 0;
      break;
    case PROG_CREATE:
      row_select = 1;
      col_select = 0;
      opt_select = 0;
      workingText = "\0";
      break;
    case PROG_RENAME:
      active_prog = row_select;
      row_select = 1;
      col_select = 0;
      opt_select = 0;
      workingText = activeProgram().getName();
      break;
    case PROG_COPY:
      active_prog = row_select;
      row_select = 1;
      col_select = 0;
      opt_select = 0;
      workingText = "\0";
      break;
    case NAV_PROG_INSTR:
      //need to enforce row/ column select limits based on 
      //program length/ instruction width
      if(prev_select != -1) {
        row_select = prev_select;
        start_render = row_select;
        prev_select = -1;
      }
      opt_select = -1;
      break;
    case SET_CALL_PROG:
      prev_select = row_select;
      row_select = 0;
      col_select = 0;
      start_render = 0;
      break;
    case CONFIRM_INSERT:
      workingText = "";
      break;
    case SELECT_INSTR_INSERT:
    case SELECT_JMP_LBL:
    case SELECT_REG_STMT:
    case SELECT_COND_STMT:
    case SET_IF_STMT_ACT:
    case SET_SELECT_STMT_ACT:
    case SET_SELECT_STMT_ARG:
    case SET_EXPR_ARG:
    case SET_BOOL_EXPR_ARG:
    case SET_EXPR_OP:
      opt_select = 0;
      break;
    case SET_MV_INSTR_OFFSET:
    case INPUT_DREG_IDX:
    case INPUT_IOREG_IDX:
    case INPUT_CONST:
      workingText = "";
      break;
    case SET_IO_INSTR_IDX:
    case SET_JUMP_TGT:
    case SET_LBL_NUM:
      col_select = 1;
      opt_select = 0;
      workingText = "";
      break;
    case SET_MV_INSTR_TYPE:
      MotionInstruction mInst = activeMotionInst();
      
      switch (mInst.getMotionType()) {
        case MTYPE_JOINT:
          opt_select = 0;
          break;
        case MTYPE_LINEAR:
          opt_select = 1;
          break;
        case MTYPE_CIRCULAR:
          opt_select = 2;
          break;
        default:
          opt_select = -1;
      }
      
      break;
    case SET_MV_INSTR_SPD:
      mInst = activeMotionInst();
      int instSpd;
      // Convert speed into an integer value
      if (mInst.motionType == MTYPE_JOINT) {
        instSpd = Math.round(mInst.speed * 100f);
      } else {
       instSpd = Math.round(mInst.speed);
      }
      
      workingText = Integer.toString(instSpd);
    case SET_MV_INSTR_REG_TYPE:
      mInst = activeMotionInst();
      
      if (mInst.usesGPosReg()) {
        opt_select = 1;
      } else {
        opt_select = 0;
      }
      
      break;
    case SET_MV_INSTR_IDX:
      mInst = activeMotionInst();
      workingText = Integer.toString(mInst.getPosition());
      break;
    case SET_MV_INSTR_TERM:
      mInst = activeMotionInst();
      workingText = Integer.toString(mInst.getTermination());
      break;
    case SET_FRAME_INSTR_IDX:
    case SET_SELECT_ARGVAL:
    case SET_REG_EXPR_IDX1:
    case SET_REG_EXPR_IDX2:
      opt_select = 0;
      workingText = "";
      break;
    case SET_IO_INSTR_STATE:
    case SET_FRM_INSTR_TYPE:
    case SET_REG_EXPR_TYPE:
      opt_select = 0;
      break;
    case SELECT_INSTR_DELETE:
    case SELECT_COMMENT:
    case SELECT_CUT_COPY:
      int size = contents.size() - 1;
      row_select = max(0, min(row_select, size));
      col_select = 0;
      break;
    
    //Registers
    case NAV_DATA:
      opt_select = 0;
      active_index = 0;
      break;
    case NAV_DREGS:
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      row_select = active_index;
      col_select = 0;
      break;
    case DIRECT_ENTRY_TOOL:
    case DIRECT_ENTRY_USER:
      row_select = 0;
      col_select = 1;
      contents = loadFrameDirectEntry(teachFrame);
      options = new ArrayList<String>();
      break;
    case NAV_INSTR_MENU:
      opt_select = 0;
      break;
    case VIEW_INST_REG:
      opt_select = -1;
      break;
    case SWAP_PT_TYPE:
      opt_select = 0;
      break;
    case CP_DREG_COM:
    case CP_DREG_VAL:
    case CP_PREG_COM:
    case CP_PREG_PT:
      opt_select = 1;
      workingText = Integer.toString((active_index + 1));
      break;
    case EDIT_DREG_COM:
      row_select = 1;
      col_select = 0;
      opt_select = 0;
      
      if(DREG[active_index].comment != null) {
        workingText = DREG[active_index].comment;
      }
      else {
        workingText = "\0";
      }
      break;   
    case EDIT_PREG_COM:
      row_select = 1;
      col_select = 0;
      opt_select = 0;
      
      if(GPOS_REG[active_index].comment != null) {
        workingText = GPOS_REG[active_index].comment;
      }
      else {
        workingText = "\0";
      }
      break;
    case EDIT_DREG_VAL:
      opt_select = 0;
      // Bring up float input menu
      if(DREG[active_index].value != null) {
        workingText = Float.toString(DREG[active_index].value);
      } else {
        workingText = "";
      }
      break;
    case EDIT_PREG_C:
    case EDIT_PREG_J:
      row_select = 0;
      col_select = 1;
      contents = loadPosRegEntry(GPOS_REG[active_index]);
      break;
    default:
      break;
  }
  
  updateScreen();
}

// update text displayed on screen
public void updateScreen() {
  int next_px = display_px;
  int next_py = display_py;
  int txt, bg;
  
  clearScreen();
  
  // draw display background
  cp5.addTextarea("txt")
  .setPosition(display_px,display_py)
  .setSize(display_width, display_height)
  .setColorBackground(UI_LIGHT)
  .moveTo(g1);
  
  String header = null;
  // display the name of the program that is being edited
  header = getHeader(mode);
    
  if(header != null) {
    // Display header field
    cp5.addTextarea("header")
    .setText(" " + header)
    .setFont(fnt_con14)
    .setPosition(next_px, next_py)
    .setSize(display_width, 20)
    .setColorValue(UI_LIGHT)
    .setColorBackground(UI_DARK)
    .hideScrollbar()
    .show()
    .moveTo(g1);
    
    next_py += 20;
  }
  
  contents = getContents(mode);
  options = getOptions(mode);
  
  boolean selectMode = (mode.getType() == ScreenType.TYPE_LINE_SELECT);
    
  /*************************
   *    Display Contents   *
   *************************/
  
  if(contents.size() > 0) {
    row_select = clamp(row_select, 0, contents.size() - 1);
    col_select = clamp(col_select, 0, contents.get(row_select).size() - 1);
    start_render = clamp(start_render, row_select - (ITEMS_TO_SHOW - 1), row_select);
  }
  
  index_contents = 1;
  for(int i = start_render; i < contents.size() && i - start_render < ITEMS_TO_SHOW; i += 1) {
    //get current line
    DisplayLine temp = contents.get(i);
    next_px = display_px + temp.xAlign;
    
    if(i == row_select) { bg = UI_DARK; }
    else                { bg = UI_LIGHT;}
    
    //if(i == 0 || contents.get(i - 1).itemIdx != contents.get(i).itemIdx) {
    //  //leading row select indicator []
    //  cp5.addTextarea(Integer.toString(index_contents))
    //  .setText("")
    //  .setPosition(next_px, next_py)
    //  .setSize(10, 20)
    //  .setColorBackground(bg)
    //  .hideScrollbar()
    //  .moveTo(g1);
    //}
    
    //index_contents++;
    //next_px += 10;
    
    //draw each element in current line
    for(int j = 0; j < temp.size(); j += 1) {
      if(i == row_select) {
        if(j == col_select && !selectMode){
          //highlight selected row + column
          txt = UI_LIGHT;
          bg = UI_DARK;          
        } 
        else if(selectMode && !selectedLines[contents.get(i).itemIdx]){
          //highlight selected line
          txt = UI_LIGHT;
          bg = UI_DARK;
        }
        else {
          txt = UI_DARK;
          bg = UI_LIGHT;
        }
      } else if(selectMode && selectedLines[contents.get(i).itemIdx]) {
        //highlight any currently selected lines
        txt = UI_LIGHT;
        bg = UI_DARK;
      } else {
        //display normal row
        txt = UI_DARK;
        bg = UI_LIGHT;
      }
      
      //grey text for comme also this
      if(temp.size() > 0 && temp.get(0).contains("//")) {
        txt = color(127);
      }
      
      cp5.addTextarea(Integer.toString(index_contents))
      .setText(temp.get(j))
      .setFont(fnt_con14)
      .setPosition(next_px, next_py)
      .setSize(temp.get(j).length()*CHAR_WDTH + TXT_PAD, 20)
      .setColorValue(txt)
      .setColorBackground(bg)
      .hideScrollbar()
      .moveTo(g1);
      
      index_contents++;
      next_px += temp.get(j).length()*CHAR_WDTH + (TXT_PAD - 8); 
    }//end draw line elements
        
    if(i == row_select) { txt = UI_DARK;  }
    else                { txt = UI_LIGHT; }
    
    ////Trailing row select indicator []
    //cp5.addTextarea(Integer.toString(index_contents))
    //.setText("")
    //.setPosition(next_px, next_py)
    //.setSize(10, 20)
    //.setColorBackground(txt)
    //.hideScrollbar()
    //.moveTo(g1);
    
    next_py += 20;
    //index_contents += 1;
  }//end display contents
  
  // display options for an element being edited
  next_px = display_px;
  next_py += contents.size() == 0 ? 0 : 20;
  
  int maxHeight;
  if(mode.getType() == ScreenType.TYPE_EXPR_EDIT) {
    maxHeight = 4;
  } else {
    maxHeight = options.size();
  }
  
  /*************************
   *    Display Options    *
   *************************/
  
  index_options = 100;
  for(int i = 0; i < options.size(); i += 1) {
    if(i == opt_select) {
      txt = UI_LIGHT;
      bg = UI_DARK;
    }
    else {
      txt = UI_DARK;
      bg = UI_LIGHT;
    }
    
    cp5.addTextarea(Integer.toString(index_options))
    .setText(" " + options.get(i))
    .setFont(fnt_con14)
    .setPosition(next_px, next_py)
    .setSize(options.get(i).length()*8 + 40, 20)
    .setColorValue(txt)
    .setColorBackground(bg)
    .hideScrollbar()
    .moveTo(g1);
    
    index_options++;
    next_px += (i % maxHeight == maxHeight - 1) ? 80 : 0;
    next_py += (i % maxHeight == maxHeight - 1) ? -20*(maxHeight - 1) : 20;    
  }
  
  // display the numbers that the user has typed
  next_py += 20;
  index_nums = 1000;
  for(int i = 0; i < nums.size(); i+= 1) {
    if(nums.get(i) == -1) {
      cp5.addTextarea(Integer.toString(index_nums))
      .setText(".")
      .setFont(fnt_con14)
      .setPosition(next_px, next_py)
      .setSize(40, 20)
      .setColorValue(UI_LIGHT)
      .setColorBackground(color(255, 0, 0))
      .hideScrollbar()
      .moveTo(g1);
    }
    else {
      cp5.addTextarea(Integer.toString(index_nums))
      .setText(Integer.toString(nums.get(i)))
      .setFont(fnt_con14)
      .setPosition(next_px, next_py)
      .setSize(40, 20)
      .setColorValue(UI_LIGHT)
      .setColorBackground(color(255, 0, 0))
      .hideScrollbar()
      .moveTo(g1);
    }
    
    index_nums++;
    next_px += options.get(i).length()*8 + 20;   
  }
  
  // display hints for function keys
  String[] funct;
  funct = getFunctionLabels(mode);
    
  //set f button text labels
  for(int i = 0; i < 5; i += 1) {
    cp5.addTextarea("lf"+i)
    .setText(funct[i])
    .setFont(fnt_con12)
     // Keep function labels in their original place
    .setPosition(display_width*i/5 + 15 , display_height - g1_py)
    .setSize(display_width/5 - 5, 20)
    .setColorValue(UI_DARK)
    .setColorBackground(UI_LIGHT)
    .hideScrollbar()
    .moveTo(g1);
  }
} // end updateScreen()

/*Text generation methods*/

//Header text
public String getHeader(Screen mode){
  String header = null;
  
  switch(mode) {
    case NAV_PROGRAMS:
      header = "PROGRAMS";
      break;
    case PROG_CREATE:
      header = "NAME PROGRAM";
      break;
    case PROG_RENAME:
      header = "RENAME PROGRAM";
      break;
    case PROG_COPY:
      header = "COPY PROGRAM";
      break;
    case CONFIRM_INSERT:
    case CONFIRM_RENUM:
    case NAV_PROG_INSTR:
    case NAV_INSTR_MENU:
    case SET_MV_INSTR_SPD:
    case SET_MV_INSTR_IDX:
    case SET_MV_INSTR_TERM:
    case SET_MV_INSTR_OFFSET:
    case SELECT_INSTR_INSERT:
    case SET_IO_INSTR_STATE:
    case SET_FRM_INSTR_TYPE:
    case SET_FRAME_INSTR_IDX:
    case SET_EXPR_ARG:
    case SET_BOOL_EXPR_ARG:
    case SET_JUMP_TGT:
    case SELECT_CUT_COPY:    
    case SELECT_INSTR_DELETE:
    case VIEW_INST_REG:
      header = activeProgram().getName();
      break;
    case SELECT_IO_INSTR_REG:
      header = "SELECT IO REGISTER";
      break;
    case SELECT_FRAME_INSTR_TYPE:
      header = "SELECT FRAME INSTRUCTION TYPE";
      break;
    case SELECT_COND_STMT:
      header = "INSERT IF/ SELECT STATEMENT";
      break;
    case SELECT_JMP_LBL:
      header = "INSERT JUMP/ LABEL INSTRUCTION";
      break;
    case SET_CALL_PROG:
      header = "SELECT CALL TARGET";
      break;
    case ACTIVE_FRAMES:
      header = "ACTIVE FRAMES";
      break;
    case NAV_TOOL_FRAMES:
      header = "TOOL FRAMES";
      break;
    case NAV_USER_FRAMES:
      header = "USER FRAMES";
      break;
    case TFRAME_DETAIL:
      header = String.format("TOOL FRAME: %d", curFrameIdx + 1);
      break;
    case UFRAME_DETAIL:
      header = String.format("USER FRAME: %d", curFrameIdx + 1);
      break;
    case FRAME_METHOD_TOOL:
      header = String.format("TOOL FRAME: %d", curFrameIdx + 1);
      break;
    case FRAME_METHOD_USER:
      header = String.format("USER FRAME: %d", curFrameIdx + 1);
      break;
    case TEACH_3PT_TOOL:
    case TEACH_3PT_USER:
      header = "THREE POINT METHOD";
      break;
    case TEACH_4PT:
      header = "FOUR POINT METHOD";
      break;
    case TEACH_6PT:
      header = "SIX POINT METHOD";
      break;
    case DIRECT_ENTRY_TOOL:
    case DIRECT_ENTRY_USER:
      header = "DIRECT ENTRY METHOD";
      break;
    case NAV_DATA:
      header = "VIEW REGISTERS";
      break;
    case NAV_DREGS:
    case CP_DREG_COM:
    case CP_DREG_VAL:
      header = "REGISTERS";
      break;
    case NAV_PREGS_J:
      header = "POSTION REGISTERS (J)";
      break;
    case NAV_PREGS_C:
      header = "POSTION REGISTERS (C)";
      break;
    case CP_PREG_COM:
    case CP_PREG_PT:
    case SWAP_PT_TYPE:
      header = "POSTION REGISTERS";
      break;
    case EDIT_DREG_VAL:
      header = "REGISTERS";
      break;
    case EDIT_PREG_C:
    case EDIT_PREG_J:
      header = "POSITION REGISTER: ";
      
      if(mode != Screen.EDIT_DREG_COM && GPOS_REG[active_index].comment != null) {
        // Show comment if it exists
        header += GPOS_REG[active_index].comment;
      } 
      else {
        header += active_index;
      }
      break;
    case EDIT_DREG_COM:
      header = String.format("Enter a name for R[%d]", active_index);
      break;
    case EDIT_PREG_COM:
      header = String.format("Enter a name for PR[%d]", active_index);
      break;
    default:
      break;
  }
  
  return header;
}

//Main display content text
public ArrayList<DisplayLine> getContents(Screen mode){
  ArrayList<DisplayLine> contents = new ArrayList<DisplayLine>();
  
  switch(mode) {
    //Program list navigation/ edit
    case NAV_PROGRAMS:
    case SET_CALL_PROG:
      contents = loadPrograms();
      break;
    
    case PROG_CREATE:
    case PROG_RENAME:
    case PROG_COPY:
      contents = loadTextInput();
      break;
    
    //View instructions
    case CONFIRM_INSERT:
    case CONFIRM_RENUM:
    case FIND_REPL:
    case NAV_PROG_INSTR:
    case VIEW_INST_REG:
    case SELECT_INSTR_DELETE:
    case SELECT_COMMENT:
    case SELECT_CUT_COPY:
    case SET_MV_INSTR_TYPE:
    case SET_MV_INSTR_REG_TYPE:
    case SET_MV_INSTR_IDX:
    case SET_MV_INSTR_SPD:
    case SET_MV_INSTR_TERM:
    case SET_MV_INSTR_OFFSET:
    case SET_IO_INSTR_STATE:
    case SET_IO_INSTR_IDX:
    case SET_FRM_INSTR_TYPE:
    case SET_FRAME_INSTR_IDX:
    case SET_REG_EXPR_TYPE:
    case SET_REG_EXPR_IDX1:
    case SET_REG_EXPR_IDX2:
    case SET_IF_STMT_ACT:
    case SET_SELECT_STMT_ARG:
    case SET_SELECT_ARGVAL:
    case SET_SELECT_STMT_ACT:
    case SET_EXPR_ARG:
    case SET_BOOL_EXPR_ARG:
    case SET_EXPR_OP:
    case INPUT_DREG_IDX:
    case INPUT_IOREG_IDX:
    case INPUT_CONST:
    case SET_BOOL_CONST:
    case SET_LBL_NUM:
    case SET_JUMP_TGT:
      contents = loadInstructions(active_prog);
      break;
      
    case ACTIVE_FRAMES:
      /* workingText corresponds to the active row's index display */
      if (row_select == 0) {
        contents.add(newLine("Tool: ", workingText));
        contents.add(newLine("User: ", Integer.toString(activeUserFrame + 1)));
      } else {
        contents.add(newLine("Tool: ", Integer.toString(activeToolFrame + 1)));
        contents.add(newLine("User: ", workingText));
      }
      break;
      
    //View frame details
    case NAV_TOOL_FRAMES:
      contents = loadFrames(CoordFrame.TOOL);
      break;
    case NAV_USER_FRAMES:
      contents = loadFrames(CoordFrame.USER);
      break;
    //View frame details
    case TFRAME_DETAIL:
    case TEACH_3PT_TOOL:
    case TEACH_6PT:
      contents = loadFrameDetail(CoordFrame.TOOL);
      break;
    case UFRAME_DETAIL:
    case TEACH_3PT_USER:
    case TEACH_4PT:
      contents = loadFrameDetail(CoordFrame.USER);
      break;
    case FRAME_METHOD_TOOL:
    case FRAME_METHOD_USER:
    case DIRECT_ENTRY_USER:
    case DIRECT_ENTRY_TOOL:
    case EDIT_DREG_VAL:
    case CP_DREG_COM:
    case CP_DREG_VAL:
    case CP_PREG_COM:
    case CP_PREG_PT:
    case SWAP_PT_TYPE:
      contents = this.contents;
      break;
      
    //View/ edit registers
    case NAV_DREGS:
    case NAV_PREGS_C:
    case NAV_PREGS_J:
      contents = loadRegisters();
      break;
    case EDIT_PREG_C:
    case EDIT_PREG_J:
      contents = this.contents;
      break;
    case EDIT_DREG_COM:
    case EDIT_PREG_COM:
      contents = loadTextInput();
      break;
     
    default:
      break;
  }
  
  return contents;
}
//Options menu text
public ArrayList<String> getOptions(Screen mode){
  ArrayList<String> options = new ArrayList<String>();
  
  switch(mode) {
    //Main menu and submenus
    case NAV_MAIN_MENU:
      options.add("1 UTILITIES (NA)"   );
      options.add("2 TEST CYCLE (NA)"  );
      options.add("3 MANUAL FCTNS (NA)");
      options.add("4 ALARM (NA)"       );
      options.add("5 I/O (NA)"         );
      options.add("6 SETUP"            );  
      options.add("7 FILE (NA)"        );
      options.add("8 USER (NA)"        );
      break;
    case NAV_SETUP:
      options.add("1 Prog Select (NA)" );
      options.add("2 General (NA)"     );
      options.add("3 Call Guard (NA)"  );
      options.add("4 Frames"           );
      options.add("5 Macro (NA)"       );
      options.add("6 Ref Position (NA)");
      options.add("7 Port Init (NA)"   );
      options.add("8 Ovrd Select (NA)" );
      options.add("9 User Alarm (NA)"  );
      options.add("0 --NEXT--"         );
      break;
      
    case CONFIRM_PROG_DELETE:
      options.add("Delete selected program?");
      break;
    
    //Instruction options
    case NAV_INSTR_MENU:
      options.add("1 Insert"           );
      options.add("2 Delete"           );
      options.add("3 Cut/ Copy"        );
      options.add("4 Paste (NA)"       );
      options.add("5 Find/ Replace"    );
      options.add("6 Renumber"         );
      options.add("7 Comment"          );
      options.add("8 Undo (NA)"        );
      options.add("9 Remark"           );
      break;
    case CONFIRM_INSERT:
      options.add("Enter number of lines to insert:");
      options.add("\0" + workingText);
      break;
    case SELECT_INSTR_DELETE:
      options.add("Select lines to delete (ENTER).");
      break;
    case SELECT_CUT_COPY:
      options.add("Select lines to cut/ copy (ENTER).");
      break;
    case FIND_REPL:
      options.add("Enter text to search for:");
      options.add("\0" + workingText);
      break;
    case CONFIRM_RENUM: 
      options.add("Renumber program positions?");
      break;
    case SELECT_COMMENT:
      options.add("Select lines to comment/uncomment.");
      break;
      
    //Instruction edit options
    case SET_MV_INSTR_TYPE:
    case SET_MV_INSTR_REG_TYPE:
    case SET_MV_INSTR_IDX:
    case SET_MV_INSTR_SPD:
    case SET_MV_INSTR_TERM:
    case SET_MV_INSTR_OFFSET:
    case SET_IO_INSTR_STATE:
    case SET_IO_INSTR_IDX:
    case SET_FRM_INSTR_TYPE:
    case SET_FRAME_INSTR_IDX:
    case SET_REG_EXPR_TYPE:
    case SET_REG_EXPR_IDX1:
    case SET_REG_EXPR_IDX2:
    case SET_IF_STMT_ACT:
    case SET_SELECT_STMT_ARG:
    case SET_SELECT_ARGVAL:
    case SET_SELECT_STMT_ACT:
    case SET_EXPR_ARG:
    case SET_BOOL_EXPR_ARG:
    case SET_EXPR_OP:
    case INPUT_DREG_IDX:
    case INPUT_IOREG_IDX:
    case INPUT_CONST:
    case SET_BOOL_CONST:
    case SET_LBL_NUM:
    case SET_JUMP_TGT:
      options = loadInstrEdit(mode);
      break;
    
    //Insert instructions (non-movemet)
    case SELECT_INSTR_INSERT:
      options.add("1. I/O"       );
      options.add("2. Frames"    );
      options.add("3. Registers" );
      options.add("4. IF/SELECT" );
      options.add("5. JMP/LBL"   );
      options.add("6. CALL"      );
      options.add("7. WAIT (NA)"      );
      options.add("8. Macro (NA)"     );
      break;
    case SELECT_IO_INSTR_REG:
      options = loadIORegisters();
      break;
    case SELECT_FRAME_INSTR_TYPE:
      options.add("1. TFRAME_NUM = ...");
      options.add("2. UFRAME_NUM = ...");
      break;
    case SELECT_REG_STMT:
      options.add("1. R[x] = (...)");
      options.add("2. IO[x] = (...)");
      options.add("3. PR[x] = (...)");
      options.add("4. PR[x, y] = (...)");
      break;
    case SELECT_COND_STMT:
      options.add("1. IF Stmt");
      options.add("2. IF (...)");
      options.add("3. SELECT Stmt");
      break;
    case SELECT_JMP_LBL:
      options.add("1. LBL[...]");
      options.add("2. JMP LBL[...]");
      break;
      
    //Frame navigation and edit menus
    case SELECT_FRAME_MODE:
      options.add("1. Tool Frame");
      options.add("2. User Frame");
      break;
    case FRAME_METHOD_TOOL:
      options.add("1. Three Point Method");
      options.add("2. Six Point Method");
      options.add("3. Direct Entry Method");
      break;
    case FRAME_METHOD_USER:
      options.add("1. Three Point Method");
      options.add("2. Four Point Method");
      options.add("3. Direct Entry Method");
      break;
    case VIEW_INST_REG:
      options = loadInstructionReg();
      break;
    
    case TEACH_3PT_TOOL:
    case TEACH_3PT_USER:
    case TEACH_4PT:
    case TEACH_6PT:
      options = loadPointList();
      break;
    //Data navigation and edit menus
    case NAV_DATA:
      options.add("1. Data Registers");
      options.add("2. Position Registers");
      break;
    case NAV_PREGS_J:
    case NAV_PREGS_C:
      opt_select = -1;
      // Display the point with the Position register of the highlighted line, when viewing the Position registers
      if (active_index >= 0 && active_index < GPOS_REG.length && GPOS_REG[active_index].point != null) {
        String[] pregEntry = GPOS_REG[active_index].point.toLineStringArray(mode == Screen.NAV_PREGS_C);
        
        for (String line : pregEntry) {
          options.add(line);
        }
      }
      
      break;
    case CP_DREG_COM:
      options.add(String.format("Move R[%d]'s comment to:", active_index + 1));
      options.add(String.format("R[%s]", workingText));
      break;
    case CP_DREG_VAL:
      options.add(String.format("Move R[%d]'s value to:", active_index + 1));
      options.add(String.format("R[%s]", workingText));
      break;
    case CP_PREG_COM:
      options.add(String.format("Move PR[%d]'s comment to:", active_index + 1));
      options.add(String.format("PR[%s]", workingText));
      break;
    case CP_PREG_PT:
      options.add(String.format("Move PR[%d]'s point to:", active_index + 1));
      options.add(String.format("PR[%s]", workingText));
      break;
    case SWAP_PT_TYPE:
      options.add("1. Cartesian");
      options.add("2. Joint");
      break;
    case EDIT_DREG_VAL:
      options.add("Input register value:");
      options.add("\0" + workingText);
      break;
    case DIRECT_ENTRY_TOOL:
    case DIRECT_ENTRY_USER:
    case EDIT_PREG_C:
    case EDIT_PREG_J:
      options = this.options;
      break;
    case EDIT_RSTMT:
      options.add("Register");
      options.add("Position Register Point");
      options.add("Position Register Value");
      break;
    
    //Misc functions
    case JUMP_TO_LINE:
      options.add("Use number keys to enter line number to jump to");
      options.add("\0" + workingText);
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        options.add("1. Uppercase");
        options.add("1. Lowercase");
      }
  }

  return options;
}

//Function label text
public String[] getFunctionLabels(Screen mode){
  String[] funct = new String[5];
  
  switch(mode) {
    case NAV_PROGRAMS:
      // F2, F3
      funct[0] = "[Create]";
      if(programs.size() > 0) {
        funct[1] = "[Rename]";
        funct[2] = "[Delete]";
        funct[3] = "[Copy]";
        funct[4] = "";
      } else {
        funct[1] = "";
        funct[2] = "";
        funct[3] = "";
        funct[4] = "";
      }
      break;
    case NAV_PROG_INSTR:
      // F1, F4, F5f
      funct[0] = shift ? "[New Pt]" : "";
      funct[1] = "[New Ins]";
      funct[2] = "";
      funct[3] = "[Edit]";
      funct[4] = (col_select == 0) ? "[Opt]" : "";
      if(activeInstruction() instanceof MotionInstruction) {
        funct[4] = (col_select == 3) ? "[Reg]" : funct[4];
      } 
      else if(activeInstruction() instanceof IfStatement) {
        IfStatement stmt = (IfStatement)activeInstruction();
        int selectIdx = getSelectedIdx();
        
        if(stmt.expr instanceof Expression) {
          if(selectIdx > 1 && selectIdx < stmt.expr.getLength() + 1) {
            funct[2] = "[Insert]";
          }
          if(selectIdx > 2 && selectIdx < stmt.expr.getLength() + 1) {
            funct[4] = "[Delete]";
          }
        }
      } else if(activeInstruction() instanceof SelectStatement) {
        int selectIdx = getSelectedIdx();
        
        if(selectIdx >= 3) {
          funct[2] = "[Insert]";
          funct[4] = "[Delete]";
        }
      } else if(activeInstruction() instanceof RegisterStatement) {
        RegisterStatement stmt = (RegisterStatement)activeInstruction();
        int rLen = (stmt.posIdx == -1) ? 2 : 3;
        int selectIdx = getSelectedIdx();

        if(selectIdx > rLen && selectIdx < stmt.expr.getLength() + rLen) {
          funct[2] = "[Insert]";
        }
        if(selectIdx > (rLen + 1) && selectIdx < stmt.expr.getLength() + rLen) {
          funct[4] = "[Delete]";
        }
      }
      break;
    case VIEW_INST_REG:
      funct[0] = "";
      funct[1] = "";
      funct[2] = "";
      funct[3] = "";
      funct[4] = "[Offset]";
      break;
    case SELECT_COMMENT:
      funct[0] = "";
      funct[1] = "";
      funct[2] = "";
      funct[3] = "[Done]";
      funct[4] = "";
      break;
    case SELECT_CUT_COPY:
      funct[0] = "";
      funct[1] = "";
      funct[2] = "[Cut]";
      funct[3] = "[Copy]";
      funct[4] = "[Cancel]";
      break;
    case NAV_TOOL_FRAMES:
    case NAV_USER_FRAMES:
      // F1, F2, F3
      if(shift) {
        funct[0] = "[Clear]";
        funct[1] = "";
        funct[2] = "[Switch]";
        funct[3] = "";
        funct[4] = "";
      } else {
        funct[0] = "[Set]";
        funct[1] = "";
        funct[2] = "[Switch]";
        funct[3] = "";
        funct[4] = "";
      }
      break;
    case TFRAME_DETAIL:
    case UFRAME_DETAIL:
      // F2
      funct[0] = "";
      funct[1] = "[Method]";
      funct[2] = "";
      funct[3] = "";
      funct[4] = "";
      break;
    case TEACH_3PT_TOOL:
    case TEACH_3PT_USER:
    case TEACH_4PT:
    case TEACH_6PT:
      // F1, F5
      funct[0] = "";
      funct[1] = "[Method]";
      funct[2] = "";
      funct[3] = "[Mov To]";
      funct[4] = "[Record]";
      break;
    case DIRECT_ENTRY_TOOL:
    case DIRECT_ENTRY_USER:
      funct[0] = "";
      funct[1] = "[Method]";
      funct[2] = "";
      funct[3] = "";
      funct[4] = "";
      break;
    case ACTIVE_FRAMES:
      // F1, F2
      funct[0] = "[List]";
      funct[1] = "";
      funct[2] = "";
      funct[3] = "";
      funct[4] = "";
      break;
    case NAV_PREGS_C:
    case NAV_PREGS_J:
      // F1 - F5
      if (shift) {
        funct[0] = "[Clear]";
        funct[1] = "[Copy]";
        funct[2] = "[Type]";
        funct[3] = "[Move To]";
        funct[4] = "[Record]";
      } else {
        funct[0] = "[Clear]";
        funct[1] = "[Copy]";
        funct[2] = "[Switch]";
        funct[3] = "[Move To]";
        funct[4] = "[Record]";
      }
     break;
    case NAV_DREGS:
      // F1 - F3
      funct[0] = "[Clear]";
      funct[1] = "[Copy]";
      funct[2] = "[Switch]";
      funct[3] = "";
      funct[4] = "";
      break;
    case CONFIRM_INSERT:
    case CONFIRM_PROG_DELETE:
    case CONFIRM_RENUM:
    case FIND_REPL:
    case SELECT_INSTR_DELETE:
      // F4, F5
      funct[0] = "";
      funct[1] = "";
      funct[2] = "";
      funct[3] = "[Confirm]";
      funct[4] = "[Cancel]";
      break;
    default:
      if (mode.type == ScreenType.TYPE_TEXT_ENTRY) {
        if(opt_select == 0) {
          // F1 - F5
          funct[0] = "[ABCDEF]";
          funct[1] = "[GHIJKL]";
          funct[2] = "[MNOPQR]";
          funct[3] = "[STUVWX]";
          funct[4] = "[YZ_@*.]";
        } else {
          funct[0] = "[abcdef]";
          funct[1] = "[ghijkl]";
          funct[2] = "[mnopqr]";
          funct[3] = "[stuvwx]";
          funct[4] = "[yz_@*.]";
        }
      } else {
        funct[0] = "";
        funct[1] = "";
        funct[2] = "";
        funct[3] = "";
        funct[4] = "";
      }
      break;
  }
  
  return funct;
}

/*
 * Removes all text on screen and prepares the UI to transition to a
 * new screen display.
 */
public void clearScreen() {
  //remove all text labels on screen  
  List<Textarea> displayText = cp5.getAll(Textarea.class);
  for(Textarea t: displayText) {
    // ONLY remove text areas from the Pendant!
    if (t.getParent().equals(g1)) {
      cp5.remove(t.getName());
    }
  }
  
  cp5.update();
}

public void clearContents() {
  for(int i = 0; i < index_contents; i += 1) {
    if(cp5.getGroup(Integer.toString(i)) != null)
    cp5.getGroup(Integer.toString(i)).remove();
  }
  
  index_contents = 0;
}

public void clearOptions() {
  for(int i = 100; i < index_options; i += 1) {
    if(cp5.getGroup(Integer.toString(i)) != null)
    cp5.getGroup(Integer.toString(i)).remove();
  }
  
  index_options = 100;
}

public void clearNums() {
  for(int i = 1000; i < index_nums; i += 1) {
    if(cp5.getGroup(Integer.toString(i)) != null)
    cp5.getGroup(Integer.toString(i)).remove();
  }
  
  index_nums = 1000;
}

public ArrayList<DisplayLine> loadPrograms() {
  ArrayList<DisplayLine> progs = new ArrayList<DisplayLine>();
  int size = programs.size();
   
  //int start = start_render;
  //int end = min(start + ITEMS_TO_SHOW, size);
  
  for(int i = 0; i < size; i += 1) {
    progs.add(newLine(i, programs.get(i).getName()));
  }
  
  return progs;
}

// prepare for displaying motion instructions on screen
public ArrayList<DisplayLine> loadInstructions(int programID) {
  ArrayList<DisplayLine> instruct_list = new ArrayList<DisplayLine>();
  int tokenOffset = TXT_PAD - PAD_OFFSET;
  
  Program p = programs.get(programID);
  int size = p.getInstructions().size();
    
  for(int i = 0; i < size; i+= 1) {
    DisplayLine line = new DisplayLine(i);
    Instruction instr = p.getInstruction(i);
    int xPos = 10;
    
    // Add line number
    if(instr.isCommented()) {
      line.add("//"+Integer.toString(i+1) + ")");
    } else {
      line.add(Integer.toString(i+1) + ")");
    }
    
    int numWdth = line.get(line.size() - 1).length();
    xPos += numWdth*CHAR_WDTH + tokenOffset;
    
    if(instr instanceof MotionInstruction) {
      // Show '@' at the an instrution, if the Robot's position is close to that position stored in the instruction's register
      MotionInstruction a = (MotionInstruction)instr;
      Point ee_point = nativeRobotEEPoint(armModel.getJointAngles());
      Point instPt = a.getVector(p);
      
      if(instPt != null && ee_point.position.dist(instPt.position) < (liveSpeed / 100f)) {
        line.add("@");
      }
      else {
        line.add("\0");
      }
      
      xPos += CHAR_WDTH + tokenOffset;
    }
    
    String[] fields = instr.toStringArray();
    
    for (int j = 0; j < fields.length; j += 1) {
      String field = fields[j];
      xPos += field.length()*CHAR_WDTH + tokenOffset;
      
      if(field.equals("\n") && j != fields.length - 1) {
        instruct_list.add(line);
        if(instr instanceof SelectStatement) {
          xPos = 11*CHAR_WDTH + 3*tokenOffset;
        } else {
          xPos = 3*CHAR_WDTH + 3*tokenOffset;
        }
        
        line = new DisplayLine(i, xPos);
        xPos += field.length()*CHAR_WDTH + tokenOffset;
      } else if(xPos > display_width) {
        instruct_list.add(line);
        xPos = 2*CHAR_WDTH + tokenOffset;
        
        line = new DisplayLine(i, xPos);
        field = ": " + field;
        xPos += field.length()*CHAR_WDTH + tokenOffset;
      }
      
      if(!field.equals("\n")) {
        line.add(field);
      }
    }
    
    instruct_list.add(line);
  }
  
  if(mode.getType() != ScreenType.TYPE_LINE_SELECT) {
    instruct_list.add(newLine(size, "[End]"));
  }
  
  return instruct_list;
}

/**
 * Deals with updating the UI after confirming/canceling a deletion
 */
public void updateInstructions() {
  int instSize = activeProgram().getInstructions().size();
  
  active_instr = min(active_instr,  instSize - 1);
  row_select = min(active_instr, ITEMS_TO_SHOW - 1);
  col_select = 0;
  start_render = active_instr - row_select;
  
  lastScreen();
}

public void getInstrEdit(Instruction ins, int selectIdx) {
  if(ins instanceof MotionInstruction) {
    if(getSelectedLine() == 0) {
      // edit movement instruction line 1
      switch(col_select) {
        case 2: // motion type
          nextScreen(Screen.SET_MV_INSTR_TYPE);
          break;
        case 3: // register type
          nextScreen(Screen.SET_MV_INSTR_REG_TYPE);
          break;
        case 4: // register
          nextScreen(Screen.SET_MV_INSTR_IDX);
          break;
        case 5: // speed
          nextScreen(Screen.SET_MV_INSTR_SPD);
          break;
        case 6: // termination type
          nextScreen(Screen.SET_MV_INSTR_TERM);
          break;
        case 7: // offset register
          nextScreen(Screen.SET_MV_INSTR_OFFSET);
          break;
      }
    } else {
      // edit movement instruciton line 2 (circular only)
      switch(col_select) {
        case 0: // register type
          nextScreen(Screen.SET_MV_INSTR_REG_TYPE);
          break;
        case 1: // register
          nextScreen(Screen.SET_MV_INSTR_IDX);
          break;
        case 2: // speed
          nextScreen(Screen.SET_MV_INSTR_SPD);
          break;
        case 3: // termination type
          nextScreen(Screen.SET_MV_INSTR_TERM);
          break;
        case 4: // offset register
          nextScreen(Screen.SET_MV_INSTR_OFFSET);
          break;
      }
    }
  }
  else if(ins instanceof FrameInstruction) {
    switch(selectIdx) {
      case 1:
        nextScreen(Screen.SET_FRM_INSTR_TYPE);
        break;
      case 2:
        nextScreen(Screen.SET_FRAME_INSTR_IDX);
        break;
    }
  }
  else if(ins instanceof IOInstruction) {
     switch(selectIdx) {
      case 1:
        nextScreen(Screen.SET_IO_INSTR_IDX);
        break;
      case 2:
        nextScreen(Screen.SET_IO_INSTR_STATE);
        break;
    }
  }
  else if(ins instanceof LabelInstruction){
    nextScreen(Screen.SET_LBL_NUM);
  }
  else if(ins instanceof JumpInstruction){
    nextScreen(Screen.SET_JUMP_TGT);
  }
  else if(ins instanceof CallInstruction){
    nextScreen(Screen.SET_CALL_PROG);
  } 
  else if(ins instanceof IfStatement){
    IfStatement stmt = (IfStatement)ins;
    
    if(stmt.expr instanceof Expression) {
      int len = stmt.expr.getLength();
      
      if(selectIdx >= 3 && selectIdx < len + 1) {
        editExpression((Expression)stmt.expr, 3);
      } else if(selectIdx == len + 2) {
        nextScreen(Screen.SET_IF_STMT_ACT);
      } else if(selectIdx == len + 3) {
        if(stmt.instr instanceof JumpInstruction) {
          nextScreen(Screen.SET_JUMP_TGT);
        } else {
          nextScreen(Screen.SET_CALL_PROG);
        }
      }
    } 
    else if(stmt.expr instanceof BooleanExpression) {
      if(selectIdx == 2) {
        opEdit = ((BooleanExpression)stmt.expr).getArg1();
        nextScreen(Screen.SET_BOOL_EXPR_ARG);
      } else if(selectIdx == 3) {
        opEdit = stmt.expr;
        nextScreen(Screen.SET_EXPR_OP);
      } else if(selectIdx == 4){
        opEdit = ((BooleanExpression)stmt.expr).getArg2();
        nextScreen(Screen.SET_BOOL_EXPR_ARG);
      } else if(selectIdx == 5){
        nextScreen(Screen.SET_IF_STMT_ACT);
      } else {
        if(stmt.instr instanceof JumpInstruction) {
          nextScreen(Screen.SET_JUMP_TGT);
        } else {
          nextScreen(Screen.SET_CALL_PROG);
        }
      }
    }
  } 
  else if(ins instanceof SelectStatement) {
    SelectStatement stmt = (SelectStatement)ins;
    
    if(selectIdx == 2) {
      opEdit = stmt.arg;
      nextScreen(Screen.SET_SELECT_STMT_ARG);
    } else if((selectIdx - 3) % 3 == 0 && selectIdx > 2) {
      opEdit = stmt.cases.get((selectIdx - 3)/3);
      nextScreen(Screen.SET_SELECT_STMT_ARG);
    } else if((selectIdx - 3) % 3 == 1) {
      editIdx = (selectIdx - 3)/3;
      nextScreen(Screen.SET_SELECT_STMT_ACT);
    } else if((selectIdx - 3) % 3 == 2) {
      editIdx = (selectIdx - 3)/3;
      if(stmt.instrList.get(editIdx) instanceof JumpInstruction) {
        nextScreen(Screen.SET_JUMP_TGT);
      } else if(stmt.instrList.get(editIdx) instanceof CallInstruction) {
        nextScreen(Screen.SET_CALL_PROG);
      }
    }
  } else if(ins instanceof RegisterStatement) {
    RegisterStatement stmt = (RegisterStatement)ins;
    int len = stmt.expr.getLength();
    int rLen = (stmt.posIdx == -1) ? 2 : 3;
    
    if(selectIdx == 1) {
      nextScreen(Screen.SET_REG_EXPR_TYPE);
    } else if(selectIdx == 2) {
      nextScreen(Screen.SET_REG_EXPR_IDX1);
    } else if(selectIdx == 3 && stmt.posIdx != -1) {
      nextScreen(Screen.SET_REG_EXPR_IDX2);
    } else if(selectIdx >= rLen + 1 && selectIdx <= len + rLen) {
      editExpression(stmt.expr, selectIdx - (rLen + 2));
    }
  }
}

public void editExpression(Expression expr, int selectIdx) {
  int[] elements = expr.mapToEdit();
  opEdit = expr;
  ExpressionElement e = expr.get(elements[selectIdx]);
  
  if(e instanceof Expression) {
    //if selecting the open or close paren
    if(selectIdx == 0 || selectIdx == e.getLength() || 
    elements[selectIdx - 1] != elements[selectIdx] || 
    elements[selectIdx + 1] != elements[selectIdx]) {
      nextScreen(Screen.SET_EXPR_ARG);
    } else {
      int startIdx = expr.getStartingIdx(elements[selectIdx]);
      editExpression((Expression)e, selectIdx - startIdx - 1);
    }
  } else if(e instanceof ExprOperand) {
    editOperand((ExprOperand)e, elements[selectIdx]);
  } else {
    editIdx = elements[selectIdx];
    nextScreen(Screen.SET_EXPR_OP);
  }
}

/**
 * Accepts an ExpressionOperand object and forwards the UI to the appropriate
 * menu to edit said object based on the operand type.
 *
 * @param o - The operand to be edited.
 * @ins_idx - The index of the operand's container ExpressionElement list into which this
 *     operand is stored.
 *
 */
public void editOperand(ExprOperand o, int ins_idx) {
  switch(o.type) {
    case -2: //Uninit
      editIdx = ins_idx;
      nextScreen(Screen.SET_EXPR_ARG);
      break;
    case 0: //Float const
      opEdit = o;
      nextScreen(Screen.INPUT_CONST);
      break;
    case 1: //Bool const
      opEdit = o;
      nextScreen(Screen.SET_BOOL_CONST);
      break;
    case 2: //Data reg
      opEdit = o;
      nextScreen(Screen.INPUT_DREG_IDX);
      break;
    case 3: //IO reg
      opEdit = o;
      switchScreen(Screen.INPUT_IOREG_IDX);
      break;
  }
}

public ArrayList<String> loadInstrEdit(Screen mode) {
  ArrayList<String> edit = new ArrayList<String>();
  
  switch(mode){
    case SET_MV_INSTR_TYPE:
      edit.add("1.JOINT");
      edit.add("2.LINEAR");
      edit.add("3.CIRCULAR");
      break;
    case SET_MV_INSTR_REG_TYPE:
      edit.add("1.LOCAL(P)");
      edit.add("2.GLOBAL(PR)");
      break;
    case SET_MV_INSTR_IDX:
      edit.add("Enter desired position/ register (1-1000):");
      edit.add("\0" + workingText);
      break;
    case SET_MV_INSTR_SPD:
      edit.add("Enter desired speed:");
      MotionInstruction castIns = activeMotionInst();
      
      if(castIns.getMotionType() == MTYPE_JOINT) {
        speedInPercentage = true;
        workingTextSuffix = "%";
      } else {
        workingTextSuffix = "mm/s";
        speedInPercentage = false;
      }
      
      edit.add(workingText + workingTextSuffix);
      break;
    case SET_MV_INSTR_TERM:
      edit.add("Enter desired termination %(0-100):");
      edit.add("\0" + workingText);
      break;
    case SET_MV_INSTR_OFFSET:
      edit.add("Enter desired offset register (1-1000):");
      edit.add("\0" + workingText);
      break;
    case SET_IO_INSTR_STATE:
      edit.add("1. ON");
      edit.add("2. OFF");
      break;
    case SET_IO_INSTR_IDX:
      edit.add("Select I/O register index:");
      edit.add("\0" + workingText);
      break;
    case SET_FRM_INSTR_TYPE:
      edit.add("1. TFRAME_NUM = x");
      edit.add("2. UFRAME_NUM = x");
      break;
    case SET_FRAME_INSTR_IDX:
      edit.add("Select frame index:");
      edit.add("\0" + workingText);
      break;
    case SET_REG_EXPR_TYPE:
      edit.add("1. R[x] = (...)");
      edit.add("2. IO[x] = (...)");
      edit.add("3. PR[x] = (...)");
      edit.add("4. PR[x, y] = (...)");
      break;
    case SET_REG_EXPR_IDX1:
      edit.add("Select register index:");
      edit.add("\0" + workingText);
      break;
    case SET_REG_EXPR_IDX2:
      edit.add("Select point index:");
      edit.add("\0" + workingText);
      break;
    case SET_EXPR_OP:
      if(opEdit instanceof BooleanExpression) {
        edit.add("1. ... =  ...");
        edit.add("2. ... <> ...");
        edit.add("3. ... >  ...");
        edit.add("4. ... <  ...");
        edit.add("5. ... >= ...");
        edit.add("6. ... <= ...");
      } else if(opEdit instanceof Expression) {
        if(activeInstruction() instanceof IfStatement) {
          edit.add("1. + ");
          edit.add("2. - ");
          edit.add("3. * ");
          edit.add("4. / ");
          edit.add("5. | ");
          edit.add("6. % ");
          edit.add("7. = ");
          edit.add("8. <> ");
          edit.add("9. > ");
          edit.add("10. < ");
          edit.add("11. >= ");
          edit.add("12. <= ");
          edit.add("13. AND ");
          edit.add("14. OR ");
          edit.add("15. NOT ");
          edit.add("16. ... ");
        } else {
          edit.add("1. + ");
          edit.add("2. - ");
          edit.add("3. * ");
          edit.add("4. / ");
          edit.add("5. | ");
          edit.add("6. % ");
        }
      }
      break;
    case SET_EXPR_ARG:
    case SET_BOOL_EXPR_ARG:
      edit.add("R[x]");
      edit.add("IO[x]");
      if(opEdit instanceof Expression) {
        edit.add("PR[x]");
        edit.add("PR[x, y]");
        edit.add("(...)");
      }
      edit.add("Const");
      break;
    case INPUT_DREG_IDX:
    case INPUT_IOREG_IDX:
    case INPUT_PREG_IDX1:
      edit.add("Input register index:");
      edit.add("\0" + workingText);
      break;
    case INPUT_PREG_IDX2:
      edit.add("Input position value index:");
      edit.add("\0" + workingText);
      break;
    case INPUT_CONST:
      edit.add("Input constant value:");
      edit.add("\0" + workingText);
      break;
    case SET_BOOL_CONST:
      edit.add("1. False");
      edit.add("2. True");
      break;
    case SET_IF_STMT_ACT:
    case SET_SELECT_STMT_ACT:
      edit.add("JMP LBL[x]");
      edit.add("CALL");
      break;
    case SET_SELECT_STMT_ARG:
      edit.add("R[x]");
      edit.add("Const");
      break;
    case SET_SELECT_ARGVAL:
      edit.add("Input value/ register index:");
      edit.add("\0" + workingText);
      break;
    case SET_LBL_NUM:
      edit.add("Set label number:");
      edit.add("\0" + workingText);
      break;
    case SET_JUMP_TGT:
      edit.add("Set jump target label:");
      edit.add("\0" + workingText);
      break;
    default:
      break;
  }
  
  return edit;
}

public ArrayList<String> loadInstructionReg() {
  ArrayList<String> instReg = new ArrayList<String>();
  
  // show register contents if you're highlighting a register
  Instruction ins = activeInstruction();
  if(ins instanceof MotionInstruction) {
    MotionInstruction castIns = (MotionInstruction)ins;
    Point p = castIns.getVector(activeProgram());
    
    if (p != null) {
      instReg.add("Position values (press ENTER to exit):");
      
      String[] regEntry = p.toLineStringArray(castIns.getMotionType() != MTYPE_JOINT);
      
      for (String line : regEntry) {
        instReg.add(line);
      }
      
      displayPoint = p;
    }
  }
  
  return instReg;
}

// clears the array of selected lines
public boolean[] resetSelection(int n) {
  selectedLines = new boolean[n];
  for(int i = 0; i < n; i += 1){
    selectedLines[i] = false;
  }
  
  return selectedLines;
}

public void newMotionInstruction() {
  Point pt = nativeRobotEEPoint(armModel.getJointAngles());
  Frame active = getActiveFrame(CoordFrame.USER);
  
  if (active != null) {
    // Convert into currently active frame
    pt = applyFrame(pt, active.getOrigin(), active.getOrientation());
    
    if (DISPLAY_TEST_OUTPUT) {
      System.out.printf("New: %s\n", convertNativeToWorld(pt.position));
    }
  }
  
  // overwrite current instruction
  Program prog = activeProgram();
  int reg = prog.getNextPosition();
  
  prog.addPosition(pt, reg);
  
  if(getSelectedLine() > 0) {
    MotionInstruction m = (MotionInstruction)activeInstruction();
    m.getSecondaryPoint().setPosition(reg);
    prog.setNextPosition(reg + 1);
  }
  else {
    MotionInstruction insert = new MotionInstruction(
    curCoordFrame == CoordFrame.JOINT ? MTYPE_JOINT : MTYPE_LINEAR,
    reg,
    false,
    (curCoordFrame == CoordFrame.JOINT ? liveSpeed : liveSpeed*armModel.motorSpeed) / 100f,
    0,
    activeUserFrame,
    activeToolFrame);
    
    if(active_instr != prog.getInstructions().size()) {
      prog.overwriteInstruction(active_instr, insert);
    } else {
      prog.addInstruction(insert);
    }
  }
}

public void newFrameInstruction(int fType) {
  Program p = activeProgram();
  FrameInstruction f = new FrameInstruction(fType, -1);
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, f);
  } else {
    p.addInstruction(f);
  }
}

public void newIOInstruction() {
  Program p = activeProgram();
  IOInstruction io = new IOInstruction(opt_select, OFF);
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, io);
  } else {
    p.addInstruction(io);
  }
}

public void newLabel() {
  Program p = activeProgram();
  
  LabelInstruction l = new LabelInstruction(-1);
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, l);
  } else {
    p.addInstruction(l);
  }
}

public void newJumpInstruction() {
  Program p = activeProgram();
  JumpInstruction j = new JumpInstruction(-1);
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, j);
  } else {
    p.addInstruction(j);
  }
}


public void newCallInstruction() {
  Program p = activeProgram();
  CallInstruction call = new CallInstruction();
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, call);
  } else {
    p.addInstruction(call);
  }
}

public void newIfStatement() {
  Program p = activeProgram();
  IfStatement stmt = new IfStatement(Operator.EQUAL, null);
  opEdit = stmt.expr;
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, stmt);
  } else {
    p.addInstruction(stmt);
  }
}

public void newIfExpression() {
  Program p = activeProgram();
  IfStatement stmt = new IfStatement();
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, stmt);
  } else {
    p.addInstruction(stmt);
  }
}

public void newSelectStatement() {
  Program p = activeProgram();
  SelectStatement stmt = new SelectStatement();
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, stmt);
  } else {
    p.addInstruction(stmt);
  }
}

public void newRegisterStatement(Register r) {
  Program p = activeProgram();
  RegisterStatement stmt = new RegisterStatement(r);
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, stmt);
  } else {
    p.addInstruction(stmt);
  }
}

public void newRegisterStatement(Register r, int i) {
  Program p = activeProgram();
  RegisterStatement stmt = new RegisterStatement(r, i);
  
  if(active_instr != p.getInstructions().size()) {
    p.overwriteInstruction(active_instr, stmt);
  } else {
    p.addInstruction(stmt);
  }
}

/**
 * Updates the index display in the Active Frames menu based on the
 * current value of workingText
 */
public void updateActiveFramesDisplay() {
  // Attempt to parse the inputted integer value
  try {
    int frameIdx = Integer.parseInt(workingText) - 1;
    
    if (frameIdx >= -1 && frameIdx < 10) {
      // Update the appropriate active Frame index
      if (row_select == 0) {
        activeToolFrame = frameIdx;
      } else {
        activeUserFrame = frameIdx;
      }
      
      updateCoordFrame();
    }
      
  } catch(NumberFormatException NFEx) {
    // Non-integer value
  }
  // Update display
  if (row_select == 0) {
    workingText = Integer.toString(activeToolFrame + 1);
  } else {
    workingText = Integer.toString(activeUserFrame + 1);
  }
  
  contents.get(row_select).set(col_select, workingText);
  updateScreen();
}

/**
 * Loads the set of Frames that correspond to the given coordinate frame.
 * Only TOOL and USER have Frames sets as of now.
 * 
 * @param coorFrame  the integer value representing the coordinate frame
 *                   of the desired frame set
 */
public ArrayList<DisplayLine> loadFrames(CoordFrame coordFrame) {
  ArrayList<DisplayLine> frameDisplay = new ArrayList<DisplayLine>();
  
  Frame[] frames;
  
  switch(coordFrame) {
    // Only the Tool and User Frame lists have been implemented
    case TOOL:
      frames = toolFrames;
      break;
    case USER:
      frames = userFrames;
      break;
    default:
      System.err.println("Invalid frame type @GUI: loadFrames.");
      return null;
  }
  
  for(int idx = 0; idx < frames.length; idx += 1) {
    // Display each frame on its own line
    String[] strArray = frames[idx].toLineStringArray();
    frameDisplay.add(newLine(idx, String.format("%-4s %s", String.format("%d)", idx + 1), strArray[0])));
    frameDisplay.add(newLine(idx, String.format("%s", strArray[1])));
    frameDisplay.get(idx*2 + 1).xAlign = 38;
  }
  
  return frameDisplay;
}

/**
 * Transitions to the Frame Details menu, which displays
 * the x, y, z, w, p, r values associated with the Frame
 * at curFrameIdx in either the Tool Frames or User Frames,
 * based on the value of super_mode.
 */
public ArrayList<DisplayLine> loadFrameDetail(CoordFrame coordFrame) {
  ArrayList<DisplayLine> details = new ArrayList<DisplayLine>();
  
  // Display the frame set name as well as the index of the currently selected frame
  if(coordFrame == CoordFrame.TOOL) {
    println(curFrameIdx);
    String[] fields = toolFrames[curFrameIdx].toLineStringArray();
    // Place each value in the frame on a separate lien
    for(String field : fields) { details.add(newLine(field)); }
    
  } else if(coordFrame == CoordFrame.USER) {
    String[] fields = userFrames[curFrameIdx].toLineStringArray();
    // Place each value in the frame on a separate lien
    for(String field : fields) { details.add(newLine(field)); }
  
  } else {
    return null;
  }
  
  return details;
}

/**
 * Displays the points along with their respective titles for the
 * current frame teach method (discluding the Direct Entry method).
 */
public ArrayList<String> loadPointList() {
  ArrayList<String> points = new ArrayList<String>();
  
  if(teachFrame != null) {
    
    ArrayList<String> temp = new ArrayList<String>();
    // Display TCP teach points
    if(mode == Screen.TEACH_3PT_TOOL || mode == Screen.TEACH_6PT) {
      temp.add("First Approach Point: ");
      temp.add("Second Approach Point: ");
      temp.add("Third Approach Point: ");
    }
    // Display Axes Vectors teach points
    if(mode == Screen.TEACH_3PT_USER || mode == Screen.TEACH_4PT || mode == Screen.TEACH_6PT) {
      temp.add("Orient Origin Point: ");
      temp.add("X Axis Point: ");
      temp.add("Y Axis Point: ");
    }
    // Display origin offset point
    if(mode == Screen.TEACH_4PT) {
      // Name of fourth point for the four point method?
      temp.add("Origin: ");
    }
    
    // Determine if the point has been set yet
    for(int idx = 0; idx < temp.size(); ++idx) {
      // Add each line to options
      points.add( temp.get(idx) + ((teachFrame.getPoint(idx) != null) ? "RECORDED" : "UNINIT") );
    }
  } else {
    // No teach points
    points.add("Error: teachFrame not set!");
  }
  
  return points;
}

/**
 * Takes the values associated with the given Frame's direct entry values
 * (X, Y, Z, W, P, R) and fills a 2D ArrayList, where the first column is
 * the prefix for the value in the second column.
 * 
 * @param f        The frame to be displayed for editing
 * @returning      A 2D ArrayList with the prefixes and values associated
 *                 with the Frame
 */
public ArrayList<DisplayLine> loadFrameDirectEntry(Frame f) {
  ArrayList<DisplayLine> frame = new ArrayList<DisplayLine>();
  
  String[][] entries = f.directEntryStringArray();
  
  for (int line = 0; line < entries.length; ++line) {
    frame.add(newLine(line, entries[line][0], entries[line][1]));
  }
  
  return frame; 
}

/**
 * This method attempts to modify the Frame based on the given value of method.
 * If method is even, then the frame is taught via the 3-Point Method. Otherwise,
 * the Frame is taught by either the 4-Point or 6-Point Method based on if the
 * Frame is a Tool Frame or a User Frame.
 * 
 * @param frame    The frame to be taught
 * @param method  The method by which to each the new Frame
 */
public void createFrame(Frame frame, int method) {
  if (teachFrame.setFrame(abs(method) % 2)) {
    if (DISPLAY_TEST_OUTPUT) { System.out.printf("Frame set: %d\n", curFrameIdx); }
    
    // Set new Frame
    if (frame instanceof ToolFrame) {
      // Update the current frame of the Robot Arm
      activeToolFrame = curFrameIdx;
      toolFrames[activeToolFrame] = frame;
      updateCoordFrame();
      
      saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
    } else {
      // Update the current frame of the Robot Arm
      activeUserFrame = curFrameIdx;
      userFrames[activeUserFrame] = frame;
      updateCoordFrame();
      
      saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
    }
    
  } else {
    println("Invalid input points");
  }
}

/**
 * This method takes the current values stored in contents (assuming that they corresond to
 * the six direct entry values X, Y, Z, W, P, R), parses them, saves them to given Frame object,
 * and sets the current Frame's values to the direct entry value, setting the current frame as
 * the active frame in the process.
 * 
 * @param taughtFrame  the Frame, to which the direct entry values will be stored
 */
public void createFrameDirectEntry(Frame taughtFrame, float[] inputs) {
  // The user enters values with reference to the World Frame
  PVector origin, wpr;
  
  if (taughtFrame instanceof UserFrame) {
    origin = convertWorldToNative( new PVector(inputs[0], inputs[1], inputs[2]) );
  } else {
    // Tool frame origins are actually an offset of the Robot's EE position
    origin = new PVector(inputs[0], inputs[1], inputs[2]);
  }
  // Convert the angles from degrees to radians, then convert from World to Native frame
  wpr = convertWorldToNative( (new PVector(inputs[3], inputs[4], inputs[5])).mult(DEG_TO_RAD) );
  
  // Save direct entry values
  taughtFrame.DEOrigin = origin;
  taughtFrame.DEOrientation = eulerToQuat(wpr);
  taughtFrame.setFrame(2);
  
  if(DISPLAY_TEST_OUTPUT) {
    wpr = quatToEuler(taughtFrame.orientation).mult(RAD_TO_DEG);
    System.out.printf("\n\n%s\n%s\nFrame set: %d\n", origin.toString(),
                      wpr.toString(), curFrameIdx);
  }
  
  // Set New Frame
  if(taughtFrame instanceof ToolFrame) {
    // Update the current frame of the Robot Arm
    activeToolFrame = curFrameIdx;
  } else {
    // Update the current frame of the Robot Arm
    activeUserFrame = curFrameIdx;
  } 
  
  updateCoordFrame();
  saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
}

/**
 * Displays the list of Registers in mode VIEW_REG or the Position Registers
 * for modes VIEW_REG_J or VIEW_REG_C. In mode VIEW_REG_J the joint angles
 * associated with the Point are displayed and the Cartesian values are
 * displayed in mode VIEW_REG_C.
 */
public ArrayList<DisplayLine> loadRegisters() { 
  ArrayList<DisplayLine> regs = new ArrayList<DisplayLine>();
  
  // View Registers or Position Registers
  //int start = start_render;
  //int end = min(start + ITEMS_TO_SHOW, DREG.length);
  
  // Display a subset of the list of registers
  for(int idx = 0; idx < DREG.length; ++idx) {
    String lbl;
    
    if(mode == Screen.NAV_DREGS) {
      lbl = (DREG[idx].comment == null) ? "" : DREG[idx].comment;
    } else {
      lbl  = (GPOS_REG[idx].comment == null) ? "" : GPOS_REG[idx].comment;
    }
    
    int buffer = 16 - lbl.length();
    while(buffer-- > 0) { lbl += " "; }
    
    String spaces;
    
    if(idx < 9) {
      spaces = "  ";
    } else if(idx < 99) {
      spaces = " ";
    } else {
      spaces = "";
    }
    
    // Display the comment asscoiated with a specific Register entry
    String regLbl = String.format("%s[%d:%s%s]", (mode == Screen.NAV_DREGS) ? "R" : "PR", (idx + 1), spaces, lbl);
    // Display Register value (* ifuninitialized)
    String regEntry = "*";
    
    if(mode == Screen.NAV_DREGS) {
      if(DREG[idx].value != null) {
        // Dispaly Register value
        regEntry = String.format("%4.3f", DREG[idx].value);
      }
      
    } else if(GPOS_REG[idx].point != null) {
      regEntry = "...";
    }
    
    regs.add(newLine(idx, regLbl, regEntry));
  }
  
  return regs;
}

/**
 * This method will transition to the INPUT_POINT_C or INPUT_POINT_J modes
 * based whether the current mode is VIEW_REG_C or VIEW_REG_J. In either
 * mode, the user will be prompted to input 6 floating-point values (X, Y,
 * Z, W, P, R or J1 - J6 for INPUT_POINT_C or INPUT_POINT_J respectively).
 * The input method is similar to inputting the value in DIRECT_ENTRY mode.
 */
public ArrayList<DisplayLine> loadPosRegEntry(PositionRegister reg) {
  ArrayList<DisplayLine> register = new ArrayList<DisplayLine>();
  
  if(reg.point == null) {
    // Initialize values to zero if the entry is null
    if(mode == Screen.EDIT_PREG_C) {
      register.add(newLine(0, "X: ",  ""));
      register.add(newLine(1, "Y: ",  ""));
      register.add(newLine(2, "Z: ",  ""));
      register.add(newLine(3, "W: ",  ""));
      register.add(newLine(4, "P: ",  ""));
      register.add(newLine(5, "R: ",  ""));
      
    } else if(mode == Screen.EDIT_PREG_J) {
      for(int idx = 0; idx < 6; idx += 1) {
        register.add(newLine(idx, String.format("J%d: ", idx), ""));
      }
    }
  } else {
    
    // List current entry values if the Register is initialized
    String[][] entries;
    
    if (mode == Screen.EDIT_PREG_J) {
      // List joint angles
      entries = reg.point.toJointStringArray();
    } else {
      // Display Cartesian values
      entries = reg.point.toCartesianStringArray();
    }
    
    for(int idx = 0; idx < entries.length; ++idx) {
      register.add(newLine(idx, entries[idx][0], entries[idx][1]));
    }
  }
   
  return register;
}

public ArrayList<String> loadIORegisters() {
  ArrayList<String> ioRegs = new ArrayList<String>();
  
  for(int i = 0; i < IO_REG.length; i += 1){
    String state = (IO_REG[i].state == ON) ? "ON" : "OFF";
    String ee;
    
    if (IO_REG[i].name != null) {
      ee = IO_REG[i].name;
    } else {
      ee = "";
    }
    
    ioRegs.add( String.format("IO[%d:%-8s] = %s", i + 1, ee, state) );
  }
  
  return ioRegs;
}

public void createRegisterPoint(boolean fromJointAngles) {
  // Obtain point inputs from UI display text
  float[] inputs = new float[6];
  try {
    for(int idx = 0; idx < inputs.length; ++idx) {
      String inputStr = contents.get(idx).get(col_select);
      inputs[idx] = Float.parseFloat(inputStr);
      // Bring the input values with the range [-9999, 9999]
      inputs[idx] = max(-9999f, min(inputs[idx], 9999f));
    }
  } catch (NumberFormatException NFEx) {
    // Invalid input
    println("Values must be real numbers!");
    return;
  }
  
  if(fromJointAngles) {
    // Bring angles within range: (0, TWO_PI)
    for(int idx = 0; idx < inputs.length; ++idx) {
      inputs[idx] = mod2PI(inputs[idx] * DEG_TO_RAD);
    }
    
    GPOS_REG[active_index].point = nativeRobotEEPoint(inputs);
  } else {
    PVector position = convertWorldToNative( new PVector(inputs[0], inputs[1], inputs[2]) );
    // Convert the angles from degrees to radians, then convert from World to Native frame, and finally convert to a quaternion
    float[] orientation = eulerToQuat( convertWorldToNative( (new PVector(inputs[3], inputs[4], inputs[5]).mult(DEG_TO_RAD)) ) );
    
    // Use default the Robot's joint angles for computing inverse kinematics
    float[] jointAngles = inverseKinematics(new float[] {0f, 0f, 0f, 0f, 0f, 0f}, position, orientation);
    GPOS_REG[active_index].point = new Point(position, orientation, jointAngles);
  }
  
  GPOS_REG[active_index].isCartesian = !fromJointAngles;
  saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
}

/**
 * This method loads text to screen in such a way as to allow the user
 * to input an arbitrary character string consisting of letters (a-z
 * upper and lower case) and/ or special characters (_, @, *, .) via
 * the function row, as well as numbers via the number pad. Strings are
 * limited to 16 characters and can be used to name new routines, as well
 * as set remark fields for frames and instructions.
 */
public ArrayList<DisplayLine> loadTextInput() {
  ArrayList<DisplayLine> remark = new ArrayList<DisplayLine>();
  
  remark.add(newLine("\0"));
 
  DisplayLine line = new DisplayLine();
  // Give each letter in the name a separate column
  for(int idx = 0; idx < workingText.length() && idx < TEXT_ENTRY_LEN; idx += 1) {
    line.add( Character.toString(workingText.charAt(idx)) );
  }
  
  remark.add(line);
  
  return remark;
}

/**
 * Given a set of Strings this method returns a single
 * String ArrayList, which contains all the given elements
 * in the order that they are given as arguments.
 * 
 * @param columns  A list of Strings
 * @return         An ArrayList containing all the given
 *                 Strings
 */
public DisplayLine newLine(String... columns) {
  DisplayLine line =  new DisplayLine();
  
  for(String col : columns) {
    line.add(col);
  }
  
  return line;
}

public DisplayLine newLine(int itemIdx, String... columns) {
  DisplayLine line =  new DisplayLine(itemIdx);
  
  for(String col : columns) {
    line.add(col);
  }
  
  return line;
}

/**
 * 
 */
public int moveUp(boolean page) {
  if (page && start_render > 0) {
    // Move display frame up an entire screen's display length
    row_select = max(0, row_select - (ITEMS_TO_SHOW - 1));
    start_render = max(0, start_render - (ITEMS_TO_SHOW - 1));
  } 
  else {
    // Move up a single row
    row_select = max(0, row_select - 1);
  }
  
  return contents.get(row_select).itemIdx;
}

public int moveUpInstr(boolean page) {
  if (page && start_render > 0) {
    // Move display frame up an entire screen's display length
    row_select = max(0, row_select - (ITEMS_TO_SHOW - 1));
    start_render = max(0, start_render - (ITEMS_TO_SHOW - 1));
  } 
  else {
    if(getSelectedIdx() == 0 && active_instr > 0) {
      // Move up a single instruction
      while(row_select > 0 && active_instr - 1 == contents.get(row_select - 1).itemIdx) {
        row_select = max(0, row_select - 1);
      }
    } else {
      // Move up a single row
      row_select = max(0, row_select - 1);
    }
  }
  
  return contents.get(row_select).itemIdx;  
}

/**
 * 
 */
public int moveDown(boolean page) {
  int size = contents.size();  
  
  if (page && size > (start_render + ITEMS_TO_SHOW)) {
    // Move display frame down an entire screen's display length
    row_select = min(size - 1, row_select + (ITEMS_TO_SHOW - 1));
    start_render = max(0, min(size - ITEMS_TO_SHOW, start_render + (ITEMS_TO_SHOW - 1)));
  } else {
    // Move down a single row
    row_select = min(size - 1, row_select + 1);
  }
  
  return contents.get(row_select).itemIdx;
}

public int moveDownInstr(boolean page) {
  int size = contents.size();  
  
  if (page && size > (start_render + ITEMS_TO_SHOW)) {
    // Move display frame down an entire screen's display length
    row_select = min(size - 1, row_select + (ITEMS_TO_SHOW - 1));
    start_render = max(0, min(size - ITEMS_TO_SHOW, start_render + (ITEMS_TO_SHOW - 1)));
  } else {
    int lenMod = 0;
    if(mode.getType() == ScreenType.TYPE_LINE_SELECT) lenMod = 1;
    if(getSelectedIdx() == 0 && active_instr < activeProgram().size() - lenMod) {
      // Move down a single instruction
      while(active_instr == contents.get(row_select).itemIdx) {
        row_select = min(size - 1, row_select + 1);
      }
    } else {
      // Move down a single row
      row_select = min(size - 1, row_select + 1);
    }
  }
  
  return contents.get(row_select).itemIdx;
}

public void moveLeft() {
  if(row_select > 0 && contents.get(row_select - 1).itemIdx == contents.get(row_select).itemIdx) {
    col_select -= 1;
    if(col_select < 0) {
      moveUp(false);
      col_select = contents.get(row_select).size() - 1;
    }
  } else {
    col_select = max(0, col_select - 1);
  }
}

public void moveRight() {
  if(row_select < contents.size() - 1 && contents.get(row_select + 1).itemIdx == contents.get(row_select).itemIdx) {
    col_select += 1;
    if(col_select > contents.get(row_select).size() - 1) {
      moveDown(false);
      col_select = 0;
    }
  } else {
    col_select = min(contents.get(row_select).size() - 1, col_select + 1);
  }
}

/**
 * Returns the first line in the current list of contents that the instruction 
 * matching the given index appears on.
 */
public int getInstrLine(int instrIdx) {
  ArrayList<DisplayLine> instr = loadInstructions(active_prog);
  int row = instrIdx;
  
  while(instr.get(row).itemIdx != instrIdx) {
    row += 1;
    if(row_select >= contents.size() - 1) break;
  }
  
  return row;
}

public int getSelectedLine() {
  int row = 0;
  DisplayLine currRow = contents.get(row_select);
  while(row_select - row >= 0 && currRow.itemIdx == contents.get(row_select - row).itemIdx) {
    row += 1;
  }
  
  return row - 1;
}

public int getSelectedIdx() {
  if(mode.getType() == ScreenType.TYPE_LINE_SELECT) return 0;
  
  int idx = col_select;
  for(int i = row_select - 1; i >= 0; i -= 1) {
    if(contents.get(i).itemIdx != contents.get(i + 1).itemIdx) break;
    idx += contents.get(i).size();
  }
  
  return idx;
}

public class DisplayLine {
  ArrayList<String> contents;
  int itemIdx;
  int xAlign;
      
  public DisplayLine() {
    contents = new ArrayList<String>();
    itemIdx = -1;
    xAlign = 0;
  }
  
  public DisplayLine(int idx) {
    contents = new ArrayList<String>();
    itemIdx = idx;
    xAlign = 0;
  }
  
  public DisplayLine(int idx, int align) {
    contents = new ArrayList<String>();
    itemIdx = idx;
    xAlign = align;
  }
  
  public DisplayLine(ArrayList<String> c, int idx, int align) {
    contents = c;
    itemIdx = idx;
    xAlign = align;
  }
  
  public int size() {
    return contents.size();
  }
  
  public String get(int idx) {
    return contents.get(idx);
  }
  
  public String set(int i, String s) {
    return contents.set(i, s);
  }
  
  public boolean add(String s) {
    return contents.add(s);
  }
  
  public void add(int i, String s) {
    contents.add(i, s);
  }
  
  public String remove(int i) {
    return contents.remove(i);
  }
}
/**
 * A extension of ControlP5's ButtonBar object that actually bloody
 * lets you figure out which button is active in a reasonable manner.
 */
public class ButtonTabs extends ButtonBar {
  
  private String selectedButtonName;
  
  public ButtonTabs(ControlP5 parent, String name) {
    super(parent, name);
    selectedButtonName = null;
  }
  
  public void onClick() {
    // Update active button state
    super.onClick();
    
    List items = getItems();
    selectedButtonName = null;
    // Determine which button is active
    for (Object item : items) {
      HashMap map = (HashMap)item;
      Object value = map.get("selected");
      
      if (value instanceof Boolean && (Boolean)value) {
        // Update selectedButtonName
        selectedButtonName = (String)map.get("name");
      }
    }
  }
  
  /**
   * Return the name of the button which is currenty active, or
   * null if no button is active.
   */
  public String getActiveButtonName() {
    return selectedButtonName;
  }
}

/**
 * An extension of the DropdownList class in ControlP5 that allows easier access of
 * the currently selected element's value.
 */
public class MyDropdownList extends DropdownList {
  
  public MyDropdownList( ControlP5 theControlP5 , String theName ) {
    super(theControlP5, theName);
  }

  protected MyDropdownList( ControlP5 theControlP5 , ControllerGroup< ? > theGroup , String theName , int theX , int theY , int theW , int theH ) {
    super( theControlP5 , theGroup , theName , theX , theY , theW , theH );
  }
  
  protected void onRelease() {
    super.onRelease();
    // Some dropdown lists influence the display
    manager.updateWindowContentsPositions();
  }
  
  /**
   * Updates the current active label for the dropdown list to the given
   * label, if it exists in the list.
   */
  public void setActiveLabel(String Elementlabel) {
    Map<String, Object> associatedObjects = getItem( getCaptionLabel().getText() );
    
    if (associatedObjects != null) {
      getCaptionLabel().setText(Elementlabel);
    }
  }
  
  /**
   * Updates the currently active label on the dropdown list based
   * on the current list of items.
   */
  public void updateActiveLabel() {
    Map<String, Object> associatedObjects = getItem( getCaptionLabel().getText() );
    
    if (associatedObjects == null || associatedObjects.isEmpty()) {
      getCaptionLabel().setText( getName() );
    }
  }
  
  /**
   * Returns the value associated with the active label of the Dropdown list.
   */
  public Object getActiveLabelValue() {    
    Map<String, Object> associatedObjects = getItem( getCaptionLabel().getText() );
    
    if (associatedObjects != null) {
      return associatedObjects.get("value");
    }
    
    // You got problems ...
    return null;
  }
  
  /**
   * Deactivates the currently selected option
   * in the Dropdown list.
   */
  public void resetLabel() {
    getCaptionLabel().setText( getName() );
    setValue(0);
  }
}

public class WindowManager {
  private ControlP5 UIManager;
  
  private Group createObjWindow, editObjWindow,
                sharedElements, scenarioWindow;

  private ButtonTabs windowTabs;
  private Button[] cameraViews;
  private Background background;
  
  private Textarea objNameLbl, scenarioNameLbl;
  private Textfield objName, scenarioName;
  
  private ArrayList<Textarea> shapeDefAreas;
  private ArrayList<Textfield> shapeDefFields;
  
  private Textarea[] objOrientationLbls;
  private Textfield[] objOrientationFields;
  
  private Textarea[] dropdownLbls;
  private MyDropdownList[] dropdownLists;
  
  private Button[] miscButtons;
  
  public static final int offsetX = 10,
                          distBtwFieldsY = 15,
                          distLblToFieldX = 5,
                          lLblWidth = 120,
                          mLblWidth = 86,
                          sLblWidth = 60,
                          fieldHeight = 20,
                          fieldWidth = 95,
                          lButtonWidth = 88,
                          mButtonWidth = 56,
                          sButtonWidth = 26,
                          sButtonHeight = 26,
                          tButtonHeight = 20,
                          sdropItemWidth = 80,
                          mdropItemWidth = 90,
                          ldropItemWidth = 120,
                          dropItemHeight = 21;
  
  /**
   * Creates a new window with the given ControlP5 object as the parent
   * and the given fonts which will be applied to the text in the window.
   */
  public WindowManager(ControlP5 manager, PFont small, PFont medium) {
    // Initialize content fields
    UIManager = manager;
    
    cameraViews = new Button[6];
    objOrientationLbls = new Textarea[6];
    objOrientationFields = new Textfield[6];
    shapeDefAreas = new ArrayList<Textarea>();
    shapeDefFields = new ArrayList<Textfield>();
    dropdownLbls = new Textarea[7];
    dropdownLists = new MyDropdownList[7];
    miscButtons = new Button[7];
    
    // Create some temporary color and dimension variables
    int bkgrdColor = color(210),
          fieldTxtColor = color(0),
          fieldCurColor = color(0),
          fieldActColor = color(255, 0, 0),
          fieldBkgrdColor = color(255),
          fieldFrgrdColor = color(0),
          buttonTxtColor = color(255),
          buttonDefColor = color(70),
          buttonActColor = color(220, 40, 40);
    
    int[] relPos = new int[] { 0, 0 };
    
    String[] windowList = new String[] { "Hide", "Pendant", "Create", "Edit", "Scenario" };
    // Create window tab bar
    windowTabs = (ButtonTabs)(new ButtonTabs(UIManager, "List:")
                  // Sets button text color
                  .setColorValue(buttonTxtColor)
                  .setColorBackground(buttonDefColor)
                  .setColorActive(buttonActColor)
                  .setPosition(relPos[0], relPos[1])
                  .setSize(windowList.length * lButtonWidth, tButtonHeight));
    
    windowTabs.getCaptionLabel().setFont(medium);
    windowTabs.addItems(windowList);
    
    // Initialize camera view buttons
    cameraViews[0] = UIManager.addButton("FrontView")
                              .setCaptionLabel("F")
                              .setColorValue(buttonTxtColor)
                              .setColorBackground(buttonDefColor)
                              .setColorActive(buttonActColor)
                              .moveTo(createObjWindow)
                              .setPosition(0, 0)
                              .setSize(sButtonWidth, sButtonHeight);
    
    cameraViews[1] = UIManager.addButton("BackView")
                              .setCaptionLabel("Bk")
                              .setColorValue(buttonTxtColor)
                              .setColorBackground(buttonDefColor)
                              .setColorActive(buttonActColor)
                              .moveTo(createObjWindow)
                              .setPosition(0, 0)
                              .setSize(sButtonWidth, sButtonHeight);
    
    cameraViews[2] = UIManager.addButton("LeftView")
                              .setCaptionLabel("L")
                              .setColorValue(buttonTxtColor)
                              .setColorBackground(buttonDefColor)
                              .setColorActive(buttonActColor)
                              .moveTo(createObjWindow)
                              .setPosition(0, 0)
                              .setSize(sButtonWidth, sButtonHeight);
    
    cameraViews[3] = UIManager.addButton("RightView")
                              .setCaptionLabel("R")
                              .setColorValue(buttonTxtColor)
                              .setColorBackground(buttonDefColor)
                              .setColorActive(buttonActColor)
                              .moveTo(createObjWindow)
                              .setPosition(0, 0)
                              .setSize(sButtonWidth, sButtonHeight);
    
    cameraViews[4] = UIManager.addButton("TopView")
                              .setCaptionLabel("T")
                              .setColorValue(buttonTxtColor)
                              .setColorBackground(buttonDefColor)
                              .setColorActive(buttonActColor)
                              .moveTo(createObjWindow)
                              .setPosition(0, 0)
                              .setSize(sButtonWidth, sButtonHeight);
    
    cameraViews[5] = UIManager.addButton("BottomView")
                              .setCaptionLabel("Bt")
                              .setColorValue(buttonTxtColor)
                              .setColorBackground(buttonDefColor)
                              .setColorActive(buttonActColor)
                              .moveTo(createObjWindow)
                              .setPosition(0, 0)
                              .setSize(sButtonWidth, sButtonHeight);
    
    
    relPos = relativePosition(windowTabs, RelativePoint.BOTTOM_LEFT, 0, 0);
    background = UIManager.addBackground("WindowBackground").setPosition(relPos[0], relPos[1])
                          .setBackgroundColor(bkgrdColor)
                          .setSize(windowTabs.getWidth(), 0);
    
    // Initialize the groups
    sharedElements = UIManager.addGroup("SHARED").setPosition(relPos[0], relPos[1])
                          .setBackgroundColor(bkgrdColor)
                          .setSize(windowTabs.getWidth(), 0)
                          .hideBar();
    
    createObjWindow = UIManager.addGroup("CREATEOBJ").setPosition(relPos[0], relPos[1])
                               .setBackgroundColor(bkgrdColor)
                               .setSize(windowTabs.getWidth(), 0)
                               .hideBar();
    
    editObjWindow = UIManager.addGroup("EDITOBJ").setPosition(relPos[0], relPos[1])
                             .setBackgroundColor(bkgrdColor)
                             .setSize(windowTabs.getWidth(), 0)
                             .hideBar();
    
    scenarioWindow = UIManager.addGroup("SCENARIO").setPosition(relPos[0], relPos[1])
                          .setBackgroundColor(bkgrdColor)
                          .setSize(windowTabs.getWidth(), 0)
                          .hideBar();
    
    // Initialize window contents
    for (int idx = 0; idx < 5; ++idx) {
      shapeDefAreas.add( UIManager.addTextarea(String.format("Dim%dLbl", idx), String.format("Dim(%d):", idx), 0, 0, mLblWidth, sButtonHeight)
                                  .setFont(medium)
                                  .setColor(fieldTxtColor)
                                  .setColorActive(fieldActColor)
                                  .setColorBackground(bkgrdColor)
                                  .setColorForeground(bkgrdColor)
                                  .moveTo(sharedElements) );
      
      shapeDefFields.add( UIManager.addTextfield(String.format("Dim%d", idx), 0, 0, fieldWidth, fieldHeight)
                                   .setColor(fieldTxtColor)
                                   .setColorCursor(fieldCurColor)
                                   .setColorActive(fieldActColor)
                                   .setColorLabel(bkgrdColor)
                                   .setColorBackground(fieldBkgrdColor)
                                   .setColorForeground(fieldFrgrdColor)
                                   .moveTo(sharedElements) );
    }
    
    dropdownLbls[0] = UIManager.addTextarea("ObjTypeLbl", "Type:", 0, 0, mLblWidth, sButtonHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(createObjWindow);
    
    objNameLbl = UIManager.addTextarea("ObjNameLbl", "Name:", 0, 0, sLblWidth, fieldHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(createObjWindow);
    
    objName = UIManager.addTextfield("ObjName", 0, 0, fieldWidth, fieldHeight)
                       .setColor(fieldTxtColor)
                       .setColorCursor(fieldCurColor)
                       .setColorActive(fieldActColor)
                       .setColorLabel(bkgrdColor)
                       .setColorBackground(fieldBkgrdColor)
                       .setColorForeground(fieldFrgrdColor)
                       .moveTo(createObjWindow);
    
    dropdownLbls[1] = UIManager.addTextarea("ShapeLbl", "Shape:", 0, 0, mLblWidth, sButtonHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(createObjWindow);
    
    dropdownLbls[2] = UIManager.addTextarea("FillLbl", "Fill:", 0, 0, mLblWidth, sButtonHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(createObjWindow);
    
    dropdownLbls[3] = UIManager.addTextarea("OutlineLbl", "Outline:", 0, 0, mLblWidth, sButtonHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(createObjWindow);
    
    miscButtons[0] = UIManager.addButton("CreateWldObj")
                                .setCaptionLabel("Create")
                                .setColorValue(buttonTxtColor)
                                .setColorBackground(buttonDefColor)
                                .setColorActive(buttonActColor)
                                .moveTo(createObjWindow)
                                .setPosition(0, 0)
                                .setSize(mButtonWidth, sButtonHeight);
    
    miscButtons[2] = UIManager.addButton("ClearFields")
                                .setCaptionLabel("Clear")
                                .setColorValue(buttonTxtColor)
                                .setColorBackground(buttonDefColor)
                                .setColorActive(buttonActColor)
                                .moveTo(createObjWindow)
                                .setPosition(0, 0)
                                .setSize(mButtonWidth, sButtonHeight);
    
    dropdownLbls[4] = UIManager.addTextarea("ObjLabel", "Object:", 0, 0, mLblWidth, fieldHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(editObjWindow);
    
    objOrientationLbls[0] = UIManager.addTextarea("XArea", "X:", 0, 0, sLblWidth, fieldHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(editObjWindow);
    
    objOrientationFields[0] = UIManager.addTextfield("XField", 0, 0, fieldWidth, fieldHeight)
                                 .setColor(fieldTxtColor)
                                 .setColorCursor(fieldCurColor)
                                 .setColorActive(fieldActColor)
                                 .setColorLabel(bkgrdColor)
                                 .setColorBackground(fieldBkgrdColor)
                                 .setColorForeground(fieldFrgrdColor)
                                 .moveTo(editObjWindow);
    
    objOrientationLbls[1] = UIManager.addTextarea("YArea", "Y:", 0, 0, sLblWidth, fieldHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(editObjWindow);
    
    objOrientationFields[1] = UIManager.addTextfield("YField", 0, 0, fieldWidth, fieldHeight)
                                 .setColor(fieldTxtColor)
                                 .setColorCursor(fieldCurColor)
                                 .setColorActive(fieldActColor)
                                 .setColorLabel(bkgrdColor)
                                 .setColorBackground(fieldBkgrdColor)
                                 .setColorForeground(fieldFrgrdColor)
                                 .moveTo(editObjWindow);
    
    objOrientationLbls[2] = UIManager.addTextarea("ZArea", "Z:", 0, 0, sLblWidth, fieldHeight)
                          .setFont(medium)
                          .setColor(fieldTxtColor)
                          .setColorActive(fieldActColor)
                          .setColorBackground(bkgrdColor)
                          .setColorForeground(bkgrdColor)
                          .moveTo(editObjWindow);
    
    objOrientationFields[2] = UIManager.addTextfield("ZField", 0, 0, fieldWidth, fieldHeight)
                                 .setColor(fieldTxtColor)
                                 .setColorCursor(fieldCurColor)
                                 .setColorActive(fieldActColor)
                                 .setColorLabel(bkgrdColor)
                                 .setColorBackground(fieldBkgrdColor)
                                 .setColorForeground(fieldFrgrdColor)
                                 .moveTo(editObjWindow);
    
    objOrientationLbls[3] = UIManager.addTextarea("WArea", "W:", 0, 0, sLblWidth, fieldHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(editObjWindow);
    
    objOrientationFields[3] = UIManager.addTextfield("WField", 0, 0, fieldWidth, fieldHeight)
                                 .setColor(fieldTxtColor)
                                 .setColorCursor(fieldCurColor)
                                 .setColorActive(fieldActColor)
                                 .setColorLabel(bkgrdColor)
                                 .setColorBackground(fieldBkgrdColor)
                                 .setColorForeground(fieldFrgrdColor)
                                 .moveTo(editObjWindow);
    
    objOrientationLbls[4] = UIManager.addTextarea("PArea", "P:", 0, 0, sLblWidth, fieldHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(editObjWindow);
    
    objOrientationFields[4] = UIManager.addTextfield("PField", 0, 0, fieldWidth, fieldHeight)
                                 .setColor(fieldTxtColor)
                                 .setColorCursor(fieldCurColor)
                                 .setColorActive(fieldActColor)
                                 .setColorLabel(bkgrdColor)
                                 .setColorBackground(fieldBkgrdColor)
                                 .setColorForeground(fieldFrgrdColor)
                                 .moveTo(editObjWindow);
    
    objOrientationLbls[5] = UIManager.addTextarea("RArea", "R:", 0, 0, sLblWidth, fieldHeight)
                         .setFont(medium)
                         .setColor(fieldTxtColor)
                         .setColorActive(fieldActColor)
                         .setColorBackground(bkgrdColor)
                         .setColorForeground(bkgrdColor)
                         .moveTo(editObjWindow);
    
    objOrientationFields[5] = UIManager.addTextfield("RField", 0, 0, fieldWidth, fieldHeight)
                                 .setColor(fieldTxtColor)
                                 .setColorCursor(fieldCurColor)
                                 .setColorActive(fieldActColor)
                                 .setColorLabel(bkgrdColor)
                                 .setColorBackground(fieldBkgrdColor)
                                 .setColorForeground(fieldFrgrdColor)
                                 .moveTo(editObjWindow);
    
    dropdownLbls[5] = UIManager.addTextarea("FixtureLbl", "Reference:", 0, 0, lLblWidth, sButtonHeight)
                          .setFont(medium)
                          .setColor(fieldTxtColor)
                          .setColorActive(fieldActColor)
                          .setColorBackground(bkgrdColor)
                          .setColorForeground(bkgrdColor)
                          .moveTo(editObjWindow);
    
    miscButtons[1] = UIManager.addButton("UpdateWldObj")
                                .setCaptionLabel("Confirm")
                                .setColorValue(buttonTxtColor)
                                .setColorBackground(buttonDefColor)
                                .setColorActive(buttonActColor)
                                .moveTo(editObjWindow)
                                .setSize(mButtonWidth, sButtonHeight);
    
    miscButtons[3] = UIManager.addButton("DeleteWldObj")
                                .setCaptionLabel("Delete")
                                .setColorValue(buttonTxtColor)
                                .setColorBackground(buttonDefColor)
                                .setColorActive(buttonActColor)
                                .moveTo(editObjWindow)
                                .setSize(mButtonWidth, sButtonHeight);
    
    scenarioNameLbl = UIManager.addTextarea("NewScenarioLbl", "Name:", 0, 0, sLblWidth, fieldHeight)
                          .setFont(medium)
                          .setColor(fieldTxtColor)
                          .setColorActive(fieldActColor)
                          .setColorBackground(bkgrdColor)
                          .setColorForeground(bkgrdColor)
                          .moveTo(scenarioWindow);
    
    scenarioName = UIManager.addTextfield("ScenarioName", 0, 0, fieldWidth, fieldHeight)
                            .setColor(fieldTxtColor)
                            .setColorCursor(fieldCurColor)
                            .setColorActive(fieldActColor)
                            .setColorLabel(bkgrdColor)
                            .setColorBackground(fieldBkgrdColor)
                            .setColorForeground(fieldFrgrdColor)
                            .moveTo(scenarioWindow);
    
    miscButtons[4] = UIManager.addButton("NewScenario")
                                .setCaptionLabel("New")
                                .setColorValue(buttonTxtColor)
                                .setColorBackground(buttonDefColor)
                                .setColorActive(buttonActColor)
                                .moveTo(scenarioWindow)
                                .setSize(mButtonWidth, sButtonHeight);
    
    dropdownLbls[6] = UIManager.addTextarea("ActiveScenarioLbl", "Scenario:", 0, 0, lLblWidth, sButtonHeight)
                          .setFont(medium)
                          .setColor(fieldTxtColor)
                          .setColorActive(fieldActColor)
                          .setColorBackground(bkgrdColor)
                          .setColorForeground(bkgrdColor)
                          .moveTo(scenarioWindow);
    
    miscButtons[5] = UIManager.addButton("SaveScenario")
                                .setCaptionLabel("Save")
                                .setColorValue(buttonTxtColor)
                                .setColorBackground(buttonDefColor)
                                .setColorActive(buttonActColor)
                                .moveTo(scenarioWindow)
                                .setSize(mButtonWidth, sButtonHeight);
    
    miscButtons[6] = UIManager.addButton("SetScenario")
                                .setCaptionLabel("Load")
                                .setColorValue(buttonTxtColor)
                                .setColorBackground(buttonDefColor)
                                .setColorActive(buttonActColor)
                                .moveTo(scenarioWindow)
                                .setSize(mButtonWidth, sButtonHeight);
    
    // Initialize dropdown lists
   dropdownLists[6] = (MyDropdownList)((new MyDropdownList( UIManager, "Scenario"))
                        .setSize(ldropItemWidth, 4 * dropItemHeight)
                        .setBarHeight(dropItemHeight)
                        .setItemHeight(dropItemHeight)
                        .setColorValue(buttonTxtColor)
                        .setColorBackground(buttonDefColor)
                        .setColorActive(buttonActColor)
                        .moveTo(scenarioWindow)
                        .close());
                      
   dropdownLists[5] = (MyDropdownList)((new MyDropdownList( UIManager, "Fixture"))
                        .setSize(ldropItemWidth, 4 * dropItemHeight)
                        .setBarHeight(dropItemHeight)
                        .setItemHeight(dropItemHeight)
                        .setColorValue(buttonTxtColor)
                        .setColorBackground(buttonDefColor)
                        .setColorActive(buttonActColor)
                        .moveTo(editObjWindow)
                        .close());
   
   dropdownLists[4] = (MyDropdownList)((new MyDropdownList( UIManager, "Object"))
                        .setSize(ldropItemWidth, 4 * dropItemHeight)
                        .setBarHeight(dropItemHeight)
                        .setItemHeight(dropItemHeight)
                        .setColorValue(buttonTxtColor)
                        .setColorBackground(buttonDefColor)
                        .setColorActive(buttonActColor)
                        .moveTo(editObjWindow)
                        .close());
     
    dropdownLists[3] = (MyDropdownList)((new MyDropdownList( UIManager, "Outline"))
                        .setSize(sdropItemWidth, sButtonHeight + 3 * dropItemHeight)
                        .setBarHeight(dropItemHeight)
                        .setItemHeight(dropItemHeight)
                        .setColorValue(buttonTxtColor)
                        .setColorBackground(buttonDefColor)
                        .setColorActive(buttonActColor)
                        .moveTo(createObjWindow)
                        .close());
    
    dropdownLists[3].addItem("black", color(0));
    dropdownLists[3].addItem("red", color(255, 0, 0));
    dropdownLists[3].addItem("green", color(0, 255, 0));
    dropdownLists[3].addItem("blue", color(0, 0, 255));
    dropdownLists[3].addItem("orange", color(255, 60, 0));
    dropdownLists[3].addItem("yellow", color(255, 255, 0));
    dropdownLists[3].addItem("pink", color(255, 0, 255));
    dropdownLists[3].addItem("purple", color(90, 0, 255));
    
    
    dropdownLists[2] = (MyDropdownList)((new MyDropdownList( UIManager, "Fill"))
                        .setSize(mdropItemWidth, 4 * dropItemHeight)
                        .setBarHeight(dropItemHeight)
                        .setItemHeight(dropItemHeight)
                        .setColorValue(buttonTxtColor)
                        .setColorBackground(buttonDefColor)
                        .setColorActive(buttonActColor)
                        .moveTo(createObjWindow)
                        .close());
   
    dropdownLists[2].addItem("white", color(255));
    dropdownLists[2].addItem("black", color(0));
    dropdownLists[2].addItem("red", color(255, 0, 0));
    dropdownLists[2].addItem("green", color(0, 255, 0));
    dropdownLists[2].addItem("blue", color(0, 0, 255));
    dropdownLists[2].addItem("orange", color(255, 60, 0));
    dropdownLists[2].addItem("yellow", color(255, 255, 0));
    dropdownLists[2].addItem("pink", color(255, 0, 255));
    dropdownLists[2].addItem("purple", color(90, 0, 255));
    dropdownLists[2].addItem("sky blue", color(0, 255, 255));
    dropdownLists[2].addItem("dark green", color(0, 100, 15));
   
   dropdownLists[1] = (MyDropdownList)((new MyDropdownList( UIManager, "Shape"))
                       .setSize(sdropItemWidth, 4 * dropItemHeight)
                       .setBarHeight(dropItemHeight)
                       .setItemHeight(dropItemHeight)
                       .setColorValue(buttonTxtColor)
                       .setColorBackground(buttonDefColor)
                       .setColorActive(buttonActColor)
                       .moveTo(createObjWindow)
                       .close());
                         
   dropdownLists[1].addItem("Box", ShapeType.BOX);
   dropdownLists[1].addItem("Cylinder", ShapeType.CYLINDER);
   dropdownLists[1].addItem("Import", ShapeType.MODEL);
   
   dropdownLists[0] = (MyDropdownList)((new MyDropdownList( UIManager, "ObjType"))
                       .setSize(sdropItemWidth, 3 * dropItemHeight)
                       .setBarHeight(dropItemHeight)
                       .setItemHeight(dropItemHeight)
                       .setColorValue(buttonTxtColor)
                       .setColorBackground(buttonDefColor)
                       .setColorActive(buttonActColor)
                       .moveTo(createObjWindow)
                       .close());
     
   dropdownLists[0].addItem("Parts", 0.0f);
   dropdownLists[0].addItem("Fixtures", 1.0f);
   
   // Set fonts for buttons and dropdown lists
   for (Button b : cameraViews) {
     b.getCaptionLabel().setFont(small);
     b.hide();
   }
   
   for (Button b : miscButtons) {
     b.getCaptionLabel().setFont(small);
   }
   
   for (DropdownList list : dropdownLists) {
     list.getCaptionLabel().setFont(small);
   }
  }
  
  /**
   * Updates the current active window display based on the selected button on
   * windowTabs. Due to some problems with hiding groups with the ControlP5
   * object, when a new window is brought up a large white sphere is drawn oer
   * the screen to clear the image of the previous window.
   */
  public void updateWindowDisplay() {
    String windowState = windowTabs.getActiveButtonName();
    
    if (windowState == null || windowState.equals("Hide")) {
      // Hide any window
      g1.hide();
      setGroupVisible(createObjWindow, false);
      setGroupVisible(editObjWindow, false);
      setGroupVisible(sharedElements, false);
      setGroupVisible(scenarioWindow, false);
      
      updateWindowContentsPositions();
      
    } else if (windowState.equals("Pendant")) {
      // Show pendant
      setGroupVisible(createObjWindow, false);
      setGroupVisible(editObjWindow, false);
      setGroupVisible(sharedElements, false);
      setGroupVisible(scenarioWindow, false);
      
      if (!g1.isVisible()) {
        updateWindowContentsPositions();
      }
      
      g1.show();
      
    } else if (windowState.equals("Create")) {
      // Show world object creation window
      g1.hide();
      setGroupVisible(editObjWindow, false);
      setGroupVisible(scenarioWindow, false);
      
      if (!createObjWindow.isVisible()) {
        setGroupVisible(createObjWindow, true);
        setGroupVisible(sharedElements, true);
        
        clearAllInputFields();
        updateWindowContentsPositions();
        updateListContents();
        resetListLabels();
      }
      
    } else if (windowState.equals("Edit")) {
      // Show world object edit window
      g1.hide();
      setGroupVisible(createObjWindow, false);
      setGroupVisible(scenarioWindow, false);
      
      if (!editObjWindow.isVisible()) {
        setGroupVisible(editObjWindow, true);
        setGroupVisible(sharedElements, true);
        
        clearAllInputFields();
        updateWindowContentsPositions();
        updateListContents();
        resetListLabels();
      }
      
    } else if (windowState.equals("Scenario")) {
      // Show scenario creating/saving/loading
      g1.hide();
      setGroupVisible(createObjWindow, false);
      setGroupVisible(editObjWindow, false);
      
      if (!scenarioWindow.isVisible()) {
        setGroupVisible(scenarioWindow, true);
        
        clearAllInputFields();
        updateWindowContentsPositions();
        updateListContents();
        resetListLabels();
      }
    }
  }
  
  /**
   * Updates the positions of all the elements in the active window
   * based on the current button tab that is active.
   */
  public void updateWindowContentsPositions() {
    String windowState = windowTabs.getActiveButtonName();
    
    if (windowState == null || windowState.equals("Hide")) {
      // Window is hidden
      background.hide();
      for (Button b : cameraViews) {
        b.hide();
      }
      
      return;
      
    } else if (windowState.equals("Create")) {
      // Create window
      updateCreateWindowContentPositions();
      
    } else if (windowState.equals("Edit")) {
      // Edit window
      updateEditWindowContentPositions();
      
    } else if (windowState.equals("Scenario")) {
      // Scenario window
      updateScenarioWindowContentPositions();
    }
    
    // Update the camera view buttons
    int[] relPos = relativePosition(windowTabs, RelativePoint.BOTTOM_RIGHT, offsetX, 0);
    
    for (Button b : cameraViews) {  
      b.setPosition(relPos[0], relPos[1]).show();
      relPos = relativePosition(b, RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    }
    
    updateListContents();
  }
  
  /**
   * Updates the positions of all the contents of the world object creation window.
   */
  private void updateCreateWindowContentPositions() {
    updateDimLblsAndFields();
    
    // Object Type dropdown list and label
    int[] relPos = new int[] { offsetX, offsetX };
    dropdownLbls[0] = dropdownLbls[0].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(dropdownLbls[0], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    dropdownLists[0] = (MyDropdownList)dropdownLists[0].setPosition(relPos[0], relPos[1]);
    // Name label and field
    relPos = relativePosition(dropdownLbls[0], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    objNameLbl = objNameLbl.setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(objNameLbl, RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    objName = objName.setPosition(relPos[0], relPos[1]);
    // Shape type label and dropdown
    relPos = relativePosition(objNameLbl, RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    dropdownLbls[1] = dropdownLbls[1].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(dropdownLbls[1], RelativePoint.TOP_RIGHT, distLblToFieldX, abs(fieldHeight - dropItemHeight) / 2);
    dropdownLists[1] = (MyDropdownList)dropdownLists[1].setPosition(relPos[0], relPos[1]);
    // Dimension label and fields
    relPos = relativePosition(dropdownLbls[1], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    relPos = updateDimLblAndFieldPositions(relPos[0], relPos[1]);
    
    // Fill color label and dropdown
    dropdownLbls[2] = dropdownLbls[2].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(dropdownLbls[2], RelativePoint.TOP_RIGHT, distLblToFieldX, abs(fieldHeight - dropItemHeight) / 2);
    dropdownLists[2] = (MyDropdownList)dropdownLists[2].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(dropdownLbls[2], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    Object val = dropdownLists[1].getActiveLabelValue();
    
    if (val == ShapeType.MODEL) {
      // No stroke color for Model Shapes
      dropdownLbls[3] = dropdownLbls[3].hide();
      dropdownLists[3] = (MyDropdownList)dropdownLists[3].hide();
      
    } else {
      // Outline color label and dropdown
      dropdownLbls[3] = dropdownLbls[3].setPosition(relPos[0], relPos[1]).show();
      relPos = relativePosition(dropdownLbls[3], RelativePoint.TOP_RIGHT, distLblToFieldX, abs(fieldHeight - dropItemHeight) / 2);
      
      dropdownLists[3] = (MyDropdownList)dropdownLists[3].setPosition(relPos[0], relPos[1]).show();
      relPos = relativePosition(dropdownLbls[3], RelativePoint.BOTTOM_RIGHT, distLblToFieldX, distBtwFieldsY);
    } 

    // Create button
    miscButtons[0] = miscButtons[0].setPosition(relPos[0], relPos[1]);
    // Clear button
    relPos = relativePosition(miscButtons[0], RelativePoint.TOP_RIGHT, offsetX, 0);
    miscButtons[2] = miscButtons[2].setPosition(relPos[0], relPos[1]);
    // Update window background display
    relPos = relativePosition(miscButtons[2], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    background.setBackgroundHeight(relPos[1])
              .setHeight(relPos[1])
              .show();
  }
  
  /**
   * Updates the positions of all the contents of the world object editing window.
   */
  private void updateEditWindowContentPositions() {
    updateDimLblsAndFields();
    
    // Object list dropdown and label
    int[] relPos = new int[] { offsetX, offsetX };
    dropdownLbls[4] = dropdownLbls[4].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(dropdownLbls[4], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    dropdownLists[4] = (MyDropdownList)dropdownLists[4].setPosition(relPos[0], relPos[1]);
    // Dimension label and fields
    relPos = relativePosition(dropdownLbls[4], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    relPos = updateDimLblAndFieldPositions(relPos[0], relPos[1]);
    
    // X label and field
    objOrientationLbls[0] = objOrientationLbls[0].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(objOrientationLbls[0], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    objOrientationFields[0] = objOrientationFields[0].setPosition(relPos[0], relPos[1]);
    // Y label and field
    relPos = relativePosition(objOrientationLbls[0], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    objOrientationLbls[1] = objOrientationLbls[1].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(objOrientationLbls[1], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    objOrientationFields[1] = objOrientationFields[1].setPosition(relPos[0], relPos[1]);
    // Z label and field
    relPos = relativePosition(objOrientationLbls[1], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    objOrientationLbls[2] = objOrientationLbls[2].setPosition(relPos[0], relPos[1]);;
    
    relPos = relativePosition(objOrientationLbls[2], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    objOrientationFields[2] = objOrientationFields[2].setPosition(relPos[0], relPos[1]);
    // W label and field
    relPos = relativePosition(objOrientationLbls[2], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    objOrientationLbls[3] = objOrientationLbls[3].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(objOrientationLbls[3], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    objOrientationFields[3] = objOrientationFields[3].setPosition(relPos[0], relPos[1]);
    // P label and field
    relPos = relativePosition(objOrientationLbls[3], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    objOrientationLbls[4] = objOrientationLbls[4].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(objOrientationLbls[4], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    objOrientationFields[4] = objOrientationFields[4].setPosition(relPos[0], relPos[1]);
    // R label and field
    relPos = relativePosition(objOrientationLbls[4], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    objOrientationLbls[5] = objOrientationLbls[5].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(objOrientationLbls[5], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    objOrientationFields[5] = objOrientationFields[5].setPosition(relPos[0], relPos[1]);
   
    relPos = relativePosition(objOrientationLbls[5], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    
    if (getActiveWorldObject() instanceof Part) {
       // Reference fxiture (for Parts only) label and dropdown
      dropdownLbls[5] = dropdownLbls[5].setPosition(relPos[0], relPos[1]).show();
      relPos = relativePosition(dropdownLbls[5], RelativePoint.TOP_RIGHT, distLblToFieldX, abs(fieldHeight - dropItemHeight) / 2);
      
      dropdownLists[5] = (MyDropdownList)dropdownLists[5].setPosition(relPos[0], relPos[1]).show();
      relPos = relativePosition(dropdownLbls[5], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
      
    } else {
      // Fixtures do not have a reference object
      dropdownLbls[5].hide();
      dropdownLists[5] = (MyDropdownList)dropdownLists[5].hide();
    }
    
    // Confirm button
    miscButtons[1] = miscButtons[1].setPosition(relPos[0], relPos[1]);
    // Delete button
    relPos = relativePosition(miscButtons[1], RelativePoint.TOP_RIGHT, offsetX, 0);
    miscButtons[3] = miscButtons[3].setPosition(relPos[0], relPos[1]);
    // Update window background display
    relPos = relativePosition(miscButtons[3], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    background.setBackgroundHeight(relPos[1])
              .setHeight(relPos[1])
              .show();
  }
  
  /**
   * Updates the positions of all the contents of the scenario window.
   */
  private void updateScenarioWindowContentPositions() {
    // New scenario name label
    int[] relPos = new int[] {offsetX, offsetX };
    scenarioNameLbl = scenarioNameLbl.setPosition(relPos[0], relPos[1]);
    // New scenario name field
    relPos = relativePosition(scenarioNameLbl, RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    scenarioName = scenarioName.setPosition(relPos[0], relPos[1]);
    // New scenario button
    relPos = relativePosition(scenarioNameLbl, RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    miscButtons[4] = miscButtons[4].setPosition(relPos[0], relPos[1]);
    // Scenario dropdown list and label
    relPos = relativePosition(miscButtons[4], RelativePoint.BOTTOM_LEFT, 0, 2 * distBtwFieldsY);
    dropdownLbls[6] = dropdownLbls[6].setPosition(relPos[0], relPos[1]);
    
    relPos = relativePosition(dropdownLbls[6], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    dropdownLists[6] = (MyDropdownList)dropdownLists[6].setPosition(relPos[0], relPos[1]);
    // Save scenario button
    relPos = relativePosition(dropdownLbls[6], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    miscButtons[5] = miscButtons[5].setPosition(relPos[0], relPos[1]);
    // Load scenario button
    relPos = relativePosition(miscButtons[5], RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
    miscButtons[6] = miscButtons[6].setPosition(relPos[0], relPos[1]);
    // Update window background display
    relPos = relativePosition(miscButtons[6], RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
    background.setBackgroundHeight(relPos[1])
              .setHeight(relPos[1])
              .show();
  }
  
  /**
   * Updates positions of all the visible dimension text areas and fields. The given x and y positions are used to
   * place the first text area and field pair and updated through the process of updating the positions of the rest
   * of the visible text areas and fields. Then the x and y position of the last visible text area and field is returned
   * in the form a 2-element integer array.
   * 
   * @param initialXPos  The x position of the first text area-field pair
   * @param initialYPos  The y position of the first text area-field pair
   * @returning          The x and y position of the last visible text area  in a 2-element integer array
   */
  private int[] updateDimLblAndFieldPositions(int initialXPos, int initialYPos) {
    int[] relPos = new int[] { initialXPos, initialYPos };
    int idxDim = 0;
    
    // Update position and label text of the dimension fields based on the selected shape from the Shape dropDown List
    while (idxDim < shapeDefFields.size()) {
      Textfield dimField = shapeDefFields.get(idxDim);
      
      if (!dimField.isVisible()) { break; }
      
      Textarea dimLbl = shapeDefAreas.get(idxDim);
      shapeDefAreas.set(idxDim, dimLbl.setPosition(relPos[0], relPos[1]) );
      relPos = relativePosition(dimLbl, RelativePoint.TOP_RIGHT, distLblToFieldX, 0);
      
      shapeDefFields.set(idxDim, dimField.setPosition(relPos[0], relPos[1]) );
      relPos = relativePosition(dimLbl, RelativePoint.BOTTOM_LEFT, 0, distBtwFieldsY);
      
      ++idxDim;
    }
    
    return relPos;
  }
  
  /**
   * Returns a position that is relative to the dimensions and position of the Controller object given.
   */
  private <T> int[] relativePosition(ControllerInterface<T> obj, RelativePoint pos, int offsetX, int offsetY) {
    int[] relPosition = new int[] { 0, 0 };
    float[] objPosition = obj.getPosition();
    float[] objDimensions;
    
    if (obj instanceof Group) {
      // getHeight() does not function the same for Group objects for some reason ...
      objDimensions = new float[] { obj.getWidth(), ((Group)obj).getBackgroundHeight() };
    } else if (obj instanceof DropdownList) {
      // Ignore the number of items displayed by the DropdownList, when it is open
      objDimensions = new float[] { obj.getWidth(), ((DropdownList)obj).getBarHeight() };
    } else {
      objDimensions = new float[] { obj.getWidth(), obj.getHeight() };
    }
    
    switch(pos) {
      case TOP_RIGHT:
        relPosition[0] = (int)(objPosition[0] + objDimensions[0] + offsetX);
        relPosition[1] = (int)(objPosition[1] + offsetY);
        break;
        
      case TOP_LEFT:
        relPosition[0] = (int)(objPosition[0] + offsetX);
        relPosition[1] = (int)(objPosition[1] + offsetY);
        break;
        
      case BOTTOM_RIGHT:
       relPosition[0] = (int)(objPosition[0] + objDimensions[0] + offsetX);
       relPosition[1] = (int)(objPosition[1] + objDimensions[1] + offsetY);
       break;
       
      case BOTTOM_LEFT:
        relPosition[0] = (int)(objPosition[0] + offsetX);
        relPosition[1] = (int)(objPosition[1] + objDimensions[1] + offsetY);
        break;
        
      default:
    }
    
    return relPosition;
  }
  
  /**
   * Update the contents of the two dropdown menus that
   * contain world objects.
   */
  private void updateListContents() {
    
    if (activeScenario != null) {
      dropdownLists[4] = (MyDropdownList)dropdownLists[4].clear();
      dropdownLists[5] = (MyDropdownList)dropdownLists[5].clear();
      dropdownLists[5].addItem("None", null);
      
      for (WorldObject wldObj : activeScenario) {
        dropdownLists[4].addItem(wldObj.toString(), wldObj);
        
        if (wldObj instanceof Fixture) {
          // Load all fixtures from the active scenario
          dropdownLists[5].addItem(wldObj.toString(), wldObj);
        }
      }
      // Update each dropdownlist's active label
      dropdownLists[4].updateActiveLabel();
      dropdownLists[5].updateActiveLabel();
    }
    
    dropdownLists[6] = (MyDropdownList)dropdownLists[6].clear();
    for (int idx = 0; idx < SCENARIOS.size(); ++idx) {
      // Load all scenario indices
      Scenario s = SCENARIOS.get(idx);
      dropdownLists[6].addItem(s.getName(), s);
    }
    dropdownLists[6].updateActiveLabel();
  }
  
  /**
   * Update how many of the dimension field and label pairs are displayed in
   * the create world object window based on which shape type is chosen from the shape dropdown list.
   */
  private void updateDimLblsAndFields() {
    String activeButtonLabel = windowTabs.getActiveButtonName();
    String[] lblNames = new String[0];
    
    if (activeButtonLabel != null) {
      if (activeButtonLabel.equals("Create")) {
        ShapeType selectedShape = (ShapeType)dropdownLists[1].getActiveLabelValue();
        
        // Define the label text and the number of dimensionos fields to display
        if (selectedShape == ShapeType.BOX) {
          lblNames = new String[] { "Length:", "Height:", "Width" };
          
        } else if (selectedShape == ShapeType.CYLINDER) {
          lblNames = new String[] { "Radius", "Height" };
          
        } else if (selectedShape == ShapeType.MODEL) {
          Object objType = dropdownLists[0].getActiveLabelValue();
          
          if (objType instanceof Float && (Float)objType == 0.0f) {
            // Define the dimensions of the bounding box of the Part
            lblNames = new String[] { "Source:", "Scale:", "Length:", "Height", "Width" };
            
          } else {
            lblNames = new String[] { "Source:", "Scale:" };
          }
    
        }
        
      } else if (activeButtonLabel.equals("Edit")) {
        Object val = dropdownLists[4].getActiveLabelValue();
        
        if (val instanceof WorldObject) {
          Shape s = ((WorldObject)val).getForm();
          
          if (s instanceof Box) {
            lblNames = new String[] { "Length:", "Height:", "Width" };
            
          } else if (s instanceof Cylinder) {
            lblNames = new String[] { "Radius", "Height" };
          
          } else if (s instanceof ModelShape) {
            if (val instanceof Part) {
              // Define the dimensions of the bounding box of the Part
              lblNames = new String[] { "Scale:", "Length:", "Height:", "Width" };
              
            } else if (val instanceof Fixture) {
              lblNames = new String[] { "Scale:" };
            }
          }
        }
        
      }
    }
    
    for (int idxDim = 0; idxDim < shapeDefFields.size(); ++idxDim) {
      if (idxDim < lblNames.length) {
        // Show a number of dimension fields and labels equal to the value of dimSize
        shapeDefAreas.set(idxDim, shapeDefAreas.get(idxDim).setText(lblNames[idxDim]).show());
        shapeDefFields.set(idxDim, shapeDefFields.get(idxDim).show());
        
      } else {
        // Hide remaining dimension fields and labels
        shapeDefAreas.set(idxDim, shapeDefAreas.get(idxDim).hide());
        shapeDefFields.set(idxDim, shapeDefFields.get(idxDim).hide());
      }
    }
  }
  
  /**
   * Only update the group visiblility if it does not
   * match the given visiblity flag.
   */
  private void setGroupVisible(Group g, boolean setVisible) {
    if (g.isVisible() != setVisible) {
      g.setVisible(setVisible);
    }
  }
  
  /**
   * Creates a world object form the input fields in the Create window.
   */
  public WorldObject createWorldObject() {
    // Check the object type dropdown list
    Object val = dropdownLists[0].getActiveLabelValue();
    // Determine if the object to be create is a Fixture or a Part
    Float objectType = 0.0f;
    
    if (val instanceof Float) {
      objectType = (Float)val;
    }
    
    pushMatrix();
    resetMatrix();
    WorldObject wldObj = null;
    
    try {
      
      if (objectType == 0.0f) {
        // Create a Part
        String name = objName.getText();
        
        ShapeType type = (ShapeType)dropdownLists[1].getActiveLabelValue();
          
        int fill = (Integer)dropdownLists[2].getActiveLabelValue();
        
        switch(type) {
          case BOX:
            int strokeVal = (Integer)dropdownLists[3].getActiveLabelValue();
            Float[] shapeDims = getBoxDimensions();
            // Construct a box shape
            if (shapeDims != null && shapeDims[0] != null && shapeDims[1] != null && shapeDims[2] != null) {
              wldObj = new Part(name, fill, strokeVal, shapeDims[0], shapeDims[1], shapeDims[2]);
            }
            break;
            
          case CYLINDER:
            strokeVal = (Integer)dropdownLists[3].getActiveLabelValue();
            shapeDims = getCylinderDimensions();
            // Construct a cylinder
            if (shapeDims != null && shapeDims[0] != null && shapeDims[1] != null) {
              wldObj = new Part(name, fill, strokeVal, shapeDims[0], shapeDims[1]);
            }
            break;
            
          case MODEL:
            String srcFile = shapeDefFields.get(0).getText();
            shapeDims = getModelDimensions(true);
            // Construct a complex model
            if (shapeDims != null && shapeDims[1] != null && shapeDims[2] != null && shapeDims[3] != null) {
              ModelShape model;
              
              if (shapeDims[0] != null) {
                // Define shape scale
                model = new ModelShape(srcFile, fill, shapeDims[0]);
              } else {
                model = new ModelShape(srcFile, fill);
              }
              
              wldObj = new Part(name, model, shapeDims[1], shapeDims[2], shapeDims[3]);
            }
            break;
          default:
        }
        
      } else if (objectType == 1.0f) {
        // Create a fixture
        String name = objName.getText();
        ShapeType type = (ShapeType)dropdownLists[1].getActiveLabelValue();
          
        int fill = (Integer)dropdownLists[2].getActiveLabelValue();
        
        switch(type) {
          case BOX:
            int strokeVal = (Integer)dropdownLists[3].getActiveLabelValue();
            Float[] shapeDims = getBoxDimensions();
            // Construct a box shape
            if (shapeDims != null && shapeDims[0] != null && shapeDims[1] != null && shapeDims[2] != null) {
              wldObj = new Fixture(name, fill, strokeVal, shapeDims[0], shapeDims[1], shapeDims[2]);
            }
            break;
            
          case CYLINDER:
            strokeVal = (Integer)dropdownLists[3].getActiveLabelValue();
            shapeDims = getCylinderDimensions();
            // Construct a cylinder
            if (shapeDims != null && shapeDims[0] != null && shapeDims[1] != null) {
              wldObj = new Fixture(name, fill, strokeVal, shapeDims[0], shapeDims[1]);
            }
            break;
            
          case MODEL:
            String srcFile = shapeDefFields.get(0).getText();
            shapeDims = getModelDimensions(false);
            // Construct a complex model
            ModelShape model;
            
            if (shapeDims != null && shapeDims[0] != null) {
              // Define model scale value
              model = new ModelShape(srcFile, fill, shapeDims[0]);
            } else {
              model = new ModelShape(srcFile, fill);
            }
            
            wldObj = new Fixture(name, model);
            break;
          default:
        }
      }
      
    } catch (NullPointerException NPEx) {
      println("Missing parameter!");
    } catch (ClassCastException CCEx) {
      println("Invalid field?");
      CCEx.printStackTrace();
    } catch (IndexOutOfBoundsException IOOBEx) {
      println("Missing field?");
      IOOBEx.printStackTrace();
    }
    
    popMatrix();
      
    return wldObj;
  }
  
  /**
   * Eit the position and orientation (as well as the fixture reference for Parts)
   * of the currently selected World Object in the Object dropdown list.
   */
  public void editWorldObject() {
    WorldObject toEdit = getActiveWorldObject();
    
    if (toEdit != null) {
      
      if (armModel != null && toEdit == armModel.held) {
        // Cannot edit an object being held by the Robot
        println("Cannot edit an object currently being held by the Robot!");
        return;
      }
      
      try {
        Shape s = toEdit.getForm();
        
        if (s instanceof Box) {
          Float[] newDims = getBoxDimensions();
          
          if (newDims[0] != null) {
            // Update the box's length
            s.setDim(newDims[0], DimType.LENGTH);
            
            if (toEdit instanceof Part) {
              // Update the bounding-box's length
              ((Part)toEdit).setOBBDim(newDims[0] + 10f, DimType.LENGTH);
            }
          }
          
          if (newDims[1] != null) {
            // Update the box's height
            s.setDim(newDims[1], DimType.HEIGHT);
            
            if (toEdit instanceof Part) {
              // Update the bounding-box's height
              ((Part)toEdit).setOBBDim(newDims[1] + 10f, DimType.HEIGHT);
            }
          }
          
          if (newDims[2] != null) {
            // Update the box's width
            s.setDim(newDims[2], DimType.WIDTH);
            
            if (toEdit instanceof Part) {
              // Update the bounding-box's width
              ((Part)toEdit).setOBBDim(newDims[2] + 10f, DimType.WIDTH);
            }
          }
          
        } else if (s instanceof Cylinder) {
          Float[] newDims = getCylinderDimensions();
          
          if (newDims[0] != null) {
            // Update the cylinder's radius
            s.setDim(newDims[0], DimType.RADIUS);
            
            if (toEdit instanceof Part) {
              // Update the bounding-box's length and height
              ((Part)toEdit).setOBBDim(2f * newDims[0] + 5f, DimType.LENGTH);
              ((Part)toEdit).setOBBDim(2f * newDims[0] + 5f, DimType.HEIGHT);
            }
          }
          
          if (newDims[1] != null) {
            // Update the cylinder's height
            s.setDim(newDims[1], DimType.HEIGHT);
            
            if (toEdit instanceof Part) {
              // Update the bounding-box's width
              ((Part)toEdit).setOBBDim(newDims[1] + 10f, DimType.WIDTH);
            }
          }
         
        } else if (s instanceof ModelShape) {
          Float[] newDims = getModelDimensions( (toEdit instanceof Part) );
          
          if (newDims[0] != null) {
            // Update the model's scale value
            s.setDim(newDims[0], DimType.SCALE);
          }
          
          if (toEdit instanceof Part) {
            // Update the length, height or width of the Part's bounding-box
            Part p = (Part)toEdit;
            
            if (newDims[1] != null) {
              // Update the bounding-box's length
              p.setOBBDim(newDims[1], DimType.LENGTH);
            }
            
            if (newDims[2] != null) {
              // Update the bounding-box's height
              p.setOBBDim(newDims[2], DimType.HEIGHT);
            }
            
            if (newDims[3] != null) {
              // Update the bounding-box's width
              p.setOBBDim(newDims[3], DimType.WIDTH);
            }
          }
        }
        
        // Convert origin position and orientation into the World Frame
        PVector oPosition = convertNativeToWorld( toEdit.getLocalCenter() ),
                oWPR = convertNativeToWorld( matrixToEuler(toEdit.getLocalOrientationAxes()).mult(RAD_TO_DEG) );
        Float[] inputValues = getOrientationValues();
        // Update position and orientation
        if (inputValues[0] != null) { oPosition.x = inputValues[0]; }
        if (inputValues[1] != null) { oPosition.y = inputValues[1]; }
        if (inputValues[2] != null) { oPosition.z = inputValues[2]; }
        if (inputValues[3] != null) { oWPR.x = inputValues[3]; }
        if (inputValues[4] != null) { oWPR.y = inputValues[4]; }
        if (inputValues[5] != null) { oWPR.z = inputValues[5]; }
        
        // Convert values from the World to the Native coordinate system
        PVector position = convertWorldToNative( oPosition );
        PVector wpr = convertWorldToNative( oWPR.mult(DEG_TO_RAD) );
        float[][] orientation = eulerToMatrix(wpr);
        // Update the Objects position and orientaion
        toEdit.setLocalCenter(position);
        toEdit.setLocalOrientationAxes(orientation);
        
        if (toEdit instanceof Part) {
          // Set the reference of the Part to the currently active fixture
          Fixture refFixture = (Fixture)dropdownLists[5].getActiveLabelValue();
          ((Part)toEdit).setFixtureRef(refFixture);
        }
      } catch (NullPointerException NPEx) {
        println("Missing parameter!");
      }
    } else {
      println("No object selected!");
    }
    
    /* If the edited object is a fixture, then update the orientation
     * of all parts, which reference this fixture, in this scenario. */
    if (toEdit instanceof Fixture) {
      if (activeScenario != null) {
        
        for (WorldObject wldObj : activeScenario) {
          if (wldObj instanceof Part) {
            Part p = (Part)wldObj;
            
            if (p.getFixtureRef() == toEdit) {
              p.updateAbsoluteOrientation();
            }
          }
        }
      }
    }
    
  }
  
  /**
   * TODO
   */
  private Float[] getBoxDimensions() {
    try {
      // null values represent an uninitialized field
      final Float[] dimensions = new Float[] { null, null, null };
      
      // Pull from the dim fields
      String lenField = shapeDefFields.get(0).getText(),
             hgtField = shapeDefFields.get(1).getText(),
             wdhField = shapeDefFields.get(2).getText();
      
      if (lenField != null && !lenField.equals("")) {
        // Read length input
        float val = Float.parseFloat(lenField);
        
        if (val <= 0) {
          throw new NumberFormatException("Invalid length value!");
        }
        // Length cap of 9999
        dimensions[0] = min(val, 9999f);
      }
      
      if (hgtField != null && !hgtField.equals("")) {
        // Read height input
        float val = Float.parseFloat(hgtField);
        
        if (val <= 0) {
          throw new NumberFormatException("Invalid height value!");
        }
        // Height cap of 9999
        dimensions[1] = min(val, 9999f);
      }
      
      if (wdhField != null && !wdhField.equals("")) {
        // Read Width input
        float val = Float.parseFloat(wdhField);
        
        if (val <= 0) {
          throw new NumberFormatException("Invalid width value!");
        }
        // Width cap of 9999
        dimensions[2] = min(val, 9999f);
      }
      
      return dimensions;
      
    } catch (NumberFormatException NFEx) {
      println("Invalid number input!");
      return null;
      
    } catch (NullPointerException NPEx) {
      println("Missing parameter!");
      return null;
    }
  }
  
  /**
   *TODO
   */
  private Float[] getCylinderDimensions() {
    try {
      // null values represent an uninitialized field
      final Float[] dimensions = new Float[] { null, null };
      
      // Pull from the dim fields
      String radField = shapeDefFields.get(0).getText(),
             hgtField = shapeDefFields.get(1).getText();
      
      if (radField != null && !radField.equals("")) {
        // Read radius input
        float val = Float.parseFloat(radField);
        
        if (val <= 0) {
          throw new NumberFormatException("Invalid length value!");
        }
        // Radius cap of 9999
        dimensions[0] = min(val, 9999f);
      }
      
      if (hgtField != null && !hgtField.equals("")) {
        // Read height input
        float val = Float.parseFloat(hgtField);
        
        if (val <= 0) {
          throw new NumberFormatException("Invalid height value!");
        }
        // Height cap of 9999
        dimensions[1] = min(val, 9999f);
      }
      
      return dimensions;
      
    } catch (NumberFormatException NFEx) {
      println("Invalid number input!");
      return null;
      
    } catch (NullPointerException NPEx) {
      println("Missing parameter!");
      return null;
    }
  }
  
  /**
   * TODO
   */
  private Float[] getModelDimensions(boolean forAPart) {
    try {
      // null values represent an uninitialized field
      final Float[] dimensions = new Float[] { null, null, null, null };
      
      String activeWindow = windowTabs.getActiveButtonName(),
             sclField, lenField, hgtField, wdhField;
      // Pull from the Dim fields
      if (activeWindow != null && activeWindow.equals("Create")) {
        sclField = shapeDefFields.get(1).getText();
        lenField = shapeDefFields.get(2).getText();
        hgtField = shapeDefFields.get(3).getText();
        wdhField = shapeDefFields.get(4).getText();
        
      } else {
        sclField = shapeDefFields.get(0).getText();
        lenField = shapeDefFields.get(1).getText();
        hgtField = shapeDefFields.get(2).getText();
        wdhField = shapeDefFields.get(3).getText();
      }
      
      if (sclField != null && !sclField.equals("")) {
        // Read scale input
        float val = Float.parseFloat(sclField);
        
        if (val <= 0) {
          throw new NumberFormatException("Invalid scale value");
        }
        // Scale cap of 50
        dimensions[0] = min(val, 50f);
      }
      
      if (forAPart) {
        if (lenField != null && !lenField.equals("")) {
          // Read length input
          float val = Float.parseFloat(lenField);
          
          if (val <= 0) {
            throw new NumberFormatException("Invalid length value!");
          }
          // Length cap of 9999
          dimensions[1] = min(val, 9999f);
        }
        
        if (hgtField != null && !hgtField.equals("")) {
          // Read height input
          float val = Float.parseFloat(hgtField);
          
          if (val <= 0) {
            throw new NumberFormatException("Invalid height value!");
          }
          // Height cap of 9999
          dimensions[2] = min(val, 9999f);
        }
        
        if (wdhField != null && !wdhField.equals("")) {
          // Read Width input
          float val = Float.parseFloat(wdhField);
          
          if (val <= 0) {
            throw new NumberFormatException("Invalid width value!");
          }
          // Width cap of 9999
          dimensions[3] = min(val, 9999f);
        }
      }
      
      return dimensions;
      
    } catch (NumberFormatException NFEx) {
      println(NFEx.getMessage());
      return null;
      
    } catch (NullPointerException NPEx) {
      println("Missing parameter!");
      return null;
    }
  }
  
  /**
   * TODO
   */
  private Float[] getOrientationValues() {
    try {
        // Pull from x, y, z, w, p, r, fields input fields
        String xFieldVal = objOrientationFields[0].getText(), yFieldVal = objOrientationFields[1].getText(),
               zFieldVal = objOrientationFields[2].getText(), wFieldVal = objOrientationFields[3].getText(),
               pFieldVal = objOrientationFields[4].getText(), rFieldVal = objOrientationFields[5].getText();
        // NaN indicates an uninitialized field
        Float[] values = new Float[] { null, null, null, null, null, null };
        
        // Update x value
        if (xFieldVal != null && !xFieldVal.equals("")) {
          float val = Float.parseFloat(xFieldVal);
          // Bring value within the range [-9999, 9999]
          val = max(-9999f, min(val, 9999f));
          values[0] = val;
        }
        // Update y value
        if (yFieldVal != null && !yFieldVal.equals("")) {
          float val = Float.parseFloat(yFieldVal);
          // Bring value within the range [-9999, 9999]
          val = max(-9999f, min(val, 9999f));
          values[1] = val;
        }
        // Update z value
        if (zFieldVal != null && !zFieldVal.equals("")) {
          float val = Float.parseFloat(zFieldVal);
          // Bring value within the range [-9999, 9999]
          val = max(-9999f, min(val, 9999f));
          values[2] = val;
        }
        // Update w angle
        if (wFieldVal != null && !wFieldVal.equals("")) {
          float val = Float.parseFloat(wFieldVal);
          // Bring value within the range [-9999, 9999]
          val = max(-9999f, min(val, 9999f));
          values[3] = val;
        }
        // Update p angle
        if (pFieldVal != null && !pFieldVal.equals("")) {
          float val = Float.parseFloat(pFieldVal);
          // Bring value within the range [-9999, 9999]
          val = max(-9999f, min(val, 9999f));
          values[4] = val;
        }
        // Update r angle
        if (rFieldVal != null && !rFieldVal.equals("")) {
          float val = Float.parseFloat(rFieldVal);
          // Bring value within the range [-9999, 9999]
          val = max(-9999f, min(val, 9999f));
          values[5] = val;
        }
        
        return values;
        
    } catch (NumberFormatException NFEx) {
      println("Invalid number input!");
      return null;
      
    } catch (NullPointerException NPEx) {
      println("Missing parameter!");
      return null;
    }
  }
  
  /**
   * Reset the base label of every dropdown list.
   */
  private void resetListLabels() {
    for (MyDropdownList list : dropdownLists) {
      list.resetLabel();
    }
    
    for (int idxDim = 0; idxDim < shapeDefFields.size(); ++idxDim) {
      // Hide remaining dimension fields and labels
      shapeDefAreas.set(idxDim, shapeDefAreas.get(idxDim).hide());
      shapeDefFields.set(idxDim, shapeDefFields.get(idxDim).hide());
      ++idxDim;
    }
    
    dropdownLbls[5].hide();
    dropdownLists[5] = (MyDropdownList)dropdownLists[5].hide();
    updateDimLblsAndFields();
  }
  
  /**
   * Delete the world object that is selected in
   * the Object dropdown list, if any.
   * 
   * @returning  -1  if the active Scenario is null
   *              0  if the object was removed succesfully,
   *              1  if the object did not exist in the scenario,
   *              2  if the object was a Fixture that was removed
   *                 from the scenario and was referenced by at
   *                 least one Part in the scenario
   */
  public int deleteActiveWorldObject() {
    int ret = -1;
    
    if (activeScenario != null) {
      ret = activeScenario.removeWorldObject( getActiveWorldObject() );
    }
    
    return ret;
  }
  
  /**
   * Reinitialize any and all input fields
   */
  private void clearAllInputFields() {
    clearGroupInputFields(null);
    updateDimLblsAndFields();
  }
  
  /**
   * Reinitialize the input fields for any contents in the Create Object window
   */
  private void clearCreateInputFields() {
    clearGroupInputFields(createObjWindow);
    clearSharedInputFields();
    updateDimLblsAndFields();
  }
  
  /**
   * Reinitialize the input fields for any contents in the Edit Object window
   */
  private void clearEditInputFields() {
    clearGroupInputFields(editObjWindow);
    clearSharedInputFields();
    updateDimLblsAndFields();
  }
  
  /**
   * Reinitialize the input fields for any shared contents
   */
  private void clearSharedInputFields() {
    clearGroupInputFields(sharedElements);
    updateDimLblsAndFields();
  }
  
  /**
   * Reinitialize the input fields for any contents in the Scenario window
   */
  private void clearScenarioInputFields() {
    clearGroupInputFields(scenarioWindow);
    updateDimLblsAndFields();
  }
  
  /**
   * Reinitializes any controller interface in the given group that accepts user
   * input; currently only text fields and dropdown lists are updated.
   */
  private void clearGroupInputFields(Group g) {
    List<ControllerInterface<?>> contents = UIManager.getAll();
    
    for (ControllerInterface<?> controller : contents) {
      
      if (g == null || controller.getParent().equals(g)) {
        
        if (controller instanceof Textfield) {
          // Clear anything inputted into the text field
          controller = ((Textfield)controller).setValue("");
        } else if (controller instanceof MyDropdownList) {
          // Reset the caption label of the dropdown list and close the list
          ((MyDropdownList)controller).resetLabel();
          controller = ((DropdownList)controller).close();
        }
      }
    }
  }
  
  /**
   * Creates a new scenario with the name pulled from the scenario name text field.
   * If the name given is already given to another existing scenario, then no new
   * Scenario is created. Also, names can only consist of 16 letters or numbers.
   * 
   * @returning  A new Scenario object or null if the scenario name text field's
   *             value is invalid
   */
  public Scenario initializeScenario() {
    String activeButtonLabel = windowTabs.getActiveButtonName();
    
    if (activeButtonLabel != null && activeButtonLabel.equals("Scenario")) {
      String name = scenarioName.getText();
      
      if (name != null) {
        // Names only consist of letters and numbers
        if (Pattern.matches("[a-zA-Z0-9]+", name)) {
          
          for (Scenario s : SCENARIOS) {
            if (s.getName().equals(name)) {
              // Duplicate name
              println("Names must be unique!");
              return null;
            }
          }
          
          if (name.length() > 16) {
            // Names have a max length of 16 characters
            name = name.substring(0, 16);
          }
          
          return new Scenario(name);
        }
      }
    }
    
    // Invalid input or wrong window open 
    return null;
  }
  
  /**
   * Returns the scenario associated with the label that is active
   * for the scenario dropdown list.
   * 
   * @returning  The index value or null if no such index exists
   */
  public Scenario getActiveScenario() {
    String activeButtonLabel = windowTabs.getActiveButtonName();
    
    if (activeButtonLabel != null && activeButtonLabel.equals("Scenario")) {
      Object val = dropdownLists[6].getActiveLabelValue();
      
      if (val instanceof Scenario) {
        // Set the active scenario index
        return (Scenario)val;
      } else if (val != null) {
        // Invalid entry in the dropdown list
        System.out.printf("Invalid class type: %d!\n", val.getClass());
      }
    }
    
    return null;
  }
  
    /**
   * Returns the object that is currently being edited
   * in the world object editing menu.
   */
  protected WorldObject getActiveWorldObject() {
    Object wldObj = dropdownLists[4].getActiveLabelValue();
    
    if (editObjWindow.isVisible() && wldObj instanceof WorldObject) {
      return (WorldObject)wldObj;
    } else {
      return null;
    }
  }
  
  /**
   * Deterimes whether a single text field is active.
   */
  public boolean isATextFieldActive() {
    // Check EVERY text field
    if (objName.isFocus() || scenarioName.isFocus()) {
      return true;
    }
    
    for (Textfield tField : objOrientationFields) {
      if (tField.isFocus()) {
        return true;
      }
    }
    
    for (Textfield tField : shapeDefFields) {
      if (tField.isFocus()) {
        return true;
      }
    }
    
    return false;
  }
  
  /**
   * Determines whether the mouse is over a dropdown list.
   */
  public boolean isMouseOverADropdownList() {
    for (MyDropdownList dropdown : dropdownLists) {
      if (dropdown.isMouseOver()) {
        return true;
      }
    }
    
    return false;
  }
}


public class Triangle {
  // normal, vertex 1, vertex 2, vertex 3
  public PVector[] components = new PVector[4];
}

public class Model {
  public PShape mesh;
  public String name;
  public boolean[] rotations = new boolean[3]; // is rotating on this joint valid?
  // Joint ranges follow a clockwise format running from the PVector.x to PVector.y, where PVector.x and PVector.y range from [0, TWO_PI]
  public PVector[] jointRanges = new PVector[3];
  public float[] currentRotations = new float[3]; // current rotation value
  public float[] targetRotations = new float[3]; // we want to be rotated to this value
  public int[] rotationDirections = new int[3]; // use shortest direction rotation
  public float rotationSpeed;
  public float[] jointsMoving = new float[3]; // for live control using the joint buttons
  
  /**
   * Use default scaling
   */
  public Model(String filename, int col) {
    for(int n = 0; n < 3; n++) {
      rotations[n] = false;
      currentRotations[n] = 0;
      jointRanges[n] = null;
    }
    rotationSpeed = 0.01f;
    name = filename;
    loadSTLModel(filename, col, 1.0f);
  }
  
  /**
   * Define the scaling of the Model.
   */
  public Model(String filename, int col, float scaleVal) {
    for(int n = 0; n < 3; n++) {
      rotations[n] = false;
      currentRotations[n] = 0;
      jointRanges[n] = null;
    }
    rotationSpeed = 0.01f;
    name = filename;
    loadSTLModel(filename, col, scaleVal);
  }
  
  public void loadSTLModel(String filename, int col, float scaleVal) {
    ArrayList<Triangle> triangles = new ArrayList<Triangle>();
    byte[] data = loadBytes(filename);
    int n = 84; // skip header and number of triangles
    
    while(n < data.length) {
      Triangle t = new Triangle();
      for(int m = 0; m < 4; m++) {
        byte[] bytesX = new byte[4];
        bytesX[0] = data[n+3]; bytesX[1] = data[n+2];
        bytesX[2] = data[n+1]; bytesX[3] = data[n];
        n += 4;
        byte[] bytesY = new byte[4];
        bytesY[0] = data[n+3]; bytesY[1] = data[n+2];
        bytesY[2] = data[n+1]; bytesY[3] = data[n];
        n += 4;
        byte[] bytesZ = new byte[4];
        bytesZ[0] = data[n+3]; bytesZ[1] = data[n+2];
        bytesZ[2] = data[n+1]; bytesZ[3] = data[n];
        n += 4;
        t.components[m] = new PVector(
        ByteBuffer.wrap(bytesX).getFloat(),
        ByteBuffer.wrap(bytesY).getFloat(),
        ByteBuffer.wrap(bytesZ).getFloat()
        );
      }
      triangles.add(t);
      n += 2; // skip meaningless "attribute byte count"
    }
    mesh = createShape();
    mesh.beginShape(TRIANGLES);
    mesh.noStroke();
    mesh.scale(scaleVal);
    mesh.fill(col);
    for(Triangle t : triangles) {
      mesh.normal(t.components[0].x, t.components[0].y, t.components[0].z);
      mesh.vertex(t.components[1].x, t.components[1].y, t.components[1].z);
      mesh.vertex(t.components[2].x, t.components[2].y, t.components[2].z);
      mesh.vertex(t.components[3].x, t.components[3].y, t.components[3].z);
    }
    mesh.endShape();
  } // end loadSTLModel
  
  public boolean anglePermitted(int idx, float angle) {
    
    if(jointRanges[idx].x < jointRanges[idx].y) {
      // Joint range does not overlap TWO_PI
      return angle >= jointRanges[idx].x && angle < jointRanges[idx].y;
    } else {
      // Joint range overlaps TWO_PI
      return !(angle >= jointRanges[idx].y && angle < jointRanges[idx].x);
    }
  }
  
  public void draw() {
    shape(mesh);
  }
  
} // end Model class

public class ArmModel {
  
  public EEType activeEndEffector;
  public int endEffectorState;
  private final HashMap<EEType, Integer> EEToIORegMap;
  
  private Model eeMSuction, eeMClaw, eeMClawPincer, eeMPointer, eeMGlueGun, eeMWielder;
  
  public RobotMotion motionType;
  
  public ArrayList<Model> segments = new ArrayList<Model>();
  public int type;
  public float motorSpeed;
  // Indicates the direction of motion of the Robot when jogging
  public float[] jogLinear = new float[3];
  public float[] jogRot = new float[3];
  
  /* Bounding Boxes of the Robot Arm */
  public final BoundingBox[] armOBBs;
  /* Bounding Boxes unique to each End Effector */
  private final HashMap<EEType, ArrayList<BoundingBox>> eeOBBsMap;
  private final HashMap<EEType, ArrayList<BoundingBox>> eePickupOBBs;
  
  public Part held;
  /* Keep track of the Robot End Effector's orientation at the previous draw state */
  public float[][] oldEEOrientation;
  
  public PVector tgtPosition;
  public float[] tgtOrientation;
  
  public ArmModel() {
    activeEndEffector = EEType.NONE;
    endEffectorState = OFF;
    // Initialize the End Effector to IO Register mapping
    EEToIORegMap = new HashMap<EEType, Integer>();
    EEToIORegMap.put(EEType.SUCTION, 0);
    EEToIORegMap.put(EEType.CLAW, 1);
    EEToIORegMap.put(EEType.POINTER, 2);
    EEToIORegMap.put(EEType.GLUE_GUN, 3);
    EEToIORegMap.put(EEType.WIELDER, 4);
    
    motorSpeed = 1000.0f; // speed in mm/sec
    
    eeMSuction = new Model("SUCTION.stl", color(108, 206, 214));
    eeMClaw = new Model("GRIPPER.stl", color(108, 206, 214));
    eeMClawPincer = new Model("PINCER.stl", color(200, 200, 0));
    eeMPointer = new Model("POINTER.stl", color(108, 206, 214), 1f);
    eeMGlueGun = new Model("GLUE_GUN.stl", color(108, 206, 214));
    eeMWielder = new Model("WIELDER.stl", color(108, 206, 214));
    
    motionType = RobotMotion.HALTED;
    // Joint 1
    Model base = new Model("ROBOT_MODEL_1_BASE.STL", color(200, 200, 0));
    base.rotations[1] = true;
    base.jointRanges[1] = new PVector(0, TWO_PI);
    base.rotationSpeed = radians(150)/60.0f;
    // Joint 2
    Model axis1 = new Model("ROBOT_MODEL_1_AXIS1.STL", color(40, 40, 40));
    axis1.rotations[2] = true;
    axis1.jointRanges[2] = new PVector(4.34f, 2.01f);
    axis1.rotationSpeed = radians(150)/60.0f;
    // Joint 3
    Model axis2 = new Model("ROBOT_MODEL_1_AXIS2.STL", color(200, 200, 0));
    axis2.rotations[2] = true;
    axis2.jointRanges[2] = new PVector(5.027f, 4.363f);
    axis2.rotationSpeed = radians(200)/60.0f;
    // Joint 4
    Model axis3 = new Model("ROBOT_MODEL_1_AXIS3.STL", color(40, 40, 40));
    axis3.rotations[0] = true;
    axis3.jointRanges[0] = new PVector(0, TWO_PI);
    axis3.rotationSpeed = radians(250)/60.0f;
    // Joint 5
    Model axis4 = new Model("ROBOT_MODEL_1_AXIS4.STL", color(40, 40, 40));
    axis4.rotations[2] = true;
    axis4.jointRanges[2] = new PVector(59f * PI / 40f, 11f * PI / 20f);
    axis4.rotationSpeed = radians(250)/60.0f;
    // Joint 6
    Model axis5 = new Model("ROBOT_MODEL_1_AXIS5.STL", color(200, 200, 0));
    axis5.rotations[0] = true;
    axis5.jointRanges[0] = new PVector(0, TWO_PI);
    axis5.rotationSpeed = radians(420)/60.0f;
    Model axis6 = new Model("ROBOT_MODEL_1_AXIS6.STL", color(40, 40, 40));
    segments.add(base);
    segments.add(axis1);
    segments.add(axis2);
    segments.add(axis3);
    segments.add(axis4);
    segments.add(axis5);
    segments.add(axis6);
    
    for(int idx = 0; idx < jogLinear.length; ++idx) {
      jogLinear[idx] = 0;
    }
    
    for(int idx = 0; idx < jogRot.length; ++idx) {
      jogRot[idx] = 0;
    }
    
    /* Initialies dimensions of the Robot Arm's hit boxes */
    armOBBs = new BoundingBox[7];
    
    armOBBs[0] = new BoundingBox(420, 115, 420);
    armOBBs[1] = new BoundingBox(317, 85, 317);
    armOBBs[2] = new BoundingBox(130, 185, 170);
    armOBBs[3] = new BoundingBox(74, 610, 135);
    armOBBs[4] = new BoundingBox(165, 165, 165);
    armOBBs[5] = new BoundingBox(160, 160, 160);
    armOBBs[6] = new BoundingBox(128, 430, 128);
    
    eeOBBsMap = new HashMap<EEType, ArrayList<BoundingBox>>();
    eePickupOBBs = new HashMap<EEType, ArrayList<BoundingBox>>();
    // Faceplate
    ArrayList<BoundingBox> limbo = new ArrayList<BoundingBox>();
    limbo.add( new BoundingBox(102, 102, 36) );
    eeOBBsMap.put(EEType.NONE, limbo);
    // Cannot pickup
    limbo = new ArrayList<BoundingBox>();
    eePickupOBBs.put(EEType.NONE, limbo);
    
    // Claw Gripper
    limbo = new ArrayList<BoundingBox>();
    limbo.add( new BoundingBox(102, 102, 46) );
    limbo.add( new BoundingBox(89, 21, 31) );
    limbo.add( new BoundingBox(89, 21, 31) );
    eeOBBsMap.put(EEType.CLAW, limbo);
    // In between the grippers
    limbo = new ArrayList<BoundingBox>();
    limbo.add(new BoundingBox(55, 3, 15) );
    limbo.get(0).setColor(color(0, 0, 255));
    eePickupOBBs.put(EEType.CLAW, limbo);
    
    // Suction 
    limbo = new ArrayList<BoundingBox>();
    limbo.add( new BoundingBox(102, 102, 46) );
    limbo.add( new BoundingBox(37, 37, 82/*87*/) );
    limbo.add( new BoundingBox(37, 62/*67*/, 37) );
    eeOBBsMap.put(EEType.SUCTION, limbo);
    // One for each suction cup
    limbo = new ArrayList<BoundingBox>();
    limbo.add(new BoundingBox(25, 25, 3) );
    limbo.get(0).setColor(color(0, 0, 255));
    limbo.add(new BoundingBox(25, 3, 25) );
    limbo.get(1).setColor(color(0, 0, 255));
    eePickupOBBs.put(EEType.SUCTION, limbo);
    
    // Pointer
    limbo = new ArrayList<BoundingBox>();
    limbo.add( new BoundingBox(102, 102, 46) );
    limbo.add( new BoundingBox(24, 24, 32) );
    limbo.add( new BoundingBox(18, 18, 56) );
    limbo.add( new BoundingBox(9, 9, 37) );
    eeOBBsMap.put(EEType.POINTER, limbo);
    // Cannot pickup
    limbo = new ArrayList<BoundingBox>();
    eePickupOBBs.put(EEType.POINTER, limbo);
    
    // TODO Glue Gun
    limbo = new ArrayList<BoundingBox>();
    eeOBBsMap.put(EEType.GLUE_GUN, limbo);
    // Cannot pickup
    limbo = new ArrayList<BoundingBox>();
    eePickupOBBs.put(EEType.GLUE_GUN, limbo);
    
    // TODO Wielder
    limbo = new ArrayList<BoundingBox>();
    eeOBBsMap.put(EEType.WIELDER, limbo);
    // Cannot pickup
    limbo = new ArrayList<BoundingBox>();
    eePickupOBBs.put(EEType.WIELDER, limbo);
    
    held = null;
    // Initializes the old transformation matrix for the arm model
    pushMatrix();
    applyModelRotation(getJointAngles());
    oldEEOrientation = getTransformationMatrix();
    popMatrix();
  } // end ArmModel constructor
  
  /**
   * Update the Robot's position and orientation (as well as
   * those of its bounding boxes) based on the active
   * program or a move to command, or jogging.
   */
  public void updateRobot(Program active) {
    if (!robotFault) {
      // Execute arm movement
      if(programRunning) {
        // Run active program
        programRunning = !executeProgram(active, this, execSingleInst);
        
      } else if (motionType != RobotMotion.HALTED) {
        // Move the Robot progressively to a point
        boolean doneMoving = true;
        
        switch (armModel.motionType) {
          case MT_JOINT:
            doneMoving = interpolateRotation((liveSpeed / 100.0f));
            break;
          case MT_LINEAR:
            doneMoving = executeMotion(this, (liveSpeed / 100.0f));
            break;
          default:
        }
        
        if (doneMoving) {
          halt();
        }
        
      } else if (modelInMotion()) {
        // Jog the Robot
        intermediatePositions.clear();
        executeLiveMotion();
      }
    }
    
    updateCollisionOBBs();
  }
  
  public void draw() {
    noStroke();
    fill(200, 200, 0);
    
    pushMatrix();
    translate(ROBOT_POSITION.x, ROBOT_POSITION.y, ROBOT_POSITION.z);
    
    rotateZ(PI);
    rotateY(PI/2);
    segments.get(0).draw();
    rotateY(-PI/2);
    rotateZ(-PI);
    
    fill(50);
    
    translate(-50, -166, -358); // -115, -213, -413
    rotateZ(PI);
    translate(150, 0, 150);
    rotateX(PI);
    rotateY(segments.get(0).currentRotations[1]);
    rotateX(-PI);
    translate(-150, 0, -150);
    segments.get(1).draw();
    rotateZ(-PI);
    
    fill(200, 200, 0);
    
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    rotateX(segments.get(1).currentRotations[2]);
    translate(0, -62, -62);
    segments.get(2).draw();
    rotateY(-PI/2);
    rotateZ(-PI);
    
    fill(50);

    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    rotateZ(PI);
    rotateX(segments.get(2).currentRotations[2]);
    rotateZ(-PI);
    translate(0, -75, -75);
    segments.get(3).draw();
    rotateY(PI/2);
    rotateZ(-PI);
    
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    rotateY(segments.get(3).currentRotations[0]);
    translate(-70, 0, -70);
    segments.get(4).draw();
    rotateY(-PI/2);
    rotateZ(-PI/2);
    
    fill(200, 200, 0);
    
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    rotateX(segments.get(4).currentRotations[2]);
    translate(0, -50, -50);
    segments.get(5).draw();
    rotateY(PI/2);
    rotateZ(-PI);
    
    fill(50);
    
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    rotateZ(segments.get(5).currentRotations[0]);
    translate(-45, -45, 0);
    segments.get(6).draw();
    
    drawEndEffector(activeEndEffector, endEffectorState);
    
    popMatrix();
    
    if (COLLISION_DISPLAY) { drawBoxes(); }
  }//end draw arm model
  
  /**
   * Draw the End Effector model associated with the given
   * End Effector type in the current coordinate system.
   * 
   * @param ee       The End Effector to draw
   * @param eeState  The state of the End Effector to be drawn
   */
  private void drawEndEffector(EEType ee, int eeState) {
    pushMatrix();
    
    // Center the End Effector on the Robot's faceplate and draw it.
    if(ee == EEType.SUCTION) {
      rotateY(PI);
      translate(-88, -37, 0);
      eeMSuction.draw();
      
    } else if(ee == EEType.CLAW) {
      rotateY(PI);
      translate(-88, 0, 0);
      eeMClaw.draw();
      rotateZ(PI/2);
      
      if(eeState == OFF) {
        // Draw open grippers
        translate(10, -85, 30);
        eeMClawPincer.draw();
        translate(55, 0, 0);
        eeMClawPincer.draw();
        
      } else if(eeState == ON) {
        // Draw closed grippers
        translate(28, -85, 30);
        eeMClawPincer.draw();
        translate(20, 0, 0);
        eeMClawPincer.draw();
      }
    } else if (ee == EEType.POINTER) {
      rotateY(PI);
      rotateZ(PI);
      translate(45, -45, 10);
      eeMPointer.draw();
      
    } else if (ee == EEType.GLUE_GUN) {
      rotateZ(PI);
      translate(-48, -46, -12);
      eeMGlueGun.draw();
      
    } else if (ee == EEType.WIELDER) {
      rotateY(PI);
      rotateZ(PI);
      translate(46, -44, 10);
      eeMWielder.draw();
    }
    
    popMatrix();
  }
  
  /**
   * Updates the position and orientation of the hit
   * boxes related to the Robot Arm.
   */
  private void updateCollisionOBBs() { 
    noFill();
    stroke(0, 255, 0);
    
    pushMatrix();
    resetMatrix();
    
    translate(ROBOT_POSITION.x, ROBOT_POSITION.y, ROBOT_POSITION.z);
    
    rotateZ(PI);
    rotateY(PI/2);
    translate(200, 50, 200);
    // Segment 0
    armOBBs[0].setCoordinateSystem();
    
    translate(0, 100, 0);
    armOBBs[1].setCoordinateSystem();
    
    translate(-200, -150, -200);
    
    rotateY(-PI/2);
    rotateZ(-PI);
    
    translate(-50, -166, -358);
    rotateZ(PI);
    translate(150, 0, 150);
    rotateX(PI);
    rotateY(segments.get(0).currentRotations[1]);
    rotateX(-PI);
    translate(10, 95, 0);
    rotateZ(-0.1f * PI);
    // Segment 1
    armOBBs[2].setCoordinateSystem();
    
    rotateZ(0.1f * PI);
    translate(-160, -95, -150);
    rotateZ(-PI);
    
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    rotateX(segments.get(1).currentRotations[2]);
    translate(30, 240, 0);
    // Segment 2
    armOBBs[3].setCoordinateSystem();
    
    translate(-30, -302, -62);
    rotateY(-PI/2);
    rotateZ(-PI);
    
    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    rotateZ(PI);
    rotateX(segments.get(2).currentRotations[2]);
    rotateZ(-PI);
    translate(75, 0, 0);
    // Segment 3
    armOBBs[4].setCoordinateSystem();
    
    translate(-75, -75, -75);
    rotateY(PI/2);
    rotateZ(-PI);
    
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    rotateY(segments.get(3).currentRotations[0]);
    translate(5, 75, 5);
    // Segment 4
    armOBBs[5].setCoordinateSystem();
    
    translate(0, 295, 0);
    armOBBs[6].setCoordinateSystem();
    
    translate(-75, -370, -75);
    
    rotateY(-PI/2);
    rotateZ(-PI/2);
    
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    rotateX(segments.get(4).currentRotations[2]);
    translate(0, -50, -50);
    // Segment 5
    rotateY(PI/2);
    rotateZ(-PI);
    
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    rotateZ(segments.get(5).currentRotations[0]);
    translate(-45, -45, 0);
    popMatrix();
    
    // End Effector
    updateOBBBoxesForEE(activeEndEffector);
  }
  
  /**
   * Updates position and orientation of the hit boxes associated
   * with the given End Effector.
   */
  private void updateOBBBoxesForEE(EEType current) {
    ArrayList<BoundingBox> curEEOBBs = eeOBBsMap.get(current),
                           curPUEEOBBs = eePickupOBBs.get(current);
    
    pushMatrix();
    resetMatrix();
    applyModelRotation(getJointAngles());
    
    switch(current) {
      case NONE:
        // Face Plate EE
        translate(0, 0, 10);
        curEEOBBs.get(0).setCoordinateSystem();
        translate(0, 0, -10);
        break;
        
      case CLAW:
        // Claw Gripper EE
        curEEOBBs.get(0).setCoordinateSystem();
        
        translate(-2, 0, -54);
        curPUEEOBBs.get(0).setCoordinateSystem();
        
        if (endEffectorState == OFF) {
          // When claw is open
          translate(0, 27, 0);
          curEEOBBs.get(1).setCoordinateSystem();
          translate(0, -54, 0);
          curEEOBBs.get(2).setCoordinateSystem();
          translate(0, 27, 0);
          
        } else if (endEffectorState == ON) {
          // When claw is closed
          translate(0, 10, 0);
          curEEOBBs.get(1).setCoordinateSystem();
          translate(0, -20, 0);
          curEEOBBs.get(2).setCoordinateSystem();
          translate(0, 10, 0);
        }
        
        translate(2, 0, 54);
        break;
        
      case SUCTION:
        // Suction EE
        curEEOBBs.get(0).setCoordinateSystem();
        
        translate(-2, 0, -64);
        BoundingBox limbo = curEEOBBs.get(1);
        limbo.setCoordinateSystem();
        
        float dist = -43;
        translate(0, 0, dist);
        curPUEEOBBs.get(0).setCoordinateSystem();
        translate(0, -50, 19 - dist);
        limbo = curEEOBBs.get(2);
        limbo.setCoordinateSystem();
        
        dist = -33;
        translate(0, dist, 0);
        curPUEEOBBs.get(1).setCoordinateSystem();
        translate(2, 50 - dist, 45);
        break;
        
      case POINTER:
        // Pointer EE
        curEEOBBs.get(0).setCoordinateSystem();

        translate(0, 0, -30);
        curEEOBBs.get(1).setCoordinateSystem();
        translate(0, -18, -34);
        rotateX(-0.75f);
        curEEOBBs.get(2).setCoordinateSystem();
        rotateX(0.75f);
        translate(0, -21, -32);
        curEEOBBs.get(3).setCoordinateSystem();
        translate(0, 21, 32);
        translate(0, 18, 34);
        translate(0, 0, 30);
        break;
      
      case GLUE_GUN:
        // TODO
        break;
      
      case WIELDER:
        // TODO
        break;
        
      default:
    }
    
    popMatrix();
  }
  
  /**
   * Updates the reference to the Robot's previous
   * End Effector orientation, which is used to move
   * the object held by the Robot.
   */
  public void updatePreviousEEOrientation() {
    pushMatrix();
    resetMatrix();
    applyModelRotation(armModel.getJointAngles());
    // Keep track of the old coordinate frame of the armModel
    oldEEOrientation = getTransformationMatrix();
    popMatrix();
  }
  
  /* Changes all the Robot Arm's hit boxes to green */
  public void resetOBBColors() {
    for(BoundingBox b : armOBBs) {
      b.setColor(color(0, 255, 0));
    }
    
    ArrayList<BoundingBox> eeHB = eeOBBsMap.get(activeEndEffector);
    
    for(BoundingBox b : eeHB) {
      b.setColor(color(0, 255, 0));
    }
  }
  
  /* Determine if select pairs of hit boxes of the Robot Arm are colliding */
  public boolean checkSelfCollisions() {
    boolean collision = false;
    
    // Pairs of indices corresponding to two of the Arm body hit boxes, for which to check collisions
    int[] check_pairs = new int[] { 0, 3, 0, 4, 0, 5, 0, 6, 1, 5, 1, 6, 2, 5, 2, 6, 3, 5 };
    
    /* Check select collisions between the body segments of the Arm:
     * The base segment and the four upper arm segments
     * The base rotating segment and lower long arm segment as well as the upper long arm and
     *   upper rotating end segment
     * The second base rotating hit box and the upper long arm segment as well as the upper
     *   rotating end segment
     * The lower long arm segment and the upper rotating end segment
     */
    for(int idx = 0; idx < check_pairs.length - 1; idx += 2) {
      if( collision3D(armOBBs[ check_pairs[idx] ], armOBBs[ check_pairs[idx + 1] ]) ) {
        armOBBs[ check_pairs[idx] ].setColor(color(255, 0, 0));
        armOBBs[ check_pairs[idx + 1] ].setColor(color(255, 0, 0));
        collision = true;
      }
    }
    
    ArrayList<BoundingBox> eeHB = eeOBBsMap.get(activeEndEffector);
    
    // Check collisions between all EE hit boxes and base as well as the first long arm hit boxes
    for(BoundingBox hb : eeHB) {
      for(int idx = 0; idx < 4; ++idx) {
        if(collision3D(hb, armOBBs[idx]) ) {
          hb.setColor(color(255, 0, 0));
          armOBBs[idx].setColor(color(255, 0, 0));
          collision = true;
        }
      }
    }
    
    return collision;
  }
  
  /* Determine if the given ojbect is collding with any part of the Robot. */
  public boolean checkObjectCollision(Part obj) {
    boolean collision = false;
    
    for(BoundingBox b : armOBBs) {
      if( obj.collision(b) ) {
        b.setColor(color(255, 0, 0));
        collision = true;
      }
    }
    
    ArrayList<BoundingBox> eeHBs = eeOBBsMap.get(activeEndEffector);
    
    for(BoundingBox b : eeHBs) {
      if(obj.collision(b)) {
        b.setColor(color(255, 0, 0));
        collision = true;
      }
    }
    
    return collision;
  }
  
  /* Draws the Robot Arm's hit boxes in the world */
  public void drawBoxes() {
    // Draw hit boxes of the body poriotn of the Robot Arm
    for(BoundingBox b : armOBBs) {
      b.draw();
    }
        
    ArrayList<BoundingBox> curEEHitBoxes = eeOBBsMap.get(activeEndEffector);
    
    // Draw End Effector hit boxes
    for(BoundingBox b : curEEHitBoxes) {
      b.draw();
    }
    
    curEEHitBoxes = eePickupOBBs.get(activeEndEffector);
    // Draw Pickup hit boxes
    for (BoundingBox b : curEEHitBoxes) {
      b.draw();
    }
  }
  
  //returns the rotational values for each arm joint
  public float[] getJointAngles() {
    float[] rot = new float[6];
    for(int i = 0; i < segments.size(); i += 1) {
      for(int j = 0; j < 3; j += 1) {
        if(segments.get(i).rotations[j]) {
          rot[i] = segments.get(i).currentRotations[j];
          break;
        }
      }
    }
    return rot;
  }//end get joint rotations
  
  /**
   * Determines if the given angle is within the bounds of valid angles for
   * the Robot's joint corresponding to the given index value.
   * 
   * @param joint  An integer between 0 and 5 which corresponds to one of
   *               the Robot's joints J1 - J6
   * @param angle  The angle in question
   */
  public boolean anglePermitted(int joint, float angle) {
    joint = abs(joint) % 6;
    // Get the joint's range bounds
    PVector rangeBounds = getJointRange(joint);
    return angleWithinBounds(mod2PI(angle), rangeBounds.x, rangeBounds.y);
  }
  
  /**
   * Returns the start and endpoint of the range of angles, which
   8 are valid for the joint of the Robot, corresponding to the
   * given index. The range of valid angles spans from the x value
   * of the returned PVector ot its y value, moving clockwise around
   * the Unit Circle.
   * 
   * @param joint  An integer between 0 and 5 corresponding to the
   *               of the Robot's joints: J1 - J6.
   * @returning    A PVector, whose x and y values correspond to the
   *               start and endpoint of the range of angles valid
   *               for the joint corresponding to the given index.
   */
  public PVector getJointRange(int joint) {
    joint = abs(joint) % 6;
    Model seg = segments.get(joint);
    
    for (int axes = 0; axes < 3; ++axes) {
      if (seg.rotations[axes]) {
        return seg.jointRanges[axes];
      }
    }
    // Should not be reachable
    return new PVector(0f, 0f, 0f);
  }
  
  /* Calculate and returns a 3x3 matrix whose columns are the unit vectors of
   * the end effector's current x, y, z axes with respect to the current frame.
   */
  public float[][] getOrientationMatrix() {
    pushMatrix();
    resetMatrix();
    applyModelRotation(getJointAngles());
    float[][] matrix = getRotationMatrix();
    popMatrix();
    
    return matrix;
  }
  
  /* Calculate and returns a 3x3 matrix whose columns are the unit vectors of
   * the end effector's current x, y, z axes with respect to an arbitrary coordinate
   * system specified by the rotation matrix 'frame.'
   */
  public float[][] getOrientationMatrix(float[][] frame) {
    float[][] m = getOrientationMatrix();
    RealMatrix A = new Array2DRowRealMatrix(floatToDouble(m, 3, 3));
    RealMatrix B = new Array2DRowRealMatrix(floatToDouble(frame, 3, 3));
    RealMatrix AB = A.multiply(B.transpose());
    
    return doubleToFloat(AB.getData(), 3, 3);
  }
  
  //convenience method to set all joint rotation values of the robot arm
  public void setJointAngles(float[] rot) {
    for(int i = 0; i < segments.size(); i += 1) {
      for(int j = 0; j < 3; j += 1) {
        if(segments.get(i).rotations[j]) {
          segments.get(i).currentRotations[j] = rot[i];
          segments.get(i).currentRotations[j] %= TWO_PI;
          if(segments.get(i).currentRotations[j] < 0) {
            segments.get(i).currentRotations[j] += TWO_PI;
          }
        }
      }
    }
  }//end set joint rotations
  
  public boolean interpolateRotation(float speed) {
    boolean done = true;
    
    for(Model a : segments) {
      for(int r = 0; r < 3; r++) {
        if(a.rotations[r]) {
          float distToDest = abs(a.currentRotations[r] - a.targetRotations[r]);
          
          if (distToDest <= 0.0001f) {
            // Destination (basically) met
            continue;
            
          } else if (distToDest >= (a.rotationSpeed * speed)) {
            done = false;
            a.currentRotations[r] += a.rotationSpeed * a.rotationDirections[r] * speed;
            a.currentRotations[r] = mod2PI(a.currentRotations[r]);
            
          } else if (distToDest > 0.0001f) {
            // Destination too close to move at current speed
            a.currentRotations[r] = a.targetRotations[r];
            a.currentRotations[r] = mod2PI(a.currentRotations[r]);
          }
        }
      } // end loop through rotation axes
    } // end loop through arm segments
    return done;
  } // end interpolate rotation
  
  /**
   * Sets the Model's target joint angles to the given set of angles and updates the
   * rotation directions of each of the joint segments.
   */
  public void setupRotationInterpolation(float[] tgtAngles) {
    // Set the Robot's target angles
    for(int n = 0; n < tgtAngles.length; n++) {
      for(int r = 0; r < 3; r++) {
        if(armModel.segments.get(n).rotations[r])
        armModel.segments.get(n).targetRotations[r] = tgtAngles[n];
      }
    }
    
    // Calculate whether it's faster to turn CW or CCW
    for(int joint = 0; joint < 6; ++joint) {
      Model a = armModel.segments.get(joint);
      
      for(int r = 0; r < 3; r++) {
        if(a.rotations[r]) {
          // The minimum distance between the current and target joint angles
          float dist_t = minimumDistance(a.currentRotations[r], a.targetRotations[r]);
          
          // check joint movement range
          if(a.jointRanges[r].x == 0 && a.jointRanges[r].y == TWO_PI) {
            a.rotationDirections[r] = (dist_t < 0) ? -1 : 1;
          }
          else {  
            /* Determine if at least one bound lies within the range of the shortest angle
            * between the current joint angle and the target angle. If so, then take the
            * longer angle, otherwise choose the shortest angle path. */
            
            // The minimum distance from the current joint angle to the lower bound of the joint's range
            float dist_lb = minimumDistance(a.currentRotations[r], a.jointRanges[r].x);
            
            // The minimum distance from the current joint angle to the upper bound of the joint's range
            float dist_ub = minimumDistance(a.currentRotations[r], a.jointRanges[r].y);
            
            if(dist_t < 0) {
              if( (dist_lb < 0 && dist_lb > dist_t) || (dist_ub < 0 && dist_ub > dist_t) ) {
                // One or both bounds lie within the shortest path
                a.rotationDirections[r] = 1;
              } 
              else {
                a.rotationDirections[r] = -1;
              }
            } 
            else if(dist_t > 0) {
              if( (dist_lb > 0 && dist_lb < dist_t) || (dist_ub > 0 && dist_ub < dist_t) ) {  
                // One or both bounds lie within the shortest path
                a.rotationDirections[r] = -1;
              } 
              else {
                a.rotationDirections[r] = 1;
              }
            }
          }
        }
      }
    }
  }
  
  /**
   * Move the Robot, based on the current Coordinate Frame and the current values
   * of the each segments jointsMoving array or the values in the Robot's jogLinear
   * and jogRot arrays.
   */
  public void executeLiveMotion() {
    
    if (curCoordFrame == CoordFrame.JOINT) {
      // Jog in the Joint Frame
      for(int i = 0; i < segments.size(); i += 1) {
        Model model = segments.get(i);
        
        for(int n = 0; n < 3; n++) {
          if(model.rotations[n]) {
            float trialAngle = model.currentRotations[n] +
            model.rotationSpeed * model.jointsMoving[n] * liveSpeed / 100f;
            trialAngle = mod2PI(trialAngle);
            
            if(model.anglePermitted(n, trialAngle)) {
              
              float old_angle = model.currentRotations[n];
              model.currentRotations[n] = trialAngle;
              
              if(armModel.checkSelfCollisions()) {
                // End robot arm movement
                model.currentRotations[n] = old_angle;
                updateCollisionOBBs();
                model.jointsMoving[n] = 0;
                halt();
              }
            } 
            else {
              model.jointsMoving[n] = 0;
              halt();
            }
          }
        }
      }
      
    } else {
      // Jog in the World, Tool or User Frame
      Frame curFrame;
      
      if (curCoordFrame == CoordFrame.TOOL) {
        curFrame = getActiveFrame(CoordFrame.TOOL);
      } else if (curCoordFrame == CoordFrame.USER) {
        curFrame = getActiveFrame(CoordFrame.USER);
      } else {
        curFrame = null;
      }
      
      Point curPoint = nativeRobotEEPoint(getJointAngles());
      
      // Apply translational motion vector
      if (translationalMotion()) {
        // Respond to user defined movement
        float distance = motorSpeed / 6000f * liveSpeed;
        PVector translation = new PVector(jogLinear[0], jogLinear[1], jogLinear[2]);
        translation = rotateVector(translation.mult(distance), WORLD_AXES);
        
        if (curFrame != null) {
            // Convert the movement vector into the current reference frame
          translation = rotateVectorQuat(translation, curFrame.getOrientationNegation());
        }
        
        tgtPosition.add(translation);
      } else {
        // No translational motion
        tgtPosition = curPoint.position;
      }
      
      // Apply rotational motion vector
      if (rotationalMotion()) {
        // Respond to user defined movement
        float theta = DEG_TO_RAD * 0.025f * liveSpeed;
        PVector rotation = new PVector(jogRot[0], jogRot[1], jogRot[2]);
        rotation = convertWorldToNative(rotation);
        
        if (curFrame != null) {
          // Convert the movement vector into the current reference frame
          rotation = rotateVectorQuat(rotation, curFrame.getOrientationNegation());
        }
        rotation.normalize();
        
        tgtOrientation = rotateQuat(tgtOrientation, rotation, theta);
        
        if (quaternionDotProduct(tgtOrientation, curPoint.orientation) < 0f) {
          // Use -q instead of q
          tgtOrientation = vectorScalarMult(tgtOrientation, -1);
        }
      } else {
        // No rotational motion
        tgtOrientation = curPoint.orientation;
      }
      
      jumpTo(tgtPosition, tgtOrientation);
    }
  }
  
  /**
   * Attempts to move the Robot to the given position and orientation from its current
   * position using Inverse Kinematics.
   * 
   * @param destPosition     The desired position of the Robot End Effector in Native
   *                         Coordinates
   * @param destOrientation  The desired orientation of the Robot as a quaternion, in
   *                         Native Coordinates
   * @returning   EXEC_FAILURE if inverse kinematics fails or the joint angles returned
   *              are invalid and EXEC_SUCCESS if the Robot is successfully moved to the
   *              given position
   */
  public int jumpTo(PVector destPosition, float[] destOrientation) {
    boolean invalidAngle = false;
    float[] srcAngles = getJointAngles();
    // Calculate the joint angles for the desired position and orientation
    float[] destAngles = inverseKinematics(srcAngles, destPosition, destOrientation);
    
    // Check the destination joint angles with each joint's range of valid joint angles
    for(int joint = 0; !(destAngles == null) && joint < 6; joint += 1) {
      if (!anglePermitted(joint, destAngles[joint])) {
        invalidAngle = true;
        
        if (DISPLAY_TEST_OUTPUT) {
          PVector rangeBounds = getJointRange(joint);
          System.out.printf("Invalid angle: J[%d] = %4.3f : [%4.3f -> %4.3f]\n", joint,
                             destAngles[joint], rangeBounds.x, rangeBounds.y);
        } 
      }
    }
    
    // Did we successfully find the desired angles?
    if ((destAngles == null) || invalidAngle) {
      if (DISPLAY_TEST_OUTPUT) {
        Point RP = nativeRobotEEPoint(getJointAngles());
        System.out.printf("IK Failure ...\n%s -> %s\n%s -> %s\n\n", RP.position, destPosition,
                                arrayToString(RP.orientation), arrayToString(destOrientation));
      }
      
      triggerFault();
      return EXEC_FAILURE;
    }

    setJointAngles(destAngles);
    return EXEC_SUCCESS;
  }
  
  /**
   * TODO comment
   */
  public void moveTo(float[] jointAngles) {
    setupRotationInterpolation(jointAngles);
    motionType = RobotMotion.MT_JOINT;
  }
  
  /**
   * TODO comment
   */
  public void moveTo(PVector position, float[] orientation) {
    Point start = nativeRobotEEPoint(armModel.getJointAngles());
    Point end = new Point(position, orientation, start.angles);
    beginNewLinearMotion(start, end);
    motionType = RobotMotion.MT_LINEAR;
  }
  
  /**
   * Transitions from the current End Effector
   * to the next End Effector in a cyclic pattern:
   * 
   * NONE -> SUCTION -> CLAW -> POINTER -> GLUE_GUN -> WIELDER -> NONE
   */
  public void cycleEndEffector() {
    // Switch to the next End Effector in the cycle
    switch (activeEndEffector) {
      case NONE:
        activeEndEffector = EEType.SUCTION;
        break;
      
      case SUCTION:
        activeEndEffector = EEType.CLAW;
        break;
        
      case CLAW:
        activeEndEffector = EEType.POINTER;
        break;
      
      case POINTER:
        activeEndEffector = EEType.GLUE_GUN;
        break;
        
      case GLUE_GUN:
        activeEndEffector = EEType.WIELDER;
        break;
      
      case WIELDER:
      default:
        activeEndEffector = EEType.NONE;
        break;
    }
    
    IORegister associatedIO = getIORegisterFor(activeEndEffector);
    // Set end effector state
    if (associatedIO != null) {
      endEffectorState = associatedIO.state;
    } else {
      endEffectorState = OFF;
    }
    
    releaseHeldObject();
  }
  
  /**
   * Toggle the Robot's state between ON and OFF. Update the
   * Robot's currently held world object as well.
   */
  public void toggleEEState() {
    if (endEffectorState == ON) {
      endEffectorState = OFF;
    } else {
      endEffectorState = ON;
    }
    
    updateIORegister();
    checkPickupCollision(activeScenario);
  }
  
  /**
   * TODO comment this
   */
  public boolean canPickup(Part p) {
    ArrayList<BoundingBox> curEEOBBs = eeOBBsMap.get(activeEndEffector);
    
    for (BoundingBox b : curEEOBBs) {
      // Cannot be colliding with a normal bounding box
      if (p != null && p.collision(b)) {
        return false;
      }
    }
    
    curEEOBBs = eePickupOBBs.get(activeEndEffector);
    
    for (BoundingBox b : curEEOBBs) {
      // Must be colliding with a pickup bounding box
      if (p != null && p.collision(b)) {
        return true;
      }
    }
    
    return false;
  }
  
  /**
   * TODO comment
   */
  public int checkPickupCollision(Scenario active) {
    // End Effector must be on and no object is currently held to be able to pickup an object
    if (endEffectorState == ON && armModel.held == null) {
      ArrayList<BoundingBox> curPUEEOBBs = eePickupOBBs.get(activeEndEffector);
      
      // Can this End Effector pick up objects?
      if (active != null && curPUEEOBBs.size() > 0) {
        
        for (WorldObject wldObj : active) {
          // Only parts can be picked up
          if (wldObj instanceof Part && canPickup( (Part)wldObj )) {
              // Pickup the object
              held = (Part)wldObj;
              return 0;
          }
        }
      }
      
    } else if (endEffectorState == OFF && armModel.held != null) {
      // Release the object
      armModel.releaseHeldObject();
      return 1;
    }
    
    return 2;
  }
  
  /**
   * If an object is currently being held by the Robot arm, then release it.
   * Then, update the Robot's End Effector status and IO Registers.
   */
  public void releaseHeldObject() {
    if (held != null) {
      endEffectorState = OFF;
      updateIORegister();
      armModel.held = null;
    }
  }
  
  /**
   * Update the I/O register associated with the Robot's current End Effector
   * (if any) to the Robot's current End Effector state.
   */
  public void updateIORegister() {
    // Get the I/O register associated with the current End Effector
    IORegister associatedIO = getIORegisterFor(activeEndEffector);
    
    if (associatedIO != null) {
      associatedIO.state = endEffectorState;
    }
  }
  
  /**
   * Returns the I/O register associated with the given End Effector
   * type, or null if noy such I/O register exists.
   */
  public IORegister getIORegisterFor(EEType ee) {
    Integer regIdx = EEToIORegMap.get(ee);
    
    if (regIdx != null && regIdx >= 0 && regIdx < IO_REG.length) {
      return IO_REG[regIdx];
    }
    
    return null;
  }
  
  /**
   * Returns true if at least one joint of the Robot is in motion.
   */
  public boolean jointMotion() {
    for(Model m : segments) {
      // Check each segments active joint
      for(int idx = 0; idx < m.jointsMoving.length; ++idx) {
        if(m.jointsMoving[idx] != 0) {
          return true;
        }
      }
    }
    
    return false;
  }
  
  /**
   * Returns true if the Robot is jogging translationally.
   */
  public boolean translationalMotion() {
    return jogLinear[0] != 0 || jogLinear[1] != 0 || jogLinear[2] != 0;
  }
  
  /**
   * Returns true if the Robot is jogging rotationally.
   */
  public boolean rotationalMotion() {
    return jogRot[0] != 0 || jogRot[1] != 0 || jogRot[2] != 0;
  }
  
  /**
   * Indicates that the Robot Arm is in motion.
   */
  public boolean modelInMotion() {
    return programRunning || motionType != RobotMotion.HALTED ||
           jointMotion() || translationalMotion() || rotationalMotion();
  }
  
  /**
   * Stops all robot movement
   */
  public void halt() {
    for(Model model : segments) {
      model.jointsMoving[0] = 0;
      model.jointsMoving[1] = 0;
      model.jointsMoving[2] = 0;
    }
    
    for(int idx = 0; idx < jogLinear.length; ++idx) {
      jogLinear[idx] = 0;
    }
    
    for(int idx = 0; idx < jogRot.length; ++idx) {
      jogRot[idx] = 0;
    }
    
    // Reset button highlighting
    resetButtonColors();
    motionType = RobotMotion.HALTED;
    programRunning = false;
  }
} // end ArmModel class
private final int MTYPE_JOINT = 0, MTYPE_LINEAR = 1, MTYPE_CIRCULAR = 2;
private final int FTYPE_TOOL = 0, FTYPE_USER = 1;
//stack containing the previously running program state when a new program is called
private Stack<int[]> call_stack = new Stack<int[]>();
// Indicates whether a program is currently running
private boolean programRunning = false;

public class Point  {
  // X, Y, Z
  public PVector position;
  // Q1 - Q4
  public float[] orientation;
  // J1 - J6
  public float[] angles;

  public Point() {
    angles = new float[] { 0f, 0f, 0f, 0f, 0f, 0f };
    position = new PVector(0f, 0f, 0f);
    orientation = new float[] { 1f, 0f, 0f, 0f };
  }
  
  public Point(PVector pos, float[] orient) {
    angles = new float[] { 0f, 0f, 0f, 0f, 0f, 0f };
    position = pos.copy();
    orientation = Arrays.copyOfRange(orient, 0, 4);
  }
  
  public Point(float x, float y, float z, float r, float i, float j, float k,
  float j1, float j2, float j3, float j4, float j5, float j6) {
    orientation = new float[4];
    angles = new float[6];
    position = new PVector(x,y,z);
    orientation[0] = r;
    orientation[1] = i;
    orientation[2] = j;
    orientation[3] = k;
    angles[0] = j1;
    angles[1] = j2;
    angles[2] = j3;
    angles[3] = j4;
    angles[4] = j5;
    angles[5] = j6;
  }
  
  public Point(PVector pos, float[] orient, float[] jointAngles) {
    position = pos.copy();
    orientation = Arrays.copyOfRange(orient, 0, 4);
    angles = Arrays.copyOfRange(jointAngles, 0, 6);
  }

  public Point clone() { return new Point(position, orientation, angles); }
  
  public Float getValue(int idx) {
    switch(idx) {
      // Joint angles
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:   return angles[idx];
      // Position
      case 6:   return position.x;
      case 7:   return position.y;
      case 8:   return position.z;
      // Orientation
      case 9:   
      case 10:  
      case 11:  
      case 12:  return orientation[idx - 9];
      default:
    }
    
    return null;
  }
  
  public void setValue(int idx, float value) {
    switch(idx) {
      // Joint angles
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:   angles[idx] = value;
      // Position
      case 6:   position.x = value;
      case 7:   position.y = value;
      case 8:   position.z = value;
      // Orientation
      case 9:   
      case 10:  
      case 11:  
      case 12:  orientation[idx - 9] = value;
      default:
    }
  }
  
  /**
   * Computes and returns the result of the addition of this point with
   * another point, 'p.' Does not alter the original values of this point.
   */
  public Point add(Point p) {
    Point p3 = new Point();
    
    PVector p3Pos = PVector.add(position, p.position);
    float[] p3Orient = quaternionMult(orientation, p.orientation);
    float[] p3Joints = new float[6];
    
    for(int i = 0; i < 6; i += 1) {
      p3Joints[i] = angles[i] + p.angles[i];
    }
    
    p3.position = p3Pos;
    p3.orientation = p3Orient;
    p3.angles = p3Joints;
    
    return p3;
  }
  
  /**
   * Negates the current values of the point.
   */
  public Point negate() {
    position = position.mult(-1);
    orientation = vectorScalarMult(orientation, -1);
    angles = vectorScalarMult(angles, -1);
    return this;
  }
    
  /**
   * Converts the original toStringArray into a 2x1 String array, where the origin
   * values are in the first element and the W, P, R values are in the second
   * element (or in the case of a joint angles, J1-J3 on the first and J4-J6 on
   * the second), where each element has space buffers.
   * 
   * @param displayCartesian  whether to display the joint angles or the cartesian
   *                          values associated with the point
   * @returning               A 2-element String array
   */
  public String[] toLineStringArray(boolean displayCartesian) {
    String[][] entries;
    
    if (displayCartesian) {
      entries = toCartesianStringArray();
    } else {
      entries = toJointStringArray();
    }
    
    
    String[] line = new String[2];
    // X, Y, Z with space buffers
    line[0] = String.format("%-12s %-12s %s", entries[0][0].concat(entries[0][1]),
            entries[1][0].concat(entries[1][1]), entries[2][0].concat(entries[2][1]));
    // W, P, R with space buffers
    line[1] = String.format("%-12s %-12s %s", entries[3][0].concat(entries[3][1]),
            entries[4][0].concat(entries[4][1]), entries[5][0].concat(entries[5][1]));
    
    return line;
  }

  /**
   * Returns a String array, whose entries are the joint values of the
   * Point with their respective labels (J1-J6).
   * 
   * @return  A 6x2-element String array
   */
  public String[][] toJointStringArray() {
    String[][] entries = new String[6][2];
    
    for(int idx = 0; idx < angles.length; ++idx) {
      entries[idx][0] = String.format("J%d: ", (idx + 1));
      
      if (angles == null) {
        entries[idx][1] = Float.toString(Float.NaN);
      } else {
        entries[idx][1] = String.format("%4.3f", angles[idx] * RAD_TO_DEG);
      }
    }
    
    return entries;
  }

  /**
   * Returns a string array, where each entry is one of the values of the Cartiesian
   * represent of the Point: (X, Y, Z, W, P, and R) and their respective labels.
   * 
   * @return  A 6x2-element String array
   */
  public String[][] toCartesianStringArray() {
    String[][] entries = new String[6][2];
    
    PVector pos;
    if (position == null) {
      // Uninitialized
      pos = new PVector(Float.NaN, Float.NaN, Float.NaN);
    } else {
      // Display in terms of the World Frame
      pos = convertNativeToWorld(position);
    }
    
    // Convert Quaternion to Euler Angles
    PVector angles;
    if (orientation == null) {
      // Uninitialized
      angles = new PVector(Float.NaN, Float.NaN, Float.NaN);
    } else {
       // Display in terms of the World Frame
      angles = convertNativeToWorld( quatToEuler(orientation) ).mult(RAD_TO_DEG);
    }
    
    entries[0][0] = "X: ";
    entries[0][1] = String.format("%4.3f", pos.x);
    entries[1][0] = "Y: ";
    entries[1][1] = String.format("%4.3f", pos.y);
    entries[2][0] = "Z: ";
    entries[2][1] = String.format("%4.3f", pos.z);
    entries[3][0] = "W: ";
    entries[3][1] = String.format("%4.3f", angles.x);
    entries[4][0] = "P: ";
    entries[4][1] = String.format("%4.3f", angles.y);
    entries[5][0] = "R: ";
    entries[5][1] = String.format("%4.3f", angles.z );
    
    return entries;
  }
} // end Point class

public class Program {
  private String name;
  private int nextPosition;
  /**
   * The positions associated with this program, which are
   * stored in reference to the current User frame
   */
  private Point[] LPosReg = new Point[1000];
  private ArrayList<Instruction> instructions;

  public Program(String s) {
    name = s;
    nextPosition = 0;
    for(int n = 0; n < LPosReg.length; n++) LPosReg[n] = new Point();
    instructions = new ArrayList<Instruction>();
  }

  public ArrayList<Instruction> getInstructions() {
    return instructions;
  }
  
  public void setName(String n) { name = n; }

  public String getName() {
    return name;
  }
  
  public int size() {
    return instructions.size();
  }

  public int getRegistersLength() {
    return LPosReg.length;
  }

  public Instruction getInstruction(int i){
    return instructions.get(i);
  }

  public void addInstruction(Instruction i) {
    //i.setProg(this);
    instructions.add(i);
    
    if(i instanceof MotionInstruction ) {
      MotionInstruction castIns = (MotionInstruction)i;
      if(!castIns.usesGPosReg() && castIns.getPosition() >= nextPosition) {
        nextPosition = castIns.getPosition()+1;
        if(nextPosition >= LPosReg.length) nextPosition = LPosReg.length-1;
      }
    }
  }

  public void overwriteInstruction(int idx, Instruction i) {
    instructions.set(idx, i);
    if(i instanceof MotionInstruction ) { 
      MotionInstruction castIns = (MotionInstruction)i;
      if(!castIns.usesGPosReg() && castIns.getPosition() >= nextPosition) {
        nextPosition = castIns.getPosition()+1;
        if(nextPosition >= LPosReg.length) nextPosition = LPosReg.length-1;
      }
    }
  }

  public void addPosition(Point in, int idx) {
    if(idx >= 0 && idx < LPosReg.length) LPosReg[idx] = in;
  }
  
  public int getNextPosition() { return nextPosition; }
  public void setNextPosition(int next) { nextPosition = next; }

  public Point getPosition(int idx) {
    if(idx >= 0 && idx < LPosReg.length) return LPosReg[idx];
    else return null;
  }
  
  public void setPosition(int idx, Point pt){
    LPosReg[idx] = pt;
  }
  
  public void clearPositions(){
    LPosReg = new Point[1000];
  }
  
  public LabelInstruction getLabel(int n){    
    for(Instruction i: instructions){
      if(i instanceof LabelInstruction){
        if(((LabelInstruction)i).labelNum == n){
          return (LabelInstruction)i;
        }
      }
    }
    
    return null;
  }
  
  /**
   * Determines if a label with the given number exists in the program and returns its
   * instruction index if it does.
   * 
   * @param lblNum  The target label index
   * @returning     The instruction index of the target label, or -1 if it exists
   */
  public int findLabelIdx(int lblNum) {
    
    for (int idx = 0; idx < instructions.size(); ++idx) {
      Instruction inst = instructions.get(idx);
      // Check the current instruction
      if (inst instanceof LabelInstruction && ((LabelInstruction)inst).labelNum == lblNum) {
        // Return the label's instruction index
        return idx;
      }
    }
    // A label with the given number does not exist
    return -1;
  }
  
  /**
   * Return an independent replica of this program object.
   */
  public Program clone() {
    Program copy = new Program(name);
    // Copy instructions
    for (Instruction inst : instructions) {
      copy.addInstruction(inst.clone());
    }
    // Copy positions
    for (int idx = 0; idx < LPosReg.length; ++idx) {
      copy.addPosition(LPosReg[idx].clone(), idx);
    }
    // Copy next register
    copy.setNextPosition(nextPosition);
    
    return copy;
  }
} // end Program class


public int addProgram(Program p) {
  if(p == null) {
    return -1;
  } 
  else {
    int idx = 0;
    
    if(programs.size() < 1) {
      programs.add(p);
    } 
    else {
      while(idx < programs.size() && programs.get(idx).name.compareTo(p.name) < 0) { ++idx; }
      programs.add(idx, p);
    }
    
    return idx;
  }
}

/**
 * Returns the currently active program or null if no program is active
 */
public Program activeProgram() {
  if (active_prog < 0 || active_prog >= programs.size()) {
    //System.out.printf("Not a valid program index: %d!\n", active_prog);
    return null;
  }
  
  return programs.get(active_prog);
}

/**
 * Returns the instruction that is currently active in the currently active program.
 * 
 * @returning  The active instruction of the active program or null if no instruction
 *             is active
 */
public Instruction activeInstruction() {
  Program activeProg = activeProgram();
  
  if (activeProg == null || active_instr < 0 || active_instr >= activeProg.getInstructions().size()) {
    //System.out.printf("Not a valid instruction index: %d!\n", active_instr);
    return null;
  }
  
  return activeProg.getInstruction(active_instr);
}

/**
 * Returns the active instructiob of the active program, if
 * that instruction is a motion instruction.
 */
public MotionInstruction activeMotionInst() {
  Instruction inst = activeInstruction();
  
  if(inst instanceof MotionInstruction) {
    return (MotionInstruction)inst;
  }
  
  return null;
}

public class Instruction {
  protected boolean com = false;
  
  public boolean isCommented(){ return com; }
  public void setIsCommented(boolean comFlag) { com = comFlag; }
  public void toggleCommented() { com = !com; }
    
  public int execute() { return 0; }
    
  public String toString() {
    String[] fields = toStringArray();
    String str = new String();
    
    /* Return a stirng which is the concatenation of all the elements in
     * this instruction's toStringArray() method, separated by spaces */
    for (int fdx = 0; fdx < fields.length; ++fdx) {
      str += fields[fdx];
      
      if (fdx < (fields.length - 1)) {
        str += " ";
      }
    }
    
    return str;
  }
  
  public String[] toStringArray() {
    return new String[] {"..."};
  }
  
  /**
   * Create an independent replica of this instruction.
   */
  public Instruction clone() {
    Instruction copy = new Instruction();
    copy.setIsCommented( isCommented() );
    
    return copy;
  }
}

public final class MotionInstruction extends Instruction  {
  private int motionType;
  private int positionNum;
  private int offsetRegNum;
  private boolean offsetActive;
  private boolean isGPosReg;
  private float speed;
  private int termination;
  private int userFrame, toolFrame;
  private MotionInstruction circSubInstr;

  public MotionInstruction(int m, int p, boolean g, 
                           float s, int t, int uf, int tf) {
    motionType = m;
    positionNum = p;
    offsetRegNum = -1;
    offsetActive = false;
    isGPosReg = g;
    speed = s;
    termination = t;
    userFrame = uf;
    toolFrame = tf;
    if(motionType != -1) {
      circSubInstr = new MotionInstruction(-1, -1, false, 100, 0, uf, tf);
    } else {
      circSubInstr = null;
    }
  }

  public MotionInstruction(int m, int p, boolean g, float s, int t) {
    motionType = m;
    positionNum = p;
    offsetRegNum = -1;
    offsetActive = false;
    isGPosReg = g;
    speed = s;
    termination = t;
    userFrame = -1;
    toolFrame = -1;
    if(motionType != -1) {
      circSubInstr = new MotionInstruction(-1, -1, false, 100, 0);
    } else {
      circSubInstr = null;
    }
  }

  public int getMotionType() { return motionType; }
  public void setMotionType(int in) { motionType = in; }
  public int getPosition() { return positionNum; }
  public void setPosition(int in) { positionNum = in; }
  public int getOffset() { return offsetRegNum; }
  public void setOffset(int in) { offsetRegNum = in; }
  public boolean toggleOffsetActive() { return (offsetActive = !offsetActive); }
  public boolean usesGPosReg() { return isGPosReg; }
  public void setGlobalPosRegUse(boolean in) { isGPosReg = in; }
  public float getSpeed() { return speed; }
  public void setSpeed(float in) { speed = in; }
  public int getTermination() { return termination; }
  public void setTermination(int in) { termination = in; }
  public int getUserFrame() { return userFrame; }
  public void setUserFrame(int in) { userFrame = in; }
  public int getToolFrame() { return toolFrame; }
  public void setToolFrame(int in) { toolFrame = in; }
  public MotionInstruction getSecondaryPoint() { return circSubInstr; }
  public void setSecondaryPoint(MotionInstruction p) { circSubInstr = p; }

  public float getSpeedForExec(ArmModel model) {
    if(motionType == MTYPE_JOINT) return speed;
    else return (speed / model.motorSpeed);
  }
  
  /**
   * Verify that the given frame indices match those of the
   * instructions frame indices.
   */
  public boolean checkFrames(int activeToolIdx, int activeFrameIdx) {
    return (toolFrame == activeToolIdx) && (userFrame == activeFrameIdx);
  }
  
  /**
   * Returns the point associated with this motion instruction
   * (can be either a position in the program or a global position
   * register value) in Native Coordinates.
   * 
   * @param parent  The program, to which this instruction belongs
   * @returning     The point associated with this instruction
   */
  public Point getVector(Program parent) {
    Point pt;
    Point offset;
    
    if(isGPosReg) {
      pt = GPOS_REG[positionNum].point.clone();    
    } else {
      pt = parent.LPosReg[positionNum].clone();
    }
    
    if(offsetRegNum != -1) {
      offset = GPOS_REG[offsetRegNum].point;
    } else {
      offset = new Point();
    }
    
    if (userFrame != -1 && motionType != MTYPE_JOINT) {
      // Convert point into the Native Coordinate System
      Frame active = userFrames[userFrame];
      pt = removeFrame(pt, active.getOrigin(), active.getOrientation());
    }
      
    return pt.add(offset);
  } // end getVector()
  
  public Instruction clone() {
    Instruction copy = new MotionInstruction(motionType, positionNum, isGPosReg, speed, termination, userFrame, toolFrame);
    copy.setIsCommented( isCommented() );
    
    return copy;
  }
  
  public String[] toStringArray() {
    String[] fields;
    int instrLen, subInstrLen;
    
    if(motionType == MTYPE_CIRCULAR) {
      instrLen = offsetActive ? 7 : 6;
      subInstrLen = circSubInstr.offsetActive ? 5 : 4;      
      fields = new String[instrLen + subInstrLen];
    } else {
      instrLen = offsetActive ? 6 : 5;
      subInstrLen = 0;
      fields = new String[instrLen];
    }
    
    // Motion type
    switch(motionType) {
      case MTYPE_JOINT:
        fields[0] = "J";
        break;
      case MTYPE_LINEAR:
        fields[0] = "L";
        break;
      case MTYPE_CIRCULAR:
        fields[0] = "C";
        break;
      default:
        fields[0] = "\0";
    }
    
    // Regster type
    if (isGPosReg) {
      fields[1] = "PR[";
    } else {
      fields[1] = "P[";
    }
    
    // Register index
    if(positionNum == -1) {
      fields[2] = "...]";
    } else {
      fields[2] = String.format("%d]", positionNum + 1);
    }
    
    // Speed
    if (motionType == MTYPE_JOINT) {
      fields[3] = String.format("%d%%", Math.round(speed * 100));
    } else {
      fields[3] = String.format("%dmm/s", (int)(speed));
    }
    
    // Termination percent
    if (termination == 0) {
      fields[4] = "FINE";
    } else {
      fields[4] = String.format("CONT%d", termination);
    }
    
    if(offsetActive) {
      if(offsetRegNum == -1) {
        fields[5] = "OFST PR[...]";
      } else {
        fields[5] = String.format("OFST PR[%d]", offsetRegNum + 1);
      }
    }
    
    if(motionType == MTYPE_CIRCULAR) {
      String[] secondary = circSubInstr.toStringArray();
      fields[instrLen - 1] = "\n";
      fields[instrLen] = ":" + secondary[1];
      fields[instrLen + 1] = secondary[2];
      fields[instrLen + 2] = secondary[3];
      fields[instrLen + 3] = secondary[4];
      if(subInstrLen > 4) {
        fields[instrLen + 4] = secondary[5];
      }
    }
        
    return fields;
  }
} // end MotionInstruction class

public class FrameInstruction extends Instruction {
  private int frameType;
  private int frameIdx;
  
  public FrameInstruction(int f) {
    super();
    frameType = f;
    frameIdx = -1;
  }
  
  public FrameInstruction(int f, int r) {
    super();
    frameType = f;
    frameIdx = r;
  }
  
  public int getFrameType(){ return frameType; }
  public void setFrameType(int t){ frameType = t; }
  public int getReg(){ return frameIdx; }
  public void setReg(int r){ frameIdx = r; }
  
  public int execute() {    
    if (frameType == FTYPE_TOOL) {
      activeToolFrame = frameIdx;
    } else if (frameType == FTYPE_USER) {
      activeUserFrame = frameIdx;
    }
    // Update the current active frames
    updateCoordFrame();
    
    return 0;
  }
  
  public Instruction clone() {
    Instruction copy = new FrameInstruction(frameType, frameIdx);
    copy.setIsCommented( isCommented() );
    
    return copy;
  }
  
  public String[] toStringArray() {
    String[] fields = new String[2];
    // Frame type
    if (frameType == FTYPE_TOOL) {
      fields[0] = "TFRAME_NUM =";
    } else if (frameType == FTYPE_USER) {
      fields[0] = "UFRAME_NUM =";
    } else {
      fields[0] = "?FRAME_NUM =";
    }
    // Frame index
    fields[1] = Integer.toString(frameIdx + 1);
    
    return fields;
  }
  
} // end FrameInstruction class

public class IOInstruction extends Instruction {
  private int state;
  private int reg;
  
  public IOInstruction(){
    super();
    state = OFF;
    reg = -1;
  }
  
  public IOInstruction(int r, int t) {
    super();
    state = t;
    reg = r;
  }

  public int getState(){ return state; }
  public void setState(int s){ state = s; }
  public int getReg(){ return reg; }
  public void setReg(int r){ reg = r; }
  
  public int execute() {
    armModel.endEffectorState = state;
    armModel.checkPickupCollision(activeScenario);
    return 0;
  }
  
  public Instruction clone() {
    Instruction copy = new IOInstruction(state, reg);
    copy.setIsCommented( isCommented() );
    
    return copy;
  }
  
  public String[] toStringArray() {
    String[] fields = new String[2];
    // Register index
    if (reg == -1) {
      fields[0] = "IO[...] =";
    } else {
      fields[0] = String.format("IO[%d] =", reg + 1);
    }
    // Register value
    if (state == ON) {
      fields[1] = "ON";
    } else {
      fields[1] = "OFF";
    }
    
    return fields;
  }
} // end ToolInstruction class

public class LabelInstruction extends Instruction {
  int labelNum;
  
  public LabelInstruction(int num) {
    labelNum = num;
  }
  
  public String[] toStringArray() {
    String[] fields = new String[1];
    // Label number
    if (labelNum == -1) {
      fields[0] = "LBL[...]";
    } else {
      fields[0] = String.format("LBL[%d]", labelNum);
    }
    
    return fields;
  }
  
  public Instruction clone() {
    Instruction copy = new LabelInstruction(labelNum);
    copy.setIsCommented( isCommented() );
    
    return copy;
  }
}

public class JumpInstruction extends Instruction {
  public int tgtLblNum;
  
  public JumpInstruction() {
    tgtLblNum = -1;
  }
  
  public JumpInstruction(int l) {
    tgtLblNum = l;
  }
  
  /**
   * Returns the index of the instruction to which to jump.
   */
  public int execute() {
    Program p = activeProgram();
    
    if (p != null) {
      int lblIdx = p.findLabelIdx(tgtLblNum);
      
      if (lblIdx != -1) {
        // Return destination instrution index
        return lblIdx;
      } else {
        println("Invalid jump instruction!");
        return 1;
      }
    } else {
      println("No active program!");
      return 2;
    }
  }
  
  public Instruction clone() {
    Instruction copy = new JumpInstruction(tgtLblNum);
    copy.setIsCommented( isCommented() );
    
    return copy;
  }
  
  public String[] toStringArray() {
    String[] ret;
    // Target label number
    if (tgtLblNum == -1) {
      ret = new String[] {"JMP", "LBL[...]"};
    } else {
      ret = new String[] {"JMP", "LBL[" + tgtLblNum + "]"};
    }
    
    return ret;
  }
}

public class CallInstruction extends Instruction {
  Program callProg;
  int progIdx;
  
  public CallInstruction() {
    callProg = null;
    progIdx = -1;
  }
  
  public CallInstruction(Program p, int i) {
    callProg = p;
    progIdx = i;
  }
  
  public int execute() {
    int[] p = new int[2];
    p[0] = active_prog;
    p[1] = active_instr + 1;
    call_stack.push(p);
    
    active_prog = progIdx;
    active_instr = 0;
    row_select = 0;
    col_select = 0;
    start_render = 0;
    updateScreen();
    
    programRunning = !executeProgram(callProg, armModel, false);
    
    return 0;
  }
  
  public String toString() {
    String progName = (callProg == null) ? "..." : callProg.name;
    return "Call " + progName;
  }
  
  public String[] toStringArray() {
    String[] ret = new String[2];
    ret[0] = "Call";
    ret[1] = (callProg == null) ? "..." : callProg.name;
    return ret;
  }
}

/**
 * An if statement consists of an expression and an instruction. If the expression evaluates
 * to true, the execution of this if statement will result in the execution of the associated
 * instruction.
 *
 * Legal operators for the if statement expression are "=, <>, >, <, >=, and <=," which 
 * correspond to the equal, not equal, greater-than, less-than, greater-than or equal to,
 * and less-than or equal to operations, respectively.
 *
 * @param o - the operator to use for this if statement's expression.
 * @param i - the instruction to be executed if the statement expression evaluates to true.
 */
public class IfStatement extends Instruction {
  AtomicExpression expr;
  Instruction instr;
  
  public IfStatement() {
    expr = new Expression();
    instr = null;
  }
  
  public IfStatement(Operator o, Instruction i){
    expr = new BooleanExpression(o);
    instr = i;
  }
  
  public int execute() {
    ExprOperand result = expr.evaluate();
    
    if(result == null || result.boolVal == null) {
      return 1;
    } else if(expr.evaluate().getBoolVal()){
      instr.execute();
    }
    
    return 0;
  }
  
  public String toString() {
    return "IF " + expr.toString() + " : " + instr.toString();
  }
  
  public String[] toStringArray() {
    String[] exprArray = expr.toStringArray();
    String[] instArray, ret;
    if(instr == null) {
      ret = new String[exprArray.length + 2];
      ret[ret.length - 1] = "...";
    } else {
      ret = new String[exprArray.length + 3];
      instArray = instr.toStringArray();
      ret[ret.length - 2] = instArray[0];
      ret[ret.length - 1] = instArray[1];
    }
        
    ret[0] = "IF";
    for(int i = 1; i < exprArray.length + 1; i += 1) {
      ret[i] = exprArray[i - 1];
    }
    ret[exprArray.length] += " :";

    return ret;
  }
  
  public Instruction clone() {
    if (instr == this) {
      // Cannot copy!
      return null;
    }
    
    Instruction copy = new IfStatement(null, instr.clone());
    copy.setIsCommented( isCommented() );
    // TODO actually copy the if statement
    return copy;
  }
}

public class SelectStatement extends Instruction {
  ExprOperand arg;
  ArrayList<ExprOperand> cases;
  ArrayList<Instruction> instrList;
    
  public SelectStatement() {
    arg = new ExprOperand();
    cases = new ArrayList<ExprOperand>();
    instrList = new ArrayList<Instruction>();
    addCase();
  }
  
  public SelectStatement(ExprOperand a) {
    arg = a;
    cases = new ArrayList<ExprOperand>();
    instrList = new ArrayList<Instruction>();
    addCase();
  }
  
  public int execute() {
    for(int i = 0; i < cases.size(); i += 1) {
      ExprOperand c = cases.get(i);
      if(c == null) return 1;
      
      println("testing case " + i + " = " + cases.get(i).getDataVal() + " against " + arg.getDataVal());
      
      if(c.type != ExpressionElement.UNINIT && arg.getDataVal() == c.dataVal) {
        Instruction instr = instrList.get(i);
        
        if(instr instanceof JumpInstruction || instr instanceof CallInstruction) {
          println("executing " + instrList.get(i).toString());
          instr.execute();
        }
        break;
      }
    }
    
    return 0;
  }
  
  public void addCase() {
    cases.add(new ExprOperand());
    instrList.add(new Instruction());
  }
  
  public void addCase(ExprOperand e, Instruction i) {
    cases.add(e);
    instrList.add(i);
  }
  
  public void deleteCase(int idx) {
    if(cases.size() > 1) {
      cases.remove(idx);
    }
    
    if(instrList.size() > 1) {
      instrList.remove(idx);
    }
  }
  
  public String toString() {
    return "";
  }
  
  public Instruction clone() {   
    Instruction copy = new SelectStatement();
    copy.setIsCommented( isCommented() );
    // TODO actually copy the select statement
    return copy;
  }
  
  public String[] toStringArray() {
    String[] ret = new String[2 + 4*cases.size()];
    ret[0] = "SELECT";
    ret[1] = arg.toString();
    
    for(int i = 0; i < cases.size(); i += 1) {
      String[] iString = instrList.get(i).toStringArray();
      
      ret[i*4 + 2] = "= " + cases.get(i).toString();
      ret[i*4 + 3] = iString[0];
      ret[i*4 + 4] = iString.length == 1 ? "..." : iString[1];
      ret[i*4 + 5] = "\n";
    }
    
    return ret;
  }
}

public class RegisterStatement extends Instruction {
  Register reg;  //the register to be modified by this instruction
  int posIdx;  //used if editing a single value in a position register
  Expression expr;  //the expression whose value will be stored in 'reg' after evaluation
  
  /**
   * Creates a register statement with a given register and a blank Expression.
   *
   * @param reg - The destination register for this register expression. The
   *              result of the expression 'expr' will be assigned to 'reg'
   *              upon successful execution of this statement.
   * @param expr - The expression to be evaluated in conjunction with the execution
   *               of this statement. The value of this expression, if valid for the
   *               register 
   */
  public RegisterStatement(Register r) {
    reg = r;
    posIdx = -1;
    expr = new Expression();
  }
  
  public RegisterStatement(Register r, int i) {
    reg = r;
    posIdx = i;
    expr = new Expression();
  }
  
  public RegisterStatement(Register r, int idx, Expression e) {
    reg = r;
    posIdx = idx;
    expr = e;
  }
  
  public Register setRegister(Register r) {
    reg = r;
    posIdx = -1;
    return reg;
  }
  
  public Register setRegister(Register r, int idx) {
    reg = r;
    posIdx = idx;
    return reg;
  }
  
  public int execute() {
    ExprOperand result = expr.evaluate();
    
    if(result == null) return 1;
    
    if(reg instanceof DataRegister) {
      if(result.getDataVal() == null) return 1;
      ((DataRegister)reg).value = result.getDataVal();
      
      println(result.dataVal + ", " + ((DataRegister)reg).value);
    } 
    else if(reg instanceof IORegister) {
      if(result.getBoolVal() == null) return 1;
      ((IORegister)reg).state = result.getBoolVal() ? ON : OFF;
    } 
    else if(reg instanceof PositionRegister && posIdx == -1) {
      if(result.getPointVal() == null) return 1;
      ((PositionRegister)reg).point = result.getPointVal();
    } 
    else {
      if(result.getDataVal() == null) return 1;
      println(result.getDataVal());
      ((PositionRegister)reg).setPointValue(posIdx, result.getDataVal());
    }
        
    return 0;
  }
  
  public Instruction clone() {
    Instruction copy = new RegisterStatement(reg, posIdx, (Expression)expr.clone());    
    return copy;
  }
  
  /**
   * Convert the entire statement to a set of Strings, where each
   * operator and operand is a separate String Object.
   */
  public String[] toStringArray() {
    String[] ret;
    String[] exprString = expr.toStringArray();
    String rString = "";
    int rLen;
        
    if(reg instanceof DataRegister) { rString  = "R["; }
    else if(reg instanceof IORegister) { rString  = "IO["; }
    else if(reg instanceof PositionRegister) { rString  = "PR["; }
    
    if(posIdx == -1) {
      ret = new String[2 + expr.getLength()];
            
      ret[0] = rString;
      ret[1] = (reg.getIdx() == -1) ? "...] =" : (reg.getIdx() + 1) + "] =";
      rLen = 2;
    } else {
      ret = new String[3 + expr.getLength()];
      
      ret[0] = rString;
      ret[1] = (reg.getIdx() == -1) ? "...," : (reg.getIdx() + 1) + ",";
      ret[2] = (reg.getIdx() == -1) ? "...] =" : posIdx + "] =";
      rLen = 3;
    }
    
    for(int i = 0; i < exprString.length; i += 1) {
      ret[i + rLen] = exprString[i];
    }
    
    return ret;
  }
}

public class RecordScreen implements Runnable {
  public RecordScreen() {
    System.out.format("Record screen...\n");
  }
  public void run() {
    try{ 
      // create a timestamp and attach it to the filename
      Calendar calendar = Calendar.getInstance();
      java.util.Date now = calendar.getTime();
      java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());
      String filename = "output_" + currentTimestamp.toString() + ".flv"; 
      filename = filename.replace(' ', '_');
      filename = filename.replace(':', '_');   

      // record screen
      System.out.format("run script to record screen...\n");
      Runtime rt = Runtime.getRuntime();
      Process proc = rt.exec("ffmpeg -f dshow -i " + 
      "video=\"screen-capture-recorder\":audio=\"Microphone" + 
      " (Conexant SmartAudio HD)\" " + filename );
      //Process proc = rt.exec(script);
      while(record == ON) {
        Thread.sleep(4000);
      }
      rt.exec("taskkill /F /IM ffmpeg.exe"); // close ffmpeg
      System.out.format("finish recording\n");
      
    }catch (Throwable t) {
      t.printStackTrace();
    }
    
  }
}
// Position Registers
private final PositionRegister[] GPOS_REG = new PositionRegister[100];
// Data Registers
private final DataRegister[] DREG = new DataRegister[100];
// IO Registers
private final IORegister[] IO_REG = new IORegister[5];

public abstract class Register {
  protected String comment;
  protected int idx;
  
  public Register() {
    comment = null;
    idx = -1;
  }
  
  public Register(int i) {
    comment = null;
    idx = i;
  }
  
  public String getComment() { return comment; }
  public int getIdx() { return idx; }
  public String setComment(String s) { return comment = s; }
  public int setIdx(int i) { return idx = i; }
}

/* A simple class for a Register of the Robot Arm, which holds a value associated with a comment. */
public class DataRegister extends Register {
  public Float value;
  
  public DataRegister() {
    comment = null;
    value = null;
  }
  
  public DataRegister(int i) {
    idx = i;
    comment = null;
    value = null;
  }
  
  public DataRegister(int i, String c, Float v) {
    idx = i;
    comment = c;
    value = v;
  }
}

/* A simple class for a Position Register of the Robot Arm, which holds a point associated with a comment. */
public class PositionRegister extends Register {
  /**
   * The point associated with this Position Register, which is saved in
   * the current User frame with the active Tool frame TCP offset, though
   * is independent of Frames
   */
  public Point point;
  public boolean isCartesian;
  
  public PositionRegister() {
    comment = null;
    point = null;
    isCartesian = false;
  }
  
  public PositionRegister(int i) {
    idx = i;
    comment = null;
    point = null;
    isCartesian = false;
  }
  
  public PositionRegister(int i, String c, Point pt, boolean isCart) {
    idx = i;
    comment = c;
    point = pt;
    isCartesian = isCart;
  }
  
  /**
   * Returns the value of the point stored in this register which corresponds
   * to the register mode (joint or cartesian) and the given index 'idx.'
   * Note that 'idx' should be in the range of 0 to 5 inclusive, as this value
   * is meant to represent either 1 of 6 joint angles for a joint type point,
   * or 1 of 6 cartesian points (x, y, z, w, p, r) for a cartesian type point.
   */
  public Float getPointValue(int idx) {
    if(point == null) {
      return null;
    }
    
    if(!isCartesian) {
      return point.getValue(idx);
    }
    else if(idx < 3) {
      return point.getValue(idx + 6);
    }
    else {
      PVector pOrientation = quatToEuler(point.orientation);
      return pOrientation.array()[idx - 3];
    }
  }
  
  public void setPointValue(int idx, float value) {
    if(point == null) {
      point = new Point();
    }
    
    if(!isCartesian) {
      point.getValue(idx);
    }
    else if(idx < 3) {
      point.getValue(idx + 6);
    }
    else {
      PVector pOrientation = quatToEuler(point.orientation);
      pOrientation.array()[idx - 3] = value;
    }
  }
}

/* A simple class designed to hold a state value along with a name. */
public class IORegister extends Register {
  public final String name;
  public int state;
  
  public IORegister() {
    name = "";
    state = OFF;
  }
  
  public IORegister(int i, int iniState) {
    idx = i;
    name = "";
    state = iniState;
  }
  
  public IORegister(int i, String comm, int iniState) {
    idx = i;
    name = comm;
    state = iniState;
  }
}
/**
 * This method saves all programs, frames, and initialized registers,
 * each to separate files
 */
public void saveState() {
  saveProgramBytes( new File(sketchPath("tmp/programs.bin")) );
  saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
  saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
  saveScenarioBytes( new File(sketchPath("tmp/scenarios.bin")) );
}

/**
 * Load program, frames, and registers from their respective
 * binary files.
 *
 * @return  a byte value
 */
public byte loadState() {
  byte[] fileFlags = new byte[] { 1, 1, 1, 1 };
  
  File f = new File(sketchPath("tmp/"));
  if(!f.exists()) { f.mkdirs(); }
  
  /* Load all saved Programs */
  
  File progFile = new File( sketchPath("tmp/programs.bin") );
  
  if(progFile.exists()) {
    int ret = loadProgramBytes(progFile);
    
    if(ret == 0) {
      println("Successfully loaded programs!");
      fileFlags[0] = 0;
    } else {
      println("Failed to load programs ...");
    }
  }
  
  /* Load and Initialize the Tool and User Frames */
  
  File frameFile = new File( sketchPath("tmp/frames.bin") );
  
  if(frameFile.exists()) {
    // Load both the User and Tool Frames
    int ret = loadFrameBytes(frameFile);
    
    if(ret == 0) {
      println("Successfully loaded frames!");
      fileFlags[1] = 0;
    } else {
      println("Failed to load frames ...");
      
    }
  }
  
  // Create new frames if they could not be loaded
  if(fileFlags[1] == 1) {
    
    toolFrames = new Frame[10];
    userFrames = new Frame[10];
    
    for(int n = 0; n < toolFrames.length; n += 1) {
      toolFrames[n] = new ToolFrame();
      userFrames[n] = new UserFrame();
    }
  }
  
  
  /* Load and Initialize the Position Register and Registers */
  
  File regFile = new File(sketchPath("tmp/registers.bin"));
  
  if(regFile.exists()) {
    int ret = loadRegisterBytes(regFile);
    
    if(ret == 0) {
      println("Successfully loaded registers!");
      fileFlags[2] = 0;
    } else {
      println("Failed to load registers ...");
    }
  }
  
  File scenarioFile = new File(sketchPath("tmp/scenarios.bin"));
  
  if(scenarioFile.exists()) {
    int ret = loadScenarioBytes(scenarioFile);  
    
    if(ret == 0) {
      println("Successfully loaded scenarios!");
      fileFlags[3] = 0;
    } else {
      println("Failed to load scenarios ...");
    }
  }
  
  // Initialize uninitialized registers and position registers to with null fields
  for(int reg = 0; reg < DREG.length; reg += 1) {
    
    if(DREG[reg] == null) {
      DREG[reg] = new DataRegister(reg);
    }
    
    if(GPOS_REG[reg] == null) {
      GPOS_REG[reg] = new PositionRegister(reg);
    }
  }
  
  // Associated each End Effector with an I/O Register
  int idx = 0;
  IO_REG[idx++] = new IORegister(idx, (EEType.SUCTION).name(), OFF);
  IO_REG[idx++] = new IORegister(idx, (EEType.CLAW).name(), OFF);
  IO_REG[idx++] = new IORegister(idx, (EEType.POINTER).name(), OFF);
  IO_REG[idx++] = new IORegister(idx, (EEType.GLUE_GUN).name(), OFF);
  IO_REG[idx++] = new IORegister(idx, (EEType.WIELDER).name(), OFF);
  
  for(; idx < IO_REG.length; idx += 1) {
    // Intialize the rest of the I/O registers
    IO_REG[idx] = new IORegister(idx, OFF);
  }
  
  byte ret = 0;
  
  for (int bdx = 0; bdx < fileFlags.length; bdx += 1) {
    // Move each flag to a separate bit spot
    ret += (fileFlags[bdx] << bdx);
  }
  
  return ret;
}

/**
 * Saves all the Programs currently in ArrayList programs to the
 * given file.
 * 
 * @param dest  where to save all the programs
 * @return      0 if the save was successful,
 *              1 if dest could not be created or found,
 *              2 if an error occurs when saving the Programs
 */
public int saveProgramBytes(File dest) {
  
  try {
    // Create dest if it does not already exist
    if(!dest.exists()) {      
      try {
        dest.createNewFile();
        System.out.printf("Successfully created %s.\n", dest.getName());
      } catch (IOException IOEx) {
        System.out.printf("Could not create %s ...\n", dest.getName());
        IOEx.printStackTrace();
        return 1;
      }
    } 
    
    FileOutputStream out = new FileOutputStream(dest);
    DataOutputStream dataOut = new DataOutputStream(out);
    // Save the number of programs
    dataOut.writeInt(programs.size());
    
    for(Program prog : programs) {
      // Save each program
      saveProgram(prog, dataOut);
    }
    
    dataOut.close();
    out.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not locate dest
    System.out.printf("%s does not exist!\n", dest.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (IOException IOEx) {
    // An error occrued with writing to dest
    System.out.printf("%s is corrupt!\n", dest.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Loads all Programs stored in the given file. This method expects that the number of
 * programs to be stored is stored at the immediate beginning of the file as an integer.
 * Though, no more then 200 programs will be loaded.
 * 
 * @param src  The file from which to load the progarms
 * @return     0 if the load was successful,
 *             1 if src could not be found,
 *             2 if an error occured while reading the programs,
 *             3 if the end of the file is reached before all the expected programs are
 *               read
 */
public int loadProgramBytes(File src) {
  
  try {
    FileInputStream in = new FileInputStream(src);
    DataInputStream dataIn = new DataInputStream(in);
    // Read the number of programs stored in src
    int size = max(0, min(dataIn.readInt(), 200));
    
    while(size-- > 0) {
      // Read each program from src
      programs.add( loadProgram(dataIn) );
    }
    
    dataIn.close();
    in.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not locate src
    System.out.printf("%s does not exist!\n", src.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (EOFException EOFEx) {
    // Reached the end of src unexpectedly
    System.out.printf("End of file, %s, was reached unexpectedly!\n", src.getName());
    EOFEx.printStackTrace();
    return 3;
    
  } catch (IOException IOEx) {
    // An error occured with reading from src
    System.out.printf("%s is corrupt!\n", src.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Saves the data associated with the given Program to the given output stream.
 * Not all the Points in a programs Point array are stored: only the Points
 * associated with a MotionInstruction are saved after the MotionInstruction,
 * to which it belongs.
 * 
 * @param  p            The program to save
 * @param  out          The output stream to which to save the Program
 * @throws IOException  If an error occurs with saving the Program
 */
private void saveProgram(Program p, DataOutputStream out) throws IOException {
  
  if (p == null) {
    // Indicates a null value is saved
    out.writeByte(0);
    
  } else {
    // Indicates a non-null value is saved
    out.writeByte(1);
    
    out.writeUTF(p.name);
    out.writeInt(p.nextPosition);
    out.writeInt(p.instructions.size());
    // Save each instruction
    for(Instruction inst : p.instructions) {
      saveInstruction(inst, out);
      // Save only the Points associated with a MotionInstruction
      if(inst instanceof MotionInstruction) {
        savePoint(p.LPosReg[ ((MotionInstruction)inst).positionNum ], out);
      }
    }
  }
}

/**
 * Creates a program from data in the given input stream. A maximum of
 * 500 instructions will be read for a single program
 * 
 * @param in            The input stream to read from
 * @return              A program created from data in the input stream,
 *                      or null
 * @throws IOException  If an error occurs with reading from the input
 *                      stream
 */
private Program loadProgram(DataInputStream in) throws IOException {
  // Read flag byte
  byte flag = in.readByte();
  
  if (flag == 0) {
    return null;
    
  } else {
    // Read program name
    String name = in.readUTF();
    Program prog = new Program(name);
    // Read the next register value
    int nReg = in.readInt();
    prog.setNextPosition(nReg);
    // Read the number of instructions stored for this porgram
    int numOfInst = max(0, min(in.readInt(), 500));
    
    while(numOfInst-- > 0) {
      // Read each instruction
      Instruction inst = loadInstruction(in);
      prog.addInstruction(inst);
      // Read the points stored after each MotionIntruction
      if(inst instanceof MotionInstruction) {
        Point pt = loadPoint(in);
        prog.addPosition(pt, ((MotionInstruction)inst).positionNum);
      }
    }
    
    return prog;
  }
}

/**
 * Saves the data associated with the given Point object to the file opened
 * by the given output stream. Null Points are saved a single zero byte.
 * 
 * @param   p            The Point of which to save the data
 * @param   out          The output stream used to save the Point
 * @throws  IOException  If an error occurs with writing the data of the Point
 */
private void savePoint(Point p, DataOutputStream out) throws IOException {
  
  if (p == null) {
    // Indicate a null value is saved
    out.writeByte(0);
    
  } else {
    // Indicate a non-null value is saved
    out.writeByte(1);
    // Write position of the point
    savePVector(p.position, out);
    // Write point's orientation
    saveFloatArray(p.orientation, out);
    // Write the joint angles for the point's position
    saveFloatArray(p.angles, out);
    
    if (p.angles == null) {
      println("null angles!");
    }
  }
}

/**
 * Loads the data of a Point from the file opened by the given
 * input stream. It is possible that null will be returned by
 * this method if a null Point was saved.
 *
 * @param  in           The input stream used to read the data of
 *                      a Point
 * @return              The Point stored at the current position
 *                      of the input stream
 * @throws IOException  If an error occurs with reading the data
 *                      of the Point
 */
private Point loadPoint(DataInputStream in) throws IOException {
  // Read flag byte
  byte val = in.readByte();
  
  if (val == 0) {
    return null;
    
  } else {
    // Read the point's position
    PVector position = loadPVector(in);
    // Read the point's orientation
    float[] orientation = loadFloatArray(in);
    // Read the joint angles for the joint's position
    float[] angles = loadFloatArray(in);
    
    if (angles == null) {
      println("null angles!");  
    }
    
    return new Point(position, orientation, angles);
  }
}

/**
 * Saves the data stored in the given instruction to the file opened by the give output
 * stream. Currently, this method will only work for instructions of type: Motion, Frame
 * and Tool.
 * 
 * @param inst          The instruction of which to save the data
 * @pararm out          The output stream used to save the given instruction
 * @throws IOException  If an error occurs with saving the instruction
 */
private void saveInstruction(Instruction inst, DataOutputStream out) throws IOException {
  
  // Each Instruction subclass MUST have its own saving code block associated with its unique data fields
  if (inst instanceof MotionInstruction) {
    MotionInstruction m_inst = (MotionInstruction)inst;
    // Flag byte denoting this instruction as a MotionInstruction
    out.writeByte(2);
    // Write data associated with the MotionIntruction object
    out.writeBoolean(m_inst.isCommented());
    out.writeInt(m_inst.motionType);
    out.writeInt(m_inst.positionNum);
    out.writeBoolean(m_inst.isGPosReg);
    out.writeFloat(m_inst.speed);
    out.writeInt(m_inst.termination);
    out.writeInt(m_inst.userFrame);
    out.writeInt(m_inst.toolFrame);
    
  } else if(inst instanceof FrameInstruction) {
    FrameInstruction f_inst = (FrameInstruction)inst;
    // Flag byte denoting this instruction as a FrameInstruction
    out.writeByte(3);
    // Write data associated with the FrameInstruction object
    out.writeBoolean(f_inst.isCommented());
    out.writeInt(f_inst.frameType);
    out.writeInt(f_inst.frameIdx);
    
  } else if(inst instanceof IOInstruction) {
    IOInstruction t_inst = (IOInstruction)inst;
    // Flag byte denoting this instruction as a ToolInstruction
    out.writeByte(4);
    // Write data associated with the ToolInstruction object
    out.writeBoolean(t_inst.isCommented());
    out.writeInt(t_inst.reg);
    out.writeInt( saveint(t_inst.state) );
    
  } else if(inst instanceof LabelInstruction) {
    LabelInstruction l_inst = (LabelInstruction)inst;
    
    out.writeByte(5);
    out.writeBoolean(l_inst.isCommented());
    out.writeInt(l_inst.labelNum);
    
  } else if(inst instanceof JumpInstruction) {
    JumpInstruction j_inst = (JumpInstruction)inst;
    
    out.writeByte(6);
    out.writeBoolean(j_inst.isCommented());
    out.writeInt(j_inst.tgtLblNum);
    
  } /* Add other instructions here! */
    else if (inst instanceof Instruction) {
    /// A blank instruction
    out.writeByte(1);
    out.writeBoolean(inst.isCommented());
    
  } else {
    // Indicate a null-value is saved
    out.writeByte(0);
  }
  
  
}

/**
 * The next instruction stored in the file opened by the given input stream
 * is read, created, and returned. This method is currently only functional
 * for instructions of type: Motion, Frame, and Tool.
 *
 * @param in            The input stream from which to read the data of an
 *                      instruction
 * @return              The instruction saved at the current position of the
 *                      input stream
 * @throws IOException  If an error occurs with reading the data of the
 *                      instruciton
 */
private Instruction loadInstruction(DataInputStream in) throws IOException {
  Instruction inst = null;
  // Read flag byte
  byte instType = in.readByte();
  
  if(instType == 2) {
    // Read data for a MotionInstruction object
    boolean isCommented = in.readBoolean();
    int mType = in.readInt();
    int reg = in.readInt();
    boolean isGlobal = in.readBoolean();
    float spd = in.readFloat();
    int term = in.readInt();
    int uFrame = in.readInt();
    int tFrame = in.readInt();
    
    inst = new MotionInstruction(mType, reg, isGlobal, spd, term, uFrame, tFrame);
    inst.setIsCommented(isCommented);
    
  } else if(instType == 3) {
    // Read data for a FrameInstruction object
    boolean isCommented = in.readBoolean();
    inst = new FrameInstruction( in.readInt(), in.readInt() );
    inst.setIsCommented(isCommented);
    
  } else if(instType == 4) {
    // Read data for a ToolInstruction object
    boolean isCommented = in.readBoolean();
    int reg = in.readInt();
    int setting = in.readInt();
    
    inst = new IOInstruction(reg, loadint(setting));
    inst.setIsCommented(isCommented);
    
  } else if (instType == 5) {
    boolean isCommented = in.readBoolean();
    int labelNum = in.readInt();
    
    inst = new LabelInstruction(labelNum);
    inst.setIsCommented(isCommented);
    
  } else if (instType == 6) {
    boolean isCommented = in.readBoolean();
    int tgtLabelNum = in.readInt();
    
    inst = new JumpInstruction(tgtLabelNum);
    inst.setIsCommented(isCommented);
    
  } /* Add other instructions here! */
    else if (instType == 1) {
    inst = new Instruction();
    boolean isCommented = in.readBoolean();
    inst.setIsCommented(isCommented);
    
  } else {
    return null;
  }
  
  return inst;
}

/**
 * Convert the given End Effector status
 * to a unique integer value.
 */
private int saveint(int stat) {
  switch (stat) {
    case ON:  return 0;
    case OFF: return 1;
    default:  return -1;
  }
}

/**
 * Converts a valid integer value to its
 * corresponding End Effector Status.
 */
private int loadint(int val) {
  switch (val) {
    case 0:   return ON;
    case 1:   return OFF;
    default:  return -1;
  }
}

/**
 * Given a valid file path, both the Tool Frame and then the User
 * Frame sets are saved to the file. First the length of a list
 * is saved and then its respective elements.
 *
 * @param dest  the file to which the frame sets will be saved
 * @return      0 if successful,
 *              1 if dest could not be created or found
 *              2 if an error occurs with writing to the file
 */
public int saveFrameBytes(File dest) {
  
  try {
    // Create dest if it does not already exist
    if(!dest.exists()) {
      try {
        dest.createNewFile();
        System.out.printf("Successfully created %s.\n", dest.getName());
      } catch (IOException IOEx) {
        System.out.printf("Could not create %s ...\n", dest.getName());
        IOEx.printStackTrace();
      }
    }
    
    FileOutputStream out = new FileOutputStream(dest);
    DataOutputStream dataOut = new DataOutputStream(out);
    
    // Save Tool Frames
    dataOut.writeInt(toolFrames.length);
    for(Frame frame : toolFrames) {
      saveFrame(frame, dataOut);
    }
    
    // Save User Frames
    dataOut.writeInt(userFrames.length);
    for(Frame frame : userFrames) {
      saveFrame(frame, dataOut);
    }
    
    dataOut.close();
    out.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not find dest
    System.out.printf("%s does not exist!\n", dest.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (IOException IOEx) {
    // Error with writing to dest
    System.out.printf("%s is corrupt!\n", dest.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Loads both the Tool and User Frames from the file path denoted
 * by the given String. The Tool Frames are expected to come before
 * the Usser Frames. In addition, it is expected that both frame
 * sets store the length of the set before the first element.
 * 
 * @param src  the file, which contains the data for the Tool and
 *             User Frames
 * @return     0 if successful,
 *             1 if an error occurs with accessing the give file
 *             2 if an error occurs with reading from the file
 *             3 if the end of the file is reached before reading
 *             all the data for the frames
 */
public int loadFrameBytes(File src) {
  int idx = -1;
  
  try {
    FileInputStream in = new FileInputStream(src);
    DataInputStream dataIn = new DataInputStream(in);
    
    // Load Tool Frames
    int size = max(0, min(dataIn.readInt(), 10));
    toolFrames = new ToolFrame[size];
    
    
    for(idx = 0; idx < size; ++idx) {
      toolFrames[idx] = loadFrame(dataIn);
    }
    
    // Load User Frames
    size = max(0, min(dataIn.readInt(), 10));
    userFrames = new UserFrame[size];
    
    for(idx = 0; idx < size; ++idx) {
      userFrames[idx] = loadFrame(dataIn);
    }
    
    dataIn.close();
    in.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not find src
    System.out.printf("%s does not exist!\n", src.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (EOFException EOFEx) {
    // Reached the end of src unexpectedly
    System.out.printf("End of file, %s, was reached unexpectedly!\n", src.getName());
    EOFEx.printStackTrace();
    return 3;
    
  } catch (IOException IOEx) {
    // Error with reading from src
    System.out.printf("%s is corrupt!\n", src.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Saves the data of the given frame's origin, orientation and axes vectors
 * to the file opened by the given DataOutputStream.
 * 
 * @param f    A non-null frame object
 * @param out  An output stream used to write the given frame to a file
 * @throw IOException  if an error occurs with writing the frame to the file
 */
private void saveFrame(Frame f, DataOutputStream out) throws IOException {
  
  // Save a flag to indicate what kind of frame was saved
  if (f == null) {
    out.writeByte(0);
    return;
    
  } else if (f instanceof ToolFrame) {
    out.writeByte(1);
  
  } else if (f instanceof UserFrame) {
    out.writeByte(2);
  
  } else {
    throw new IOException("Invalid Frame!");
  }
  
  if (f instanceof UserFrame) {
    // Write User frame origin
    savePVector(f.getOrigin(), out);
    
  } else {
    // Write Tool frame TCP offset
    savePVector( ((ToolFrame)f).getTCPOffset(), out );
  }
  
  // Write frame axes
  saveFloatArray(f.orientation, out);
  
  // Write frame orientation points
  for (Point pt : f.axesTeachPoints) {
    savePoint(pt, out);
  }
  
  // Write frame manual entry origin value
  savePVector(f.DEOrigin, out);
  // Write frame manual entry origin value
  saveFloatArray(f.DEOrientation, out);
  
  if (f instanceof ToolFrame) {
    ToolFrame tFrame = (ToolFrame)f;
    // Save points for the TCP teaching of the frame
    for (Point p : tFrame.TCPTeachPoints) {
      savePoint(p, out);
    }
    
  } else {
    // Save point for the origin offset of the frame
    savePoint( ((UserFrame)f).orientOrigin, out );
  }
}

/**
 * Loads the data associated with a Frame object (origin,
 * orientation and axes vectors) from the file opened by
 * the given DataOutputStream.
 *
 * @param out  An input stream used to read from a file
 * @return     The next frame stored in the file
 * @throw IOException  if an error occurs while reading the frame
 *                     from to the file
 */
private Frame loadFrame(DataInputStream in) throws IOException {
  
  Frame f = null;
  byte type = in.readByte();
  
  if (type == 0) {
    return null;
  } else if (type == 1) {
    f = new ToolFrame();
  
  } else if (type == 2) {
    f = new UserFrame();
  
  } else {
    println(type);
    throw new IOException("Invalid Frame type!");
  }
  
  PVector v = loadPVector(in);
  
  if (f instanceof UserFrame) {
    // Read origin value
    ((UserFrame)f).setOrigin(v);
  } else {
    // Read TCP offset values
    ((ToolFrame)f).setTCPOffset(v);
  }

  // Read axes quaternion values
  f.setOrientation( loadFloatArray(in) );
  
  // Read origin values
  f.axesTeachPoints = new Point[3];
  // Read in orientation points
  for (int idx = 0; idx < 3; ++idx) {
    f.axesTeachPoints[idx] = loadPoint(in);
  }
  
  // Read manual entry origin values
  f.DEOrigin = loadPVector(in);
  f.DEOrientation = loadFloatArray(in);
  
  if (f instanceof ToolFrame) {
    ToolFrame tFrame = (ToolFrame)f;
    
    // Load points for the TCP teaching of the frame
    for (int idx = 0; idx < 3; ++idx) {
      tFrame.TCPTeachPoints[idx] = loadPoint(in);
    }
    
  } else {
    // Load point for the origin offset of the frame
    ((UserFrame)f).orientOrigin = loadPoint(in);
  }
  
  return f;
}

/**
 * Saves all initialized Register and Position Register Entries with their
 * respective indices in their respective lists to dest. In addition, the
 * number of Registers and Position Registers saved is saved to the file
 * before each respective set of entries.
 * 
 * @param dest  Some binary file to which to save the Register entries
 * @return      0 if the save was successful,
 *              1 if dest could not be found pr created
 *              2 if an error occrued while writing to dest
 */
public int saveRegisterBytes(File dest) {
  
  try {
    
    // Create dest if it does not already exist
    if(!dest.exists()) {
      try {
        dest.createNewFile();
        System.out.printf("Successfully created %s.\n", dest.getName());
      } catch (IOException IOEx) {
        System.out.printf("Could not create %s ...\n", dest.getName());
        IOEx.printStackTrace();
      }
    }
    
    FileOutputStream out = new FileOutputStream(dest);
    DataOutputStream dataOut = new DataOutputStream(out);
    
    int numOfREntries = 0,
    numOfPREntries = 0;
    
    ArrayList<Integer> initializedR = new ArrayList<Integer>(),
    initializedPR = new ArrayList<Integer>();
    
    // Count the number of initialized entries and save their indices
    for(int idx = 0; idx < DREG.length; ++idx) {
      if(DREG[idx].value != null || DREG[idx].comment != null) {
        initializedR.add(idx);
        ++numOfREntries;
      }
      
      if(GPOS_REG[idx].point != null || GPOS_REG[idx].comment != null) {
        initializedPR.add(idx);
        ++numOfPREntries;
      }
    }
    
    dataOut.writeInt(numOfREntries);
    // Save the Register entries
    for(Integer idx : initializedR) {
      dataOut.writeInt(idx);
      
      if(DREG[idx].value == null) {
        // save for null Float value
        dataOut.writeFloat(Float.NaN);
      } else {
        dataOut.writeFloat(DREG[idx].value);
      }
      
      if(DREG[idx].comment == null) {
        dataOut.writeUTF("");
      } else {
        dataOut.writeUTF(DREG[idx].comment);
      }
    }
    
    dataOut.writeInt(numOfPREntries);
    // Save the Position Register entries
    for(Integer idx : initializedPR) {
      dataOut.writeInt(idx);
      savePoint(GPOS_REG[idx].point, dataOut);
      
      if(GPOS_REG[idx].comment == null) {
        dataOut.writeUTF("");
      } else {
        dataOut.writeUTF(GPOS_REG[idx].comment);
      }
      
      dataOut.writeBoolean(GPOS_REG[idx].isCartesian);
    }
    
    dataOut.close();
    out.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not be located dest
    System.out.printf("%s does not exist!\n", dest.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (IOException IOEx) {
    // Error occured while reading from dest
    System.out.printf("%s is corrupt!\n", dest.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Loads all the saved Registers and Position Registers from the
 * given binary file. It is expected that the number of entries
 * saved for both the Registers and Position Registers exist in the
 * file before each respective list. Also, the index of an entry
 * in the Register (or Position Register) list should also exist
 * before each antry in the file.
 * 
 * @param src  The binary file from which to load the Register and
 *             Position Register entries
 * @return     0 if the load was successful,
 *             1 if src could not be located,
 *             2 if an error occured while reading from src
 *             3 if the end of file is reached in source, before
 *               all expected entries were read
 */
public int loadRegisterBytes(File src) {
  
  try {
    FileInputStream in = new FileInputStream(src);
    DataInputStream dataIn = new DataInputStream(in);
    
    int size = max(0, min(dataIn.readInt(), DREG.length));
    
    // Load the Register entries
    while((size -= 1) > 0) {
      // Each entry is saved after its respective index in REG
      int reg = dataIn.readInt();
      
      Float v = dataIn.readFloat();
      // Null values are saved as NaN
      if(Float.isNaN(v)) { v = null; }
      
      String c = dataIn.readUTF();
      // Null comments are saved as ""
      if(c.equals("")) { c = null; }
      
      DREG[reg] = new DataRegister(reg, c, v);
    }
    
    size = max(0, min(dataIn.readInt(), GPOS_REG.length));
    
    // Load the Position Register entries
    while((size -= 1) > 0) {
      // Each entry is saved after its respective index in POS_REG
      int idx = dataIn.readInt();
      
      Point p = loadPoint(dataIn);
      String c = dataIn.readUTF();
      // Null comments are stored as ""
      if(c == "") { c = null; }
      boolean isCartesian = dataIn.readBoolean();
      
      GPOS_REG[idx] = new PositionRegister(idx, c, p, isCartesian);
    }
    
    dataIn.close();
    in.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not be located src
    System.out.printf("%s does not exist!\n", src.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (EOFException EOFEx) {
    // Unexpectedly reached the end of src
    System.out.printf("End of file, %s, was reached unexpectedly!\n", src.getName());
    EOFEx.printStackTrace();
    return 3;
    
  } catch (IOException IOEx) {
    // Error occrued while reading from src
    System.out.printf("%s is corrupt!\n", src.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Saves all the scenarios stored in SCENARIOS to given
 * destination binary file.
 * 
 * @param dest  The binary file to which to save the scenarios
 * @returning   0  if the saving of scenarios is successful,
 *              1  if the file could not be found,
 *              2  if some other error occurs with writing
 *                 to dest
 */
public int saveScenarioBytes(File dest) {
  
  try {
     
    // Create dest if it does not already exist
    if(!dest.exists()) {
      try {
        dest.createNewFile();
        System.out.printf("Successfully created %s.\n", dest.getName());
      } catch (IOException IOEx) {
        System.out.printf("Could not create %s ...\n", dest.getName());
        IOEx.printStackTrace();
      }
    }
    
    FileOutputStream out = new FileOutputStream(dest);
    DataOutputStream dataOut = new DataOutputStream(out);
    
    int numOfScenarios = SCENARIOS.size();
    // Save the number of scenarios
    dataOut.writeInt(numOfScenarios);
    
    if (activeScenario == null) {
      // No active scenario
      dataOut.writeUTF("");
    } else {
      // Save the name of the active scenario
      dataOut.writeUTF(activeScenario.getName());
    }
    
    // Save all the scenarios
    for (int sdx = 0; sdx < SCENARIOS.size(); ++sdx) {
      Scenario s = SCENARIOS.get(sdx);
      
      if (s.getName().equals( activeScenario.getName() )) {
        // Update the previous version of the active scenario
        s = (Scenario)activeScenario.clone();
        SCENARIOS.set(sdx, s);
      }
      
      saveScenario(s, dataOut);
    }
    
    dataOut.close();
    out.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not be located dest
    System.out.printf("%s does not exist!\n", dest.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (IOException IOEx) {
    // Error occrued while writing to dest
    System.out.printf("%s is corrupt!\n", dest.getName());
    IOEx.printStackTrace();
    return 2;
    
  }
}

/**
 * Attempts to load scenarios from the given binary file.
 * It is expected that an integer representing the number
 * of scenarios is saved in the file first, followed by the
 * index of the previously active scenario, and finally at
 * least that number of scenarios.
 * 
 * @param src  The binary file from which to read scenarios
 * @returning  0  if loading was succssful,
 *             1  if the file could not be found,
 *             2  if the file is corrupt,
 *             3  if the end of file is reached unexpectedly,
 *             4  if an error occurs with loading a .stl file
 *                for the shape of a world object
 */
public int loadScenarioBytes(File src) {
  
  try {
    FileInputStream in = new FileInputStream(src);  
    DataInputStream dataIn = new DataInputStream(in);
    
    int numOfScenarios = dataIn.readInt();
    String activeScenarioName = dataIn.readUTF();
    
    // Load all scenarios saved
    while (numOfScenarios-- > 0) {
      Scenario s = loadScenario(dataIn);
      
      if (s.getName().equals(activeScenarioName)) {
        // Set the active scenario
        activeScenario = (Scenario)s.clone();
      }
      
      SCENARIOS.add(s);
    }
    
    dataIn.close();
    in.close();
    return 0;
    
  } catch (FileNotFoundException FNFEx) {
    // Could not be located src
    System.out.printf("%s does not exist!\n", src.getName());
    FNFEx.printStackTrace();
    return 1;
    
  } catch (EOFException EOFEx) {
    // Unexpectedly reached the end of src
    System.out.printf("End of file, %s, was reached unexpectedly!\n", src.getName());
    EOFEx.printStackTrace();
    return 3;
    
  } catch (IOException IOEx) {
    // Error occrued while reading from src
    System.out.printf("%s is corrupt!\n", src.getName());
    IOEx.printStackTrace();
    return 2;
    
  } catch (NullPointerException NPEx) {
    // Error with loading a .stl model
    System.out.printf("Missing source file!\n");
    NPEx.printStackTrace();
    return 4;
  }
}

/**
 * Saveds all the data associated with a scenario to the given output stream.
 * First a single flag byte is saved to the stream followed by the number of
 * objects in the scenario and then exxactly that number of world objects.
 * 
 * @param s    The scenario to save
 * @param out  The output stream to which to save the scenario
 * @throws     IOException if an erro occurs with writing to the output stream
 */
public void saveScenario(Scenario s, DataOutputStream out) throws IOException {
  
  if (s == null) {
    // Indicate the value saved is null
    out.writeByte(0);
    
  } else {
    // Indicate the value saved is non-null
    out.writeByte(1);
    // Write the name of the scenario
    out.writeUTF(s.getName());
    // Save the number of world objects in the scenario
    out.writeInt( s.size() );
    
    for (WorldObject wldObj : s) {
      // Save all the world objects associated with the scenario
      saveWorldObject(wldObj, out);  
    }
  }
}

/**
 * Attempts to load the data of a Scenario from the given input stream. It is expected that
 * the stream contains a single byte (the flag byte) followed by a String representing the
 * name of the scenario. After the name of the scenario, there should be an positive integer
 * value followed by exactly that many world objects.
 * 
 * @param in   The input stream from which to read bytes
 * @returning  The Scenario pulled from the input stream
 * @throws     IOException  if an error occurs with reading from the input stream
 *             NullPointerException  if a world object has a model shape, whose source file is
 *             corrupt or missing
 */
public Scenario loadScenario(DataInputStream in) throws IOException, NullPointerException {
  // Read flag byte
  byte flag = in.readByte();  
  
  if (flag == 0) {
    return null;
    
  } else {
    // Read the name of the scenario
    String name = in.readUTF();
    Scenario s = new Scenario(name);
    // An extra set of only the loaded fixtures
    ArrayList<Fixture> fixtures = new ArrayList<Fixture>();
    // A list of parts which have a fixture reference defined
    ArrayList<LoadedPart> partsWithReferences = new ArrayList<LoadedPart>();
    
    // Read the number of objects in the scenario
    int size = in.readInt();
    // Read all the world objects contained in the scenario
    while (size-- > 0) {
      Object loadedObject = loadWorldObject(in);
      
      if (loadedObject instanceof WorldObject) {
        // Add all normal world objects to the scenario
        s.addWorldObject( (WorldObject)loadedObject );
        
        if (loadedObject instanceof Fixture) {
          // Save an extra reference of each fixture
          fixtures.add( (Fixture)loadedObject );
        }
        
      } else if (loadedObject instanceof LoadedPart) {
        LoadedPart lPart = (LoadedPart)loadedObject;
        
        if (lPart.part != null) {
          // Save the part in the scenario
          s.addWorldObject(lPart.part);
          
          if (lPart.referenceName != null) {
            // Save any part with a defined reference
            partsWithReferences.add(lPart);
          }
        }
      }
    }
    
    // Set all the Part's references
    for (LoadedPart lPart : partsWithReferences) {
      for (Fixture f : fixtures) {
        if (lPart.referenceName.equals(f.getName())) {
          lPart.part.setFixtureRef(f);
        }
      }
    }
    
    return s;
  }
}

/**
 * Saved all the fields associated with the given world object to the given data output
 * stream. First a single byte (the flag byte) is saved to the stream followed by the
 * name and shape of the object and finally the fields associated with subclass of the object.
 * 
 * @param wldObj  The world object to save
 * @param out     The output stream to which to save the world object
 * @throws        IOException if an error occurs with writing to the output stream
 */
public void saveWorldObject(WorldObject wldObj, DataOutputStream out) throws IOException {
  
  if (wldObj == null) {  
    // Indicate that the value saved is null
    out.writeByte(0);
    
  } else {
    if (wldObj instanceof Part) {
      // Indicate that the value saved is a Part
      out.writeByte(1);
    } else if (wldObj instanceof Fixture) {
      // Indicate that the value saved is a Fixture
      out.writeByte(2);
    }
    
    // Save the name and form of the object
    out.writeUTF(wldObj.getName());
    saveShape(wldObj.getForm(), out);
    // Save the local orientation of the object
    savePVector(wldObj.getLocalCenter(), out);
    saveFloatArray2D(wldObj.getLocalOrientationAxes(), out);
    
    if (wldObj instanceof Part) {
      Part part = (Part)wldObj;
      String refName = "";
      
      savePVector(part.getOBBDims(), out);
      
      if (part.getFixtureRef() != null) {
        // Save the name of the part's fixture reference
        refName = part.getFixtureRef().getName();
      }
      
      out.writeUTF(refName);
    }
  }
}

/**
* TODO recomment this
 * Attempts to load the data associated with a world object from the given data input stream. It
 * is expected that the input stream contains a single byte (for the flag byte) followed by the
 * name and shape of the object, which is followde by the data specific to the object's subclass.
 * 
 * @param in   The input stream from which to read bytes
 * @returning  The world object pulled from the input streaam (which can be null!)
 * @throws     IOException  if an error occurs with rading from the input stream
 *             NullPointerExpcetion  if the world object has a model shape and its source file is
 *             corrupt or missing
 */
public Object loadWorldObject(DataInputStream in) throws IOException, NullPointerException {
  // Load the flag byte
  byte flag = in.readByte();  
  Object wldObjFields = null;
  
  if (flag != 0) {
    // Load the name and shape of the object
    String name = in.readUTF();
    Shape form = loadShape(in);
    // Load the object's local orientation
    PVector center = loadPVector(in);
    float[][] orientationAxes = loadFloatArray2D(in);
    CoordinateSystem localOrientation = new CoordinateSystem();
    localOrientation.setOrigin(center);
    localOrientation.setAxes(orientationAxes);
    
    if (flag == 1) {
      // Load the part's bounding-box and fixture reference name
      PVector OBBDims = loadPVector(in);
      String refName = in.readUTF();
      
      if (refName.equals("")) {
        // A part object
        wldObjFields = new Part(name, form, OBBDims, localOrientation, null);
      } else {
        // A part object with its reference's name
        wldObjFields = new LoadedPart( new Part(name, form, OBBDims, localOrientation, null), refName );
      }
      
    } else if (flag == 2) {
      // A fixture object
      wldObjFields = new Fixture(name, form, localOrientation);
    } 
  }
  
  return wldObjFields;
}

/**
 * Saves all the fields associated with the given Bounding-Box to the given data
 * output stream. A single flag byte is written first, followed by the length,
 * height, and width of box, then the center position PVector, and finally the
 * box's orientation in the form of a 3x3 float array matrix.
 * 
 * @param OBB  The Bounding-Box object to save
 * @param out  The output stream to which to save the Bounding-Box
 * @throws     IOException  if an error occurs with writing to the output stream.
 */
public void saveOBB(BoundingBox OBB, DataOutputStream out) throws IOException {
  
  if (OBB == null) {
    // Indicate the saved value is null
    out.writeByte(0);
    
  } else {
    // Indicate the saved value is non-null
    out.writeByte(1);
    // Save the bounding-boxe's dimensions
    out.writeFloat( OBB.getDim(DimType.LENGTH) );
    out.writeFloat( OBB.getDim(DimType.HEIGHT) );
    out.writeFloat( OBB.getDim(DimType.WIDTH) );
    // Save the local orientation of the bounding-box
    savePVector(OBB.getCenter(), out);
    saveFloatArray2D(OBB.getOrientationAxes(), out);
  }
}

/**
 * Attempts to load the data of a Bounding Box object from the given
 * data input stream. It is expected that the input stream contains a
 * single byte (for the flag byte) followed three float values, a
 * PVector, and finally a 3x3 float array matrix.
 * 
 * @param in   The data stream, from which to read bytes
 * @returning  The Bounding-Box pulled from the input stream (which
 *             can be null!)
 * @throws     IOException if an error occurs with reading from the
 *             input stream
 */
public BoundingBox loadOBB(DataInputStream in) throws IOException {
  
  byte flag = in.readByte();
  
  if (flag == 0) {
    return null;
    
  } else {
    // Read the dimensions of the box
    float len = in.readFloat(),
          hgt = in.readFloat(),
          wid = in.readFloat();
    // Read the local orientation of the box
    PVector center = loadPVector(in);
    float[][] axes = loadFloatArray2D(in);
    
    BoundingBox OBB = new BoundingBox(len, hgt, wid);
    // Set the local orientation of the box
    OBB.setCenter(center);
    OBB.setOrientationAxes(axes);
    return OBB;
  }
}

/**
 * Saves all the fields associated with the given Coordinate System to the given data output
 * stream. First a single byte is wrote to the output stream. Then, the origin vector and
 * finally the axes vectors are written to the output stream.
 * 
 * @param cs   The Coordinate System to save
 * @param out  The output stream to which to save the Coordinate System
 * @throws     IOException  if an error occurs in with writing to the output stream
 */
public void saveCoordSystem(CoordinateSystem cs, DataOutputStream out) throws IOException {
  if (cs == null) {
    // Indicate the saved value is null
    out.writeByte(0);
    
  } else {
    // Indicate the saved value is non-null
    out.writeByte(1);
    // Save the origin value of the coodinate system
    savePVector(cs.getOrigin(), out);
    // Save the axes vectors of the coordinate system
    saveFloatArray2D(cs.getAxes(), out);
  }
}

/**
 * Attempt to load the data of a Coordinate System object from the given data input
 * stream. It is expected that the input stream contains a single byte (for the byte
 * flag) followed by a PVector object and then finally a 3x3 float array matrix.
 * 
 * @param in   The input stream, from which to read bytes
 * @returning  The Coordinate System pulled from the input stream (which can be null!)
 * @throws     IOException  if an error occurs with reading from the input stream
 */
public CoordinateSystem loadCoordSystem(DataInputStream in) throws IOException {
  // Read the flag byte
  byte flag = in.readByte();
  
  if (flag == 0) {
    return null;
    
  } else {
    // Read the origin PVector and axes vectors
    PVector origin = loadPVector(in);
    float[][] axes = loadFloatArray2D(in);
    
    CoordinateSystem cs = new CoordinateSystem();
    cs.setOrigin(origin);
    cs.setAxes(axes);
    
    return cs;
  }
}

/**
 * Saves all the data associated with the given shape, in the form of bytes,
 * to the given data output stream. First flag byte is saved, which indicates
 * what subclass the object is (or if the object is null). Then the fields
 * associated with the subclass saved followed by the color fields common among
 * all shapes.
 * 
 * @param shape  The shape to save
 * @param out    The output stream, to which to save the given shape
 * @throws       IOException  if an error occurs with writing to the output stream
 */
public void saveShape(Shape shape, DataOutputStream out) throws IOException {
  if (shape == null) {
    // Indicate the saved value is null
    out.writeByte(0);
    
  } else {
    if (shape instanceof Box) {
      // Indicate the saved value is a box
      out.writeByte(1);
    } else if (shape instanceof Cylinder) {
      // Indicate the value saved is a cylinder
      out.writeByte(2);
    } else if (shape instanceof ModelShape) {
      // Indicate the value saved is a complex shape
      out.writeByte(3);
    }
    
    // Write fill color value
    saveInteger(shape.getFillValue(), out);
    
    if (shape instanceof Box) {
      // Write stroke value
      saveInteger(shape.getStrokeValue(), out);
      // Save length, height, and width of the box
      out.writeFloat(shape.getDim(DimType.LENGTH));
      out.writeFloat(shape.getDim(DimType.HEIGHT));
      out.writeFloat(shape.getDim(DimType.WIDTH));
      
    } else if (shape instanceof Cylinder) {
      // Write stroke value
      saveInteger(shape.getStrokeValue(), out);
      // Save the radius and height of the cylinder
      out.writeFloat(shape.getDim(DimType.RADIUS));
      out.writeFloat(shape.getDim(DimType.HEIGHT));
      
    } else if (shape instanceof ModelShape) {
      ModelShape m = (ModelShape)shape;
      
      out.writeFloat(m.getDim(DimType.SCALE));
      // Save the source path of the complex shape
      out.writeUTF(m.getSourcePath()); 
    }
  }
}

/**
 * Attempts to load a Shape from the given data input stream. It is expected that the
 * stream contains a single byte (the flag byte) followed by the fields unique to the
 * subclass of the Shape object saved, which are followed by the color fields of the Shape.
 * 
 * @param in   The input stream, from which to read bytes
 * @returning  The shape object pulled from the input stream (which can be null!)
 * @throws     IOException  if an error occurs with reading from the input stream
 *             NullPointerException  if the shape stored is a model shape and its source
 *             file is either invalid or does not exist
 */
public Shape loadShape(DataInputStream in) throws IOException, NullPointerException {
  // Read flag byte
  byte flag = in.readByte();
  Shape shape = null;
  
  if (flag != 0) {
    // Read fiil color
    Integer fill = loadInteger(in);
          
    if (flag == 1) {
      // Read stroke color
      Integer strokeVal = loadInteger(in);
      float x = in.readFloat(),
            y = in.readFloat(),
            z = in.readFloat();
      // Create a box
      shape = new Box(fill, strokeVal, x, y, z);
      
    } else if (flag == 2) {
      // Read stroke color
      Integer strokeVal = loadInteger(in);
      float radius = in.readFloat(),
            hgt = in.readFloat();
      // Create a cylinder
      shape = new Cylinder(fill, strokeVal, radius, hgt);
      
    } else if (flag == 3) {
      float scale = in.readFloat();
      String srcPath = in.readUTF();
      
      // Creates a complex shape from the srcPath located in RobotRun/data/
      shape = new ModelShape(srcPath, fill, scale);
    }
  }
  
  return shape;
}

/**
 * Writes the integer object to the given data output stream. Null values are accepted.
 */
public void saveInteger(Integer i, DataOutputStream out) throws IOException {
  
  if (i == null) {
    // Write byte flag
    out.writeByte(0);
    
  } else {
    // Write byte flag
    out.writeByte(1);
    // Write integer value
    out.writeInt(i);
  }
}

/**
 * Attempts to read an Integer object from the given data input stream.
 */
public Integer loadInteger(DataInputStream in) throws IOException {
  // Read byte flag
  byte flag = in.readByte();
  
  if (flag == 0) {
    return null;
    
  } else {
    // Read integer value
    return in.readInt();
  }
}

/**
 * Saves the x, y, z fields associated with the given PVector Object to the
 * given output stream. Null values for p are accepted.
 */
public void savePVector(PVector p, DataOutputStream out) throws IOException {
  
  if (p == null) {
    // Write flag byte
    out.writeByte(0);
    
  } else {
    // Write flag byte
    out.writeByte(1);
    // Write vector data
    out.writeFloat(p.x);
    out.writeFloat(p.y);
    out.writeFloat(p.z);
  }
}

/**
 * Attempts to load a PVector object from the given input stream.
 */
public PVector loadPVector(DataInputStream in) throws IOException {
  // Read flag byte
  int val = in.readByte();
  
  if (val == 0) {
    return null;
    
  } else {
    // Read vector data
    PVector v = new PVector();
    v.x = in.readFloat();
    v.y = in.readFloat();
    v.z = in.readFloat();
    return v;
  }
}

/**
 * Saves the list of floats to the given data output stream. A flag byte is stored
 * first, ten the length of list followed by each consecutive value in the list.
 * 
 * @param list  The array of floats to save
 * @param out   The output stream, to which to save the float array
 * @throws      IOException  if an error occurs with writing to the output stream
 */
public void saveFloatArray(float[] list, DataOutputStream out) throws IOException {
  if (list == null) {
    // Write flag value
    out.writeByte(0);
    
  } else {
    // Write flag value
    out.writeByte(1);
    // Write list length
    out.writeInt(list.length);
    // Write each value in the list
    for (int idx = 0; idx < list.length; ++idx) {
      out.writeFloat(list[idx]);
    }
  }
}

/**
 * Attempts to parse a list of floats from the given data input stream.
 * This method expects that a byte flag exists, follwed by a positive
 * integer value for the length of the array, which is followed by at
 * least that number of floating point values.
 * 
 * @param in   The input stream, from which to read bytes
 * @returning  The float array pulled from the input stream (which
 *             can be null!)
 * @throws     IOException  if an error occurs with reading from the
 *             output stream
 */
public float[] loadFloatArray(DataInputStream in) throws IOException {
  // Read byte flag
  byte flag = in.readByte();
  
  if (flag == 0) {
    return null;
    
  } else {
    // Read the length of the list
    int len = in.readInt();
    float[] list = new float[len];
    // Read each value of the list
    for (int idx = 0; idx < list.length; ++idx) {
      list[idx] = in.readFloat();
    }
    
    return list;
  }
}

/**
 * Saves the 2D array of floats to the given data output stream. A flag byte is stored
 * first, ten the dimensions of array followed by each consecutive value in the array.
 * 
 * @param list  The array matrix of floats to save
 * @param out   The output stream, to which to save the float array matrix
 * @throws      IOException  if an error occurs with writing to the output stream
 */
public void saveFloatArray2D(float[][] list, DataOutputStream out) throws IOException {
  if (list == null) {
    // Write flag value
    out.writeByte(0);
    
  } else {
    // Write flag value
    out.writeByte(1);
    // Write the dimensions of the list
    out.writeInt(list.length);
    out.writeInt(list[0].length);
    // Write each value in the list
    for (int row = 0; row < list.length; ++row) {
      for (int col = 0; col < list[0].length; ++col) {
        out.writeFloat(list[row][col]);
      }
    }
  }
}

/**
 * Attempts to parse a 2D array of floats from the given data input stream.
 * This method expects that a byte flag exists, follwed by two positive
 * integer values for the dimensions of the array, which is followed by at
 * least that number of floating point values.
 * 
 * @param in   The data input stream, from which to read bytes
 * @returning  The float array matrix pulled from the input stream
 * @throws     IOException  if an error occurs with reading from the
 *             input stream
 */
public float[][] loadFloatArray2D(DataInputStream in) throws IOException {
  // Read byte flag
  byte flag = in.readByte();
  
  if (flag == 0) {
    return null;
    
  } else {
    // Read the length of the list
    int numOfRows = in.readInt(),
        numOfCols = in.readInt();
    float[][] list = new float[numOfRows][numOfCols];
    // Read each value of the list
    for (int row = 0; row < list.length; ++row) {
      for (int col = 0; col < list[0].length; ++col) {
        list[row][col] = in.readFloat();
      }
    }
    
    return list;
  }
}

/**
 * Writes anything stored in the ArrayList String buffers to tmp\test.out.
 */
public int writeBuffer() {
  try {
    PrintWriter out = new PrintWriter(sketchPath("tmp/test.out"));
    
    for (String line : buffer) {
      out.print(line);
    }
    
    println("Write to buffer successful.");
    out.close();
  } catch(Exception Ex) {
    Ex.printStackTrace();
    return 1;
  }
  
  buffer.clear();
  return 0;
}
private final ArrayList<Scenario> SCENARIOS = new ArrayList<Scenario>();
private Scenario activeScenario;

/**
 * A simple class that defines the stroke and fill color for a shape
 * along with some methods necessarry for a shape.
 */
public abstract class Shape implements Cloneable {
  private Integer fillCVal,
                  strokeCVal;
  
  public Shape() {
    fillCVal = color(0);
    strokeCVal = color(225);
  }
  
  public Shape(Integer fill, Integer strokeVal) {
    fillCVal = fill;
    strokeCVal = strokeVal;
  }
  
  /**
   * Sets the value of the given dimension associated with
   * this shape, if that dimension exists.
   * 
   * @param newVal  The value to which to set the dimension
   * @param dim     The dimension of  which ro set the value
   */
  public abstract void setDim(Float newVal, DimType dim);
  
  /**
   * Returns the value of the given dimension associated with
   * this shape. If no such dimension exists, then -1 should
   * be returned.
   * 
   * @param dim  The dimension of which to get the value
   * @returning  The value of that dimension, or -1, if no
   *             such dimension exists
   */
  public abstract float getDim(DimType dim);
  
  /**
   * Apply stroke and fill colors.
   */
  protected void applyColors() {
    if (strokeCVal == null) {
      noStroke();
      
    } else {
      stroke(strokeCVal);
    }
    
    if (fillCVal == null) {
      noFill();
      
    } else {
      fill(fillCVal);
    } 
  }
  
  public abstract void draw();
  
  /* Getters and Setters for shapes fill and stroke colors */
  
  public Integer getStrokeValue() { return strokeCVal; }
  public void setStrokeValue(Integer newVal) { strokeCVal = newVal; }
  public Integer getFillValue() { return fillCVal; }
  public void setFillValue(Integer newVal) { fillCVal = newVal; }
  
  @Override
  public abstract Object clone();
}

/**
 * Defines the length, width, height values to draw a box.
 */
public class Box extends Shape {
  /**
   * X -> length
   * Y -> Height
   * Z -> Width
   */
  private PVector dimensions;
  
  /**
   * Create a cube, with an edge length of 10.
   */
  public Box() {
    super();
    dimensions = new PVector(10f, 10f, 10f);
  }
  
  /**
   * Create a box with the given colors and dinemsions.
   */
  public Box(int fill, int strokeVal, float len, float hgt, float wdh) {
    super(fill, strokeVal);
    dimensions = new PVector(len, hgt, wdh);
  }
  
  /**
   * Create an empty box with the given color and dinemsions.
   */
  public Box(int strokeVal, float len, float hgt, float wdh) {
    super(null, strokeVal);
    dimensions = new PVector(len, hgt, wdh);
  }
  
  /**
   * Create a cube with the given colors and dinemsion.
   */
  public Box(int fill, int strokeVal, float edgeLen) {
    super(fill, strokeVal);
    dimensions = new PVector(edgeLen, edgeLen, edgeLen);
  }
  
  /**
   * Create an empty cube with the given color and dinemsion.
   */
  public Box(int strokeVal, float edgeLen) {
    super(null, strokeVal);
    dimensions = new PVector(edgeLen, edgeLen, edgeLen);
  }
  
  public void draw() {
    // Apply colors
    applyColors();
    box(dimensions.x, dimensions.y, dimensions.z);
  }
  
  @Override
  public void setDim(Float newVal, DimType dim) {
    
    switch (dim) {
      case LENGTH:
      // Update length
        dimensions.x = newVal;
        break;
      case HEIGHT:
      // Update height
        dimensions.y = newVal;
        break;
        
      case WIDTH:
        // Update width
        dimensions.z = newVal;
        break;
      // Invalid dimension
      default:
    }
  }
  
  @Override
  public float getDim(DimType dim) {    
    switch (dim) {
      case LENGTH:  return dimensions.x;
      case HEIGHT:  return dimensions.y;
      case WIDTH:   return dimensions.z;
      // Invalid dimension
      default:      return -1f;
    }
  }
  
  @Override
  public Object clone() {
    return new Box(getFillValue(), getStrokeValue(), dimensions.x, dimensions.y, dimensions.z);
  }
}

/**
 * Defines the radius and height to draw a uniform cylinder
 */
public class Cylinder extends Shape {
  private float radius, height;
  
  public Cylinder() {
    super();
    radius = 10f;
    height = 10f;
  }
  
  public Cylinder(int fill, int strokeVal, float rad, float hgt) {
    super(fill, strokeVal);
    radius = rad;
    height = hgt;
  }
  
  public Cylinder(int strokeVal, float rad, float hgt) {
    super(null, strokeVal);
    radius = rad;
    height = hgt;
  }
  
  /**
   * Assumes the center of the cylinder is halfway between the top and bottom of of the cylinder.
   * 
   * Based off of the algorithm defined on Vormplus blog at:
   * http://vormplus.be/blog/article/drawing-a-cylinder-with-processing
   */
  public void draw() {
    applyColors();
    
    float halfHeight = height / 2,
          diameter = 2 * radius;
    
    translate(0f, 0f, halfHeight);
    // Draw top of the cylinder
    ellipse(0f, 0f, diameter, diameter);
    translate(0f, 0f, -height);
    // Draw bottom of the cylinder
    ellipse(0f, 0f, diameter, diameter);
    translate(0f, 0f, halfHeight);
    
    beginShape(TRIANGLE_STRIP);
    // Draw a string of triangles around the circumference of the Cylinders top and bottom.
    for (int degree = 0; degree <= 360; ++degree) {
      float pos_x = cos(DEG_TO_RAD * degree) * radius,
            pos_y = sin(DEG_TO_RAD * degree) * radius;
      
      vertex(pos_x, pos_y, halfHeight);
      vertex(pos_x, pos_y, -halfHeight);
    }
    
    endShape();
  }
  
  @Override
  public void setDim(Float newVal, DimType dim) {
    switch(dim) {
      case RADIUS:
      // Update radius
        radius = newVal;
        break;
        
      case HEIGHT:
        // Update height
        height = newVal;
        break;
        
      default:
    }
  }
  
  @Override
  public float getDim(DimType dim) {
    switch(dim) {
      case RADIUS:  return radius;
      case HEIGHT:  return height;
      // Invalid dimension
      default:      return -1f;
    }
  }
  
  @Override
  public Object clone() {
    return new Cylinder(getFillValue(), getStrokeValue(), radius, height);
  }
}

/**
 * A complex shape formed from a .stl source file.
 */
public class ModelShape extends Shape {
  private PShape form;
  private float scale;
  private String srcFilePath;
  
  /**
   * Create a complex model from the soruce .stl file of the
   * given name, filename, stored in the '/RobotRun/data/'
   * with the given fill color.
   * 
   * @throws NullPointerException  if the given filename is
   *         not a valid .stl file in RobotRun/data/
   */
  public ModelShape(String filename, int fill) throws NullPointerException {
    super(fill, null);
    srcFilePath = filename;
    scale = 1f;
    form = loadSTLModel(filename, fill, scale);
  }
  
  /**
   * Create a complex model from the soruce .stl file of the
   * given name, filename, stored in the '/RobotRun/data/'
   * with the given fill color and scale value.
   * 
   * @throws NullPointerException  if the given filename is
   *         not a valid .stl file in RobotRun/data/
   */
  public ModelShape(String filename, int fill, float scale) throws NullPointerException {
    super(fill, null);
    srcFilePath = filename;
    this.scale = scale;
    form = loadSTLModel(filename, fill, scale);
  }
  
  public void draw() {
    shape(form);
  }
  
  @Override
  public void setDim(Float newVal, DimType dim) {
    switch(dim) {
      case SCALE:
        // Update the model's scale
        form.scale(newVal / scale);
        scale = newVal;
        break;
        
      default:
    }
  }
  
  @Override
  public float getDim(DimType dim) {
      switch(dim) {
      case SCALE:  return scale;
      default:     return -1f;
    }
  }
  
  public String getSourcePath() { return srcFilePath; }
  
  @Override
  public Object clone() {
      // Created from source file
      return new ModelShape(srcFilePath, getFillValue(), scale);
  }
}

public class Ray {
  private PVector origin;
  private PVector direction;
  
  public Ray() {
    origin = new PVector(0f, 0f, 0f);
    direction = new PVector(1f, 1f, 1f);
  }
  
  public Ray(PVector origin, PVector pointOnRay) {
    this.origin = origin.copy();
    direction = pointOnRay.sub(origin);
    direction.normalize();
  }
  
  public void draw() {
    stroke(0);
    noFill();
    PVector endpoint = PVector.add(origin, PVector.mult(direction, 5000f));
    line(origin.x, origin.y, origin.z, endpoint.x, endpoint.y, endpoint.z);
  }
}

/**
 * Defines the axes and origin vector associated with a Coordinate System.
 */
public class CoordinateSystem implements Cloneable {
  private PVector origin;
  /* A 3x3 rotation matrix */
  private float[][] axesVectors;
  
  public CoordinateSystem() {
    /* Pull origin and axes from the current transformation matrix */
    origin = getCoordFromMatrix(0f, 0f, 0f);
    axesVectors = getRotationMatrix();
  }
  
  /**
   * Create a coordinate syste with the given origin and 3x3 rotation matrix.
   */
  public CoordinateSystem(PVector origin, float[][] axes) {
    this.origin = origin.copy();
    axesVectors = new float[3][3];
    // Copy axes into axesVectors
    for (int row = 0; row < 3; ++row) {
      for (int col = 0; col < 3; ++col) {
        axesVectors[row][col] = axes[row][col];
      }
    }
  }
  
  /**
   * Apply the coordinate system's origin and axes to the current transformation matrix.
   */
  public void apply() {
    applyMatrix(axesVectors[0][0], axesVectors[1][0], axesVectors[2][0], origin.x,
                axesVectors[0][1], axesVectors[1][1], axesVectors[2][1], origin.y,
                axesVectors[0][2], axesVectors[1][2], axesVectors[2][2], origin.z,
                                0,                 0,                 0,        1);
  }
  
  public void setOrigin(PVector newCenter) {
    origin = newCenter;
  }
  
  public PVector getOrigin() { return origin; }
  
  /**
   * Reset the coordinate system's axes vectors and return the
   * old axes; the given rotation matrix should be in row
   * major order!
   */
  public void setAxes(float[][] newAxes) {
    axesVectors = new float[3][3];
    
    // Copy axes into axesVectors
    for (int row = 0; row < 3; ++row) {
      for (int col = 0; col < 3; ++col) {
        axesVectors[row][col] = newAxes[row][col];
      }
    }
  }
  
  /**
   * Return this coordinate system's axes in row major order.
   */
  public float[][] getAxes() {
    return axesVectors;
  }
  
  @Override
  public Object clone() {
    float[][] axesCopy = new float[3][3];
    
     // Copy axes into axesVectors
    for (int row = 0; row < 3; ++row) {
      for (int col = 0; col < 3; ++col) {
        axesCopy[row][col] = axesVectors[row][col];
      }
    }
    
    return new CoordinateSystem(origin.copy(), axesCopy);
  }
}

/**
 * A box object with its own local Coordinate system.
 */
public class BoundingBox {
  private CoordinateSystem localOrientation;
  /* The origin of the bounding box's local Coordinate System */
  private Box boundingBox;
  
  /**
   * Create a cube object with the given colors and dimension
   */
  public BoundingBox() {
    localOrientation = new CoordinateSystem();
    boundingBox = new Box(color(0, 255, 0), 10f);
  }
  
  /**
   * Create a cube object with the given colors and dimension
   */
  public BoundingBox(float edgeLen) {
    localOrientation = new CoordinateSystem();
    boundingBox = new Box(color(0, 255, 0), edgeLen);
  }
  
  /**
   * Create a box object with the given colors and dimensions
   */
  public BoundingBox(float len, float hgt, float wdh) {
    localOrientation = new CoordinateSystem();
    boundingBox = new Box(color(0, 255, 0), len, hgt, wdh);
  }
  
  /**
   * Apply the Coordinate System of the bounding-box onto the
   * current transformation matrix.
   */
  public void applyCoordinateSystem() {
    localOrientation.apply();
  }
  
  /**
   * Reset the bounding-box's coordinate system to the current
   * transformation matrix.
   */
  public void setCoordinateSystem() {
    localOrientation = new CoordinateSystem();
  }
  
  /**
   * Draw both the object and its bounding box;
   */
  public void draw() {
    pushMatrix();
    // Draw shape in its own coordinate system
    localOrientation.apply();
    boundingBox.draw();
    popMatrix();
  }
  
  /**
   * Reset the object's center point
   */
  public void setCenter(PVector newCenter) {
    localOrientation.setOrigin(newCenter);
  }
  
  public PVector getCenter() { return localOrientation.getOrigin(); }
  
  /**
   * Reset the object's orientation axes; the given rotation
   * matrix should be in row major order!
   */
  public void setOrientationAxes(float[][] newOrientation) {
    localOrientation.setAxes(newOrientation);
  }
  
  public float[][] getOrientationAxes() {
    return localOrientation.getAxes();
  }
  
  /**
   * Sets the stroke color of this ounding-box
   * to the given value.
   */
  public void setColor(int newColor) {
    boundingBox.setStrokeValue(newColor);
  }
  
  /**
   * See Box.setDim()
   */
  public void setDim(Float newVal, DimType dim) {
    boundingBox.setDim(newVal, dim);
  }
  
  /**
   * See Box.getDim()
   */
  public float getDim(DimType dim) {
    return boundingBox.getDim(dim);
  }
  
  /**
   * Sets all the dimension values of the
   * bounding-box, where:
   * X -> length
   * Y -> height
   * Z -> width
   */
  public void setDims(PVector newDims) {
    boundingBox.setDim(newDims.x, DimType.LENGTH);
    boundingBox.setDim(newDims.y, DimType.HEIGHT);
    boundingBox.setDim(newDims.z, DimType.WIDTH);
  }
  
  /**
   * Returns the bounding-box's dimension in the
   * form of a PVector: (length, height, width).
   */
  public PVector getDims() {
    PVector dims = new PVector();
    dims.x = boundingBox.getDim(DimType.LENGTH);
    dims.y = boundingBox.getDim(DimType.HEIGHT);
    dims.z = boundingBox.getDim(DimType.WIDTH);
    return dims;
  }
  
  /**
   * Return a reference to this bounding-box's box.
   */
  public Box getBox() { return boundingBox; }
  
  /**
   * Determine of a single position, in Native Coordinates, is with
   * the bounding box of the this world object.
   */
  public boolean collision(PVector point) {
    // Convert the point to the current reference frame
    float[][] tMatrix = transformationMatrix(localOrientation.getOrigin(), localOrientation.getAxes());
    PVector relPosition = transformVector(point, invertHCMatrix(tMatrix));
    
    PVector OBBDim = getDims();
    // Determine if the point iw within the bounding-box of this object
    boolean is_inside = relPosition.x >= -(OBBDim.x / 2f) && relPosition.x <= (OBBDim.x / 2f)
                     && relPosition.y >= -(OBBDim.y / 2f) && relPosition.y <= (OBBDim.y / 2f)
                     && relPosition.z >= -(OBBDim.z / 2f) && relPosition.z <= (OBBDim.z / 2f);
    
    return is_inside;
  }
  
  /**
   * Return a replicate of this world object's Bounding Box
   */
  public BoundingBox clone() {
    pushMatrix();
    localOrientation.apply();
    PVector dims = getDims();
    BoundingBox copy = new BoundingBox(dims.x, dims.y, dims.z);
    copy.setColor( boundingBox.getStrokeValue() );
    popMatrix();
    
    return copy;
  }
}

/**
 * Any object in the World other than the Robot.
 */
public abstract class WorldObject implements Cloneable {
  private String name;
  private Shape form;
  protected CoordinateSystem localOrientation;
  
  public WorldObject() {
    name = "Object";
    form = new Box();
    localOrientation = new CoordinateSystem();
  }
  
  public WorldObject(String n, Shape f) {
    name = n;
    form = f;
    localOrientation = new CoordinateSystem();
  }
  
  public WorldObject(String n, Shape f, CoordinateSystem cs) {
    name = n;
    form = f;
    localOrientation = cs;
  }
  
  /**
   * Apply the local Coordinate System of the World Object.
   */
  public void applyCoordinateSystem() {
    localOrientation.apply();
  }
  /**
   * Transform the World Object's local Coordinate System to
   * the current transformation matrix.
   */
  public void setCoordinateSystem() {
    localOrientation = new CoordinateSystem();
  }
  
  /**
   * Draw the world object in its local orientation.
   */
  public void draw() {
    pushMatrix();
    // Draw shape in its own coordinate system
    applyCoordinateSystem();
    form.draw();
    popMatrix();
  }
  
  /**
   * Returns a list of values with short prefix labels, which descibe
   * the dimensions of the this world object's shape (except for Model
   * shapes, because their dimensions are unknown).
   * 
   * @returning  A non-null, variable length string array
   */
  public String[] dimFieldsToStringArray() {
    String[] fields;
    
    if (form instanceof Box) {
      fields = new String[3];
      // Add the box's length, height, and width values
      fields[0] = String.format("L: %4.3f", form.getDim(DimType.LENGTH));
      fields[1] = String.format("H: %4.3f", form.getDim(DimType.HEIGHT));
      fields[2] = String.format("W: %4.3f", form.getDim(DimType.WIDTH));
      
    } else if (form instanceof Cylinder) {
      fields = new String[2];
      // Add the cylinder's radius and height values
      fields[0] = String.format("R: %4.3f", form.getDim(DimType.RADIUS));
      fields[1] = String.format("H: %4.3f", form.getDim(DimType.HEIGHT));
      
    } else if (form instanceof ModelShape) {
      
      if (this instanceof Part)  {
        // Use bounding-box dimensions instead
        fields = new String[4];
        PVector dims = ((Part)this).getOBBDims();
        
        fields[0] = String.format("S: %4.3f", form.getDim(DimType.SCALE));
        fields[1] = String.format("L: %4.3f", dims.x);
        fields[2] = String.format("H: %4.3f", dims.y);
        fields[3] = String.format("W: %4.3f", dims.z);
        
      } else if (this instanceof Fixture) {
        fields = new String[1];
        fields[0] = String.format("S: %4.3f", form.getDim(DimType.SCALE));
        
      } else {
        // No dimensios to display
        fields = new String[0];
      }
      
    } else {
      // Invalid shape
      fields = new String[0];
    }
    
    return fields;
  }
  
  // Getter and Setter methods for the World Object's local orientation, name, and form
  
  public void setLocalCenter(PVector newCenter) { localOrientation.setOrigin(newCenter); }
  
  /**
   * Updates all non-null values of the object's center position.
   * If a given value is null, then the origin value remains unchanged.
   * 
   * @param x  The new x value*
   * @param y  The new y value*
   * @param z  The new z value*
   *           *null indicates that the origin value will remain unchanged
   */
  public void updateLocalCenter(Float x, Float y, Float z) {
    PVector center = localOrientation.getOrigin();
    
    if (x != null) {
      // Update x value
      center.x = x;
    }
    if (y != null) {
      // Update y value
      center.y = y;
    }
    if (z != null) {
      // update z value
      center.z = z;
    }
  }
  
  public PVector getLocalCenter() { return localOrientation.getOrigin(); }
  
  public void setLocalOrientationAxes(float[][] newAxes) {
    localOrientation.setAxes(newAxes);
  }
  
  public float[][] getLocalOrientationAxes() {
    return localOrientation.getAxes();
  }
  
  public void setName(String newName) { name = newName; }
  public String getName() { return name; }
  
  public Shape getForm() { return form; }
  
  @Override
  public abstract Object clone();
  public String toString() { return name; }
}

/**
 * A world object whose Coordinate System can be referenced by a Part
 * as its parent Coordinate System.
 */
public class Fixture extends WorldObject {
  
  /**
   * Create a cube object with the given colors and dimension
   */
  public Fixture(String n, int fill, int strokeVal, float edgeLen) {
    super(n, new Box(fill, strokeVal, edgeLen));
  }
  
  /**
   * Create a box object with the given colors and dimensions
   */
  public Fixture(String n, int fill, int strokeVal, float len, float hgt, float wdh) {
    super(n, new Box(fill, strokeVal, len, hgt, wdh));
  }
  
  /**
   * Creates a cylinder object with the given colors and dimensions.
   */
  public Fixture(String n, int fill, int strokeVal, float rad, float hgt) {
    super(n, new Cylinder(fill, strokeVal, rad, hgt));
  }
  
  /**
   * Creates a fixture with the given name and shape.
   */
  public Fixture(String n, ModelShape model) {
    super(n, model);
  }
  
  /**
   * Creates a fixture with the given name and shape, and coordinate system.
   */
  public Fixture(String n, Shape s, CoordinateSystem cs) {
    super(n, s, cs);
  }
  
  /**
   * Applies the inverse of this Fixture's Coordinate System's transformation matrix to the matrix stack.
   */
  public void removeCoordinateSystem() {
    float[][] tMatrix = transformationMatrix(localOrientation.getOrigin(), localOrientation.getAxes());
    tMatrix = invertHCMatrix(tMatrix);
    
    applyMatrix(tMatrix[0][0], tMatrix[1][0], tMatrix[2][0], tMatrix[0][3],
                tMatrix[0][1], tMatrix[1][1], tMatrix[2][1], tMatrix[1][3],
                tMatrix[0][2], tMatrix[1][2], tMatrix[2][2], tMatrix[2][3],
                            0,             0,             0,             1);
  }
  
  @Override
  public Object clone() {
    return new Fixture(getName(), (Shape)getForm().clone(), (CoordinateSystem)localOrientation.clone());
  }
}

/**
 * Defines a world object, which has a shape, a bounding box and a reference to a fixture.
 * The bounding box holds the local coordinate system of the object.
 */
public class Part extends WorldObject {
  private BoundingBox absOBB;
  private Fixture reference;
  
  /**
   * Create a cube object with the given colors and dimension
   */
  public Part(String n, int fill, int strokeVal, float edgeLen) {
    super(n, new Box(fill, strokeVal, edgeLen));
    absOBB = new BoundingBox(edgeLen + 15f);
  }
  
  /**
   * Create a box object with the given colors and dimensions
   */
  public Part(String n, int fill, int strokeVal, float len, float hgt, float wdh) {
    super(n, new Box(fill, strokeVal, len, hgt, wdh));
    absOBB = new BoundingBox(len + 15f, hgt + 15f, wdh + 15f);
  }
  
  /**
   * Creates a cylinder objects with the given colors and dimensions.
   */
  public Part(String n, int fill, int strokeVal, float rad, float hgt) {
    super(n, new Cylinder(fill, strokeVal, rad, hgt));
    absOBB = new BoundingBox(2f * rad + 5f, 2f * rad + 5f, hgt + 10f);
  }
  
  /**
   * Define a complex object as a part with given dimensions for its bounding-box.
   */
  public Part(String n, ModelShape model, float OBBLen, float OBBHgt, float OBBWid) {
    super(n, model);
    absOBB = new BoundingBox(OBBLen, OBBHgt, OBBWid);
  }
  
  /**
   * Creates a Part with the given name, shape, bounding-box dimensions, and fixture reference.
   */
  public Part(String n, Shape s, PVector OBBDims, CoordinateSystem local, Fixture fixRef) {
    super(n, s, local);
    absOBB = new BoundingBox(OBBDims.x, OBBDims.y, OBBDims.z);
    setFixtureRef(fixRef);
  }
  
  @Override
  public void applyCoordinateSystem() {
    absOBB.applyCoordinateSystem();
  }
  
  @Override
  public void setCoordinateSystem() {
    absOBB.setCoordinateSystem();
  }
  
  public void applyLocalCoordinateSystem() {
    super.applyCoordinateSystem();
  }
  
  public void setLocalCoordinateSystem() {
    super.setCoordinateSystem();
  }
  
  /**
   * Draw both the object and its bounding box in its local
   * orientaiton, in the local orientation of the part's
   * fixture reference.
   */
  public void draw() {
    pushMatrix();
    applyCoordinateSystem();
    getForm().draw();
    if (COLLISION_DISPLAY) { absOBB.getBox().draw(); }
    popMatrix();
  }
  
  /**
   * Set the fixture reference of this part and
   * update its absolute orientation.
   */
  public void setFixtureRef(Fixture refFixture) {
    reference = refFixture;
    updateAbsoluteOrientation();
  }
  
  public Fixture getFixtureRef() { return reference; }
  
  /**
   * Update the Part's absolute (or world) orientation
   * based om its local orientation and fixture
   * reference's orientation.
   */
  private void updateAbsoluteOrientation() {
    pushMatrix();
    resetMatrix();
    
    if (reference != null) {
      reference.applyCoordinateSystem();
    }
    
    super.applyCoordinateSystem();
    absOBB.setCoordinateSystem();
    popMatrix();
  }
  
  /**
   * See BoundingBox.setDim()
   */
  public void setOBBDim(Float newVal, DimType dim) {
    absOBB.setDim(newVal, dim);
  }
  
  /**
   * Set the dimensions of this part's bounding box.
   */
  public void setOBBDimenions(PVector newDims) {
    absOBB.setDims(newDims);
  }
  
  /**
   * Get the dimensions of the part's bounding-box
   */
  public PVector getOBBDims() {
    return absOBB.getDims();
  }
  
  /**
   * Return a reference to this object's bounding-box.
   */ 
  private BoundingBox getOBB() { return absOBB; }
  
  /**
   * Sets the stroke color of the world's bounding-box
   * to the given value.
   */
  public void setBBColor(int newColor) {
    absOBB.setColor(newColor);
  }
  
  /**
   * Determine if the given world object is colliding
   * with this world object.
   */
  public boolean collision(Part obj) {
    return collision3D(absOBB, obj.getOBB());
  }
  
  /**
   * Determies if the given bounding box is colliding
   * with this Part's bounding box.
   */
  public boolean collision(BoundingBox obb) {
    return collision3D(absOBB, obb);
  }
  
  /**
   * Determine if the given point is within
   * this object's bounding box.
   */
  public boolean collision(PVector point) {
    return absOBB.collision(point);
  }
  
  @Override
  public void setLocalCenter(PVector newCenter) {
    super.setLocalCenter(newCenter);
    updateAbsoluteOrientation();
  }
  
  @Override
  public void updateLocalCenter(Float x, Float y, Float z) {
    super.updateLocalCenter(x, y, z);
    updateAbsoluteOrientation();
  }
  
  @Override
  public void setLocalOrientationAxes(float[][] newAxes) {
    super.setLocalOrientationAxes(newAxes);
    updateAbsoluteOrientation();
  }
  
  @Override
  public Object clone() {
    // The new object's reference still points to the same fixture!
    return new Part(getName(), (Shape)getForm().clone(), getOBBDims().copy(), (CoordinateSystem)localOrientation.clone(), reference);
  }
}

/**
 * A class used as temporary storage of a Part when it is first loaded from the scenarios file.
 */
public class LoadedPart {
  public Part part;
  public String referenceName;
  
  public LoadedPart(Part p) {
    part = p;
    referenceName = null;
  }
  
  public LoadedPart(Part p, String refName) {
    part = p;
    referenceName = refName;
  }
}

/**
 * A storage class for a collection of objects with an associated name for the collection.
 */
public class Scenario implements Iterable<WorldObject>, Cloneable {
  private String name;
  /**
   * A combine list of Parts and Fixtures
   */
  private final ArrayList<WorldObject> objList;
  
  /**
   * Create a new scenario of the given name.
   */
  public Scenario(String n) {
    name = n;
    objList = new ArrayList<WorldObject>();
  }
  
  /**
   * Only adds the given world objects that are non-null and do
   * not already exist in the scenario.
   * 
   * @param newObjs  The world objects to add to the scenario
   */
  public void addWorldObjects(WorldObject... newObjs) {
    
    for (WorldObject obj : newObjs) {
        addWorldObject(obj);
    }
  }
  
  /**
   * Add the given world object to the scenario. Though, if the name of
   * the given world object does not only contain letter and number
   * characters, then the object is not added to either list.
   * 
   * @param newObject  The object to be added to either the Part or Fixture
   *                   list
   * @returning        Whether the object was added to a list or not
   */
  public boolean addWorldObject(WorldObject newObject) {
    if (newObject == null || objList.contains(newObject)) {
      // Ignore nulls and duplicates
      if (newObject == null) {
        println("New Object is null");
      } else {
        println("New Object is: " + newObject.toString());
      }
      
      return false;
    }
    
    String originName = newObject.getName();
    
    if (originName.length() > 16) {
      // Base name length caps at 16 charcters
      newObject.setName( originName.substring(0, 16) );
      originName = newObject.getName();
    }
    
    if (Pattern.matches("[a-zA-Z0-9]+", originName)) {
    
      if (findObjectWithName(originName, objList) != null) {
        // Keep names unique
        newObject.setName( addSuffixForDuplicateName(originName, objList) );
      }
      
      // TODO add in alphabetical order
      objList.add(newObject);
      return true;
    }
    
    return false;
  }
  
  /**
   * Attempt to remove the given set of world objects from the scenario.
   * 
   * @param tgtObjs  The objects to remove from the scenario
   * @returning      The number of the given objects that were successfully
   *                 removed from the scenario
   */
  public int removeWorldObjects(WorldObject... tgtObjs) {
    int objsRemoved = 0;
    
    for (WorldObject tgt : tgtObjs) {
      int ret = removeWorldObject(tgt);
      // Keep track of the number of given targets that were successfully removed
      if (ret == 0 || ret == 2) {
        ++objsRemoved;
      }
    }
    
    return objsRemoved;
  }
  
  /**
   * Delete the given world object from the correct object
   * list, if it exists in the list.
   * 
   * @returning  0 if the object was removed succesfully,
   *             1 if the object did not exist in the scenario,
   *             2 if the object was a Fixture that was removed
   *                from the scenario and was referenced by at
   *                least one Part in the scenario
   */
  public int removeWorldObject(WorldObject toRemove) {
    if (toRemove == null) {
      return 1;
    }
    
    int ret;
    // Remove a fixture from the list
    boolean removed = objList.remove(toRemove);
    
    ret = (removed) ? 0 : 1;
    
    if (removed && toRemove instanceof Fixture) {
      // Remove the reference from all Part objects associated with this fixture
      for (WorldObject obj : objList) {
        
        if (obj instanceof Part) {
          Part part = (Part)obj;
          
          if (part.getFixtureRef() == toRemove) {
            part.setFixtureRef(null);
            ret = 2;
          }
        }
      }
    }
    
    return ret;
  }
  
  /**
   * Return the world object that corresponds to the given index in
   * the list of world objects contained in this scenario, or null
   * if the index is invalid.
   * 
   * @param idx  A valid index
   * @returning  The world object, at the given index in the list,
   *             or null
   */
  public WorldObject getWorldObject(int idx) {
    if (idx >= 0 && idx < size()) {
      return objList.get(idx);
    }
    
    return null;
  }
  
  /**
   * Return the color of all the object's bounding
   * boxes to normal (green).
   */
  public void resetObjectHitBoxColors() {
    for (WorldObject wldObj : objList) {
      if (wldObj instanceof Part) {
        // Reset all Part bounding-box colors
        ((Part)wldObj).setBBColor(color(0, 255, 0));
      }
    }
  }
  
  /**
   * Updates the collision detection of all the Parts in the scenario,
   * using the given ArmModel to detect collisions between world objects
   * and the armModel, and draws every object.
   */
  public void updateAndDrawObjects(ArmModel model) {
    int numOfObjects = objList.size();
    
    for (int idx = 0; idx < numOfObjects; ++idx) {
      WorldObject wldObj = objList.get(idx);
      
      if (wldObj instanceof Part) {
        Part p = (Part)wldObj;
        
        /* Update the transformation matrix of an object held by the Robotic Arm */
        if(model != null && p == model.held && model.modelInMotion()) {
          pushMatrix();
          resetMatrix();
          
          /***********************************************
             Moving a part with the Robot:
            
             P' = R^-1 x E' x E^-1 x P
             
             where:
             P' - new part local orientation
             R  - part fixture reference orientation
             E' - current Robot end effector orientation
             E  - previous Robot end effector orientation
             P  - current part loval orientation
           ***********************************************/
          
          Fixture refFixture = p.getFixtureRef();
        
          if (refFixture != null) {
            refFixture.removeCoordinateSystem();
          }
          
          applyModelRotation(model.getJointAngles());
          
          float[][] invEETMatrix = invertHCMatrix(armModel.oldEEOrientation);
          applyMatrix(invEETMatrix[0][0], invEETMatrix[1][0], invEETMatrix[2][0], invEETMatrix[0][3],
                      invEETMatrix[0][1], invEETMatrix[1][1], invEETMatrix[2][1], invEETMatrix[1][3],
                      invEETMatrix[0][2], invEETMatrix[1][2], invEETMatrix[2][2], invEETMatrix[2][3],
                                       0,                 0,                   0,                  1);
          
          p.applyCoordinateSystem();
          // Update the world object's position and orientation
          p.setLocalCoordinateSystem();
          p.updateAbsoluteOrientation();
          popMatrix();
        }
        
        /* Collision Detection */
        if(COLLISION_DISPLAY) {
          if( model != null && model.checkObjectCollision(p) ) {
            p.setBBColor(color(255, 0, 0));
          }
          
          // Detect collision with other objects
          for(int cdx = idx + 1; cdx < objList.size(); ++cdx) {
            
            if (objList.get(cdx) instanceof Part) {
              Part p2 = (Part)objList.get(cdx);
              
              if(p.collision(p2)) {
                // Change hit box color to indicate Object collision
                p.setBBColor(color(255, 0, 0));
                p2.setBBColor(color(255, 0, 0));
                break;
              }
            }
          }
          
          if (model != null && p != model.held && model.canPickup(p)) {
            // Change hit box color to indicate End Effector collision
            p.setBBColor(color(0, 0, 255));
          }
        }
        
        if (p == manager.getActiveWorldObject()) {
          p.setBBColor(color(255, 255, 0));
        }
      }
      // Draw the object
      wldObj.draw();
    }
  }
  
  /**
   * Adds a number suffix to the given name, so that the name is unique amonst the names of all the other world
   * objects in the given list. So, if the given name is 'block' and objects with names 'block', 'block1', and
   * 'block2' exist in wldObjList, then the new name will be 'block3'.
   * 
   * @param originName  The origin name of the new world object
   * @param eldObjList  The list of world objects, of wixh to check names
   * @returning         A unique name amongst the names of the existing world objects in the given list, that
   *                    contains the original name as a prefix
   */
  private <T extends WorldObject> String addSuffixForDuplicateName(String originName, ArrayList<T> wldObjList) {
    int nameLen = originName.length();
    ArrayList<Integer> suffixes = new ArrayList<Integer>();
    
    for (T wldObj : wldObjList) {
      String objName = wldObj.getName();
      int objNameLen = objName.length();
      
      if (objNameLen > nameLen) {
        String namePrefix = objName.substring(0, nameLen),
               nameSuffix = objName.substring(nameLen, objNameLen);
        // Find all strings that have the given name as a prefix and an integer value suffix
        if (namePrefix.equals(originName) && Pattern.matches("[0123456789]+", nameSuffix)) {
          int suffix = Integer.parseInt(nameSuffix),
              insertIdx = 0;
          // Store suffixes in increasing order
          while (insertIdx < suffixes.size() && suffix > suffixes.get(insertIdx)) {
            ++insertIdx;
          }
          
          if (insertIdx == suffixes.size()) {
            suffixes.add(suffix);
          } else {
            suffixes.add(insertIdx, suffix);
          }
        }
      }
    }
    // Determine the minimum suffix value
    int suffix = 0;
    
    if (suffixes.size() == 1 && suffixes.get(0) == 0) {
      // If the only stirng with a suffix has a suffix of '0'
      suffix = 1;
      
    } else if (suffixes.size() >= 2) {
      int idx = 0;
      
      while ((idx + 1) < suffixes.size()) {
        // Find the first occurance of a gap between to adjacent suffix values (if any)
        if ((suffixes.get(idx + 1) - suffixes.get(idx)) > 1) {
          break;
        }
        
        ++idx;
      }
      
      suffix = suffixes.get(idx) + 1;
    }
    // Concatenate the origin name with the new suffix
    return String.format("%s%d", originName, suffix);
  }
  
  /**
   * Attempts to find the world object, in the given list, with the given name. If no such object exists,
   * then null is returned, otherwise the object with the given name is returned.
   * 
   * @param tgtName     The name of the world object to find
   * @param wldObjList  The list of world objects to check
   * @returning         The object with the given name, if it exists in the given list, or null.
   */
  private <T extends WorldObject> WorldObject findObjectWithName(String tgtName, ArrayList<T> wldObjList) {
    
    if (tgtName != null && wldObjList != null) {
      
      for (T obj : wldObjList) {
        // Determine if the object exists
        if (obj != null && obj.getName().equals(tgtName)) {
          return obj;
        }
      }
    }
    
    return null;
  }
  
  @Override
  public Iterator<WorldObject> iterator() {
    return objList.iterator();
  }
  
  public int size() { return objList.size(); }
  
  public void setName(String newName) { name = newName; }
  public String getName() { return name; }
  
  @Override
  public Object clone() {
    Scenario copy = new Scenario(name);
    ArrayList<Fixture> fixtures = new ArrayList<Fixture>();
    ArrayList<Part> parts = new ArrayList<Part>();
    
    
    for (WorldObject obj : this) {
      // Add copies of all the objects in this scenario
      WorldObject newObj = (WorldObject)obj.clone();
      copy.addWorldObject(newObj);
      // Keep track of all fixtures and parts with non-null references
      if (newObj instanceof Fixture) {
        fixtures.add( (Fixture)newObj );
        
      } else if (newObj instanceof Part) {
        Part p = (Part)newObj;
        
        if (p.getFixtureRef() != null) {
          parts.add( (Part)newObj );
        }
      }
    }
    
    // Update fixture references of new parts
    for (Part p : parts) {
      String refName = p.getFixtureRef().getName();
      p.setFixtureRef(null);
      
      for (Fixture f : fixtures) {
        if (f.getName().equals( refName )) {
          p.setFixtureRef(f);
        }
      }
    }
    
    return copy;
  }
  
  @Override
  public String toString() { return name; }
}

/**
 * Build a PShape object from the contents of the given .stl source file
 * stored in /RobotRun/data/.
 * 
 * @throws NullPointerException  if hte given filename does not pertain
 *         to a valid .stl file located in RobotRun/data/
 */
public PShape loadSTLModel(String filename, int fill, float scaleVal) throws NullPointerException {
  ArrayList<Triangle> triangles = new ArrayList<Triangle>();
  byte[] data = loadBytes(filename);
  
  int n = 84; // skip header and number of triangles
  
  while(n < data.length) {
    Triangle t = new Triangle();
    for(int m = 0; m < 4; m++) {
      byte[] bytesX = new byte[4];
      bytesX[0] = data[n+3]; bytesX[1] = data[n+2];
      bytesX[2] = data[n+1]; bytesX[3] = data[n];
      n += 4;
      byte[] bytesY = new byte[4];
      bytesY[0] = data[n+3]; bytesY[1] = data[n+2];
      bytesY[2] = data[n+1]; bytesY[3] = data[n];
      n += 4;
      byte[] bytesZ = new byte[4];
      bytesZ[0] = data[n+3]; bytesZ[1] = data[n+2];
      bytesZ[2] = data[n+1]; bytesZ[3] = data[n];
      n += 4;
      t.components[m] = new PVector(
      ByteBuffer.wrap(bytesX).getFloat(),
      ByteBuffer.wrap(bytesY).getFloat(),
      ByteBuffer.wrap(bytesZ).getFloat()
      );
    }
    triangles.add(t);
    n += 2; // skip meaningless "attribute byte count"
  }
  
  PShape mesh = createShape();
  mesh.beginShape(TRIANGLES);
  mesh.noStroke();
  mesh.fill(fill);
  for(Triangle t : triangles) {
    mesh.normal(t.components[0].x, t.components[0].y, t.components[0].z);
    mesh.vertex(t.components[1].x, t.components[1].y, t.components[1].z);
    mesh.vertex(t.components[2].x, t.components[2].y, t.components[2].z);
    mesh.vertex(t.components[3].x, t.components[3].y, t.components[3].z);
  }
  mesh.endShape();
  
  mesh.scale(scaleVal);
  return mesh;
} 

/**
 * This algorithm uses the Separating Axis Theorm to project radi of each Box on to several 
 * axes to determine if a there is any overlap between the boxes. The method strongly resembles 
 * the method outlined in Section 4.4 of "Real Time Collision Detection" by Christer Ericson
 *
 * @param A  The hit box associated with some object in space
 * @param B  The hit box associated with another object in space
 * @return   Whether the two hit boxes intersect
 */
public static boolean collision3D(BoundingBox A, BoundingBox B) {
  // Rows are x, y, z axis vectors for A and B: Ax, Ay, Az, Bx, By, and Bz
  float[][] axes_A = A.getOrientationAxes();
  float[][] axes_B = B.getOrientationAxes();
  
  // Rotation matrices to convert B into A's coordinate system
  float[][] rotMatrix = new float[3][3];
  float[][] absRotMatrix = new float[3][3];
  
  for(int v = 0; v < axes_A.length; v += 1) {
    for(int u = 0; u < axes_B.length; u += 1) {
      // PLEASE do not change to matrix mutliplication
      rotMatrix[v][u] = axes_A[v][0] * axes_B[u][0] +  axes_A[v][1] * axes_B[u][1] +  axes_A[v][2] * axes_B[u][2];
      // Add offset for valeus close to zero (parallel axes)
      absRotMatrix[v][u] = abs(rotMatrix[v][u]) + 0.00000000175f;
    }
  }
  
  // T = B's position - A's
  PVector posA = new PVector().set(A.getCenter());
  PVector posB = new PVector().set(B.getCenter());
  PVector limbo = posB.sub(posA);
  // Convert T into A's coordinate frame
  float[] T = new float[] { limbo.dot(new PVector().set(axes_A[0])), 
    limbo.dot(new PVector().set(axes_A[1])), 
    limbo.dot(new PVector().set(axes_A[2])) };
  
  float radiA, radiB;
  
  for(int idx = 0; idx < absRotMatrix.length; ++idx) {
    
    if (idx == 0) {
      radiA = A.getDim(DimType.LENGTH) / 2f;
    } else if (idx == 1) {
      radiA = A.getDim(DimType.HEIGHT) / 2f;
    } else {
      radiA = A.getDim(DimType.WIDTH) / 2f;
    }
    
    radiB = (B.getDim(DimType.LENGTH) / 2) * absRotMatrix[idx][0] + 
    (B.getDim(DimType.HEIGHT) / 2) * absRotMatrix[idx][1] + 
    (B.getDim(DimType.WIDTH) / 2) * absRotMatrix[idx][2];
    
    // Check Ax, Ay, and Az
    if(abs(T[idx]) > (radiA + radiB)) { return false; }
  }
  
  for(int idx = 0; idx < absRotMatrix[0].length; ++idx) {
    radiA = (A.getDim(DimType.LENGTH) / 2) * absRotMatrix[0][idx] + 
    (A.getDim(DimType.HEIGHT) / 2) * absRotMatrix[1][idx] + 
    (A.getDim(DimType.WIDTH) / 2) * absRotMatrix[2][idx];
    
    if (idx == 0) {
      radiB = B.getDim(DimType.LENGTH) / 2f;
    } else if (idx == 1) {
      radiB = B.getDim(DimType.HEIGHT) / 2f;
    } else {
      radiB = B.getDim(DimType.WIDTH) / 2f;
    }
    
    float check = abs(T[0]*rotMatrix[0][idx] + 
    T[1]*rotMatrix[1][idx] + 
    T[2]*rotMatrix[2][idx]);
    
    // Check Bx, By, and Bz
    if(check > (radiA + radiB)) { return false; }
  }
  
  radiA = (A.getDim(DimType.HEIGHT) / 2) * absRotMatrix[2][0] + (A.getDim(DimType.WIDTH) / 2) * absRotMatrix[1][0];
  radiB = (B.getDim(DimType.HEIGHT) / 2) * absRotMatrix[0][2] + (B.getDim(DimType.WIDTH) / 2) * absRotMatrix[0][1];
  // Check axes Ax x Bx
  if(abs(T[2] * rotMatrix[1][0] - T[1] * rotMatrix[2][0]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(DimType.HEIGHT) / 2) * absRotMatrix[2][1] + (A.getDim(DimType.WIDTH) / 2) * absRotMatrix[1][1];
  radiB = (B.getDim(DimType.LENGTH) / 2) * absRotMatrix[0][2] + (B.getDim(DimType.WIDTH) / 2) * absRotMatrix[0][0];
  // Check axes Ax x By
  if(abs(T[2] * rotMatrix[1][1] - T[1] * rotMatrix[2][1]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(DimType.HEIGHT) / 2) * absRotMatrix[2][2] + (A.getDim(DimType.WIDTH) / 2) * absRotMatrix[1][2];
  radiB = (B.getDim(DimType.LENGTH) / 2) * absRotMatrix[0][1] + (B.getDim(DimType.HEIGHT) / 2) * absRotMatrix[0][0];
  // Check axes Ax x Bz
  if(abs(T[2] * rotMatrix[1][2] - T[1] * rotMatrix[2][2]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(DimType.LENGTH) / 2) * absRotMatrix[2][0] + (A.getDim(DimType.WIDTH) / 2) * absRotMatrix[0][0];
  radiB = (B.getDim(DimType.HEIGHT) / 2) * absRotMatrix[1][2] + (B.getDim(DimType.WIDTH) / 2) * absRotMatrix[1][1];
  // Check axes Ay x Bx
  if(abs(T[0] * rotMatrix[2][0] - T[2] * rotMatrix[0][0]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(DimType.LENGTH) / 2) * absRotMatrix[2][1] + (A.getDim(DimType.WIDTH) / 2) * absRotMatrix[0][1];
  radiB = (B.getDim(DimType.LENGTH) / 2) * absRotMatrix[1][2] + (B.getDim(DimType.WIDTH) / 2) * absRotMatrix[1][0];
  // Check axes Ay x By
  if(abs(T[0] * rotMatrix[2][1] - T[2] * rotMatrix[0][1]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(DimType.LENGTH) / 2) * absRotMatrix[2][2] + (A.getDim(DimType.WIDTH) / 2) * absRotMatrix[0][2];
  radiB = (B.getDim(DimType.LENGTH) / 2) * absRotMatrix[1][1] + (B.getDim(DimType.HEIGHT) / 2) * absRotMatrix[1][0];
  // Check axes Ay x Bz
  if(abs(T[0] * rotMatrix[2][2] - T[2] * rotMatrix[0][2]) > (radiA + radiB)) { return false; }
  
  
  radiA = (A.getDim(DimType.LENGTH) / 2) * absRotMatrix[1][0] + (A.getDim(DimType.HEIGHT) / 2) * absRotMatrix[0][0];
  radiB = (B.getDim(DimType.HEIGHT) / 2) * absRotMatrix[2][2] + (B.getDim(DimType.WIDTH) / 2) * absRotMatrix[2][1];
  // Check axes Az x Bx
  if(abs(T[1] * rotMatrix[0][0] - T[0] * rotMatrix[1][0]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(DimType.LENGTH) / 2) * absRotMatrix[1][1] + (A.getDim(DimType.HEIGHT) / 2) * absRotMatrix[0][1];
  radiB = (B.getDim(DimType.LENGTH) / 2) * absRotMatrix[2][2] + (B.getDim(DimType.WIDTH) / 2) * absRotMatrix[2][0];
  // Check axes Az x By
  if(abs(T[1] * rotMatrix[0][1] - T[0] * rotMatrix[1][1]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(DimType.LENGTH) / 2) * absRotMatrix[1][2] + (A.getDim(DimType.HEIGHT) / 2) * absRotMatrix[0][2];
  radiB = (B.getDim(DimType.LENGTH) / 2) * absRotMatrix[2][1] + (B.getDim(DimType.HEIGHT) / 2) * absRotMatrix[2][0];
  // Check axes Az x Bz
  if(abs(T[1] * rotMatrix[0][2] - T[0] * rotMatrix[1][2]) > (radiA + radiB)) { return false; }
  
  return true;
}
/**
 * A class designed which contains the camera transformation values
 * and the methods to manipulate apply the Camera's transformation.
 */
public class Camera {
  private PVector position,
                  // Rotations in X, Y, Z in radians
                  orientation;
  private static final float MAX_SCALE = 8f;
  private float scale;
  
  /**
   * Creates a camera with the default position, orientation and scale.
   */
  public Camera() {
    position = new PVector(0f, 0f, -500f);
    orientation = new PVector(0f, 0f, 0f);
    scale = 2f;
  }
  
  /**
   * Apply the camer's scale, position, and orientation to the current matrix.
   */
  public void apply() {
    beginCamera();
    // Apply camera translations
    translate(position.x + width / 2f, position.y + height / 2f, position.z);
    
    // Apply camera rotations
    rotateX(orientation.x);
    rotateY(orientation.y);
    
     // Apply camera scaling
    float horizontalMargin = scale * width / 2f,
          verticalMargin = scale * height / 2f,
          near = MAX_SCALE / scale,
          far = scale * 5000f;
    ortho(-horizontalMargin, horizontalMargin, -verticalMargin, verticalMargin, near, far);
    
    endCamera();
  }
  
  /**
   * Return the camera perspective to the
   * default position, orientation and scale.
   */
  public void reset() {
    position.x = 0;
    position.y = 0;
    position.z = -500f;
    orientation.x = 0f;
    orientation.y = 0f;
    orientation.z = 0f;
    scale = 2f;
  }
  
  /**
   * Change the camera's position by the given values.
   */
  public void move(float x, float y, float z) {
    float horzontialLimit = MAX_SCALE * width / 3f,
          verticalLimit = MAX_SCALE * height / 3f;
    
    position.add( new PVector(x, y, z) );
    // Apply camera position restrictions
    position.x = max(-horzontialLimit, min(position.x, horzontialLimit));
    position.y = max(-verticalLimit, min(position.y, verticalLimit));
    position.z = max(-1000f, min(position.z, 1000f));
  }
  
  /**
   * Change the camera's rotation by the given values.
   */
  public void rotate(float w, float p, float r) {
    PVector rotation = new PVector(w, p, r);
    
    orientation.add( rotation );
    // Apply caerma rotation restrictions
    orientation.x = mod2PI(orientation.x);
    orientation.y = mod2PI(orientation.y);
    orientation.z = 0f;//mod2PI(orientation.z);
  }
  
  /**
   * Change the scaling of the camera.
   */
  public void changeScale(float multiplier) {
    scale = max(0.25f, min(scale * multiplier, MAX_SCALE));
  }
  
  /**
   * Returns the Camera's position, orientation, and scale
   * in the form of a formatted String array, where each
   * entry is one of the following values:
   * 
   * Title String
   * X - The camera's x -position value
   * Y - The camera's y-position value
   * Z - The camera's z-position value
   * W - The camera's x-rotation value
   * P - The camera's y-rotation value
   * R - The camera's z-rotation value
   * S - The camera's scale value
   * 
   * @returning  A 6-element String array
   */
  public String[] toStringArray() {
    String[] fields = new String[8];
    // Display rotation in degrees
    PVector inDegrees = PVector.mult(orientation, RAD_TO_DEG);
    
    fields[0] = "Camera Fields";
    fields[1] = String.format("X: %6.9f", position.x);
    fields[2] = String.format("Y: %6.9f", position.y);
    fields[3] = String.format("Z: %6.9f", position.z);
    fields[4] = String.format("W: %6.9f", inDegrees.x);
    fields[5] = String.format("P: %6.9f", inDegrees.y);
    fields[6] = String.format("R: %6.9f", inDegrees.z);
    fields[7] = String.format("S: %3.9f", scale);
    
    return fields;
  }
  
  /**
   * Returns an independent replica of the Camera object.
   */
  public Camera clone() {
    Camera copy = new Camera();
    // Copy position, orientation, and scale
    copy.position = position.copy();
    copy.orientation = orientation.copy();
    copy.scale = scale;
    
    return copy;
  }
  
  // Getters for the Camera's position, orientation, and scale
  public PVector getPosition() { return position; }
  public PVector getOrientation() { return orientation; }
  public float getScale() { return scale; }
}


/**
 * Applies the rotations and translations of the Robot Arm to get to the
 * face plate center, given the set of six joint angles, each corresponding
 * to a joint of the Robot Arm and each within the bounds of [0, TWO_PI).
 * 
 * @param jointAngles  A valid set of six joint angles (in radians) for the Robot
 */
public void applyModelRotation(float[] jointAngles) {
  translate(ROBOT_POSITION.x, ROBOT_POSITION.y, ROBOT_POSITION.z);
  
  translate(-50, -166, -358); // -115, -213, -413
  rotateZ(PI);
  translate(150, 0, 150);
  rotateX(PI);
  rotateY(jointAngles[0]);
  rotateX(-PI);
  translate(-150, 0, -150);
  rotateZ(-PI);    
  translate(-115, -85, 180);
  rotateZ(PI);
  rotateY(PI/2);
  translate(0, 62, 62);
  rotateX(jointAngles[1]);
  translate(0, -62, -62);
  rotateY(-PI/2);
  rotateZ(-PI);   
  translate(0, -500, -50);
  rotateZ(PI);
  rotateY(PI/2);
  translate(0, 75, 75);
  rotateZ(PI);
  rotateX(jointAngles[2]);
  rotateZ(-PI);
  translate(0, -75, -75);
  rotateY(PI/2);
  rotateZ(-PI);
  translate(745, -150, 150);
  rotateZ(PI/2);
  rotateY(PI/2);
  translate(70, 0, 70);
  rotateY(jointAngles[3]);
  translate(-70, 0, -70);
  rotateY(-PI/2);
  rotateZ(-PI/2);    
  translate(-115, 130, -124);
  rotateZ(PI);
  rotateY(-PI/2);
  translate(0, 50, 50);
  rotateX(jointAngles[4]);
  translate(0, -50, -50);
  rotateY(PI/2);
  rotateZ(-PI);    
  translate(150, -10, 95);
  rotateY(-PI/2);
  rotateZ(PI);
  translate(45, 45, 0);
  rotateZ(jointAngles[5]);
}

/**
 * Converts the given point, pt, into the Coordinate System defined by the given origin
 * vector and rotation quaternion axes.
 * 
 * @param pt      A point with initialized position and orientation
 * @param origin  The origin of the Coordinate System
 * @param axes    The axes of the Coordinate System representing as a rotation quanternion
 * @returning     The point, pt, interms of the given frame's Coordinate System
 */
public Point applyFrame(Point pt, PVector origin, float[] axes) {
  PVector position = convertToFrame(pt.position, origin, axes);
  float[] orientation = quaternionRef(pt.orientation, axes);
  
  return new Point(position, orientation, pt.angles);
}

/**
 * Converts the given vector, v, into the Coordinate System defined by the given origin
 * vector and rotation quaternion axes.
 * 
 * @param v      A vector in the XYZ vector space
 * @param origin  The origin of the Coordinate System
 * @param axes    The axes of the Coordinate System representing as a rotation quanternion
 * @returning     The vector, v, interms of the given frame's Coordinate System
 */
public PVector convertToFrame(PVector v, PVector origin, float[] axes) {
  PVector vOffset = PVector.sub(v, origin);
    return rotateVectorQuat(vOffset, axes);
}

/**
 * Converts the given point, pt, from the Coordinate System defined by the given origin
 * vector and rotation quaternion axes.
 * 
 * @param pt      A point with initialized position and orientation
 * @param origin  The origin of the Coordinate System
 * @param axes    The axes of the Coordinate System representing as a rotation quanternion
 * @returning     The point, pt, interms of the given frame's Coordinate System
 */
public Point removeFrame(Point pt, PVector origin, float[] axes) {
  PVector position = convertFromFrame(pt.position, origin, axes);
  float[] orientation = quaternionMult(pt.orientation, axes);
  
  return new Point(position, orientation, pt.angles);
}

/**
 * Converts the given vector, u, from the Coordinate System defined by the given origin
 * vector and rotation quaternion axes.
 * 
 * @param v       A vector in the XYZ vector space
 * @param origin  The origin of the Coordinate System
 * @param axes    The axes of the Coordinate System representing as a rotation quanternion
 * @returning     The vector, u, in the Native frame
 */
public PVector convertFromFrame(PVector u, PVector origin, float[] axes) {
  float[] invAxes = vectorNorm(  quaternionConjugate(axes) );
  PVector vRotated = rotateVectorQuat(u, invAxes);
  return vRotated.add(origin);
}

/**
 * Converts the given vector form the right-hand World Frame Coordinate System
 * to the left-hand Native Coordinate System.
 */
public PVector convertWorldToNative(PVector v) {
  float[][] tMatrix = transformationMatrix(new PVector(0f, 0f, 0f), WORLD_AXES);
  return transformVector(v, invertHCMatrix(tMatrix));
}

/**
 * Converts the given vector form the left-hand Native Coordinate System to the
 * right-hand World Frame Coordinate System.
 */
public PVector convertNativeToWorld(PVector v) {
  float[][] tMatrix = transformationMatrix(new PVector(0f, 0f, 0f), WORLD_AXES);
  return transformVector(v, tMatrix);
}

/* Transforms the given vector from the coordinate system defined by the given
 * transformation matrix (row major order). */
public PVector transformVector(PVector v, float[][] tMatrix) {
  if(tMatrix.length != 4 || tMatrix[0].length != 4) {
    return null;
  }

  PVector u = new PVector();
  // Apply the transformation matrix to the given vector
  u.x = v.x * tMatrix[0][0] + v.y * tMatrix[1][0] + v.z * tMatrix[2][0] + tMatrix[0][3];
  u.y = v.x * tMatrix[0][1] + v.y * tMatrix[1][1] + v.z * tMatrix[2][1] + tMatrix[1][3];
  u.z = v.x * tMatrix[0][2] + v.y * tMatrix[1][2] + v.z * tMatrix[2][2] + tMatrix[2][3];

  return u;
}

/* Transforms the given vector by the given 3x3 rotation matrix (row major order). */
public PVector rotateVector(PVector v, float[][] rotMatrix) {
  if(v == null || rotMatrix == null || rotMatrix.length != 3 || rotMatrix[0].length != 3) {
    return null;
  }
  
  PVector u = new PVector();
  // Apply the rotation matrix to the given vector
  u.x = v.x * rotMatrix[0][0] + v.y * rotMatrix[1][0] + v.z * rotMatrix[2][0];
  u.y = v.x * rotMatrix[0][1] + v.y * rotMatrix[1][1] + v.z * rotMatrix[2][1];
  u.z = v.x * rotMatrix[0][2] + v.y * rotMatrix[1][2] + v.z * rotMatrix[2][2];
  
  return u;
}

/**
 * Find the inverse of the given 4x4 Homogeneous Coordinate Matrix. 
 * 
 * This method is based off of the algorithm found on this webpage:
 *    https://web.archive.org/web/20130806093214/http://www-graphics.stanford.edu/
 *      courses/cs248-98-fall/Final/q4.html
 */
public float[][] invertHCMatrix(float[][] m) {
  if(m.length != 4 || m[0].length != 4) {
    return null;
  }

  float[][] inverse = new float[4][4];

  /* [ ux vx wx tx ] -1       [ ux uy uz -dot(u, t) ]
   * [ uy vy wy ty ]     =    [ vx vy vz -dot(v, t) ]
   * [ uz vz wz tz ]          [ wx wy wz -dot(w, t) ]
   * [  0  0  0  1 ]          [  0  0  0      1     ]
   */
  inverse[0][0] = m[0][0];
  inverse[0][1] = m[1][0];
  inverse[0][2] = m[2][0];
  inverse[0][3] = -(m[0][0] * m[0][3] + m[0][1] * m[1][3] + m[0][2] * m[2][3]);
  inverse[1][0] = m[0][1];
  inverse[1][1] = m[1][1];
  inverse[1][2] = m[2][1];
  inverse[1][3] = -(m[1][0] * m[0][3] + m[1][1] * m[1][3] + m[1][2] * m[2][3]);
  inverse[2][0] = m[0][2];
  inverse[2][1] = m[1][2];
  inverse[2][2] = m[2][2];
  inverse[2][3] = -(m[2][0] * m[0][3] + m[2][1] * m[1][3] + m[2][2] * m[2][3]);
  inverse[3][0] = 0;
  inverse[3][1] = 0;
  inverse[3][2] = 0;
  inverse[3][3] = 1;

  return inverse;
}

/* Returns a 4x4 vector array which reflects the current transform matrix on the top
 * of the stack (ignores scaling values though) */
public float[][] getTransformationMatrix() {
  float[][] transform = new float[4][4];

  // Caculate four vectors corresponding to the four columns of the transform matrix
  PVector origin = getCoordFromMatrix(0, 0, 0);
  PVector xAxis = getCoordFromMatrix(1, 0, 0).sub(origin);
  PVector yAxis = getCoordFromMatrix(0, 1, 0).sub(origin);
  PVector zAxis = getCoordFromMatrix(0, 0, 1).sub(origin);

  // Place the values of each vector in the correct cells of the transform  matrix
  transform[0][0] = xAxis.x;
  transform[0][1] = xAxis.y;
  transform[0][2] = xAxis.z;
  transform[0][3] = origin.x;
  transform[1][0] = yAxis.x;
  transform[1][1] = yAxis.y;
  transform[1][2] = yAxis.z;
  transform[1][3] = origin.y;
  transform[2][0] = zAxis.x;
  transform[2][1] = zAxis.y;
  transform[2][2] = zAxis.z;
  transform[2][3] = origin.z;
  transform[3][0] = 0;
  transform[3][1] = 0;
  transform[3][2] = 0;
  transform[3][3] = 1;

  return transform;
}

/**
 * Forms the 4x4 transformation matrix (row major order) form the given
 * origin offset and axes offset (row major order) of the Native Coordinate
 * system.
 * 
 * @param origin  the X, Y, Z, offset of the origin for the Coordinate frame
 * @param axes    a 3x3 rotatin matrix (row major order) representing the unit
 *                vector axes offset of the new Coordinate Frame from the Native
 *                Coordinate Frame
 * @returning     the 4x4 transformation matrix (column major order) formed from
 *                the given origin and axes offset
 */
public float[][] transformationMatrix(PVector origin, float[][] axes) {
  float[][] transform = new float[4][4];
  
  transform[0][0] = axes[0][0];
  transform[1][0] = axes[1][0];
  transform[2][0] = axes[2][0];
  transform[3][0] = 0;
  transform[0][1] = axes[0][1];
  transform[1][1] = axes[1][1];
  transform[2][1] = axes[2][1];
  transform[3][1] = 0;
  transform[0][2] = axes[0][2];
  transform[1][2] = axes[1][2];
  transform[2][2] = axes[2][2];
  transform[3][2] = 0;
  transform[0][3] = origin.x;
  transform[1][3] = origin.y;
  transform[2][3] = origin.z;
  transform[3][3] = 1;
  
  return transform;
}

/**
 * Returns a 3x3 rotation matrix of the current transformation
 * matrix on the stack (in row major order).
 */
public float[][] getRotationMatrix() {
  float[][] rMatrix = new float[3][3];
  // Calculate origin point
  PVector origin = getCoordFromMatrix(0f, 0f, 0f),
          // Create axes vectors
          vx = getCoordFromMatrix(1f, 0f, 0f).sub(origin),
          vy = getCoordFromMatrix(0f, 1f, 0f).sub(origin),
          vz = getCoordFromMatrix(0f, 0f, 1f).sub(origin);
  // Save values in a 3x3 rotation matrix
  rMatrix[0][0] = vx.x;
  rMatrix[0][1] = vx.y;
  rMatrix[0][2] = vx.z;
  rMatrix[1][0] = vy.x;
  rMatrix[1][1] = vy.y;
  rMatrix[1][2] = vy.z;
  rMatrix[2][0] = vz.x;
  rMatrix[2][1] = vz.y;
  rMatrix[2][2] = vz.z;
  
  return rMatrix;
}

/* This method transforms the given coordinates into a vector
 * in the Processing's native coordinate system. */
public PVector getCoordFromMatrix(float x, float y, float z) {
  PVector vector = new PVector();

  vector.x = modelX(x, y, z);
  vector.y = modelY(x, y, z);
  vector.z = modelZ(x, y, z);

  return vector;
}

/* Calculate v x v */
public float[] crossProduct(float[] v, float[] u) {
  if(v.length != 3 && v.length != u.length) { return null; }
  
  float[] w = new float[v.length];
  // [a, b, c] x [d, e, f] = [ bf - ce, cd - af, ae - bd ]
  w[0] = v[1] * u[2] - v[2] * u[1];
  w[1] = v[2] * u[0] - v[0] * u[2];
  w[2] = v[0] * u[1] - v[1] * u[0];
  
  return w;
}

/* Returns a vector with the opposite sign
 * as the given vector. */
public float[] negate(float[] v) {
  float[] u = new float[v.length];
  
  for(int e = 0; e < v.length; ++e) {
    u[e] = -v[e];
  }
  
  return u;
}

//calculates rotation matrix from euler angles
public float[][] eulerToMatrix(PVector wpr) {
  float[][] r = new float[3][3];
  float xRot = wpr.x;
  float yRot = wpr.y;
  float zRot = wpr.z;
  
  r[0][0] = cos(yRot)*cos(zRot);
  r[0][1] = sin(xRot)*sin(yRot)*cos(zRot) - cos(xRot)*sin(zRot);
  r[0][2] = cos(xRot)*sin(yRot)*cos(zRot) + sin(xRot)*sin(zRot);
  r[1][0] = cos(yRot)*sin(zRot);
  r[1][1] = sin(xRot)*sin(yRot)*sin(zRot) + cos(xRot)*cos(zRot);
  r[1][2] = cos(xRot)*sin(yRot)*sin(zRot) - sin(xRot)*cos(zRot);
  r[2][0] = -sin(yRot);
  r[2][1] = sin(xRot)*cos(yRot);
  r[2][2] = cos(xRot)*cos(yRot);
  
  float[] magnitudes = new float[3];
  
  for(int v = 0; v < r.length; ++v) {
    // Find the magnitude of each axis vector
    for(int e = 0; e < r[0].length; ++e) {
      magnitudes[v] += pow(r[v][e], 2);
    }
    
    magnitudes[v] = sqrt(magnitudes[v]);
    // Normalize each vector
    for(int e = 0; e < r.length; ++e) {
      r[v][e] /= magnitudes[v];
    }
  }
  /**/

  return r;
}

/**
 * Converts the given Euler angle set values to a quaternion
 */
public float[] eulerToQuat(PVector wpr) {
  
  float[] q = new float[4];
  float xRot = wpr.x;
  float yRot = wpr.y;
  float zRot = wpr.z;
  
  q[0] = cos(xRot/2)*cos(yRot/2)*cos(zRot/2) + sin(xRot/2)*sin(yRot/2)*sin(zRot/2);
  q[1] = sin(xRot/2)*cos(yRot/2)*cos(zRot/2) - cos(xRot/2)*sin(yRot/2)*sin(zRot/2);
  q[2] = cos(xRot/2)*sin(yRot/2)*cos(zRot/2) + sin(xRot/2)*cos(yRot/2)*sin(zRot/2);
  q[3] = cos(xRot/2)*cos(yRot/2)*sin(zRot/2) - sin(xRot/2)*sin(yRot/2)*cos(zRot/2);
  
  return q;
}

//calculates euler angles from rotation matrix
public PVector matrixToEuler(float[][] r) {
  float yRot1, yRot2, xRot1, xRot2, zRot1, zRot2;
  PVector wpr, wpr2;

  if(r[2][0] != 1 && r[2][0] != -1) {
    //rotation about y-axis
    yRot1 = -asin(r[2][0]);
    yRot2 = PI - yRot1;
    //rotation about x-axis
    xRot1 = atan2(r[2][1]/cos(yRot1), r[2][2]/cos(yRot1));
    xRot2 = atan2(r[2][1]/cos(yRot2), r[2][2]/cos(yRot2));
    //rotation about z-axis
    zRot1 = atan2(r[1][0]/cos(yRot1), r[0][0]/cos(yRot1));
    zRot2 = atan2(r[1][0]/cos(yRot2), r[0][0]/cos(yRot2));
  } else {
    zRot1 = zRot2 = 0;
    if(r[2][0] == -1) {
      yRot1 = yRot2 = PI/2;
      xRot1 = xRot2 = zRot1 + atan2(r[0][1], r[0][2]);
    } else {
      yRot1 = yRot2 = -PI/2;
      xRot1 = xRot2 = -zRot1 + atan2(-r[0][1], -r[0][2]);
    }
  }

  wpr = new PVector(xRot1, yRot1, zRot1);
  wpr2 = new PVector(xRot2, yRot2, zRot2);

  return wpr;
}

//calculates quaternion from rotation matrix
public float[] matrixToQuat(float[][] r) {
  float[] q = new float[4];
  float tr = r[0][0] + r[1][1] + r[2][2];

  if(tr > 0) {
    float S = sqrt(1.0f + tr) * 2; // S=4*q[0] 
    q[0] = S / 4;
    q[1] = (r[2][1] - r[1][2]) / S;
    q[2] = (r[0][2] - r[2][0]) / S; 
    q[3] = (r[1][0] - r[0][1]) / S;
  } else if((r[0][0] > r[1][1]) & (r[0][0] > r[2][2])) {
    float S = sqrt(1.0f + r[0][0] - r[1][1] - r[2][2]) * 2; // S=4*q[1] 
    q[0] = (r[2][1] - r[1][2]) / S;
    q[1] = S / 4;
    q[2] = (r[0][1] + r[1][0]) / S; 
    q[3] = (r[0][2] + r[2][0]) / S;
  } else if(r[1][1] > r[2][2]) {
    float S = sqrt(1.0f + r[1][1] - r[0][0] - r[2][2]) * 2; // S=4*q[2]
    q[0] = (r[0][2] - r[2][0]) / S;
    q[1] = (r[0][1] + r[1][0]) / S; 
    q[2] = S / 4;
    q[3] = (r[1][2] + r[2][1]) / S;
  } else {
    float S = sqrt(1.0f + r[2][2] - r[0][0] - r[1][1]) * 2; // S=4*q[3]
    q[0] = (r[1][0] - r[0][1]) / S;
    q[1] = (r[0][2] + r[2][0]) / S;
    q[2] = (r[1][2] + r[2][1]) / S;
    q[3] = S / 4;
  }

  return vectorNorm(q);
}

//calculates euler angles from quaternion
public PVector quatToEuler(float[] q) {
  float[][] r = quatToMatrix(q);
  PVector wpr = matrixToEuler(r);
  return wpr;
}

//calculates rotation matrix from quaternion
public float[][] quatToMatrix(float[] q) {
  float[][] r = new float[3][3];
  
  r[0][0] = 1 - 2*(q[2]*q[2] + q[3]*q[3]);
  r[0][1] = 2*(q[1]*q[2] - q[0]*q[3]);
  r[0][2] = 2*(q[0]*q[2] + q[1]*q[3]);
  r[1][0] = 2*(q[1]*q[2] + q[0]*q[3]);
  r[1][1] = 1 - 2*(q[1]*q[1] + q[3]*q[3]);
  r[1][2] = 2*(q[2]*q[3] - q[0]*q[1]);
  r[2][0] = 2*(q[1]*q[3] - q[0]*q[2]);
  r[2][1] = 2*(q[0]*q[1] + q[2]*q[3]);
  r[2][2] = 1 - 2*(q[1]*q[1] + q[2]*q[2]);
  
  float[] magnitudes = new float[3];
  
  for(int v = 0; v < r.length; ++v) {
    // Find the magnitude of each axis vector
    for(int e = 0; e < r[0].length; ++e) {
      magnitudes[v] += pow(r[v][e], 2);
    }
    
    magnitudes[v] = sqrt(magnitudes[v]);
    // Normalize each vector
    for(int e = 0; e < r.length; ++e) {
      r[v][e] /= magnitudes[v];
    }
  }
  /**/
  
  return r;
}

//converts a float array to a double array
public double[][] floatToDouble(float[][] m, int l, int w) {
  double[][] r = new double[l][w];

  for(int i = 0; i < l; i += 1) {
    for(int j = 0; j < w; j += 1) {
      r[i][j] = (double)m[i][j];
    }
  }

  return r;
}

//converts a double array to a float array
public float[][] doubleToFloat(double[][] m, int l, int w) {
  float[][] r = new float[l][w];

  for(int i = 0; i < l; i += 1) {
    for(int j = 0; j < w; j += 1) {
      r[i][j] = (float)m[i][j];
    }
  }

  return r;
}

//calculates the difference between each corresponding pair of
//elements for two vectors of n elements
public float[] calculateVectorDelta(float[] v1, float[] v2, int n) {
  float[] d = new float[n];
  for(int i = 0; i < n; i += 1) {
    d[i] = v1[i] - v2[i];
  }

  return d;
}

//produces a rotation matrix given a rotation 'theta' around
//a given axis
public float[][] rotateAxisVector(float[][] m, float theta, PVector axis) {
  float s = sin(theta);
  float c = cos(theta);
  float t = 1-c;

  if(c > 0.9f)
  t = 2*sin(theta/2)*sin(theta/2);

  float x = axis.x;
  float y = axis.y;
  float z = axis.z;
  
  float[][] r = new float[3][3];

  r[0][0] = x*x*t+c;
  r[0][1] = x*y*t-z*s;
  r[0][2] = x*z*t+y*s;
  r[1][0] = y*x*t+z*s;
  r[1][1] = y*y*t+c;
  r[1][2] = y*z*t-x*s;
  r[2][0] = z*x*t-y*s;
  r[2][1] = z*y*t+x*s;
  r[2][2] = z*z*t+c;
  
  RealMatrix M = new Array2DRowRealMatrix(floatToDouble(m, 3, 3));
  RealMatrix R = new Array2DRowRealMatrix(floatToDouble(r, 3, 3));
  RealMatrix MR = M.multiply(R);

  return doubleToFloat(MR.getData(), 3, 3);
}


/* Calculates the result of a rotation of quaternion 'p'
 * about axis 'u' by 'theta' degrees
 */
public float[] rotateQuat(float[] p, PVector u, float theta) {
  float[] q = new float[4];
  
  q[0] = cos(theta/2);
  q[1] = sin(theta/2)*u.x;
  q[2] = sin(theta/2)*u.y;
  q[3] = sin(theta/2)*u.z;
  
  float[] pq = quaternionMult(p, q);

  return vectorNorm(pq);
}

public PVector rotateVectorQuat(PVector v, PVector u, float theta) {
  float[] q = new float[4];
  float[] p = new float[4];
  float[] q_inv = new float[4];
  float[] p_prime = new float[4];
  
  q[0] = cos(theta/2);
  q[1] = sin(theta/2)*u.x;
  q[2] = sin(theta/2)*u.y;
  q[3] = sin(theta/2)*u.z;
  
  p[0] = 0;
  p[1] = v.x;
  p[2] = v.y;
  p[3] = v.z;
  
  q_inv[0] = q[0];
  q_inv[1] = -q[1];
  q_inv[2] = -q[2];
  q_inv[3] = -q[3];
  
  p_prime = quaternionMult(q, p);
  p_prime = quaternionMult(p_prime, q_inv);

  return new PVector(p_prime[1], p_prime[2], p_prime[3]);
}

/**
 * Rotates the given vector, v, by the given unit quaternion, q.
 * 
 * @param v    A vector in the xyz plane
 * @param q    A unit quaternion that defines a rotation
 * @returning  v rotated by q
 */
public PVector rotateVectorQuat(PVector v, float[] q) {
  float[] p = new float[4];
  float[] q_inv = new float[4];
  float[] p_prime = new float[4];
  // v
  p[0] = 0;
  p[1] = v.x;
  p[2] = v.y;
  p[3] = v.z;
  // q'
  q_inv[0] = q[0];
  q_inv[1] = -q[1];
  q_inv[2] = -q[2];
  q_inv[3] = -q[3];
  // u = q * v * q'
  p_prime = quaternionMult(q, p);
  p_prime = quaternionMult(p_prime, q_inv);
  
  return new PVector(p_prime[1], p_prime[2], p_prime[3]);
}

/* Given 2 quaternions, calculates the quaternion representing the 
 * rotation from 'q1' to 'q2' such that 'qr'*'q1' = 'q2'. Note that 
 * the multiply operation should be taken to mean quaternion
 * multiplication, which is non-commutative.
 */
public float[] calculateQuatOffset(float[] q1, float[] q2) {
  float[] q1_inv = new float[4];
  q1_inv[0] = q1[0];
  q1_inv[1] = -q1[1];
  q1_inv[2] = -q1[2];
  q1_inv[3] = -q1[3];
  
  float[] qr = quaternionMult(q2, q1_inv);
  
  for(int i = 0; i < 4; i += 1) {
    if(qr[i] < 0.00001f)
    qr[i] = 0;
  }
  
  return qr;
}

/**
 * Returns the complex conjugate or inverse of the given quaternion.
 */
public float[] quaternionConjugate(float[] q) {
  return new float[] { q[0], -q[1], -q[2], -q[3] };
}

//returns the result of a quaternion 'q1' multiplied by quaternion 'q2'
public float[] quaternionMult(float[] q1, float[] q2) {
  float[] r = new float[4];
  r[0] = q1[0]*q2[0] - q1[1]*q2[1] - q1[2]*q2[2] - q1[3]*q2[3];
  r[1] = q1[0]*q2[1] + q1[1]*q2[0] + q1[2]*q2[3] - q1[3]*q2[2];
  r[2] = q1[0]*q2[2] - q1[1]*q2[3] + q1[2]*q2[0] + q1[3]*q2[1];
  r[3] = q1[0]*q2[3] + q1[1]*q2[2] - q1[2]*q2[1] + q1[3]*q2[0];

  return r;
}

/**
 * Returns a quaternion, which represents the rotation of q, in terms of reference.
 */
public float[] quaternionRef(float[] q, float[] reference) {
  float[] invRef = vectorNorm( quaternionConjugate(reference) );
  return vectorNorm( quaternionMult(q, invRef) );
}

//returns the result of a vector 'v' multiplied by scalar 's'
public float[] vectorScalarMult(float[] v, float s) {
  float[] ret = new float[v.length];
  for(int i = 0; i < ret.length; i += 1) { 
    ret[i] = v[i]*s; 
  }
  
  return ret;
}

//returns the result of the addition of two vectors, 'v1' and 'v2'
public float[] vectorAdd(float[] v1, float[] v2) {
  //vectors must be of matching length
  if(v1.length != v2.length) return null;
  
  float[] ret = new float[v1.length];
  for(int i = 0; i < ret.length; i += 1) {
    ret[i] = v1[i] + v2[i];
  }
  
  return ret;
}

/**
 * Computes the dot product between the two given quaternions.
 */
public float quaternionDotProduct(float[] q1, float[] q2) {
  float product = 0f;
  
  for (int idx = 0; idx < 4; ++idx) {
    product += q1[idx] * q2[idx];
  }
  
  return product;
}

//returns the magnitude of the input vector 'v'
public float getVectorMag(float[] v) {
  float ret = 0;
  for(int i = 0; i < v.length; i += 1) {
    ret += pow(v[i], 2);
  }
  
  return sqrt(ret);
}

//normalizes input vector 'v' to a unit vector
public float[] vectorNorm(float[] v) {
  float mag = getVectorMag(v);
  return vectorScalarMult(v, 1/mag);
}

/* Given two input quaternions, 'q1' and 'q2', computes the spherical-
 * linear interpolation from 'q1' to 'q2' for a given fraction of the
 * complete transformation 'q1' to 'q2', denoted by 0 <= 'mu' <= 1. 
 */
public float[] quaternionSlerp(float[] q1, float[] q2, float mu) {
  float[] qSlerp = new float[4];
  float[] q3 = new float[4];
  float cOmega = 0;
  
  if(mu == 0) return q1;
  if(mu == 1) return q2;
  
  for(int i = 0; i < 4; i += 1)
  cOmega += q1[i]*q2[i];
  
  if(cOmega < 0) {
    cOmega = -cOmega;
    q3 = vectorScalarMult(q2, -1);
  }
  else {
    q3 = vectorScalarMult(q2, 1);
  }
  
  if(cOmega > 0.99999995f) {
    qSlerp[0] = q1[0]*(1-mu) + q3[0]*mu;
    qSlerp[1] = q1[1]*(1-mu) + q3[1]*mu;
    qSlerp[2] = q1[2]*(1-mu) + q3[2]*mu;
    qSlerp[3] = q1[3]*(1-mu) + q3[3]*mu;
  }
  else {
    float omega = acos(cOmega);
    float scale1 = sin(omega*(1-mu))/sin(omega);
    float scale2 = sin(omega*mu)/sin(omega);
    
    qSlerp[0] = q1[0]*scale1 + q3[0]*scale2;
    qSlerp[1] = q1[1]*scale1 + q3[1]*scale2;
    qSlerp[2] = q1[2]*scale1 + q3[2]*scale2;
    qSlerp[3] = q1[3]*scale1 + q3[3]*scale2;
  }
  
  return vectorNorm(qSlerp);
}

/**
 * Determines if the lies within the range of angles that span from rangeStart to rangeEnd,
 * going clockwise around the Unit Cycle. It is assumed that all parameters are in radians
 * and within the range [0, TWO_PI).
 * 
 * @param angleToVerify  the angle in question
 * @param rangeStart     the 'lower bounds' of the angle range to check
 * @param rangeEnd       the 'upper bounds' of the angle range to check
 */
public boolean angleWithinBounds(float angleToVerify, float rangeStart, float rangeEnd) {
  
  if(rangeStart < rangeEnd) {
    // Joint range does not overlap TWO_PI
    return angleToVerify >= rangeStart && angleToVerify <= rangeEnd;
  } else {
    // Joint range overlaps TWO_PI
    return !(angleToVerify > rangeEnd && angleToVerify < rangeStart);
  }
}

/**
 * Brings the given angle (in radians) within the range: [0, TWO_PI).
 * 
 * @param angle  Some rotation in radians
 * @returning    The equivalent angle within the range [0, TWO_PI)
 */
public float mod2PI(float angle) {
  float temp = angle % TWO_PI;
  
  if (temp < 0f) {
    temp += TWO_PI;
  }
  
  return temp;
}

/**
 * Computes the minimum rotational magnitude to move
 * from src to dest, around the unit circle.
 * 
 * @param src   The source angle in radians
 * @param dset  The destination angle in radians
 * @returning   The minimum distance between src and dest
 */
public float minimumDistance(float src, float dest) {
  // Bring angles within range [0, TWO_PI)
  float difference = mod2PI(dest) - mod2PI(src);
  
  if (difference > PI) {
    difference -= TWO_PI;
  } else if (difference < -PI) {
    difference += TWO_PI;
  }
  
  return difference;
}

public int clamp(int in, int min, int max) {
  return min(max, max(min, in));
}

  
  public void settings() {  size(1080, 720, P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "RobotRun" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
