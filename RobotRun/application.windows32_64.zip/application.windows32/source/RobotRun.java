import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import org.apache.commons.math3.linear.*; 
import java.util.*; 
import java.nio.*; 
import java.nio.file.*; 
import java.io.*; 
import java.awt.event.KeyEvent; 
import java.io.Serializable; 
import java.io.FileInputStream; 
import java.io.FileOutputStream; 
import java.io.IOException; 
import java.util.concurrent.ArrayBlockingQueue; 

import org.apache.commons.math3.ml.neuralnet.*; 
import org.apache.commons.math3.ml.neuralnet.twod.*; 
import org.apache.commons.math3.ml.neuralnet.twod.util.*; 
import org.apache.commons.math3.ml.neuralnet.oned.*; 
import org.apache.commons.math3.ml.neuralnet.sofm.*; 
import org.apache.commons.math3.ml.neuralnet.sofm.util.*; 
import org.apache.commons.math3.ml.clustering.*; 
import org.apache.commons.math3.ml.clustering.evaluation.*; 
import org.apache.commons.math3.ml.distance.*; 
import org.apache.commons.math3.analysis.*; 
import org.apache.commons.math3.analysis.differentiation.*; 
import org.apache.commons.math3.analysis.integration.*; 
import org.apache.commons.math3.analysis.integration.gauss.*; 
import org.apache.commons.math3.analysis.function.*; 
import org.apache.commons.math3.analysis.polynomials.*; 
import org.apache.commons.math3.analysis.solvers.*; 
import org.apache.commons.math3.analysis.interpolation.*; 
import org.apache.commons.math3.stat.interval.*; 
import org.apache.commons.math3.stat.ranking.*; 
import org.apache.commons.math3.stat.clustering.*; 
import org.apache.commons.math3.stat.*; 
import org.apache.commons.math3.stat.inference.*; 
import org.apache.commons.math3.stat.correlation.*; 
import org.apache.commons.math3.stat.descriptive.*; 
import org.apache.commons.math3.stat.descriptive.rank.*; 
import org.apache.commons.math3.stat.descriptive.summary.*; 
import org.apache.commons.math3.stat.descriptive.moment.*; 
import org.apache.commons.math3.stat.regression.*; 
import org.apache.commons.math3.linear.*; 
import org.apache.commons.math3.*; 
import org.apache.commons.math3.distribution.*; 
import org.apache.commons.math3.distribution.fitting.*; 
import org.apache.commons.math3.complex.*; 
import org.apache.commons.math3.ode.*; 
import org.apache.commons.math3.ode.nonstiff.*; 
import org.apache.commons.math3.ode.events.*; 
import org.apache.commons.math3.ode.sampling.*; 
import org.apache.commons.math3.random.*; 
import org.apache.commons.math3.primes.*; 
import org.apache.commons.math3.optim.*; 
import org.apache.commons.math3.optim.linear.*; 
import org.apache.commons.math3.optim.nonlinear.vector.*; 
import org.apache.commons.math3.optim.nonlinear.vector.jacobian.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.gradient.*; 
import org.apache.commons.math3.optim.nonlinear.scalar.noderiv.*; 
import org.apache.commons.math3.optim.univariate.*; 
import org.apache.commons.math3.exception.*; 
import org.apache.commons.math3.exception.util.*; 
import org.apache.commons.math3.fitting.leastsquares.*; 
import org.apache.commons.math3.fitting.*; 
import org.apache.commons.math3.dfp.*; 
import org.apache.commons.math3.fraction.*; 
import org.apache.commons.math3.special.*; 
import org.apache.commons.math3.geometry.*; 
import org.apache.commons.math3.geometry.hull.*; 
import org.apache.commons.math3.geometry.enclosing.*; 
import org.apache.commons.math3.geometry.spherical.twod.*; 
import org.apache.commons.math3.geometry.spherical.oned.*; 
import org.apache.commons.math3.geometry.euclidean.threed.*; 
import org.apache.commons.math3.geometry.euclidean.twod.*; 
import org.apache.commons.math3.geometry.euclidean.twod.hull.*; 
import org.apache.commons.math3.geometry.euclidean.oned.*; 
import org.apache.commons.math3.geometry.partitioning.*; 
import org.apache.commons.math3.geometry.partitioning.utilities.*; 
import org.apache.commons.math3.optimization.*; 
import org.apache.commons.math3.optimization.linear.*; 
import org.apache.commons.math3.optimization.direct.*; 
import org.apache.commons.math3.optimization.fitting.*; 
import org.apache.commons.math3.optimization.univariate.*; 
import org.apache.commons.math3.optimization.general.*; 
import org.apache.commons.math3.util.*; 
import org.apache.commons.math3.genetics.*; 
import org.apache.commons.math3.transform.*; 
import org.apache.commons.math3.filter.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class RobotRun extends PApplet {














final int OFF = 0, ON = 1;

ArmModel armModel;
Model eeModelSuction;
Model eeModelClaw;
Model eeModelClawPincer;

final int ENDEF_NONE = 0, ENDEF_SUCTION = 1, ENDEF_CLAW = 2;

float lastMouseX, lastMouseY;
float cameraTX = 0, cameraTY = 0, cameraTZ = 0;
float cameraRX = 0, cameraRY = 0, cameraRZ = 0;
boolean spacebarDown = false;

ControlP5 cp5;
Textarea textDisplay;
Accordion accordion;

ArrayList<Program> programs = new ArrayList<Program>();

/* global variables for toolbar */

// for pan button
int cursorMode = ARROW;
int clickPan = 0;
float panX = 1.0f; 
float panY = 1.0f;
boolean doPan = false;

// for rotate button
int clickRotate = 0;
float myRotX = 0.0f;
float myRotY = 0.0f;
boolean doRotate = false;

float myscale = 0.5f;

/*******************************/
/* other global variables      */

// for Execution
Program currentProgram;
boolean execSingleInst = false;
MotionInstruction singleInstruction = null;
int currentInstruction;
int EXEC_SUCCESS = 0, EXEC_FAILURE = 1, EXEC_PARTIAL = 2;

/*******************************/

/*******************************/
/*        Shape Stuff          */

// The Y corrdinate of the ground plane
public static final float PLANE_Z = 200.5f;
public Object[] objects;

/*******************************/

// for store or load program state
FileInputStream in = null;
FileOutputStream out = null;

public void setup(){
  
  ortho();
  
  cp5 = new ControlP5(this);
  gui();
  armModel = new ArmModel();
  eeModelSuction = new Model("VACUUM_2.STL", color(40));
  eeModelClaw = new Model("GRIPPER.STL", color(40));
  eeModelClawPincer = new Model("GRIPPER_2.STL", color(200,200,0));
  intermediatePositions = new ArrayList<Point>();
  loadState();
   
  // Intialize world objects
  objects = new Object[2];
  pushMatrix();
  resetMatrix();
  
  translate(-100, 100, -350);
  objects[0] = new Object(125, 60, 300, color(255, 0, 0), color(255, 0, 255));
 
 translate(-250, 0, 0);
  objects[1] = new Object(250, 125, 500, color(255, 0, 255), color(255, 255, 255));
  
  popMatrix();
  
  //createTestProgram();
}

boolean doneMoving = true;

public void draw(){
  ortho();
  
  //lights();
  directionalLight(255, 255, 255, 1, 1, 0);
  ambientLight(150, 150, 150);

  background(127);
  
  //execute arm movement
  if (!doneMoving){
    //run program
    doneMoving = executeProgram(currentProgram, armModel, execSingleInst);
  }
  else{
    //respond to manual movement from J button presses
    intermediatePositions.clear();
    armModel.executeLiveMotion();
  }
  
  pushMatrix();
  resetMatrix();
  applyModelRotation(armModel, true);
  // Keep track of the old coordinate frame of the armModel
  armModel.oldEETMatrix = getTransformationMatrix();
  popMatrix();
  
  hint(ENABLE_DEPTH_TEST);
  background(255);
  noStroke();
  noFill();
  
  pushMatrix();
   
  applyCamera();

  pushMatrix(); 
  armModel.draw();
  popMatrix();
  
  if (COLLISION_DISPLAY) {
    armModel.resetBoxColors();
    armModel.checkSelfCollisions();
  }
  
  handleWorldObjects();
  
  if (COLLISION_DISPLAY) { armModel.drawBoxes(); }
  
  /*float[] q = eulerToQuat(armModel.getWPR());
  println(String.format("q = %4.3f, %4.3f, %4.3f, %4.3f", q[0], q[1], q[2], q[3]));*/
  
  noLights();
  
  //TESTING CODE: DRAW INTERMEDIATE POINTS
  noStroke();
  pushMatrix();
  if(intermediatePositions != null){
    int count = 0;
    for(Point p : intermediatePositions){
      if(count % 8 == 0){
        pushMatrix();
        translate(p.pos.x, p.pos.y, p.pos.z);
        sphere(10);
        popMatrix();
      }
      count += 1;
    }
  }
  popMatrix(); 
  //TESTING CODE: DRAW END EFFECTOR POSITION
  pushMatrix();
  noFill();
  applyModelRotation(armModel, true);
  //EE position
  stroke(255, 255, 0);
  sphere(5);
  translate(0, 0, -100);
  stroke(255, 0, 0);
  //EE x axis
  sphere(6);
  translate(0, 100, 100);
  stroke(0, 255, 0);
  //EE y axis
  sphere(6);
  translate(100, -100, 0);
  stroke(0, 0, 255);
  //EE z axis
  sphere(6);
  popMatrix();
  //END TESTING CODE
  // TESTING CODE: DRAW USER FRAME 0
  /*PVector ufo = convertWorldToNative(userFrames[0].getOrigin());
  
  PVector ufx = new PVector(
      ufo.x-userFrames[0].getAxis(0).x*80,
      ufo.y-userFrames[0].getAxis(0).y*80,
      ufo.z-userFrames[0].getAxis(0).z*80
    );
  PVector ufy = new PVector(
      ufo.x-userFrames[0].getAxis(2).x*80,
      ufo.y-userFrames[0].getAxis(2).y*80,
      ufo.z-userFrames[0].getAxis(2).z*80
    );
  PVector ufz = new PVector(
      ufo.x+userFrames[0].getAxis(1).x*80,
      ufo.y+userFrames[0].getAxis(1).y*80,
      ufo.z+userFrames[0].getAxis(1).z*80
    );
  noFill();
  stroke(255, 0, 0);
  pushMatrix();
  translate(ufo.x, ufo.y, ufo.z);
  sphere(15);
  popMatrix();
  stroke(0, 255, 0);
  pushMatrix();
  translate(ufx.x, ufx.y, ufx.z);
  sphere(15);
  popMatrix();
  stroke(0, 0, 255);
  pushMatrix();
  translate(ufy.x, ufy.y, ufy.z);
  sphere(15);
  popMatrix();
  stroke(255, 255, 0);
  pushMatrix();
  translate(ufz.x, ufz.y, ufz.z);
  sphere(15);
  popMatrix();*/
  // END TESTING CODE
  
  /* Draw a point in space */
  if (ref_point != null) {
    pushMatrix();
    translate(ref_point.x, ref_point.y, ref_point.z);
    
    noFill();
    stroke(0, 150, 200);
    sphere(5);
    
    popMatrix();
  }
  
  /*stroke(255, 0, 0);
  // Draw x origin line
  line( -5000, PLANE_Z, 0, 5000, PLANE_Z, 0 );
  // Draw y origin line
  line( 0, PLANE_Z, 5000, 0, PLANE_Z, -5000 );
  
  // Draw grid lines every 100 units, from -5000 to 5000, in the x and y plane, on the floor plane
  stroke(25, 25, 25);
  for (int l = 1; l < 50; ++l) {
    line(100 * l, PLANE_Z, -5000, 100 * l, PLANE_Z, 5000);
    line(-5000, PLANE_Z, 100 * l, 5000, PLANE_Z, 100 * l);
    
    line(-100 * l, PLANE_Z, -5000, -100 * l, PLANE_Z, 5000);
    line(-5000, PLANE_Z, -100 * l, 5000, PLANE_Z, -100 * l);
  }
  
  drawEndEffectorGridMapping();*/
  displayFrameAxes();
  displayTeachPoints();
  
  popMatrix();
  
  hint(DISABLE_DEPTH_TEST);
  
  showMainDisplayText();
  //println(frameRate + " fps");
}

public void applyCamera() {
  translate(width/1.5f,height/1.5f);
  translate(panX, panY); // for pan button
  scale(myscale);
  rotateX(myRotX); // for rotate button
  rotateY(myRotY); // for rotate button
}

/**
 * Handles the drawing of world objects as well as collision detection of world objects and the
 * Robot Arm model.
 */
public void handleWorldObjects() {
  for (Object o : objects) {
    // reset all world the object's hit box colors
    o.hit_box.outline = color(0, 255, 0);
  }
  
  for (int idx = 0; idx < objects.length; ++idx) {
    
    /* Update the transformation matrix of an object held by the Robotic Arm */
    if (objects[idx] == armModel.held && armModel.modelInMotion()) {
      pushMatrix();
      resetMatrix();
      
      // new object transform = EE transform x (old EE transform) ^ -1 x current object transform
      
      applyModelRotation(armModel, true);
      
      float[][] invEETMatrix = invertHCMatrix(armModel.oldEETMatrix);
      applyMatrix(invEETMatrix[0][0], invEETMatrix[0][1], invEETMatrix[0][2], invEETMatrix[0][3],
                  invEETMatrix[1][0], invEETMatrix[1][1], invEETMatrix[1][2], invEETMatrix[1][3],
                  invEETMatrix[2][0], invEETMatrix[2][1], invEETMatrix[2][2], invEETMatrix[2][3],
                  invEETMatrix[3][0], invEETMatrix[3][1], invEETMatrix[3][2], invEETMatrix[3][3]);
      
      armModel.held.form.applyTransform();
       
      float[][] newObjTMatrix = getTransformationMatrix();
      armModel.held.form.setTransform(newObjTMatrix);
      armModel.held.hit_box.setTransform(newObjTMatrix);
      
      popMatrix();
    }
    
    /* Collision Detection */
    if (COLLISION_DISPLAY) {
      if ( armModel.checkObjectCollision(objects[idx]) ) {
        objects[idx].hit_box.outline = color(255, 0, 0);
      }
        
      // Detect collision with other objects
      for (int cdx = idx + 1; cdx < objects.length; ++cdx) {
        
        if (objects[idx].collision(objects[cdx])) {
          // Change hit box color to indicate Object collision
          objects[idx].hit_box.outline = color(255, 0, 0);
          objects[cdx].hit_box.outline = color(255, 0, 0);
          break;
        }
      }
      
      if ( objects[idx] != armModel.held && objects[idx].collision(armModel.getEEPos()) ) {
        // Change hit box color to indicate End Effector collision
        objects[idx].hit_box.outline = color(0, 0, 255);
      }
    }
    
    // Draw world object
    objects[idx].draw();
  }
}

/**
 * Display any currently taught points during the processes of either the 3-Point, 4-Point, or 6-Point Methods.
 */
public void displayTeachPoints() {
  // Teach points are displayed only while the Robot is being taught a frame
  if (teachPointTMatrices != null && (mode == THREE_POINT_MODE || mode == FOUR_POINT_MODE || mode == SIX_POINT_MODE)) {
    
    int[] pt_colors = new int[teachPointTMatrices.size()];
    
    // First point
    if (teachPointTMatrices.size() >= 1) {
      if ((super_mode == NAV_TOOL_FRAMES && mode == THREE_POINT_MODE) || mode == SIX_POINT_MODE) {
        pt_colors[0] = color(130, 130, 130);
      } else {
        pt_colors[0] = color(255, 130, 0);
      }
      // Second point
      if (teachPointTMatrices.size() >= 2) {
        if ((super_mode == NAV_TOOL_FRAMES && mode == THREE_POINT_MODE) || mode == SIX_POINT_MODE) {
          pt_colors[1] = color(130, 130, 130);
        } else {
          pt_colors[1] = color(125, 0, 0);
        }
        // Thrid point
        if (teachPointTMatrices.size() >= 3) {
          if ((super_mode == NAV_TOOL_FRAMES && mode == THREE_POINT_MODE) || mode == SIX_POINT_MODE) {
            pt_colors[2] = color(130, 130, 130);
          } else {
            pt_colors[2] = color(0, 125, 0);
          }
          // Fourth point
          if (teachPointTMatrices.size() >= 4) {
            if (mode == SIX_POINT_MODE) {
              pt_colors[3] = color(255, 130, 0);
            } else {
              pt_colors[3] = color(0, 0, 125);
            }
            // Fifth point
            if (teachPointTMatrices.size() >= 5) {
              pt_colors[4] = color(125, 0, 0);
              // Sixth point
              if (teachPointTMatrices.size() == 6) {
                pt_colors[5] = color(0, 125, 0);
              }
            }
          }
        }
      }
    }
    
    // Display points in the teaching point set
    for (int idx = 0; idx < teachPointTMatrices.size(); ++idx) {
      float[][] T = teachPointTMatrices.get(idx);
      
      pushMatrix();
      // Applies the points transformation matrix
      applyMatrix(T[0][0], T[0][1], T[0][2], T[0][3],
                  T[1][0], T[1][1], T[1][2], T[1][3],
                  T[2][0], T[2][1], T[2][2], T[2][3],
                  T[3][0], T[3][1], T[3][2], T[3][3]);
      
      // Draw color-coded spheres for each point
      noFill();
      stroke(pt_colors[idx]);
      sphere(3);
      
      popMatrix();
    }
  }
}

/**
* Displays the current axes and the origin of the current frame of reference.
*/
public void displayFrameAxes() {
  
   if ((curCoordFrame == COORD_WORLD || curCoordFrame == COORD_TOOL) && activeToolFrame != -1) {
     /* Draw the axes of the active tool frame */
     displayOriginAxes(toolFrames[activeToolFrame].getWorldAxes(), toVectorArray( armModel.getEEPos() ));
   } else if (curCoordFrame == COORD_USER && activeUserFrame != -1) {
     /* Draw the axes of the active user frame */
     displayOriginAxes(userFrames[activeUserFrame].getWorldAxes(), toVectorArray( userFrames[activeUserFrame].getOrigin() ));
   } else if (curCoordFrame == COORD_WORLD) {
     /* Draw World Frame coordinate system */
     displayOriginAxes(new float[][] { {-1f, 0f, 0f}, {0f, 0f, 1f}, {0f, -1f, 0f} }, new float[] {0f, 0f, 0f});
   }
}

/**
 * Given a set of 3 orthogonal unit vectors a point in space, lines are
 * drawn for each of the three vectors, which intersect at the origin point.
 *
 * @param axesVectors  A set of three orthogonal unti vectors
 * @param origin       A point in space representing the intersection of the
 *                     three unit vectors
 */
public void displayOriginAxes(float[][] axesVectors, float[] origin) {
    
    pushMatrix();
    // Transform to the reference frame defined by the axes vectors
    applyMatrix(axesVectors[0][0], axesVectors[1][0], axesVectors[2][0], origin[0],
                axesVectors[0][1], axesVectors[1][1], axesVectors[2][1],  origin[1],
                axesVectors[0][2], axesVectors[1][2], axesVectors[2][2],  origin[2],
                0, 0, 0, 1);
    // X axis
    stroke(255, 0, 0);
    line(-5000, 0, 0, 5000, 0, 0);
    // Y axis
    stroke(0, 255, 0);
    line(0, -5000, 0, 0, 5000, 0);
    // Z axis
    stroke(0, 0, 255);
    line(0, 0, -5000, 0, 0, 5000);
    
    // Draw a sphere on the positive direction fo each axis
    stroke(0);
    translate(50, 0, 0);
    sphere(4);
    translate(-50, 50, 0);
    sphere(4);
    translate(0, -50, 50);
    sphere(4);
    
    popMatrix();
}
ArrayList<Point> intermediatePositions;
int motionFrameCounter = 0;
float distanceBetweenPoints = 5.0f;
int interMotionIdx = -1;

final int COORD_JOINT = 0, COORD_WORLD = 1, COORD_TOOL = 2, COORD_USER = 3;
int curCoordFrame = COORD_JOINT;
float liveSpeed = 0.1f;
boolean executingInstruction = false;

int errorCounter;
String errorText;
public static final boolean COLLISION_DISPLAY = false;

/**
 * Creates some programs for testing purposes.
 */
public void createTestProgram() {
  Program program = new Program("Test Program");
  MotionInstruction instruction =
    new MotionInstruction(MTYPE_LINEAR, 0, true, 800, 1.0f); //1.0
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_CIRCULAR, 1, true, 1600, 0.75f); //0.75
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_LINEAR, 2, true, 400, 0.5f); //0.5
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_JOINT, 3, true, 1.0f, 0);
  program.addInstruction(instruction);
  instruction = new MotionInstruction(MTYPE_JOINT, 4, true, 1.0f, 0);
  program.addInstruction(instruction);
  //for (int n = 0; n < 15; n++) program.addInstruction(
  //  new MotionInstruction(MTYPE_JOINT, 1, true, 0.5, 0));
  
  POS_REG[0] = new PositionRegister(null, new Point(165, 116, -5, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0));
  POS_REG[1] = new PositionRegister(null, new Point(166, -355, 120, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0));
  POS_REG[2] = new PositionRegister(null, new Point(171, -113, 445, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0));
  POS_REG[3] = new PositionRegister(null, new Point(725, 225, 50, 1, 0, 0, 0, 5.6f, 1.12f, 5.46f, 0, 5.6f, 0));
  POS_REG[4] = new PositionRegister(null, new Point(775, 300, 50, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0));
  POS_REG[5] = new PositionRegister(null, new Point(-474, -218, 37, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0));
  POS_REG[6] = new PositionRegister(null, new Point(-659, -412, -454, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0));
  
  programs.add(program);
  //currentProgram = program;
  
  Program program2 = new Program("Test Program 2");
  MotionInstruction instruction2 =
    new MotionInstruction(MTYPE_JOINT, 3, true, 1.0f, 0);
  program2.addInstruction(instruction2);
  instruction2 = new MotionInstruction(MTYPE_JOINT, 4, true, 1.0f, 0);
  program2.addInstruction(instruction2);
  programs.add(program2);
  currentProgram = program2;
  
  Program program3 = new Program("Circular Test");
  MotionInstruction instruction3 =
    new MotionInstruction(MTYPE_LINEAR, 0, true, 1.0f, 0);
  program3.addInstruction(instruction3);
  instruction3 = new MotionInstruction(MTYPE_CIRCULAR, 1, true, 1.0f, 0);
  program3.addInstruction(instruction3);
  instruction3 = new MotionInstruction(MTYPE_LINEAR, 2, true, 1.0f, 0);
  program3.addInstruction(instruction3);
  instruction3 = new MotionInstruction(MTYPE_LINEAR, 3, true, 0.25f, 0);
  program3.addInstruction(instruction3);
  programs.add(program3);
  //currentProgram = program3;
  
  Program program4 = new Program("New Arm Test");
  MotionInstruction instruction4 =
    new MotionInstruction(MTYPE_LINEAR, 5, true, 1.0f, 0);
  program4.addInstruction(instruction4);
  instruction4 = new MotionInstruction(MTYPE_LINEAR, 6, true, 1.0f, 0);
  program4.addInstruction(instruction4);
  programs.add(program4);
  currentProgram = program4;
  
  for (int n = 0; n < 22; n++) {
     programs.add(new Program("Xtra" + Integer.toString(n)));
     
  }
  saveState();
} // end createTestProgram()


/**
 * Displays important information in the upper-right corner of the screen.
 */
public void showMainDisplayText() {
  fill(0);
  textAlign(RIGHT, TOP);
  String coordFrame = "CoordinateFrame: ";
  
  switch(curCoordFrame) {
    case COORD_JOINT:
      coordFrame += "Joint";
      break;
    case COORD_WORLD:
      coordFrame += "World";
      break;
    case COORD_TOOL:
      coordFrame += "Tool";
      break;
    case COORD_USER:
      coordFrame += "User";
  }
  
  text(coordFrame, width-20, 20);
  text("Speed: " + (Integer.toString((int)(Math.round(liveSpeed*100)))) + "%", width-20, 40);
  
  // Display the Current position and orientation of the Robot in the World Frame
  PVector ee_pos = armModel.getEEPos();
  //ee_pos = convertNativeToWorld(ee_pos);
  PVector wpr = armModel.getWPR();
  String dis_world = String.format("Coord  X: %8.4f  Y: %8.4f  Z: %8.4f  W: %8.4f  P: %8.4f  R: %8.4f", 
                     ee_pos.x, ee_pos.y, ee_pos.z, wpr.x*RAD_TO_DEG, wpr.y*RAD_TO_DEG, wpr.z*RAD_TO_DEG);
  
  // Display the Robot's joint angles
  float j[] = armModel.getJointRotations();
  String dis_joint = String.format("Joints  J1: %5.4f J2: %5.4f J3: %5.4f J4: %5.4f J5: %5.4f J6: %5.4f", 
                     j[0], j[1], j[2], j[3], j[4], j[5]);
  
  // Display the distance between the End Effector and the Based of the Robot
  float dist_base = PVector.dist(ee_pos, base_center);
  String dis_dist = String.format("Distance from EE to Robot Base: %f", dist_base);
  
  // Show the coordinates of the End Effector for the current Coordinate Frame
  if (curCoordFrame == COORD_JOINT) {          
    text(dis_joint, width - 20, 60);
    
    if (DISPLAY_TEST_OUTPUT) {
      text(dis_dist, width - 20, 80);
      text(dis_world, width - 20, 100);
    }
  } else {
    text(dis_world, width - 20, 60);
    
    if (DISPLAY_TEST_OUTPUT) {
      text(dis_dist, width - 20, 80);
      text(dis_joint, width - 20, 100);
    }
  }
  
  // Display a message while the robot is carrying an object
  if (armModel.held != null) {
    fill(200, 0, 0);
    text("Object held", width - 20, 120);
  }
  
  textAlign(LEFT);
  
  // Display message for camera pan-lock mode
  if (clickPan % 2 == 1) {
    textSize(14);
    fill(215, 0, 0);
    text("Press space on the keyboard to disable camera paning", 20, height / 2 + 30);
  }
  // Display message for camera rotation-lock mode
  if (clickRotate % 2 == 1) {
    textSize(14);
    fill(215, 0, 0);
    text("Press shift on the keyboard to disable camera rotation", 20, height / 2 + 55);
  }
  
  if (DISPLAY_TEST_OUTPUT) {
    textSize(12);
    fill(0, 0, 0);
    
    float[][] vectorMatrix = armModel.getRotationMatrix(armModel.currentFrame);
    String row = String.format("[  %f  %f  %f  ]", vectorMatrix[0][0], vectorMatrix[0][1], vectorMatrix[0][2]);
    text(row, 20, height / 2 + 80);
    row = String.format("[  %f  %f  %f  ]", vectorMatrix[1][0], vectorMatrix[1][1], vectorMatrix[1][2]);
    text(row, 20, height / 2 + 94);
    row = String.format("[  %f  %f  %f  ]", vectorMatrix[2][0], vectorMatrix[2][1], vectorMatrix[2][2]);
    text(row, 20, height / 2 + 108);
  }
  
  float[] q = armModel.getQuaternion();
  String quat = String.format("q: [%8.6f, %8.6f, %8.6f, %8.6f]", q[0], q[1], q[2], q[3]);
  text(quat, 20, height/2 + 148);
  
  if (ref_point != null) {
    String obj1_c = String.format("Ref Point: [%f, %f Z, %f]", ref_point.x, ref_point.y, ref_point.z);
    text(obj1_c, 20, height / 2 + 168);
  }
  textAlign(RIGHT);
  
  if (errorCounter > 0) {
    errorCounter--;
    fill(255, 0, 0);
    text(errorText, width-20, 100);
  }
}

/* Updates the curCoordFrame variable based on the current value of curCoordFrame, activeToolFrame,
 * activeUserFrame, and the current End Effector. If the new coordinate frame is user or tool and
 * no current tool or user frames are active, then the next coordinate frame is selected instead.
 *
 * @param model  The Robot Arm, for which to switch coordinate frames
 */
public void updateCoordinateMode(ArmModel model) {
  // Increment the current coordinate frame
  curCoordFrame = (curCoordFrame + 1) % 4;
  
  // Skip the tool frame, if there is no current active tool frame
  if (curCoordFrame == COORD_TOOL && !((activeToolFrame >= 0 && activeToolFrame < toolFrames.length)
                                  || model.activeEndEffector == ENDEF_SUCTION
                                  || model.activeEndEffector == ENDEF_CLAW)) {
    curCoordFrame = COORD_USER;
  }
  
  // Skip the user frame, if there is no current active user frame
  if (curCoordFrame == COORD_USER && !(activeUserFrame >= 0 && activeUserFrame < userFrames.length)) {
    curCoordFrame = COORD_JOINT;
  }
    
  // Update the Arm Model's rotation matrix for rotational motion based on the current frame
  if (curCoordFrame == COORD_TOOL || (curCoordFrame == COORD_WORLD && activeToolFrame != -1)) {
    // Active Tool Frames are used in the World Frame as well
    armModel.currentFrame = toolFrames[activeToolFrame].getNativeAxes();
  } else if (curCoordFrame == COORD_USER) {
    
    armModel.currentFrame = userFrames[activeUserFrame].getNativeAxes();
  } else {
    // Reset to the identity matrix
    armModel.currentFrame = new float[3][3];
    
    for (int diag = 0; diag < 3; ++diag) {
      armModel.currentFrame[diag][diag] = 1;
    }
  }
}

/**
 * Converts from RobotRun-defined world coordinates into
 * Processing's coordinate system.
 * Assumes that the robot starts out facing toward the LEFT.
 */
public PVector convertWorldToNative(PVector in) {
  pushMatrix();
  resetMatrix();
  float outx = modelX(0,0,0)-in.x;
  float outy = modelY(0,0,0)-in.z;
  float outz = -(modelZ(0,0,0)-in.y);
  popMatrix();
  
  return new PVector(outx, outy, outz);
}

/**
 * Converts from Processing's native coordinate system to
 * RobotRun-defined world coordinates.
 */
public PVector convertNativeToWorld(PVector in) {
  pushMatrix();
  resetMatrix();
  float outx = modelX(0,0,0)-in.x;
  float outy = in.z+modelZ(0,0,0);
  float outz = modelY(0,0,0)-in.y;
  popMatrix();
  
  return new PVector(outx, outy, outz);
}

/**
 * Takes a vector and a (probably not quite orthogonal) second vector
 * and computes a vector that's truly orthogonal to the first one and
 * pointing in the direction closest to the imperfect second vector
 * @param in First vector
 * @param second Second vector
 * @return A vector perpendicular to the first one and on the same side
 *         from first as the second one.
 */
public PVector computePerpendicular(PVector in, PVector second) {
  PVector[] plane = createPlaneFrom3Points(in, second, new PVector(in.x*2, in.y*2, in.z*2));
  PVector v1 = vectorConvertTo(in, plane[0], plane[1], plane[2]);
  PVector v2 = vectorConvertTo(second, plane[0], plane[1], plane[2]);
  PVector perp1 = new PVector(v1.y, -v1.x, v1.z);
  PVector perp2 = new PVector(-v1.y, v1.x, v1.z);
  PVector orig = new PVector(v2.x*5, v2.y*5, v2.z);
  PVector p1 = new PVector(perp1.x*5, perp1.y*5, perp1.z);
  PVector p2 = new PVector(perp2.x*5, perp2.y*5, perp2.z);
  if (dist(orig.x, orig.y, orig.z, p1.x, p1.y, p1.z) <
      dist(orig.x, orig.y, orig.z, p2.x, p2.y, p2.z))
    return vectorConvertFrom(perp1, plane[0], plane[1], plane[2]);
  else return vectorConvertFrom(perp2, plane[0], plane[1], plane[2]);
}

/**
 * This method will draw the End Effector grid mapping based on the value of EE_MAPPING:
 *
 *  0 -> a line is drawn between the EE and the grid plane
 *  1 -> a point is drawn on the grid plane that corresponds to the EE's xz coordinates
 *  For any other value, nothing is drawn
 */
public void drawEndEffectorGridMapping() {
  
  PVector ee_pos = armModel.getEEPos();
  
  // Change color of the EE mapping based on if it lies below or above the ground plane
  int c = (ee_pos.y <= PLANE_Z) ? color(255, 0, 0) : color(150, 0, 255);
  
  // Toggle EE mapping type with 'e'
  switch (EE_MAPPING) {
    case 0:
      stroke(c);
      // Draw a line, from the EE to the grid in the xy plane, parallel to the z plane
      line(ee_pos.x, ee_pos.y, ee_pos.z, ee_pos.x, PLANE_Z, ee_pos.z);
      break;
    
    case 1:
      noStroke();
      fill(c);
      // Draw a point, which maps the EE's position to the grid in the xy plane
      pushMatrix();
      rotateX(PI / 2);
      translate(0, 0, -PLANE_Z);
      ellipse(ee_pos.x, ee_pos.z, 10, 10);
      popMatrix();
      break;
      
    default:
      // No EE grid mapping
  }
}



/**
 * Performs rotations and translations to reach the end effector
 * position, similarly to calculateEndEffectorPosition(), but
 * this function doesn't return anything and also doesn't pop
 * the matrix after performing the transformations. Useful when
 * you're doing some graphical manipulation and you want to use
 * the end effector position as your start point.
 * 
 * @param model        The arm model whose transformations to apply
 * @param applyOffset  Whether to apply the Tool Frame End
 *                     Effector offset (if it exists)
 */
public void applyModelRotation(ArmModel model, boolean applyOffset){   
  translate(600, 200, 0);
  translate(-50, -166, -358); // -115, -213, -413
  rotateZ(PI);
  translate(150, 0, 150);
  rotateY(model.segments.get(0).currentRotations[1]);
  translate(-150, 0, -150);
  rotateZ(-PI);    
  translate(-115, -85, 180);
  rotateZ(PI);
  rotateY(PI/2);
  translate(0, 62, 62);
  rotateX(model.segments.get(1).currentRotations[2]);
  translate(0, -62, -62);
  rotateY(-PI/2);
  rotateZ(-PI);   
  translate(0, -500, -50);
  rotateZ(PI);
  rotateY(PI/2);
  translate(0, 75, 75);
  rotateX(model.segments.get(2).currentRotations[2]);
  translate(0, -75, -75);
  rotateY(PI/2);
  rotateZ(-PI);
  translate(745, -150, 150);
  rotateZ(PI/2);
  rotateY(PI/2);
  translate(70, 0, 70);
  rotateY(model.segments.get(3).currentRotations[0]);
  translate(-70, 0, -70);
  rotateY(-PI/2);
  rotateZ(-PI/2);    
  translate(-115, 130, -124);
  rotateZ(PI);
  rotateY(-PI/2);
  translate(0, 50, 50);
  rotateX(model.segments.get(4).currentRotations[2]);
  translate(0, -50, -50);
  rotateY(PI/2);
  rotateZ(-PI);    
  translate(150, -10, 95);
  rotateY(-PI/2);
  rotateZ(PI);
  translate(45, 45, 0);
  rotateZ(model.segments.get(5).currentRotations[0]);
  
  if (applyOffset && (curCoordFrame == COORD_TOOL || curCoordFrame == COORD_WORLD)) { armModel.applyToolFrame(activeToolFrame); }
} // end apply model rotations

/**
 * Calculate the Jacobian matrix for the robotic arm for
 * a given set of joint rotational values using a 1 DEGREE
 * offset for each joint rotation value. Each cell of the
 * resulting matrix will describe the linear approximation
 * of the robot's motion for each joint in units per radian. 
 */
public float[][] calculateJacobian(float[] angles){
  float dAngle = DEG_TO_RAD;
  float[][] J = new float[7][6];
  //get current ee position
  PVector cPos = armModel.getEEPos(angles);
  float[] cRotQ = armModel.getQuaternion(angles);
  
  //examine each segment of the arm
  for(int i = 0; i < 6; i += 1){
    //test angular offset
    angles[i] += dAngle;
    //get updated ee position
    PVector nPos = armModel.getEEPos(angles);
    float[] nRotQ = armModel.getQuaternion(angles);

    //get translational delta
    J[0][i] = (nPos.x - cPos.x)/DEG_TO_RAD;
    J[1][i] = (nPos.y - cPos.y)/DEG_TO_RAD;
    J[2][i] = (nPos.z - cPos.z)/DEG_TO_RAD;
    //get rotational delta        
    J[3][i] = (nRotQ[0] - cRotQ[0])/DEG_TO_RAD;
    J[4][i] = (nRotQ[1] - cRotQ[1])/DEG_TO_RAD;
    J[5][i] = (nRotQ[2] - cRotQ[2])/DEG_TO_RAD;
    J[6][i] = (nRotQ[3] - cRotQ[3])/DEG_TO_RAD;
    //replace the original rotational value
    angles[i] -= dAngle;
  }
  
  return J;
}//end calculate jacobian

//attempts to calculate the joint rotation values
//required to move the end effector to the point specified
//by 'tgt' and the Euler angle orientation 'rot'
public int calculateIKJacobian(PVector tgt, float[] rot){
  final int limit = 1000;  //max number of times to loop
  int count = 0;
  
  float[] angles = armModel.getJointRotations();
  float[][] frame = armModel.currentFrame;
  float[][] nFrame = armModel.getRotationMatrix();
  float[][] rMatrix = quatToMatrix(rot);
  armModel.currentFrame = nFrame;
  
  //translate target rotation to world ref frame
  RealMatrix M = new Array2DRowRealMatrix(floatToDouble(nFrame, 3, 3));
  RealMatrix O = new Array2DRowRealMatrix(floatToDouble(frame, 3, 3));
  RealMatrix MO = M.multiply(MatrixUtils.inverse(O));
  
  //translate target rotation to EE ref frame
  RealMatrix R = new Array2DRowRealMatrix(floatToDouble(rMatrix, 3, 3));
  RealMatrix OR = R.multiply(MatrixUtils.inverse(MO));
  rot = matrixToQuat(doubleToFloat(OR.getData(), 3, 3));
  //println();
  while(count < limit){
    PVector cPos = armModel.getEEPos(angles);
    float[] cRotQ = armModel.getQuaternion(angles);
    
    //calculate our translational offset from target
    float[] tDelta = calculateVectorDelta(tgt, cPos);
    //calculate our rotational offset from target
    float[] rDelta = calculateVectorDelta(rot, cRotQ, 4);
    float[] delta = new float[7];
    
    delta[0] = tDelta[0];
    delta[1] = tDelta[1];
    delta[2] = tDelta[2];
    delta[3] = rDelta[0];
    delta[4] = rDelta[1];
    delta[5] = rDelta[2];
    delta[6] = rDelta[3];
    
    float dist = PVector.dist(cPos, tgt);
    float rDist = calculateQuatMag(rDelta);
    //println("distances from tgt: " + dist + ", " + rDist);
    //check whether our current position is within tolerance
    if(dist < liveSpeed && rDist < 0.005f*liveSpeed) break;
    //calculate jacobian, 'J', and its inverse
    float[][] J = calculateJacobian(angles);
    RealMatrix m = new Array2DRowRealMatrix(floatToDouble(J, 7, 6));
    RealMatrix JInverse = new SingularValueDecomposition(m).getSolver().getInverse();
        
    //calculate and apply joint angular changes
    float[] dAngle = {0, 0, 0, 0, 0, 0};
    for(int i = 0; i < 6; i += 1){
      for(int j = 0; j < 7; j += 1){
        dAngle[i] += JInverse.getEntry(i, j)*delta[j];
      }
      //update joint angles
      angles[i] += dAngle[i];
      angles[i] += TWO_PI;
      angles[i] %= TWO_PI;
    }
    
    count += 1;
    if(count == limit){
      
    }
  }
  
  armModel.currentFrame = frame;
  
  //did we successfully find the desired angles?
  if(count >= limit){
    println("IK failure");
    return EXEC_FAILURE;
  }
  else{
    for(int i = 0; i < 6; i += 1){
      Model s = armModel.segments.get(i);
      if(angles[i] > -0.000001f && angles[i] < 0.000001f)
        angles[i] = 0;
        
      for(int j = 0; j < 3; j += 1){
        if(s.rotations[j] && !s.anglePermitted(j, angles[i])){
          //println("illegal joint angle on j" + i);
          return EXEC_FAILURE;
        }
      }
    }
    
    float[] angleOffset = new float[6];
    float maxOffset = TWO_PI;
    for(int i = 0; i < 6; i += 1){
      angleOffset[i] = abs(minimumDistance(angles[i], armModel.getJointRotations()[i]));
    }
    
    if(angleOffset[0] <= maxOffset && angleOffset[1] <= maxOffset && angleOffset[2] <= maxOffset && 
       angleOffset[3] <= maxOffset && angleOffset[4] <= maxOffset && angleOffset[5] <= maxOffset){
      armModel.setJointRotations(angles);
      return EXEC_SUCCESS;
    }
    else{
      return EXEC_PARTIAL;
    }
  }
}

public int calculateIKJacobian(Point p){
  PVector pos = p.pos;
  float[] rot = p.ori;
  return calculateIKJacobian(pos, rot);
}

/**
 * Determine how close together intermediate points between two points
 * need to be based on current speed
 */
public void calculateDistanceBetweenPoints() {
  MotionInstruction instruction = getActiveMotionInstruct();
  if (instruction != null && instruction.getMotionType() != MTYPE_JOINT)
    distanceBetweenPoints = instruction.getSpeed() / 60.0f;
  else if (curCoordFrame != COORD_JOINT)
    distanceBetweenPoints = armModel.motorSpeed * liveSpeed / 60.0f;
  else distanceBetweenPoints = 5.0f;
}

/**
 * Calculate a "path" (series of intermediate positions) between two
 * points in a straight line.
 * @param start Start point
 * @param end Destination point
 */
public void calculateIntermediatePositions(Point start, Point end) {
  calculateDistanceBetweenPoints();
  intermediatePositions.clear();
  
  PVector p1 = start.pos;
  PVector p2 = end.pos;
  float[] q1 = start.ori;
  float[] q2 = end.ori;
  float[] qi = new float[4];
  
  float mu = 0;
  int numberOfPoints = (int)(dist(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z) / distanceBetweenPoints);
  float increment = 1.0f / (float)numberOfPoints;
  for (int n = 0; n < numberOfPoints; n++) {
    mu += increment;
    
    qi = quaternionSlerp(q1, q2, mu);
    intermediatePositions.add(new Point(new PVector(
      p1.x * (1 - mu) + (p2.x * mu),
      p1.y * (1 - mu) + (p2.y * mu),
      p1.z * (1 - mu) + (p2.z * mu)),
      qi));
  }
  
  interMotionIdx = 0;
} // end calculate intermediate positions

/**
 * Calculate a "path" (series of intermediate positions) between two
 * points in a a curved line. Need a third point as well, or a curved
 * line doesn't make sense.
 * Here's how this works:
 *   Assuming our current point is P1, and we're moving to P2 and then P3:
 *   1 Do linear interpolation between points P2 and P3 FIRST.
 *   2 Begin interpolation between P1 and P2.
 *   3 When you're (cont% / 1.5)% away from P2, begin interpolating not towards
 *     P2, but towards the points defined between P2 and P3 in step 1.
 *   The mu for this is from 0 to 0.5 instead of 0 to 1.0.
 *
 * @param p1 Start point
 * @param p2 Destination point
 * @param p3 Third point, needed to figure out how to curve the path
 * @param percentage Intensity of the curve
 */
public void calculateContinuousPositions(Point start, Point end, Point next, float percentage) {
  //percentage /= 2;
  calculateDistanceBetweenPoints();
  percentage /= 1.5f;
  percentage = 1 - percentage;
  percentage = constrain(percentage, 0, 1);
  intermediatePositions.clear();
  
  PVector p1 = start.pos;
  PVector p2 = end.pos;
  PVector p3 = next.pos;
  float[] q1 = start.ori;
  float[] q2 = end.ori;
  float[] q3 = next.ori;
  float[] qi = new float[4];
  
  ArrayList<Point> secondaryTargets = new ArrayList<Point>();
  float d1 = dist(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z);
  float d2 = dist(p2.x, p2.y, p2.z, p3.x, p3.y, p3.z);
  int numberOfPoints = 0;
  if (d1 > d2){
    numberOfPoints = (int)(d1 / distanceBetweenPoints);
  } 
  else {
    numberOfPoints = (int)(d2 / distanceBetweenPoints);
  }
  
  float mu = 0;
  float increment = 1.0f / (float)numberOfPoints;
  for (int n = 0; n < numberOfPoints; n++) {
    mu += increment;
    qi = quaternionSlerp(q2, q3, mu);
    secondaryTargets.add(new Point(new PVector(
      p2.x * (1 - mu) + (p3.x * mu),
      p2.y * (1 - mu) + (p3.y * mu),
      p2.z * (1 - mu) + (p3.z * mu)),
      qi));
  }
  
  mu = 0;
  int transitionPoint = (int)((float)numberOfPoints * percentage);
  for (int n = 0; n < transitionPoint; n++) {
    mu += increment;
    qi = quaternionSlerp(q1, q2, mu);
    intermediatePositions.add(new Point(new PVector(
      p1.x * (1 - mu) + (p2.x * mu),
      p1.y * (1 - mu) + (p2.y * mu),
      p1.z * (1 - mu) + (p2.z * mu)),
      qi));
  }
  
  int secondaryIdx = 0; // accessor for secondary targets
  
  mu = 0;
  increment /= 2.0f;
  
  Point currentPoint;
  if(intermediatePositions.size() > 0){
    currentPoint = intermediatePositions.get(intermediatePositions.size()-1);
  }
  else{
    currentPoint = new Point(armModel.getEEPos(), armModel.getQuaternion());
  }
  
  for (int n = transitionPoint; n < numberOfPoints; n++) {
    mu += increment;
    Point tgt = secondaryTargets.get(secondaryIdx);
    qi = quaternionSlerp(currentPoint.ori, tgt.ori, mu);
    intermediatePositions.add(new Point(new PVector(
      currentPoint.pos.x * (1 - mu) + (tgt.pos.x * mu),
      currentPoint.pos.y * (1 - mu) + (tgt.pos.y * mu),
      currentPoint.pos.z * (1 - mu) + (tgt.pos.z * mu)), 
      qi));
    currentPoint = intermediatePositions.get(intermediatePositions.size()-1);
    secondaryIdx++;
  }
  interMotionIdx = 0;
} // end calculate continuous positions

/**
 * Creates an arc from 'start' to 'end' that passes through the point specified
 * by 'inter.'
 * @param start First point
 * @param inter Second point
 * @param end Third point
 */
public void calculateArc(Point start, Point inter, Point end){  
  calculateDistanceBetweenPoints();
  intermediatePositions.clear();
  
  PVector a = start.pos;
  PVector b = inter.pos;
  PVector c = end.pos;
  float[] q1 = start.ori;
  float[] q2 = end.ori;
  float[] qi = new float[4];
  
  // Calculate arc center point
  PVector[] plane = new PVector[3];
  plane = createPlaneFrom3Points(a, b, c);
  PVector center = circleCenter(vectorConvertTo(a, plane[0], plane[1], plane[2]),
                                vectorConvertTo(b, plane[0], plane[1], plane[2]),
                                vectorConvertTo(c, plane[0], plane[1], plane[2]));
  center = vectorConvertFrom(center, plane[0], plane[1], plane[2]);
  // Now get the radius (easy)
  float r = dist(center.x, center.y, center.z, a.x, a.y, a.z);
  // Calculate a vector from the center to point a
  PVector u = new PVector(a.x-center.x, a.y-center.y, a.z-center.z);
  u.normalize();
  // get the normal of the plane created by the 3 input points
  PVector tmp1 = new PVector(a.x-b.x, a.y-b.y, a.z-b.z);
  PVector tmp2 = new PVector(a.x-c.x, a.y-c.y, a.z-c.z);
  PVector n = tmp1.cross(tmp2);
  tmp1.normalize();
  tmp2.normalize();
  n.normalize();
  // calculate the angle between the start and end points
  PVector vec1 = new PVector(a.x-center.x, a.y-center.y, a.z-center.z);
  PVector vec2 = new PVector(c.x-center.x, c.y-center.y, c.z-center.z);
  vec1.normalize();
  vec2.normalize();
  float theta = atan2(vec1.cross(vec2).mag(), vec1.dot(vec2));

  // finally, draw an arc through all 3 points by rotating the u
  // vector around our normal vector
  float angle = 0, mu = 0;
  int numPoints = (int)(r*theta/distanceBetweenPoints);
  float inc = 1/(float)numPoints;
  float angleInc = (theta)/(float)numPoints;
  for (int i = 0; i < numPoints; i += 1) {
    PVector pos = rotateVectorQuat(u, n, angle).mult(r).add(center);
    if(i == numPoints-1) pos = end.pos;
    qi = quaternionSlerp(q1, q2, mu);
    println(pos + ", " + end.pos);
    intermediatePositions.add(new Point(pos, qi));
    angle += angleInc;
    mu += inc;
  }
}

/**
 * Initiate a new continuous (curved) motion instruction.
 * @param model Arm model to use
 * @param start Start point
 * @param end Destination point
 * @param next Point after the destination
 * @param percentage Intensity of the curve
 */
public void beginNewContinuousMotion(Point start, Point end, Point next, float p){
  calculateContinuousPositions(start, end, next, p);
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0){
    calculateIKJacobian(intermediatePositions.get(interMotionIdx));
  }
}

/**
 * Initiate a new fine (linear) motion instruction.
 * @param start Start point
 * @param end Destination point
 */
public void beginNewLinearMotion(Point start, Point end) {
  calculateIntermediatePositions(start, end);
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0){
    calculateIKJacobian(intermediatePositions.get(interMotionIdx));
  }
}

/**
 * Initiate a new circular motion instruction according to FANUC methodology.
 * @param p1 Point 1
 * @param p2 Point 2
 * @param p3 Point 3
 */
public void beginNewCircularMotion(Point start, Point inter, Point end) {
  calculateArc(start, inter, end);
  interMotionIdx = 0;
  motionFrameCounter = 0;
  if(intermediatePositions.size() > 0){
    calculateIKJacobian(intermediatePositions.get(interMotionIdx));
  }
}

/**
 * Move the arm model between two points according to its current speed.
 * @param model The arm model
 * @param speedMult Speed multiplier
 */
public boolean executeMotion(ArmModel model, float speedMult) {
  motionFrameCounter++;
  // speed is in pixels per frame, multiply that by the current speed setting
  // which is contained in the motion instruction
  float currentSpeed = model.motorSpeed * speedMult;
  if (currentSpeed * motionFrameCounter > distanceBetweenPoints) {
    interMotionIdx++;
    motionFrameCounter = 0;
    if (interMotionIdx >= intermediatePositions.size()) {
      interMotionIdx = -1;
      return true;
    }
    
    int ret = EXEC_SUCCESS;
    if(intermediatePositions.size() > 0){
      calculateIKJacobian(intermediatePositions.get(interMotionIdx));
    }
      
    if(ret == EXEC_FAILURE){
      doneMoving = true;
    }
  }
  
  return false;
} // end execute linear motion

public MotionInstruction getActiveMotionInstruct(){
  Instruction inst = null;
  Program p = programs.get(active_program);
  
  if(p != null && p.getInstructions().size() != 0)
    inst = p.getInstructions().get(active_instruction);
  else return null;
  
  if(inst instanceof MotionInstruction)
    return (MotionInstruction)inst;
  else return null;
}

/**
 * Convert a point based on a coordinate system defined as
 * 3 orthonormal vectors.
 * @param point Point to convert
 * @param xAxis X axis of target coordinate system
 * @param yAxis Y axis of target coordinate system
 * @param zAxis Z axis of target coordinate system
 * @return Coordinates of point after conversion
 */
public PVector vectorConvertTo(PVector point, PVector xAxis,
                        PVector yAxis, PVector zAxis)
{
  PMatrix3D matrix = new PMatrix3D(xAxis.x, xAxis.y, xAxis.z, 0,
                                   yAxis.x, yAxis.y, yAxis.z, 0,
                                   zAxis.x, zAxis.y, zAxis.z, 0,
                                   0,       0,       0,       1);
  PVector result = new PVector();
  matrix.mult(point, result);
  return result;
}


/**
 * Convert a point based on a coordinate system defined as
 * 3 orthonormal vectors. Reverse operation of vectorConvertTo.
 * @param point Point to convert
 * @param xAxis X axis of target coordinate system
 * @param yAxis Y axis of target coordinate system
 * @param zAxis Z axis of target coordinate system
 * @return Coordinates of point after conversion
 */
public PVector vectorConvertFrom(PVector point, PVector xAxis,
                          PVector yAxis, PVector zAxis)
{
  PMatrix3D matrix = new PMatrix3D(xAxis.x, yAxis.x, zAxis.x, 0,
                                   xAxis.y, yAxis.y, zAxis.y, 0,
                                   xAxis.z, yAxis.z, zAxis.z, 0,
                                   0,       0,       0,       1);
  PVector result = new PVector();
  matrix.mult(point, result);
  return result;
}


/**
 * Create a plane (2D coordinate system) out of 3 input points.
 * @param a First point
 * @param b Second point
 * @param c Third point
 * @return New coordinate system defined by 3 orthonormal vectors
 */
public PVector[] createPlaneFrom3Points(PVector a, PVector b, PVector c) {  
  PVector n1 = new PVector(a.x-b.x, a.y-b.y, a.z-b.z);
  n1.normalize();
  PVector n2 = new PVector(a.x-c.x, a.y-c.y, a.z-c.z);
  n2.normalize();
  PVector x = n1.copy();
  PVector z = n1.cross(n2);
  PVector y = x.cross(z);
  y.normalize();
  z.normalize();
  PVector[] coordinateSystem = new PVector[3];
  coordinateSystem[0] = x;
  coordinateSystem[1] = y;
  coordinateSystem[2] = z;
  return coordinateSystem;
}

/**
 * Finds the circle center of 3 points. (That is, find the center of
 * a circle whose circumference intersects all 3 points.)
 * The points must all lie
 * on the same plane (all have the same Z value). Should have a check
 * for colinear case, currently doesn't.
 * @param a First point
 * @param b Second point
 * @param c Third point
 * @return Position of circle center
 */
public PVector circleCenter(PVector a, PVector b, PVector c) {
  float h = calculateH(a.x, a.y, b.x, b.y, c.x, c.y);
  float k = calculateK(a.x, a.y, b.x, b.y, c.x, c.y);
  return new PVector(h, k, a.z);
}

// TODO: Add error check for colinear case (denominator is zero)
public float calculateH(float x1, float y1, float x2, float y2, float x3, float y3) {
    float numerator = (x2*x2+y2*y2)*y3 - (x3*x3+y3*y3)*y2 - 
                      ((x1*x1+y1*y1)*y3 - (x3*x3+y3*y3)*y1) +
                      (x1*x1+y1*y1)*y2 - (x2*x2+y2*y2)*y1;
    float denominator = (x2*y3-x3*y2) -
                        (x1*y3-x3*y1) +
                        (x1*y2-x2*y1);
    denominator *= 2;
    return numerator / denominator;
}

public float calculateK(float x1, float y1, float x2, float y2, float x3, float y3) {
    float numerator = x2*(x3*x3+y3*y3) - x3*(x2*x2+y2*y2) -
                      (x1*(x3*x3+y3*y3) - x3*(x1*x1+y1*y1)) +
                      x1*(x2*x2+y2*y2) - x2*(x1*x1+y1*y1);
    float denominator = (x2*y3-x3*y2) -
                        (x1*y3-x3*y1) +
                        (x1*y2-x2*y1);
    denominator *= 2;
    return numerator / denominator;
}

/**
 * Executes a program. Returns true when done.
 * @param program Program to execute
 * @param model Arm model to use
 * @return Finished yet (false=no, true=yes)
 */
public boolean executeProgram(Program program, ArmModel model, boolean singleInst) {
  //stop executing if no valid program is selected or we reach the end of the program
  if (program == null || currentInstruction >= program.getInstructions().size()){
    return true;
  }
  
  //get the next program instruction
  Instruction ins = program.getInstructions().get(currentInstruction);
  
  //motion instructions
  if (ins instanceof MotionInstruction){
    MotionInstruction instruction = (MotionInstruction)ins;
    if (instruction.getUserFrame() != activeUserFrame){
      setError("ERROR: Instruction's user frame is different from currently active user frame.");
      return true;
    }
    //start a new instruction
    if (!executingInstruction){
      boolean setup = setUpInstruction(program, model, instruction);
      if(!setup){ return true; }
      else executingInstruction = true;
    }
    //continue current instruction
    else {
      if (instruction.getMotionType() == MTYPE_JOINT){
        executingInstruction = !(model.interpolateRotation(instruction.getSpeedForExec(model)));
      }
      else{
        executingInstruction = !(executeMotion(model, instruction.getSpeedForExec(model)));
      }
      
      //move to next instruction after current is finished
      if (!executingInstruction){
        currentInstruction++;
        if(singleInst){ return true; }
      }
    }
  }
  //tool instructions
  else if (ins instanceof ToolInstruction){
    ToolInstruction instruction = (ToolInstruction)ins;
    instruction.execute();
    currentInstruction++;
  }
  //frame instructions
  else if (ins instanceof FrameInstruction){
    FrameInstruction instruction = (FrameInstruction)ins;
    instruction.execute();
    currentInstruction++;
  }//end of instruction type check
  
  return false;
}//end executeProgram

/**
 * Sets up an instruction for execution.
 * @param program Program that the instruction belongs to
 * @param model Arm model to use
 * @param instruction The instruction to execute
 * @return Returns true on failure (invalid instruction), false on success
 */
public boolean setUpInstruction(Program program, ArmModel model, MotionInstruction instruction) {
  Point start = new Point(armModel.getEEPos(), armModel.getQuaternion());
  
  if (instruction.getMotionType() == MTYPE_JOINT) {
    float[] j = instruction.getVector(program).joints;
    
    //set target rotational value for each joint
    for (int n = 0; n < j.length; n++) {
      for (int r = 0; r < 3; r++) {
        if (model.segments.get(n).rotations[r])
          model.segments.get(n).targetRotations[r] = j[n];
          //println("target rotation for joint " + n + ": " + j[n]);
      }
    }
    
    // calculate whether it's faster to turn CW or CCW
    for (Model a : model.segments) {
      for (int r = 0; r < 3; r++) {
        if (a.rotations[r]) {
         // The minimum distance between the current and target joint angles
         float dist_t = minimumDistance(a.currentRotations[r], a.targetRotations[r]);
         
         // check joint movement range
         if (a.jointRanges[r].x == 0 && a.jointRanges[r].y == TWO_PI) {
           a.rotationDirections[r] = (dist_t < 0) ? -1 : 1;
         }
         else {  
           /* Determine if at least one bound lies within the range of the shortest angle
            * between the current joint angle and the target angle. If so, then take the
            * longer angle, otherwise choose the shortest angle path. */
            
           // The minimum distance from the current joint angle to the lower bound of the joint's range
           float dist_lb = minimumDistance(a.currentRotations[r], a.jointRanges[r].x);
           
           // The minimum distance from the current joint angle to the upper bound of the joint's range
           float dist_ub = minimumDistance(a.currentRotations[r], a.jointRanges[r].y);
           
           if (dist_t < 0) {
             if ( (dist_lb < 0 && dist_lb > dist_t) || (dist_ub < 0 && dist_ub > dist_t) ) {
               // One or both bounds lie within the shortest path
               a.rotationDirections[r] = 1;
             } 
             else {
               a.rotationDirections[r] = -1;
             }
           } 
           else if (dist_t > 0){
             if ( (dist_lb > 0 && dist_lb < dist_t) || (dist_ub > 0 && dist_ub < dist_t) ) {  
               // One or both bounds lie within the shortest path
               a.rotationDirections[r] = -1;
             } 
             else {
               a.rotationDirections[r] = 1;
             }
           }
         }
        }
      }
    }
  } // end joint movement setup
  else if (instruction.getMotionType() == MTYPE_LINEAR) {
    if (instruction.getTermination() == 0) {
      beginNewLinearMotion(start, instruction.getVector(program));
    } 
    else {
      Point nextPoint = null;
      for (int n = currentInstruction+1; n < program.getInstructions().size(); n++) {
        Instruction nextIns = program.getInstructions().get(n);
        if (nextIns instanceof MotionInstruction) {
          MotionInstruction castIns = (MotionInstruction)nextIns;
          nextPoint = castIns.getVector(program);
          break;
        }
      }
      if (nextPoint == null) {
        beginNewLinearMotion(start, instruction.getVector(program));
      } 
      else{
        beginNewContinuousMotion(start, 
                                 instruction.getVector(program),
                                 nextPoint, 
                                 instruction.getTermination());
      }
    } // end if termination type is continuous
  } // end linear movement setup
  else if (instruction.getMotionType() == MTYPE_CIRCULAR) {
    // If it is a circular instruction, the current instruction holds the intermediate point.
    // There must be another instruction after this that holds the end point.
    // If this isn't the case, the instruction is invalid, so return immediately.
    Point nextPoint = null;
    if (program.getInstructions().size() >= currentInstruction + 2) {
      Instruction nextIns = program.getInstructions().get(currentInstruction+1);
      //make sure next instruction is of valid type
      if (nextIns instanceof MotionInstruction){
        MotionInstruction castIns = (MotionInstruction)nextIns;
        nextPoint = castIns.getVector(program);
      }
      else{
        return false;
      }
    } 
    // invalid instruction
    else{
      return false; 
    }
    
    beginNewCircularMotion(start, instruction.getVector(program), nextPoint);
  } // end circular movement setup
  return true;
} // end setUpInstruction

/* Returns the angle with the smallest magnitude between
 * the two given angles on the Unit Circle */
public float minimumDistance(float angle1, float angle2) {
  float dist = clampAngle(angle2) - clampAngle(angle1);
  
  if (dist > PI) {
    dist -= TWO_PI;
  } else if (dist < -PI) {
    dist += TWO_PI;
  }
  
  return dist;
}

public void setError(String text) {
  errorText = text;
  errorCounter = 600;
}

/**
 * Maps wth given angle to the range of 0 (inclusive) to
 * two PI (exclusive).
 *
 * @param angle  some angle in radians
 * @return       An angle between  0 (inclusive) to two
 *               PI (exclusive)
 */
public float clampAngle(float angle) {
  while (angle > TWO_PI) angle -= (TWO_PI);
  while (angle < 0) angle += (TWO_PI);
  // angles range: [0, TWO_PI)
  if (angle == TWO_PI) angle = 0;
  return angle;
}
final int FRAME_JOINT = 0, 
          FRAME_JGFRM = 1, 
          FRAME_WORLD = 2, 
          FRAME_TOOL = 3, 
          FRAME_USER = 4;
final int SMALL_BUTTON = 20,
          LARGE_BUTTON = 35; 
final int NONE = 0, 
          PROGRAM_NAV = 1, 
          INSTRUCTION_NAV = 2,
          INSTRUCTION_EDIT = 3,
          SET_INSTRUCTION_SPEED = 4,
          SET_INSTRUCTION_REGISTER = 5,
          SET_INSTRUCTION_TERMINATION = 6,
          JUMP_TO_LINE = 7,
          VIEW_REGISTER = 8,
          ENTER_TEXT = 9,
          PICK_LETTER = 10,
          MENU_NAV = 11,
          SETUP_NAV = 12,
          NAV_TOOL_FRAMES = 13,
          NAV_USER_FRAMES = 14,
          PICK_FRAME_MODE = 15,
          FRAME_DETAIL = 16,
          PICK_FRAME_METHOD = 17,
          THREE_POINT_MODE = 18,
          FOUR_POINT_MODE = 19,
          SIX_POINT_MODE = 20,
          DIRECT_ENTRY_MODE = 21,
          ACTIVE_FRAMES = 22,
          PICK_INSTRUCTION = 23,
          IO_SUBMENU = 24,
          SET_DO_BRACKET = 25,
          SET_DO_STATUS = 26,
          SET_RO_BRACKET = 27,
          SET_RO_STATUS = 28,
          SET_FRAME_INSTRUCTION = 29,
          SET_FRAME_INSTRUCTION_IDX = 30,
          PICK_REG_LIST = 31,
          VIEW_REG = 32,
          // C for Cartesian
          VIEW_POS_REG_C = 33,
          // J for Joint
          VIEW_POS_REG_J = 34,
          EDIT_MENU = 35,
          INPUT_FLOAT = 36,
          INPUT_POINT_C = 37,
          INPUT_POINT_J = 38,
          INPUT_COMMENT_U = 39,
          INPUT_COMMENT_L = 40,
          CONFIRM_DELETE = 41;
final int COLOR_DEFAULT = -8421377,
          COLOR_ACTIVE = -65536;
// Determines what End Effector mapping should be display
static int EE_MAPPING = 2;

int frame = FRAME_JOINT; // current frame
//String displayFrame = "JOINT";
int active_program = -1; // the currently selected program
int active_instruction = -1; // the currently selected instruction
int mode = NONE;
// Used by some modes to refer to a previous mode
int super_mode = NONE;
int NUM_MODE; // When NUM_MODE is ON, allows for entering numbers
int shift = OFF; // Is shift button pressed or not?
int step = OFF; // Is step button pressed or not?
int record = OFF;
 
int g1_px, g1_py; // the left-top corner of group1
int g1_width, g1_height; // group 1's width and height
int display_px, display_py; // the left-top corner of display screen
int display_width = 340, display_height = 270; // height and width of display screen

PFont fnt;
Group g1, g2, txt;
Button bt_show, bt_hide, 
       bt_zoomin_shrink, bt_zoomin_normal,
       bt_zoomout_shrink, bt_zoomout_normal,
       bt_pan_shrink, bt_pan_normal,
       bt_rotate_shrink, bt_rotate_normal,
       bt_record_shrink, bt_record_normal, 
       bt_ee_normal
       ;
Textlabel fn_info, num_info;

String workingText; // when entering text or a number
String workingTextSuffix;
boolean speedInPercentage;
final int ITEMS_TO_SHOW = 12; // how many programs/ instructions to display on screen
int curFrameIdx = -1;
// Used to keep track a specific point in space
PVector ref_point;
ArrayList<float[][]> teachPointTMatrices = null;
int activeUserFrame = -1;
int activeJogFrame = -1;
int activeToolFrame = -1;

// display list of programs or motion instructions
ArrayList<ArrayList<String>> contents = new ArrayList<ArrayList<String>>();
// display options for an element in a motion instruction
ArrayList<String> options = new ArrayList<String>();
// store numbers pressed by the user
ArrayList<Integer> nums = new ArrayList<Integer>(); 
// which element is on focus now?
int active_row = 0,
    active_col = 0,
    // Keep track of focused element in a displayed list
    active_index = 0,
    // Used for drawing a subsection of a list on the screen
    text_render_start = 0;
// which option is on focus now?
int which_option = -1; 
// how many textlabels have been created for display
int index_contents = 0, index_options = 100, index_nums = 1000; 
int mouseDown = 0;

/**
 * Used for comment name input. The user can cycle through the
 * six states for each function button in this mode:
 *
 * F1 -> A-F/a-f
 * F2 -> G-L/g-l
 * F3 -> M-R/m-r
 * F4 -> S-X/s-x
 * F5 -> Y, Z, _, @, *, ./y, z, _, @, *, .
 */
private final int[] letterStates = new int[] { 0, 0, 0, 0, 0 };

public static final boolean DISPLAY_TEST_OUTPUT = true;

public void gui(){
   g1_px = 0;
   g1_py = 0;
   g1_width = 100;
   g1_height = 100;
   display_px = g1_width / 2;
   display_py = SMALL_BUTTON + 1;
   /*
   PFont pfont = createFont("ArialNarrow",9,true); // new font
   ControlFont font = new ControlFont(pfont, 9);
   cp5.setFont(font);
   */
   
   // group 1: display and function buttons
   g1 = cp5.addGroup("DISPLAY")
      .setPosition(g1_px, g1_py)
      .setBackgroundColor(color(127,127,127,100));
   
   fnt = createFont("data/Consolas.ttf", 14);
   textDisplay = cp5.addTextarea("txt")
      .setPosition(display_px,display_py)
      .setSize(display_width, display_height)
      .setLineHeight(14)
      .setColor(color(128))
      .setColorBackground(color(240))
      .setColorForeground(color(15))
      .moveTo(g1);
   
   // expand group 1's width and height
   g1_width += 340;
   g1_height += 270;
   
   // text label to show how to use F1 - F5 keys
   fn_info = cp5.addTextlabel("fn_info")
       .hide();
       
   num_info = cp5.addTextlabel("num_info")
       .hide();   
   // button to show g1
   int bt_show_px = 1;
   int bt_show_py = 1;
   bt_show = cp5.addButton("show")
       .setPosition(bt_show_px, bt_show_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setCaptionLabel("SHOW")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .hide()
       ;
       
    int zoomin_shrink_px =  bt_show_px + LARGE_BUTTON;
    int zoomin_shrink_py = bt_show_py;
    PImage[] zoomin_shrink = {loadImage("images/zoomin_35x20.png"), 
                              loadImage("images/zoomin_over.png"), 
                              loadImage("images/zoomin_down.png")};   
    bt_zoomin_shrink = cp5.addButton("zoomin_shrink")
       .setPosition(zoomin_shrink_px, zoomin_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomin_shrink)
       .updateSize()
       .hide()
       ;   
       
    int zoomout_shrink_px = zoomin_shrink_px + LARGE_BUTTON ;
    int zoomout_shrink_py = zoomin_shrink_py;   
    PImage[] zoomout_shrink = {loadImage("images/zoomout_35x20.png"), 
                               loadImage("images/zoomout_over.png"), 
                               loadImage("images/zoomout_down.png")};   
    bt_zoomout_shrink = cp5.addButton("zoomout_shrink")
       .setPosition(zoomout_shrink_px, zoomout_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomout_shrink)
       .updateSize()
       .hide()
       ;    
   
    int pan_shrink_px = zoomout_shrink_px + LARGE_BUTTON;
    int pan_shrink_py = zoomout_shrink_py ;
    PImage[] pan_shrink = {loadImage("images/pan_35x20.png"), 
                           loadImage("images/pan_over.png"), 
                           loadImage("images/pan_down.png")};   
    bt_pan_shrink = cp5.addButton("pan_shrink")
       .setPosition(pan_shrink_px, pan_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(pan_shrink)
       .updateSize()
       .hide()
       ;    
       
    int rotate_shrink_px = pan_shrink_px + LARGE_BUTTON;
    int rotate_shrink_py = pan_shrink_py;   
    PImage[] rotate_shrink = {loadImage("images/rotate_35x20.png"), 
                              loadImage("images/rotate_over.png"), 
                              loadImage("images/rotate_down.png")};   
    bt_rotate_shrink = cp5.addButton("rotate_shrink")
       .setPosition(rotate_shrink_px, rotate_shrink_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(rotate_shrink)
       .updateSize()
       .hide()
       ;     
      
   // button to hide g1
   int hide_px = display_px;
   int hide_py = display_py - SMALL_BUTTON - 1;
   bt_hide = cp5.addButton("hide")
       .setPosition(hide_px, hide_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setCaptionLabel("HIDE")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);
     
    int zoomin_normal_px =  hide_px + LARGE_BUTTON + 1;
    int zoomin_normal_py = hide_py;
    PImage[] zoomin_normal = {loadImage("images/zoomin_35x20.png"), 
                              loadImage("images/zoomin_over.png"), 
                              loadImage("images/zoomin_down.png")};   
    bt_zoomin_normal = cp5.addButton("zoomin_normal")
       .setPosition(zoomin_normal_px, zoomin_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomin_normal)
       .updateSize()
       .moveTo(g1) ;   
       
    int zoomout_normal_px = zoomin_normal_px + LARGE_BUTTON + 1;
    int zoomout_normal_py = zoomin_normal_py;   
    PImage[] zoomout_normal = {loadImage("images/zoomout_35x20.png"), 
                               loadImage("images/zoomout_over.png"), 
                               loadImage("images/zoomout_down.png")};   
    bt_zoomout_normal = cp5.addButton("zoomout_normal")
       .setPosition(zoomout_normal_px, zoomout_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(zoomout_normal)
       .updateSize()
       .moveTo(g1) ;    
   
    int pan_normal_px = zoomout_normal_px + LARGE_BUTTON + 1;
    int pan_normal_py = zoomout_normal_py ;
    PImage[] pan = {loadImage("images/pan_35x20.png"), 
                    loadImage("images/pan_over.png"), 
                    loadImage("images/pan_down.png")};   
    bt_pan_normal = cp5.addButton("pan_normal")
       .setPosition(pan_normal_px, pan_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(pan)
       .updateSize()
       .moveTo(g1) ;    
       
    int rotate_normal_px = pan_normal_px + LARGE_BUTTON + 1;
    int rotate_normal_py = pan_normal_py;   
    PImage[] rotate = {loadImage("images/rotate_35x20.png"), 
                       loadImage("images/rotate_over.png"), 
                       loadImage("images/rotate_down.png")};   
    bt_rotate_normal = cp5.addButton("rotate_normal")
       .setPosition(rotate_normal_px, rotate_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(rotate)
       .updateSize()
       .moveTo(g1) ;     
       
    int record_normal_px = rotate_normal_px + LARGE_BUTTON + 1;
    int record_normal_py = rotate_normal_py;   
    PImage[] record = {loadImage("images/record-35x20.png"), 
                       loadImage("images/record-over.png"), 
                       loadImage("images/record-on.png")};   
    bt_record_normal = cp5.addButton("record_normal")
       .setPosition(record_normal_px, record_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(record)
       .updateSize()
       .moveTo(g1) ;     
      
    int EE_normal_px = record_normal_px + LARGE_BUTTON + 1;
    int EE_normal_py = record_normal_py;   
    PImage[] EE = {loadImage("images/EE_35x20.png"), 
                   loadImage("images/EE_over.png"), 
                   loadImage("images/EE_down.png")};   
    bt_ee_normal = cp5.addButton("EE")
       .setPosition(EE_normal_px, EE_normal_py)
       .setSize(LARGE_BUTTON, SMALL_BUTTON)
       .setImages(EE)
       .updateSize()
       .moveTo(g1) ;    
       
   PImage[] imgs_arrow_up = {loadImage("images/arrow-up.png"), 
                             loadImage("images/arrow-up_over.png"), 
                             loadImage("images/arrow-up_down.png")};   
   int up_px = display_px+display_width + 2;
   int up_py = display_py;
   cp5.addButton("up")
       .setPosition(up_px, up_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_up)
       .updateSize()
       .moveTo(g1) ;     
   
    PImage[] imgs_arrow_down = {loadImage("images/arrow-down.png"), 
                                loadImage("images/arrow-down_over.png"), 
                                loadImage("images/arrow-down_down.png")};   
    int dn_px = up_px;
    int dn_py = up_py + LARGE_BUTTON + 2;
    cp5.addButton("dn")
       .setPosition(dn_px, dn_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_down)
       .updateSize()
       .moveTo(g1) ;    
   
    PImage[] imgs_arrow_l = {loadImage("images/arrow-l.png"), 
                             loadImage("images/arrow-l_over.png"), 
                             loadImage("images/arrow-l_down.png")};
    int lt_px = dn_px;
    int lt_py = dn_py + LARGE_BUTTON + 2;
    cp5.addButton("lt")
       .setPosition(lt_px, lt_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_l)
       .updateSize()
       .moveTo(g1) ;  
    
    PImage[] imgs_arrow_r = {loadImage("images/arrow-r.png"), 
                             loadImage("images/arrow-r_over.png"), 
                             loadImage("images/arrow-r_down.png")};
    int rt_px = lt_px;
    int rt_py = lt_py + LARGE_BUTTON + 2;;
    cp5.addButton("rt")
       .setPosition(rt_px, rt_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setImages(imgs_arrow_r)
       .updateSize()
       .moveTo(g1) ; 
    
    int fn_px = rt_px;
    int fn_py = rt_py + LARGE_BUTTON + 2;   
    cp5.addButton("Fn")
       .setPosition(fn_px, fn_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("FCTN")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int sf_px = fn_px;
    int sf_py = fn_py + LARGE_BUTTON + 2;   
    cp5.addButton("sf")
       .setPosition(sf_px, sf_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("SHIFT")
       .setColorBackground(color(127,127,255))
       .setColorActive(color(0))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);
       
    int ne_px = sf_px ;
    int ne_py = sf_py + LARGE_BUTTON + 2;   
    cp5.addButton("ne")
       .setPosition(ne_px, ne_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("NEXT")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int se_px = display_px - 2 - LARGE_BUTTON;
    int se_py = display_py;   
    cp5.addButton("se")
       .setPosition(se_px, se_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("SELECT")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);           
    
    int mu_px = se_px ;
    int mu_py = se_py + LARGE_BUTTON + 2;   
    cp5.addButton("mu")
       .setPosition(mu_px, mu_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("MENU")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);      
    
    int ed_px = mu_px ;
    int ed_py = mu_py + LARGE_BUTTON + 2;   
    cp5.addButton("ed")
       .setPosition(ed_px, ed_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("EDIT")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);      
     
    int da_px = ed_px ;
    int da_py = ed_py + LARGE_BUTTON + 2;   
    cp5.addButton("da")
       .setPosition(da_px, da_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("DATA")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);  
    
    int sw_px = da_px ;
    int sw_py = da_py + LARGE_BUTTON + 2;   
    cp5.addButton("sw")
       .setPosition(sw_px, sw_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("SWITH")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);     
    
    int st_px = sw_px ;
    int st_py = sw_py + LARGE_BUTTON + 2;   
    cp5.addButton("st")
       .setPosition(st_px, st_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("STEP")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);        
    
    int pr_px = st_px ;
    int pr_py = st_py + LARGE_BUTTON + 2;   
    cp5.addButton("pr")
       .setPosition(pr_px, pr_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("PREV")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);     
      
    int f1_px = display_px ;
    int f1_py = display_py + display_height + 2;   
    cp5.addButton("f1")
       .setPosition(f1_px, f1_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F1")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);     
         
    int f2_px = f1_px + 41 ;
    int f2_py = f1_py;   
    cp5.addButton("f2")
       .setPosition(f2_px, f2_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F2")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);  
       
    int f3_px = f2_px + 41 ;
    int f3_py = f2_py;   
    cp5.addButton("f3")
       .setPosition(f3_px, f3_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F3")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int f4_px = f3_px + 41 ;
    int f4_py = f3_py;   
    cp5.addButton("f4")
       .setPosition(f4_px, f4_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F4")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);   
      
    int f5_px = f4_px + 41;
    int f5_py = f4_py;   
    cp5.addButton("f5")
       .setPosition(f5_px, f5_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("F5")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);   
    
    int hd_px = f5_px + 41;
    int hd_py = f5_py;   
    cp5.addButton("hd")
       .setPosition(hd_px, hd_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("HOLD")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
    int fd_px = hd_px + 41;
    int fd_py = hd_py;   
    cp5.addButton("fd")
       .setPosition(fd_px, fd_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("FWD")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);   
      
    int bd_px = fd_px + 41;
    int bd_py = fd_py;   
    cp5.addButton("bd")
       .setPosition(bd_px, bd_py)
       .setSize(LARGE_BUTTON, LARGE_BUTTON)
       .setCaptionLabel("BWD")
       .setColorBackground(color(127,127,255))
       .setColorCaptionLabel(color(255,255,255))  
       .moveTo(g1);    
       
   // adjust group 1's width to include all controllers  
   g1.setWidth(g1_width)
     .setBackgroundHeight(g1_height); 
  
    
   // group 2: tool bar
   Group g2 = cp5.addGroup("TOOLBAR")
                 .setPosition(0,display_py + display_height + LARGE_BUTTON + 15)
                 .setBackgroundColor(color(127,127,127, 50))
                 //.setWidth(g1_width)
                 //.setBackgroundHeight(740)
                 .moveTo(g1)   
                 ;
   g2.setOpen(true);              
   
   int RESET_px = 0;
   int RESET_py = 0;
   cp5.addButton("RESET")
      .setPosition(RESET_px, RESET_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("RESET")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
 
   int LEFT_px = RESET_px + LARGE_BUTTON + 1;
   int LEFT_py = RESET_py;
   PImage[] imgs_LEFT = {loadImage("images/LEFT.png"), 
                         loadImage("images/LEFT.png"), 
                         loadImage("images/LEFT.png")};  
   cp5.addButton("LEFT")
      .setPosition(LEFT_px, LEFT_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setImages(imgs_LEFT)
      .setColorBackground(color(127,127,255)) 
      .moveTo(g2);   
      
   int ITEM_px = LEFT_px + LARGE_BUTTON + 1 ;
   int ITEM_py = LEFT_py;
   cp5.addButton("ITEM")
      .setPosition(ITEM_px, ITEM_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("ITEM")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
    
   int ENTER_px = ITEM_px + LARGE_BUTTON + 1 ;
   int ENTER_py = ITEM_py;
   cp5.addButton("ENTER")
      .setPosition(ENTER_px, ENTER_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("ENTER")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int TOOL1_px = ENTER_px + LARGE_BUTTON + 1 ;
   int TOOL1_py = ENTER_py;
   cp5.addButton("TOOL1")
      .setPosition(TOOL1_px, TOOL1_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("TOOL1")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
      
   int TOOL2_px = TOOL1_px + LARGE_BUTTON + 1 ;
   int TOOL2_py = TOOL1_py;
   cp5.addButton("TOOL2")
      .setPosition(TOOL2_px, TOOL2_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("TOOL2")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);
 
   int MOVEMENU_px = TOOL2_px + LARGE_BUTTON + 1 ;
   int MOVEMENU_py = TOOL2_py;
   cp5.addButton("MOVEMENU")
      .setPosition(MOVEMENU_px, MOVEMENU_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("MVMU")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 
      
   int SETUP_px = MOVEMENU_px + LARGE_BUTTON + 1 ;
   int SETUP_py = MOVEMENU_py;
   cp5.addButton("SETUP")
      .setPosition(SETUP_px, SETUP_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("SETUP")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int STATUS_px = SETUP_px + LARGE_BUTTON + 1 ;
   int STATUS_py = SETUP_py;
   cp5.addButton("STATUS")
      .setPosition(STATUS_px, STATUS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("STATUS")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int NO_px = STATUS_px + LARGE_BUTTON + 1 ;
   int NO_py = STATUS_py;
   cp5.addButton("NO")
      .setPosition(NO_px, NO_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("NO.")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
     
   int POSN_px = NO_px + LARGE_BUTTON + 1 ;
   int POSN_py = NO_py;
   cp5.addButton("POSN")
      .setPosition(POSN_px, POSN_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("POSN")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
    
   int SPEEDUP_px = POSN_px + LARGE_BUTTON + 1 ;
   int SPEEDUP_py = POSN_py;
   cp5.addButton("SPEEDUP")
      .setPosition(SPEEDUP_px, SPEEDUP_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+%")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
    
   int SLOWDOWN_px = SPEEDUP_px + LARGE_BUTTON + 1 ;
   int SLOWDOWN_py = SPEEDUP_py;
   cp5.addButton("SLOWDOWN")
      .setPosition(SLOWDOWN_px, SLOWDOWN_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-%")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
   
   int NUM1_px = RESET_px ;
   int NUM1_py = RESET_py + SMALL_BUTTON + 1;
   cp5.addButton("NUM1")
      .setPosition(NUM1_px, NUM1_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("1")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
      
   int NUM2_px = NUM1_px + LARGE_BUTTON + 1;
   int NUM2_py = NUM1_py;
   cp5.addButton("NUM2")
      .setPosition(NUM2_px, NUM2_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("2")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
  
   int NUM3_px = NUM2_px + LARGE_BUTTON + 1;
   int NUM3_py = NUM2_py;
   cp5.addButton("NUM3")
      .setPosition(NUM3_px, NUM3_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("3")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 
 
   int NUM4_px = NUM3_px + LARGE_BUTTON + 1;
   int NUM4_py = NUM3_py;
   cp5.addButton("NUM4")
      .setPosition(NUM4_px, NUM4_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("4")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 

   int NUM5_px = NUM4_px + LARGE_BUTTON + 1;
   int NUM5_py = NUM4_py;
   cp5.addButton("NUM5")
      .setPosition(NUM5_px, NUM5_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("5")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
 
   int NUM6_px = NUM5_px + LARGE_BUTTON + 1;
   int NUM6_py = NUM5_py;
   cp5.addButton("NUM6")
      .setPosition(NUM6_px, NUM6_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("6")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
    
   int NUM7_px = NUM6_px + LARGE_BUTTON + 1;
   int NUM7_py = NUM6_py;
   cp5.addButton("NUM7")
      .setPosition(NUM7_px, NUM7_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("7")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
      
   int NUM8_px = NUM7_px + LARGE_BUTTON + 1;
   int NUM8_py = NUM7_py;
   cp5.addButton("NUM8")
      .setPosition(NUM8_px, NUM8_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("8")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int NUM9_px = NUM8_px + LARGE_BUTTON + 1;
   int NUM9_py = NUM8_py;
   cp5.addButton("NUM9")
      .setPosition(NUM9_px, NUM9_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("9")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
  
   int NUM0_px = NUM9_px + LARGE_BUTTON + 1;
   int NUM0_py = NUM9_py;
   cp5.addButton("NUM0")
      .setPosition(NUM0_px, NUM0_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("0")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
  
   int LINE_px = NUM0_px + LARGE_BUTTON + 1;
   int LINE_py = NUM0_py;
   cp5.addButton("LINE")
      .setPosition(LINE_px, LINE_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
   
   int PERIOD_px = LINE_px + LARGE_BUTTON + 1;
   int PERIOD_py = LINE_py;
   cp5.addButton("PERIOD")
      .setPosition(PERIOD_px, PERIOD_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel(".")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);   
   
   int COMMA_px = PERIOD_px + LARGE_BUTTON + 1;
   int COMMA_py = PERIOD_py;
   cp5.addButton("COMMA")
      .setPosition(COMMA_px, COMMA_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel(",")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
   
   int JOINT1_NEG_px = NUM1_px;
   int JOINT1_NEG_py = NUM1_py + SMALL_BUTTON + 1;
   cp5.addButton("JOINT1_NEG")
      .setPosition(JOINT1_NEG_px, JOINT1_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-X (J1)")
      .setColorBackground(color(127, 127, 255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);
   
   int JOINT1_POS_px = JOINT1_NEG_px + LARGE_BUTTON + 1;
   int JOINT1_POS_py = JOINT1_NEG_py;
   cp5.addButton("JOINT1_POS")
      .setPosition(JOINT1_POS_px, JOINT1_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+X (J1)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
      
   int JOINT2_NEG_px = JOINT1_POS_px + LARGE_BUTTON + 1;
   int JOINT2_NEG_py = JOINT1_POS_py;
   cp5.addButton("JOINT2_NEG")
      .setPosition(JOINT2_NEG_px, JOINT2_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Y (J2)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
     
   int JOINT2_POS_px = JOINT2_NEG_px + LARGE_BUTTON + 1;
   int JOINT2_POS_py = JOINT2_NEG_py;
   cp5.addButton("JOINT2_POS")
      .setPosition(JOINT2_POS_px, JOINT2_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Y (J2)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
    
   int JOINT3_NEG_px = JOINT2_POS_px + LARGE_BUTTON + 1;
   int JOINT3_NEG_py = JOINT2_POS_py;
   cp5.addButton("JOINT3_NEG")
      .setPosition(JOINT3_NEG_px, JOINT3_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Z (J3)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
   
   int JOINT3_POS_px = JOINT3_NEG_px + LARGE_BUTTON + 1;
   int JOINT3_POS_py = JOINT3_NEG_py;
   cp5.addButton("JOINT3_POS")
      .setPosition(JOINT3_POS_px, JOINT3_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Z (J3)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
      
   int JOINT4_NEG_px = JOINT3_POS_px + LARGE_BUTTON + 1;
   int JOINT4_NEG_py = JOINT3_POS_py;
   cp5.addButton("JOINT4_NEG")
      .setPosition(JOINT4_NEG_px, JOINT4_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-X (J4)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
     
   int JOINT4_POS_px = JOINT4_NEG_px + LARGE_BUTTON + 1;
   int JOINT4_POS_py = JOINT4_NEG_py;
   cp5.addButton("JOINT4_POS")
      .setPosition(JOINT4_POS_px, JOINT4_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+X (J4)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
      
   int JOINT5_NEG_px = JOINT4_POS_px + LARGE_BUTTON + 1;
   int JOINT5_NEG_py = JOINT4_POS_py;
   cp5.addButton("JOINT5_NEG")
      .setPosition(JOINT5_NEG_px, JOINT5_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Y (J5)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);      
     
   int JOINT5_POS_px = JOINT5_NEG_px + LARGE_BUTTON + 1;
   int JOINT5_POS_py = JOINT5_NEG_py;
   cp5.addButton("JOINT5_POS")
      .setPosition(JOINT5_POS_px, JOINT5_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Y (J5)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);     
    
   int JOINT6_NEG_px = JOINT5_POS_px + LARGE_BUTTON + 1;
   int JOINT6_NEG_py = JOINT5_POS_py;
   cp5.addButton("JOINT6_NEG")
      .setPosition(JOINT6_NEG_px, JOINT6_NEG_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("-Z (J6)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);  
   
   int JOINT6_POS_px = JOINT6_NEG_px + LARGE_BUTTON + 1;
   int JOINT6_POS_py = JOINT6_NEG_py;
   cp5.addButton("JOINT6_POS")
      .setPosition(JOINT6_POS_px, JOINT6_POS_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("+Z (J6)")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2);    
   
   int COORD_px = JOINT6_POS_px + LARGE_BUTTON + 1;
   int COORD_py = JOINT6_POS_py;
   cp5.addButton("COORD")
      .setPosition(COORD_px, COORD_py)
      .setSize(LARGE_BUTTON, SMALL_BUTTON)
      .setCaptionLabel("COORD")
      .setColorBackground(color(127,127,255))
      .setColorCaptionLabel(color(255,255,255))  
      .moveTo(g2); 
}

/* mouse events */
public void mousePressed(){
  mouseDown += 1;
  if(mouseButton == LEFT){
    if(clickRotate%2 == 1){
      doRotate = !doRotate;
    }
    else if(clickPan%2 == 1){
      doPan = !doPan;
    }
  }
}

public void mouseDragged(MouseEvent e) {
    // Hold down the center mouse button and move the mouse to pan the camera
   if (mouseButton == CENTER) {
      panX += mouseX - pmouseX;
      panY += mouseY - pmouseY;
   }
   
   // Hold down the right omuse button an move the mouse to rotate the camera
   if (mouseButton == RIGHT){
      myRotX += (mouseY - pmouseY) * 0.01f;
      myRotY += (mouseX - pmouseX) * 0.01f;
   }
}

public void mouseMoved(){
   if (doPan){
      panX += mouseX - pmouseX;
      panY += mouseY - pmouseY;
   }
   if (doRotate){
      myRotX += (mouseY - pmouseY) * 0.01f;
      myRotY += (mouseX - pmouseX) * 0.01f;
   }
}



public void mouseWheel(MouseEvent event){
  float e = event.getCount();
  // Control scaling of the camera with the mouse wheel
  if (e > 0 ) {
     myscale *= 1.1f;
     if(myscale > 2){
       myscale = 2;
     }
  }
  if (e < 0){
     myscale *= 0.9f;
     if(myscale < 0.25f){
       myscale = 0.25f;
     }
  }
}

public void mouseReleased() {
  mouseDown -= 1;
}

public void keyPressed(){
  if (mode == ENTER_TEXT) {
    // Modify the input name for the new program
    if (workingText.length() < 10 && ( (key >= '0' && key <= '9') || (key >= 'A' && key <= 'Z') || (key >= 'a' && key <= 'z') )) {
      workingText += key;
    } else if (keyCode == BACKSPACE && workingText.length() > 0) {
      workingText = workingText.substring(0, workingText.length() - 1);
    } else if (keyCode == DELETE && workingText.length() > 0) {
      println("HERE");
      workingText = workingText.substring(1, workingText.length());
    }
    
    inputProgramName();
    return;
  } else if (key == 'e') {
    EE_MAPPING = (EE_MAPPING + 1) % 3;
  } else if(key == 'f'){
    armModel.currentFrame = armModel.getRotationMatrix();
  } else if(key == 'g'){
    armModel.resetFrame();
  } else if (key == 'q') {
    armModel.getQuaternion();
  } else if(key == 'r'){
    panX = 0;
    panY = 0;
    myscale = 0.5f;
    myRotX = 0;
    myRotY = 0;
  } else if(key == 't'){
    // Release an object if it is currently being held
    if (armModel.held != null) {
      armModel.releaseHeldObject();
      armModel.endEffectorStatus = OFF;
    }
    
    float[] rot = {0, 0, 0, 0, 0, 0};
    armModel.setJointRotations(rot);
    intermediatePositions.clear();
  } else if(key == 'w'){
    /*------------Test Quaternion Rotation-------------------*/
    //armModel.currentFrame = armModel.getRotationMatrix();
    //float[] q = rotateQuat(armModel.getQuaternion(), 0, new PVector(1, 1, 1));
    //println("q = " + q[0] + ", " + q[1] + ", " + q[2] + ", " + q[3]);
    //PVector wpr = quatToEuler(q).mult(RAD_TO_DEG);
    //println("ee = " + wpr);
    //println();
    //armModel.resetFrame(); 
    /*------------Test Conversion Functions------------------*/
    //float[] q = armModel.getQuaternion();
    //PVector wpr = armModel.getWPR();
    //float[] qP = eulerToQuat(wpr);
    //PVector wprP = quatToEuler(qP);
    //println("converted values:");
    //println(qP);
    //println(wprP.mult(RAD_TO_DEG));
    //println();
    armModel.currentFrame = armModel.getRotationMatrix();
  } else if(key == 'y'){
    float[] rot = {PI, 0, 0, 0, 0, PI};
    armModel.setJointRotations(rot);
    intermediatePositions.clear();
  } else if (key == ENTER && (armModel.activeEndEffector == ENDEF_CLAW || 
                              armModel.activeEndEffector == ENDEF_SUCTION)) { 
    // Pick up an object within reach of the EE when the 'ENTER' button is pressed for either
    // the suction or claw EE
    ToolInstruction pickup;
    
    if (armModel.endEffectorStatus == ON) {
      pickup = (armModel.activeEndEffector == ENDEF_CLAW) ? 
                new ToolInstruction("RO", 4, OFF) : 
                new ToolInstruction("DO", 101, OFF);
    } else {
      pickup = (armModel.activeEndEffector == ENDEF_CLAW) ? 
                new ToolInstruction("RO", 4, ON) : 
                new ToolInstruction("DO", 101, ON);
    }
    
    pickup.execute();
  } else if (keyCode == KeyEvent.VK_1) {
    // Front view
    panX = 0;
    panY = 0;
    myRotX = 0f;
    myRotY = 0f;
  } else if (keyCode == KeyEvent.VK_2) {
    // Back view
    panX = 0;
    panY = 0;
    myRotX = 0f;
    myRotY = PI;
  } else if (keyCode == KeyEvent.VK_3) {
    // Left view
    panX = 0;
    panY = 0;
    myRotX = 0f;
    myRotY = PI / 2f;
  } else if (keyCode == KeyEvent.VK_4) {
    // Right view
    panX = 0;
    panY = 0;
    myRotX = 0f;
    myRotY = 3f * PI / 2F;
  } else if (keyCode == KeyEvent.VK_5) {
    // Top view
    panX = 0;
    panY = 0;
    myRotX = 3f * PI / 2F;
    myRotY = 0f;
  } else if (keyCode == KeyEvent.VK_6) {
    // Bottom view
    panX = 0;
    panY = 0;
    myRotX = PI / 2f;
    myRotY = 0f;
  }
  
  if(keyCode == UP){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[0] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(keyCode == DOWN){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[1] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(keyCode == LEFT){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[2] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(keyCode == RIGHT){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[3] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(key == 'z'){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[4] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  } else if(key == 'x'){
    float[] angles = armModel.getJointRotations();
    calculateJacobian(angles);
    angles[5] += DEG_TO_RAD;
    armModel.setJointRotations(angles);
  }
  
  
  if (key == ' '){ 
    pan_normal();
  }
   
  if (keyCode == SHIFT){ 
    rotate_normal();
  }
}

//private void 

public void hide(){
   g1.hide();
   bt_show.show();
   bt_zoomin_shrink.show();
   bt_zoomout_shrink.show();
   bt_pan_shrink.show();
   bt_rotate_shrink.show(); 
   
   // release buttons of pan and rotate
   clickPan = 0;
   clickRotate = 0;
   cursorMode = ARROW;
   PImage[] pan_released = {loadImage("images/pan_35x20.png"), 
                            loadImage("images/pan_over.png"), 
                            loadImage("images/pan_down.png")};
                            
   cp5.getController("pan_normal")
      .setImages(pan_released);
   cp5.getController("pan_shrink")
      .setImages(pan_released);   
   doPan = false;    

   PImage[] rotate_released = {loadImage("images/rotate_35x20.png"), 
                               loadImage("images/rotate_over.png"), 
                               loadImage("images/rotate_down.png")};
                               
   cp5.getController("rotate_normal")
      .setImages(rotate_released);
   cp5.getController("rotate_shrink")
      .setImages(rotate_released);   
   doRotate = false;   
   
   cursor(cursorMode);
}

public void show(){
   g1.show();
   bt_show.hide();
   bt_zoomin_shrink.hide();
   bt_zoomout_shrink.hide();
   bt_pan_shrink.hide();
   bt_rotate_shrink.hide();
   
   // release buttons of pan and rotate
   clickPan = 0;
   clickRotate = 0;
   cursorMode = ARROW;
   PImage[] pan_released = {loadImage("images/pan_35x20.png"), 
                            loadImage("images/pan_over.png"), 
                            loadImage("images/pan_down.png")}; 
                            
   cp5.getController("pan_normal")
      .setImages(pan_released);
   doPan = false;    

   PImage[] rotate_released = {loadImage("images/rotate_35x20.png"), 
                               loadImage("images/rotate_over.png"),
                               loadImage("images/rotate_down.png")}; 
                               
   cp5.getController("rotate_normal")
      .setImages(rotate_released);
   doRotate = false;
   
   cursor(cursorMode);
}


public void mu() {
  if (mode == INSTRUCTION_NAV || mode == INSTRUCTION_EDIT) { saveState(); }
  
  contents = new ArrayList<ArrayList<String>>();
  
  contents.add( newLine("1 UTILITIES (NA)") );
  contents.add( newLine("2 TEST CYCLE (NA)") );
  contents.add( newLine("3 MANUAL FCTNS (NA)") );
  contents.add( newLine("4 ALARM (NA)") );
  contents.add(newLine("5 I/O (NA)"));
  contents.add(newLine("6 SETUP"));
  contents.add(newLine("7 FILE (NA)"));
  contents.add(newLine("8"));
  contents.add(newLine("9 USER (NA)"));
  contents.add(newLine("0 --NEXT--"));
  
  active_col = active_row = 0;
  mode = MENU_NAV;
  updateScreen(color(255,0,0), color(0));
}

// Data button
public void da() {
  contents = new ArrayList<ArrayList<String>>();
  
  contents.add( newLine("VIEW REGISTERS") );
  
  active_row = -1;
  active_col = text_render_start = 0;
  
  pickRegisterList();
}


public void NUM0(){
   addNumber("0");
}

public void NUM1(){
   addNumber("1");
}

public void NUM2(){
   addNumber("2");
}

public void NUM3(){
   addNumber("3");
}

public void NUM4(){
   addNumber("4");
}

public void NUM5(){
   addNumber("5");
}

public void NUM6(){
   addNumber("6");
}

public void NUM7(){
   addNumber("7");
}

public void NUM8(){
   addNumber("8");
}

public void NUM9(){
   addNumber("9");
}

public void addNumber(String number) {
  if (mode == SET_INSTRUCTION_REGISTER || mode == SET_INSTRUCTION_TERMINATION ||
      mode == JUMP_TO_LINE || mode == SET_DO_BRACKET || mode == SET_RO_BRACKET ||
      mode == SET_FRAME_INSTRUCTION_IDX) {
    workingText += number;
    options.set(1, workingText);
    updateScreen(color(255, 0, 0), color(0));
  } else if (mode == SET_INSTRUCTION_SPEED) {
    workingText += number;
    options.set(1, workingText + workingTextSuffix);
  } else if (mode == DIRECT_ENTRY_MODE || mode == INPUT_POINT_J || mode == INPUT_POINT_C) {
    if (active_row >= 0 && active_row < contents.size()) {
      String line = contents.get(active_row).get(0) + number;
      
      if (line.length() > 9 + which_option) {
        // Max length of a an input value
        line = line.substring(0,  9 + which_option);
      }
      
      // Concatenate the new digit
      contents.get(active_row).set(0, line);
    }
  } else if (mode == INPUT_FLOAT) {
    
    if (workingText.length() < 16) {
      workingText += number;
      options.set(2, workingText);
    }
  } else if (mode == INPUT_COMMENT_U || mode == INPUT_COMMENT_L) {
    
    if (workingText.length() < 16) {
      workingText += number;
      // TODO update screen
    }
  }
  
  updateScreen(color(255, 0, 0), color(0));
}

public void PERIOD() {
   if (NUM_MODE == ON){
      nums.add(-1);
   } else if (mode == DIRECT_ENTRY_MODE || mode == INPUT_POINT_J || mode == INPUT_POINT_C) {
     
    if (active_row >= 0 && active_row < contents.size()) {
      // Add decimal point
      String line = contents.get(active_row).get(0) + ".";
      
      if (line.length() > 9 + which_option) {
        // Max length of a an input value
        line = line.substring(0,  9 + which_option);
      }
      
      contents.get(active_row).set(0, line);
    }
  } else if (mode == INPUT_FLOAT) {
    
    if (workingText.length() < 16) {
      workingText += ".";
      options.set(2, workingText);
    }
  } else {
     workingText += ".";
  }
   
   updateScreen(color(255,0,0), color(0,0,0));
}

public void LINE() {
  if (mode == DIRECT_ENTRY_MODE || mode == INPUT_POINT_J || mode == INPUT_POINT_C) {
    
    if (active_row >= 0 && active_row < contents.size()) {
      String line = contents.get(active_row).get(0);
      
      // Mutliply current number by -1
      if (line.length() > (which_option + 1) && line.charAt(which_option) == '-') {
        line = line.substring(0, which_option) + line.substring(which_option + 1, line.length());
      } else if (line.length() > which_option) {
        line = line.substring(0, which_option) + "-" + line.substring(which_option, line.length());
      }
      
      if (line.length() > 9 + which_option) {
        // Max length of a an input value
        line = line.substring(0,  9 + which_option);
      }
      
      contents.get(active_row).set(0, line);
    }
    
    updateScreen(color(255, 0, 0), color(0));
  } else if ((mode != INPUT_COMMENT_U && mode != INPUT_COMMENT_L) && workingText != null && workingText.length() > 0) {
    // Mutliply current number by -1
    if (workingText.charAt(0) == '-') {
      workingText = workingText.substring(1);
    } else {
      workingText = "-" + workingText;
    }
    
    options.set(2, workingText);
    updateScreen(color(255,0,0), color(0,0,0));
  }
}

public void se(){
  // Save when exiting a program
   if (mode == INSTRUCTION_NAV || mode == INSTRUCTION_EDIT) { saveState(); }
   
   active_program = 0;
   active_instruction = 0;
   active_row = 0;
   active_col = -1;
   text_render_start = 0;
   mode = PROGRAM_NAV;
   clearScreen();
   loadPrograms();
   updateScreen(color(255,0,0), color(0,0,0));
}

public void up(){
   switch (mode){
      case PROGRAM_NAV:
         options = new ArrayList<String>();
         clearOptions();
         
         if (shift == ON && text_render_start > 0) {
           // Move display frame up an entire screen's display length
           int t = text_render_start;
           
           text_render_start = max(0, t - (ITEMS_TO_SHOW - 1));
           active_program = active_program + min(0, text_render_start - t);
         } else if (shift == OFF && active_program > 0) {
           // Move up a single row
           int i = active_program,
               r = active_row;
           
           active_program = max(0, i - 1);
           active_row = max(0, r + min(active_program - i, 0));
           text_render_start = text_render_start + min((active_program - i) - (active_row - r), 0);
         }
         
         loadPrograms();
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nProg: %d\nTRS: %d\n\n",
                             active_row, active_col, active_program, text_render_start);
         }
         
         break;
      case INSTRUCTION_NAV:
         options = new ArrayList<String>();
         clearOptions();
         
         if (shift == ON && text_render_start > 0) {
           // Move display frame up an entire screen's display length
           int t = text_render_start;
           
           text_render_start = max(0, t - (ITEMS_TO_SHOW - 1));
           active_instruction = active_instruction + min(0, text_render_start - t);
         } else if (shift == OFF && active_instruction > 0) {
           // Move up a single row
           int i = active_instruction,
               r = active_row;
           
           active_instruction = max(0, i - 1);
           //active_row = max(0, r + min(active_instruction - i, 0));
           //text_render_start = text_render_start + min((active_instruction - i) - (active_row - r), 0);
           active_row -= (active_row >= 1) ? 1 : 0;
           if(active_instruction < text_render_start)
             text_render_start -= 1;
         }
         
         active_col = max( 0, min( active_col, contents.get(active_row).size() - 1 ) );
         loadInstructions(active_program);
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
                             active_row, active_col, active_instruction, text_render_start);
         }
         
         break;
      case VIEW_REG:
      case VIEW_POS_REG_J:
      case VIEW_POS_REG_C:
         
         if (shift == ON && text_render_start > 0) {
           // Move display frame up an entire screen's display length
           int t = text_render_start;
           
           text_render_start = max(0, t - (ITEMS_TO_SHOW - 2));
           active_index = active_index + min(0, text_render_start - t);
         } else if (shift == OFF && active_index > 0) {
           // Move up a single row
           int i = active_index,
               r = active_row;
           
           active_index = max(0, i - 1);
           active_row = max(2, r + min(active_index - i, 0));
           text_render_start = text_render_start + min((active_index - i) - (active_row - r), 0);
         }
         
         active_col = max( 0, min( active_col, contents.get(active_row).size() - 1 ) );
         viewRegisters();
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nIdx: %d\nTRS: %d\n\n",
                             active_row, active_col, active_index, text_render_start);
         }
         
         break;
      case INSTRUCTION_EDIT:
      case PICK_FRAME_MODE:
      case PICK_FRAME_METHOD:
      case THREE_POINT_MODE:
      case SIX_POINT_MODE:
      case FOUR_POINT_MODE:
      case SET_DO_STATUS:
      case SET_RO_STATUS:
      case PICK_REG_LIST:
         which_option = max(0, which_option - 1);
         break;
      case MENU_NAV:
      case SETUP_NAV:
      case NAV_TOOL_FRAMES:
      case NAV_USER_FRAMES:
      case PICK_INSTRUCTION:
      case IO_SUBMENU:
      case SET_FRAME_INSTRUCTION:
      case EDIT_MENU:
         active_row = max(0, active_row - 1);
         break;
      case ACTIVE_FRAMES:
      case DIRECT_ENTRY_MODE:
      case INPUT_POINT_C:
      case INPUT_POINT_J:
         active_row = max(1, active_row - 1);
         break;
   }
   
   updateScreen(color(255,0,0), color(0,0,0));
}

public void dn(){
  int size;
   switch (mode){
      case PROGRAM_NAV:
         options = new ArrayList<String>();
         clearOptions();
         //if (active_program < programs.size()-1) {
         //  if(active_program - text_render_start == ITEMS_TO_SHOW - 1)
         //    text_render_start++;
         //  else
         //    active_row++;
           
         //  active_program++;
         //  active_col = 0;
         //}
         
         size = programs.size();
         
         if (shift == ON && ( (text_render_start + ITEMS_TO_SHOW) < size )) {
           // Move display frame down an entire screen's display length
           int t = text_render_start;
           
           text_render_start = min(text_render_start + ITEMS_TO_SHOW - 1, size - ITEMS_TO_SHOW);
           active_program = active_program + max(0, text_render_start - t);
         } else if (shift == OFF && active_program < (size - 1)) {
           // Move down one row
           int i = active_program,
               r = active_row;
           
           active_program = min(i + 1, size - 1);
           active_row = min(r + max(0, (active_program - i)), contents.size() - 1);
           text_render_start = text_render_start + max(0, (active_program - i) - (active_row - r));
         }
         
         loadPrograms();
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nProg: %d\nTRS: %d\n\n",
                             active_row, active_col, active_program, text_render_start);
         }
         
         break;
      case INSTRUCTION_NAV:
         options = new ArrayList<String>();
         clearOptions();
         size = programs.get(active_program).getInstructions().size();
         //if (active_instruction < size-1) {
         //  if(active_instruction - text_render_start == ITEMS_TO_SHOW - 1)
         //    text_render_start++;
         //  else
         //    active_row++;
         //  active_instruction++;
         //  active_col = 0;
         //}
         
         size = programs.get(active_program).getInstructions().size();
        
         if (shift == ON && ( (text_render_start + ITEMS_TO_SHOW) < size )) {
           // Move display frame down an entire screen's display length
           int t = text_render_start;
           
           text_render_start = min(text_render_start + ITEMS_TO_SHOW - 1, size - ITEMS_TO_SHOW);
           active_instruction = active_instruction + max(0, text_render_start - t);
         } else if (shift == OFF && active_instruction < (size - 1)) {
           // Move down one row
           int i = active_instruction,
               r = active_row;
           
           active_instruction = min(i + 1, size - 1);
           //active_row = min(r + max(0, (active_instruction - i)), contents.size() - 1);
           //text_render_start = text_render_start + max(0, (active_instruction - i) - (active_row - r));
           active_row += (active_row < ITEMS_TO_SHOW-1) ? 1 : 0;
           if(active_instruction > text_render_start+ITEMS_TO_SHOW-1)
             text_render_start += 1;
         }
         
         loadInstructions(active_program);
         
         if (DISPLAY_TEST_OUTPUT) {
           System.out.printf("\nRow: %d\nColumn: %d\nInst: %d\nTRS: %d\n\n",
                             active_row, active_col, active_instruction, text_render_start);
         }
         
         break;
      case VIEW_REG:
      case VIEW_POS_REG_J:
      case VIEW_POS_REG_C:
      
        size = (mode == VIEW_REG) ? REG.length : POS_REG.length;
        
        if (shift == ON && ( (text_render_start + ITEMS_TO_SHOW) < size )) {
          // Move display frame down an entire screen's display length
          int t = text_render_start;
          
          text_render_start = min(text_render_start + ITEMS_TO_SHOW - 2, size - (ITEMS_TO_SHOW - 1));
          active_index = active_index + max(0, text_render_start - t);
        } else if (shift == OFF && active_index < (size - 1)) {
          // Move down one row
          int i = active_index,
              r = active_row;
          
          active_index = min(i + 1, size - 1);
          active_row = min(r + max(0, (active_index - i)), contents.size() - 1);
          text_render_start = text_render_start + max(0, (active_index - i) - (active_row - r));
        }
        
        active_col = max( 0, min( active_col, contents.get(active_row).size() - 1 ) );
        viewRegisters();
        
        if (DISPLAY_TEST_OUTPUT) {
          System.out.printf("\nRow: %d\nColumn: %d\nIdx: %d\nTRS: %d\n\n",
                            active_row, active_col, active_index, text_render_start);
        }
        
        break;
      case INSTRUCTION_EDIT:
      case PICK_FRAME_MODE:
      case PICK_FRAME_METHOD:
      case THREE_POINT_MODE:
      case SIX_POINT_MODE:
      case FOUR_POINT_MODE:
      case SET_DO_STATUS:
      case SET_RO_STATUS:
      case PICK_REG_LIST:
         which_option = min(which_option + 1, options.size() - 1);
         break;
      case MENU_NAV:
      case SETUP_NAV:
      case NAV_TOOL_FRAMES:
      case NAV_USER_FRAMES:
      case ACTIVE_FRAMES:
      case DIRECT_ENTRY_MODE:
      case INPUT_POINT_C:
      case INPUT_POINT_J:
      case PICK_INSTRUCTION:
      case IO_SUBMENU:
      case SET_FRAME_INSTRUCTION:
      case EDIT_MENU:
         active_row = min(active_row  + 1, contents.size() - 1);
         break;
   }  
   updateScreen(color(255,0,0), color(0,0,0));
}

public void lt(){
   switch (mode){
      case PROGRAM_NAV:
          break;
      case INSTRUCTION_NAV:
          options = new ArrayList<String>();
          clearOptions();
          
          active_col = max(0, active_col - 1);
          
          updateScreen(color(255,0,0), color(0,0,0));
          break;
      case INSTRUCTION_EDIT:
          mode = INSTRUCTION_NAV;
          lt();
          break;
      case VIEW_REG:
      case VIEW_POS_REG_J:
      case VIEW_POS_REG_C:
        active_col = max(0, active_col - 1);
        updateScreen(color(255, 0, 0), color(0));
        
        break;
      case INPUT_COMMENT_U:
      case INPUT_COMMENT_L:
        active_col = max(0, active_col - 1);
        
        break;
   }
   
}


public void rt(){
  switch (mode){
      case PROGRAM_NAV:
          break;
      case INSTRUCTION_NAV:
          options = new ArrayList<String>();
          clearOptions();
          
          active_col = min(active_col + 1, contents.get(active_row).size() - 1);
          println("active column: " + active_col);
          updateScreen(color(255,0,0), color(0,0,0));
          break;
      case INSTRUCTION_EDIT:
          mode = INSTRUCTION_NAV;
          rt();
          break;
      case MENU_NAV:
          if (active_row == 5) { // SETUP
            contents = new ArrayList<ArrayList<String>>();
            
            contents.add( newLine("1 Prog Select (NA)") );
            contents.add( newLine("2 General (NA)") );
            contents.add( newLine("3 Call Guard (NA)") );
            contents.add( newLine("4 Frames") );
            contents.add( newLine("5 Macro (NA)") );
            contents.add( newLine("6 Ref Position (NA)") );
            contents.add( newLine("7 Port Init (NA)") );
            contents.add( newLine("8 Ovrd Select (NA)") );
            contents.add( newLine("9 User Alarm (NA)") );
            contents.add( newLine("0 --NEXT--") );
            
            active_col = active_row = 0;
            mode = SETUP_NAV;
            updateScreen(color(255,0,0), color(0));
          }
          break;
       case PICK_INSTRUCTION:
          if (active_row == 0) { // I/O
            contents = new ArrayList<ArrayList<String>>();
            
            contents.add( newLine("1 Cell Intface (NA)") );
            contents.add( newLine("2 Custom (NA)") );
            contents.add( newLine("3 Digital") );
            contents.add( newLine("4 Analog (NA)") );
            contents.add( newLine("5 Group (NA)") );
            contents.add( newLine("6 Robot") );
            contents.add( newLine("7 UOP (NA)") );
            contents.add( newLine("8 SOP (NA)") );
            contents.add( newLine("9 Interconnect (NA)") );
            
            active_col = active_row = 0;
            mode = IO_SUBMENU;
            updateScreen(color(255,0,0), color(0));
          } else if (active_row == 1) { // Offset/Frames
            
            contents = new ArrayList<ArrayList<String>>();
            
            contents.add( newLine("1 UTOOL_NUM") );
            contents.add( newLine("1 UFRAME_NUM") );
            
            mode = SET_FRAME_INSTRUCTION;
            active_col = active_row = 0;
            updateScreen(color(255,0,0), color(0));
          }
          break;
       case DIRECT_ENTRY_MODE:
       case INPUT_POINT_C:
       case INPUT_POINT_J:
         
         // Delete a digit from the being of the number entry
         if (shift == ON && active_row >= 0 && active_row < contents.size()) {
           String entry = contents.get(active_row).get(0),
                  new_entry = "";
           
            if (entry.length() > which_option) {
              new_entry = entry.substring(0, which_option);
              
              if (entry.charAt(which_option) == '-') {
                if (entry.length() > (which_option + 2)) {
                  // Keep negative sign until the last digit is removed
                  new_entry += "-" + entry.substring((which_option + 2), entry.length());
                }
              } else if (entry.length() > (which_option + 1)) {
                new_entry += entry.substring((which_option + 1), entry.length());
              }
            } else {
              // Blank entry
              new_entry = entry;
            }
            
            contents.get(active_row).set(0, new_entry);
         }
        
         updateScreen(color(255, 0, 0), color(0));
         break;
       case VIEW_REG:
       case VIEW_POS_REG_J:
       case VIEW_POS_REG_C:
         active_col = min(active_col + 1, contents.get(active_row).size() - 1);
         updateScreen(color(255, 0, 0), color(0));
         
         break;
       case INPUT_COMMENT_U:
       case INPUT_COMMENT_L:
       
         if (shift == ON) {
           // Delete key function
           if (workingText.length() > 1) {
             workingText = workingText.substring(1, workingText.length());
           } else {
             workingText = "";
           }
         } else {
           
           if (workingText.length() < 16 && active_col == (workingText.length() - 1)
                                         && workingText.charAt(active_col) != ' ') {
             // Add a blank entry if there is room for one
             workingText += " ";
           }
           
           active_col = min(active_col + 1, contents.get(active_row).size() - 1);
         }
         
         break;
   }
}

//toggle shift state and button highlight
public void sf(){
   if (shift == OFF){ 
	 shift = ON;
     ((Button)cp5.get("sf")).setColorBackground(color(255, 0, 0));
   }
   else{
     shift = OFF;
     ((Button)cp5.get("sf")).setColorBackground(color(127, 127, 255));
   }
}

public void st() {
   if (step == OFF){ 
     step = ON;
     ((Button)cp5.get("st")).setColorBackground(color(255, 0, 0));
   }
   else{
     step = OFF;
     ((Button)cp5.get("st")).setColorBackground(color(127, 127, 255));
   }
}

public void pr(){
   se();
}


public void goToEnterTextMode() {
    clearScreen();
    active_row = 0;
    active_col = -1;
    super_mode = mode;
    mode = ENTER_TEXT;
    
    inputProgramName();
}


public void f1() {
  switch (mode) {
    case PROGRAM_NAV:
      //shift = OFF;
      break;
    case INSTRUCTION_NAV:
      if (shift == ON) {
        
        PVector eep = armModel.getEEPos();
        eep = convertNativeToWorld(eep);
        Program prog = programs.get(active_program);
        int reg = prog.nextRegister();
        float[] q = armModel.getQuaternion();
        float[] j = armModel.getJointRotations();
        
        prog.addRegister(new Point(eep.x, eep.y, eep.z, q[0], q[1], q[2], q[3],
                                   j[0], j[1], j[2], j[3], j[4], j[5]), reg);
                                   
        MotionInstruction insert = new MotionInstruction(
          (curCoordFrame == COORD_JOINT ? MTYPE_JOINT : MTYPE_LINEAR),
          reg,
          false,
          (curCoordFrame == COORD_JOINT ? liveSpeed : liveSpeed*armModel.motorSpeed),
          0,
          activeUserFrame,
          activeToolFrame);
        prog.addInstruction(insert);
          
        active_instruction = prog.getInstructions().size() - 1;
        active_col = 0;
        /* 13 is the maximum number of instructions that can be displayed at one point in time */
        active_row = min(active_instruction, ITEMS_TO_SHOW - 1);
        text_render_start = active_instruction - active_row;
        
        loadInstructions(active_program);
        updateScreen(color(255,0,0), color(0,0,0));
      } else {
        
        contents = new ArrayList<ArrayList<String>>();
        
        contents.add( newLine("1 I/O") );
        contents.add( newLine("2 Offset/Frames") );
        contents.add( newLine("(Others not yet implemented)") );
        
        active_col = active_row = 0;
        mode = PICK_INSTRUCTION;
        updateScreen(color(255,0,0), color(0));
      }
      break;
    case NAV_TOOL_FRAMES:
      if (shift == ON) {
        
        super_mode = mode;
        curFrameIdx = active_row;
        loadFrameDetails();
      } else {
        // Set the current tool frame
        if (active_row >= 0) {
          activeToolFrame = active_row;
          // Update the Robot Arm's current frame rotation matrix
          if (curCoordFrame == COORD_TOOL) {
            armModel.currentFrame = toolFrames[activeToolFrame].getNativeAxes();
          }
        }
      }
      break;
    case NAV_USER_FRAMES:
      if (shift == ON) {
        
        super_mode = mode;
        curFrameIdx = active_row;
        loadFrameDetails();
      } else {
        // Set the current user frame
        if (active_row >= 0) {
          activeUserFrame = active_row;
          // Update the Robot Arm's current frame rotation matrix
          if (curCoordFrame == COORD_USER) {
            armModel.currentFrame = userFrames[activeUserFrame].getNativeAxes();
          }
        }
      }
      break;
    case ACTIVE_FRAMES:
      if (active_row == 1) {
        loadFrames(COORD_TOOL);
      } else if (active_row == 2) {
        loadFrames(COORD_USER);
      }
    case INSTRUCTION_EDIT:
      //shift = OFF;
      break;
    case THREE_POINT_MODE:
    case SIX_POINT_MODE:
    case FOUR_POINT_MODE:
      ref_point = (shift == ON) ? null : armModel.getEEPos();
      
      break;
    case VIEW_REG:
      loadInputRegisterValueMethod();
      
      break;
    case VIEW_POS_REG_J:
      if (active_col == 1) {
        workingText = "";
        // TODO name entry
      } else if (active_col >= 2) {
        // Bring up Point editing menu
        super_mode = mode;
        mode = INPUT_POINT_J;
        loadInputRegisterPointMethod();
      }
      
      break;
    case VIEW_POS_REG_C:
      if (active_col == 1) {
        workingText = "";
        // TODO name entry
      } else if (active_col >= 2) {
        // Bring up Point editing menu
        super_mode = mode;
        mode = INPUT_POINT_C;
        loadInputRegisterPointMethod();
      }
    
      break;
    case INPUT_COMMENT_U:
    case INPUT_COMMENT_L:
      char newChar = '\0';
      
      if (mode == INPUT_COMMENT_U) {
        newChar = (char)('A' + letterStates[0]);
      } else if (mode == INPUT_COMMENT_L) {
        newChar = (char)('a' + letterStates[0]);
      }
      
      // Insert a character A - F (or a - f)
      workingText = workingText.substring(0, active_col) + (newChar) + workingText.substring(active_col + 1, workingText.length());
      // Update and reset the letter states
      letterStates[0] = (letterStates[0] + 1) % 6;
      for (int idx = 1; idx < letterStates.length; ++idx) { letterStates[idx] = 0; }
      
      // TODO update contents
      
      break;
  }
}


public void f2() {
  if (mode == PROGRAM_NAV) {
    workingText = "";
    active_program = -1;
    goToEnterTextMode();
  } else if (mode == FRAME_DETAIL) {
    options = new ArrayList<String>();
    
    if (super_mode == NAV_USER_FRAMES) {
      options.add("1. Three Point");
      options.add("2. Four Point");
      options.add("3. Direct Entry");
    } else if (super_mode == NAV_TOOL_FRAMES) {
      options.add("1. Three Point");
      options.add("2. Six Point");
      options.add("3. Direct Entry");
    }
    mode = PICK_FRAME_METHOD;
    which_option = 0;
    updateScreen(color(255,0,0), color(0));
  } if (mode == NAV_TOOL_FRAMES) {
     
     // Reset the highlighted frame in the tool frame list
     if (active_row >= 0) {
        toolFrames[active_row] = new Frame();
        saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
      }
   } else if (mode == NAV_USER_FRAMES) {
     
     // Reset the highlighted frame in the user frames list
     if (active_row >= 0) {
       userFrames[active_row] = new Frame();
       saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
     }
   } else if (mode == ACTIVE_FRAMES) {
     // Reset the active frames for the User or Tool Coordinate Frames
     if (active_row == 1) {
       
       activeToolFrame = -1;
       
       // Leave the Tool Frame
       if (curCoordFrame == COORD_TOOL || curCoordFrame == COORD_WORLD) {
         curCoordFrame = COORD_WORLD;
         armModel.resetFrame();
       }
     } else if (active_row == 2) {
       activeUserFrame = -1;
       
       // Leave the User Frame
       if (curCoordFrame == COORD_USER) {
         curCoordFrame = COORD_WORLD;
         armModel.resetFrame();
       }
     }
     
     loadActiveFrames();
     updateScreen(color(255,0,0), color(0));
   } else if (mode == VIEW_REG || mode == VIEW_POS_REG_J || mode == VIEW_POS_REG_C) {
     pickRegisterList();
  } else if (mode == INPUT_COMMENT_U || mode == INPUT_COMMENT_L) {
    char newChar = '\0';
    
    if (mode == INPUT_COMMENT_U) {
      newChar = (char)('G' + letterStates[1]);
    } else if (mode == INPUT_COMMENT_L) {
      newChar = (char)('g' + letterStates[1]);
    }
    
    // Insert a character G - L (or g - l)
    workingText = workingText.substring(0, active_col) + (newChar) + workingText.substring(active_col + 1, workingText.length());
    // Update and reset the letter states
    letterStates[0] = 0;
    letterStates[1] = (letterStates[1] + 1) % 6;
    for (int idx = 2; idx < letterStates.length; ++idx) { letterStates[idx] = 0; }
    
    // TODO update contents
  }
}


public void f3() {
  if (mode == PROGRAM_NAV) {
    options = new ArrayList<String>();
    options.add("Delete this program?  F4 = YES, F5 = NO");
    which_option = 0;
    
    super_mode = mode;
    mode = CONFIRM_DELETE;
    updateScreen(color(255, 0, 0), color(0));
  } else if (mode == NAV_TOOL_FRAMES || mode == NAV_USER_FRAMES) {
    options = new ArrayList<String>();
    options.add("1.Tool Frame");
    options.add("2.User Frame");
    //options.add("3.Jog Frame");
    
    mode = PICK_FRAME_MODE;
    which_option = 0;
    updateScreen(color(255,0,0), color(0));
  } else if (mode == INPUT_COMMENT_U || mode == INPUT_COMMENT_L) {
    char newChar = '\0';
    
    if (mode == INPUT_COMMENT_U) {
      newChar = (char)('M' + letterStates[2]);
    } else if (mode == INPUT_COMMENT_L) {
      newChar = (char)('m' + letterStates[2]);
    }
    
    // Insert a character M - R (or m - r)
    workingText = workingText.substring(0, active_col) + (newChar) + workingText.substring(active_col + 1, workingText.length());
    // Update and reset the letter states
    letterStates[0] = 0;
    letterStates[1] = 0;
    letterStates[2] = (letterStates[2] + 1) % 6;
    letterStates[3] = 0;
    letterStates[4] = 0;
    
    // TODO update contents
  }
}


public void f4() {
   switch (mode){
      case INSTRUCTION_NAV:
         Instruction ins = programs.get(active_program).getInstructions().get(active_instruction);
         if (ins instanceof MotionInstruction) {
           switch (active_col){
             case 2: // motion type
                options = new ArrayList<String>();
                options.add("1.JOINT");
                options.add("2.LINEAR");
                options.add("3.CIRCULAR");
                //NUM_MODE = ON;
                mode = INSTRUCTION_EDIT;
                which_option = 0;
                break;
             case 3: // register type
                options = new ArrayList<String>();
                options.add("1.LOCAL(P)");
                options.add("2.GLOBAL(PR)");
                //NUM_MODE = ON;
                mode = INSTRUCTION_EDIT;
                which_option = 0;
                break;
             case 4: // register
                options = new ArrayList<String>();
                options.add("Use number keys to enter a register number (0-999)");
                workingText = "";
                options.add(workingText);
                mode = SET_INSTRUCTION_REGISTER;
                which_option = 0;
                break;
             case 5: // speed
                options = new ArrayList<String>();
                options.add("Use number keys to enter a new speed");
                MotionInstruction castIns = getActiveMotionInstruct();
                if (castIns.getMotionType() == MTYPE_JOINT) {
                  speedInPercentage = true;
                  workingTextSuffix = "%";
                } else {
                  workingTextSuffix = "mm/s";
                  speedInPercentage = false;
                }
                workingText = "";
                options.add(workingText + workingTextSuffix);
                mode = SET_INSTRUCTION_SPEED;
                which_option = 0;
                break;
             case 6: // termination type
                options = new ArrayList<String>();
                options.add("Use number keys to enter termination percentage (0-100; 0=FINE)");
                workingText = "";
                options.add(workingText);
                mode = SET_INSTRUCTION_TERMINATION;
                which_option = 0;
                break;
           }
         } 
         break;
     case CONFIRM_DELETE:
         if (super_mode == PROGRAM_NAV) {
           int progIdx = active_program;
           
           if (progIdx >= 0 && progIdx < programs.size()) {
             programs.remove(progIdx);
             
             if (active_program >= programs.size()) {
               active_program = programs.size() - 1;
               /* 13 is the maximum number of instructions that can be displayed at one point in time */
               active_row = min(active_program, ITEMS_TO_SHOW - 1);
               text_render_start = active_program - active_row;
             }
             
             mode = super_mode;
             super_mode = NONE;
             loadPrograms();
             updateScreen(color(255,0,0), color(0));
             saveState();
           }
         } else if (super_mode == INSTRUCTION_NAV) {
             Program prog = programs.get(active_program);
             prog.getInstructions().remove(active_instruction);
             deleteInstEpilogue();
         }
         break;
     case INPUT_COMMENT_U:
     case INPUT_COMMENT_L:
       char newChar = '\0';
       
       if (mode == INPUT_COMMENT_U) {
         newChar = (char)('S' + letterStates[3]);
       } else if (mode == INPUT_COMMENT_L) {
         newChar = (char)('s' + letterStates[3]);
       }
       
       // Insert a character S - X (or s - x)
       workingText = workingText.substring(0, active_col) + (newChar) + workingText.substring(active_col + 1, workingText.length());
       // Update and reset the letter states
       for (int idx = 0; idx < 3; ++idx) { letterStates[idx] = 0; }
       letterStates[3] = (letterStates[3] + 1) % 6;
       letterStates[4] = 0;
       
       
       // TODO update contents
       
       break;
   }
   
   updateScreen(color(255,0,0), color(0,0,0));
}

public void f5() {
  if (mode == INSTRUCTION_NAV) {
    if (shift == ON) {
      // overwrite current instruction
      PVector eep = armModel.getEEPos();
      eep = convertNativeToWorld(eep);
      Program prog = programs.get(active_program);
      int reg = prog.nextRegister();
      float[] q = armModel.getQuaternion();
      float[] j = armModel.getJointRotations();
      prog.addRegister(new Point(eep.x, eep.y, eep.z, q[0], q[1], q[2], q[3],
                                 j[0], j[1], j[2], j[3], j[4], j[5]), reg);
      MotionInstruction insert = new MotionInstruction(
        (curCoordFrame == COORD_JOINT ? MTYPE_JOINT : MTYPE_LINEAR),
        reg,
        false,
        (curCoordFrame == COORD_JOINT ? liveSpeed : liveSpeed*armModel.motorSpeed),
        0,
        activeUserFrame,
        activeToolFrame);
      prog.overwriteInstruction(active_instruction, insert);
      active_col = 0;
      loadInstructions(active_program);
      updateScreen(color(255,0,0), color(0,0,0));
    } else {
      if (active_col == 0) {
        // if you're on the line number, bring up a list of instruction editing options
        contents = new ArrayList<ArrayList<String>>();
        
        contents.add( newLine("1 Insert (NA)") );
        contents.add( newLine("2 Delete") );
        contents.add( newLine("3 Copy (NA)") );
        contents.add( newLine("4 Find (NA)") );
        contents.add( newLine("5 Replace (NA)") );
        contents.add( newLine("6 Renumber (NA)") );
        contents.add( newLine("7 Comment (NA)") );
        contents.add( newLine("8 Undo (NA)") );
        
        active_col = active_row = 0;
        mode = EDIT_MENU;
        updateScreen(color(255,0,0), color(0));
      } else if (active_col == 2 || active_col == 3) { 
        // show register contents if you're highlighting a register
        Instruction ins = programs.get(active_program).getInstructions().get(active_instruction);
         if (ins instanceof MotionInstruction) {
         MotionInstruction castIns = (MotionInstruction)ins;
          Point p = castIns.getVector(programs.get(active_program));
          options = new ArrayList<String>();
          options.add("Data of the point in this register (press ENTER to exit):");
          if (castIns.getMotionType() != MTYPE_JOINT) {
            options.add("x: " + p.pos.x + "  y: " + p.pos.y + "  z: " + p.pos.z);
            PVector wpr = quatToEuler(p.ori);
            options.add("w: " + wpr.x + "  p: " + wpr.y + "  r: " + wpr.z);
          } else {
            options.add("j1: " + p.joints[0] + "  j2: " + p.joints[1] + "  j3: " + p.joints[2]);
            options.add("j4: " + p.joints[3] + "  j5: " + p.joints[4] + "  j6: " + p.joints[5]);
          }
          mode = VIEW_REGISTER;
          which_option = 0;
          loadInstructions(active_program);
          updateScreen(color(255,0,0), color(0,0,0));
        }
      }
    }
  } else if (mode == THREE_POINT_MODE || mode == SIX_POINT_MODE || mode == FOUR_POINT_MODE) {
    if (teachPointTMatrices != null) {
      
      pushMatrix();
      resetMatrix();
      applyModelRotation(armModel, false);
      // Save current position of the EE
      float[][] tMatrix = getTransformationMatrix();
      
      // Add the current teach point to the running list of teach points
      if (which_option >= 0 && which_option < teachPointTMatrices.size()) {
        // Cannot override the origin once it is calculated for the six point method
        teachPointTMatrices.set(which_option, tMatrix);
      } else if ((mode == THREE_POINT_MODE && teachPointTMatrices.size() < 3) ||
                 (mode == FOUR_POINT_MODE && teachPointTMatrices.size() < 4) ||
                 (mode == SIX_POINT_MODE && teachPointTMatrices.size() < 6)) {
        
        // Add a new point as long as it does not exceed number of points for a specific method
        teachPointTMatrices.add(tMatrix);
        // increment which_option
        which_option = min(which_option + 1, options.size() - 1);
      }
      
      popMatrix();
    }
    
    int limbo = mode;
    loadFrameDetails();
    mode = limbo;
    loadPointList();
  } else if (mode == CONFIRM_DELETE) {
    
    if (super_mode == PROGRAM_NAV) {  
      options = new ArrayList<String>();
      which_option = -1;
      
      mode = super_mode;
      super_mode = NONE;
      updateScreen(color(250, 0, 0), color(0));
    } else if (super_mode == INSTRUCTION_NAV) {
      deleteInstEpilogue();
    }
  } else if (mode == INPUT_COMMENT_U || mode == INPUT_COMMENT_L) {
    char newChar = '\0';
    
    if (letterStates[4] < 2) {
      
      if (mode == INPUT_COMMENT_U) {
        newChar = (char)('Y' + letterStates[0]);
      } else if (mode == INPUT_COMMENT_L) {
        newChar = (char)('y' + letterStates[0]);
      }
    } else if (letterStates[4] == 2) {
      newChar = '_';
    } else if (letterStates[4] == 3) {
      newChar = '@';
    } else if (letterStates[4] == 4) {
      newChar = '*';
    } else if (letterStates[4] == 5) {
      newChar = '.';
    }
    
    // Insert a character Y, Z, (or y, z) _, @, *, .
    workingText = workingText.substring(0, active_col) + (newChar) + workingText.substring(active_col + 1, workingText.length());
    // Update and reset the letter states
    for (int idx = 0; idx < letterStates.length - 1; ++idx) { letterStates[idx] = 0; }
    letterStates[4] = (letterStates[2] + 1) % 6;
    
    // TODO update contents
  }
}

/* Stops all of the Robot's movement */
public void hd() {
  
  for (Model model : armModel.segments) {
    model.jointsMoving[0] = 0;
    model.jointsMoving[1] = 0;
    model.jointsMoving[2] = 0;
  }
  
  for (int idx = 0; idx < armModel.mvLinear.length; ++idx) {
    armModel.mvLinear[idx] = 0;
  }
  
  for (int idx = 0; idx < armModel.mvRot.length; ++idx) {
    armModel.mvRot[idx] = 0;
  }
  
  // Reset button highlighting
  for (int j = 1; j <= 6; ++j) {
    ((Button)cp5.get("JOINT" + j + "_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT" + j + "_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void fd() {
  if (shift == ON) {
    currentProgram = programs.get(active_program);
    if (step == OFF){
      currentInstruction = 0;
      executingInstruction = false;
      execSingleInst = false;
      doneMoving = false;
    }
    else {
      currentInstruction = active_instruction;
      executingInstruction = false;
      execSingleInst = true;
      doneMoving = false;
      //Instruction ins = programs.get(active_program).getInstructions().get(active_instruction);
      //if (ins instanceof MotionInstruction) {
      //  singleInstruction = (MotionInstruction)ins;
      //  setUpInstruction(programs.get(active_program), armModel, singleInstruction);
      
      //  if (active_instruction < programs.get(active_program).getInstructions().size()-1){
      //    active_instruction = (active_instruction+1);
      //  }
      
      //  loadInstructions(active_program);
      //  updateScreen(color(255,0,0), color(0));
      //}
    }
  }
  //shift = OFF;
}

public void bd(){
  
  if (shift == ON && step == ON && active_instruction > 0) {
    
    currentProgram = programs.get(active_program);
    Instruction ins = programs.get(active_program).getInstructions().get(active_instruction - 1);
    
    if (ins instanceof MotionInstruction) {
      
      singleInstruction = (MotionInstruction)ins;
      setUpInstruction(programs.get(active_program), armModel, singleInstruction);
      
      if (active_instruction > 0)
        active_instruction = (active_instruction-1);
      
      loadInstructions(active_program);
      updateScreen(color(255,0,0), color(0));
    }
  }
}

public void ENTER(){
  switch (mode){
    case NONE:
       break;
    case PROGRAM_NAV:
       active_instruction = 0;
       text_render_start = 0;
       active_row = 0;
       active_col = 0;
       mode = INSTRUCTION_NAV;
       clearScreen();
       loadInstructions(active_program);
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case INSTRUCTION_NAV:
       if (active_col == 2 || active_col == 3){
          mode = INSTRUCTION_EDIT;
          NUM_MODE = ON;
          num_info.setText(" ");
       }
       break;
    case INSTRUCTION_EDIT:
       MotionInstruction m = getActiveMotionInstruct();
       switch (active_col){
          case 2: // motion type
             if (which_option == 0){
                if (m.getMotionType() != MTYPE_JOINT) m.setSpeed(m.getSpeed()/armModel.motorSpeed);
                m.setMotionType(MTYPE_JOINT);
             }else if (which_option == 1){
               if (m.getMotionType() == MTYPE_JOINT) m.setSpeed(armModel.motorSpeed*m.getSpeed());
                m.setMotionType(MTYPE_LINEAR);
             }else if(which_option == 2){
               if (m.getMotionType() == MTYPE_JOINT) m.setSpeed(armModel.motorSpeed*m.getSpeed());
                m.setMotionType(MTYPE_CIRCULAR);
             }
             break;
          case 3: // register type
             if (which_option == 0) m.setGlobal(false);
             else m.setGlobal(true);
             break;
          case 4: // register
             break;
          case 5: // speed
             break;
          case 6: // termination type
             break;   
       }
       loadInstructions(active_program);
       mode = INSTRUCTION_NAV;
       NUM_MODE = OFF;
       options = new ArrayList<String>();
       which_option = -1;
       clearOptions();
       nums = new ArrayList<Integer>();
       clearNums();
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case SET_INSTRUCTION_SPEED:
       float tempSpeed = Float.parseFloat(workingText);
       if (tempSpeed >= 5.0f) {
         if (speedInPercentage) {
           if (tempSpeed > 100) tempSpeed = 10; 
           tempSpeed /= 100.0f;
         } else if (tempSpeed > armModel.motorSpeed) {
           tempSpeed = armModel.motorSpeed;
         }
         MotionInstruction castIns = getActiveMotionInstruct();
         castIns.setSpeed(tempSpeed);
         saveState();
       }
       loadInstructions(active_program);
       mode = INSTRUCTION_NAV;
       options = new ArrayList<String>();
       which_option = -1;
       clearOptions();
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case SET_INSTRUCTION_REGISTER:
       try {
         int tempRegister = Integer.parseInt(workingText);
         if (tempRegister >= 0 && tempRegister < POS_REG.length) {
           MotionInstruction castIns = getActiveMotionInstruct();
           castIns.setRegister(tempRegister);
         }
       } catch (NumberFormatException NFEx){ /* Ignore invalid numbers */ }
       
       loadInstructions(active_program);
       mode = INSTRUCTION_NAV;
       options = new ArrayList<String>();
       which_option = -1;
       clearOptions();
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case SET_INSTRUCTION_TERMINATION:
       float tempTerm = Float.parseFloat(workingText);
       if (tempTerm > 0.0f) {
         tempTerm /= 100.0f;
         MotionInstruction castIns = getActiveMotionInstruct();
         castIns.setTermination(tempTerm);
       }
       
       loadInstructions(active_program);
       mode = INSTRUCTION_NAV;
       options = new ArrayList<String>();
       which_option = -1;
       clearOptions();
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case JUMP_TO_LINE:
       active_instruction = Integer.parseInt(workingText)-1;
       if (active_instruction < 0) active_instruction = 0;
       if (active_instruction >= programs.get(active_program).getInstructions().size())
         active_instruction = programs.get(active_program).getInstructions().size()-1;
       mode = INSTRUCTION_NAV;
       options = new ArrayList<String>();
       which_option = -1;
       clearOptions();
       loadInstructions(active_program);
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case VIEW_REGISTER:
       mode = INSTRUCTION_NAV;
       options = new ArrayList<String>();
       which_option = -1;
       clearOptions();
       loadInstructions(active_program);
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case ENTER_TEXT:
       if (workingText.length() > 0) {
         int new_prog = addProgram(new Program(workingText));
         workingText = "";
         active_program = new_prog;
         active_instruction = 0;
         active_row = 0;
         active_col = 0;
         mode = INSTRUCTION_NAV;
         super_mode = NONE;
         clearScreen();
         options = new ArrayList<String>();
         loadInstructions(active_program);
         updateScreen(color(255,0,0), color(0,0,0));
       } else {
         mode = super_mode;
         super_mode = NONE;
         active_row = 0;
         active_col = 0;
         clearScreen();
         options = new ArrayList<String>();
         loadPrograms();
         updateScreen(color(255,0,0), color(0,0,0));
       }
       
       break;
    case SETUP_NAV:
       options = new ArrayList<String>();
       options.add("1.Tool Frame");
       options.add("2.User Frame");
       //options.add("3.Jog Frame");
       mode = PICK_FRAME_MODE;
       which_option = 0;
       updateScreen(color(255,0,0), color(0));
       break;
    case PICK_FRAME_MODE:
       options = new ArrayList<String>();
       clearOptions();
       
       if (which_option == 0) {
         loadFrames(COORD_TOOL);
       } else if (which_option == 1) {
         loadFrames(COORD_USER);
       } // Jog Frame not implemented
       
       which_option = -1;
       break;
    case PICK_FRAME_METHOD:
       if (which_option == 0) {
         which_option = 0;
         teachPointTMatrices = new ArrayList<float[][]>();
         loadFrameDetails();
         mode = THREE_POINT_MODE;
         loadPointList();
       } else if (which_option == 1) {
         which_option = 0;
         teachPointTMatrices = new ArrayList<float[][]>();
         loadFrameDetails();
         mode = (super_mode == NAV_TOOL_FRAMES) ? SIX_POINT_MODE : FOUR_POINT_MODE;
         loadPointList();
       } else if (which_option == 2) {
         options = new ArrayList<String>();
         which_option = -1;
         loadDirectEntryMethod();
       }
       break;
    case IO_SUBMENU:
       if (active_row == 2) { // digital
          options = new ArrayList<String>();
          options.add("Use number keys to enter DO[X]");
          workingText = "";
          options.add(workingText);
          mode = SET_DO_BRACKET;
          which_option = 0;
          updateScreen(color(255,0,0), color(0));
       } else if (active_row == 5) { // robot
          options = new ArrayList<String>();
          options.add("Use number keys to enter RO[X]");
          workingText = "";
          options.add(workingText);
          mode = SET_RO_BRACKET;
          which_option = 0;
          updateScreen(color(255,0,0), color(0));
       }
       break;
    case SET_DO_BRACKET:
    case SET_RO_BRACKET:
       options = new ArrayList<String>();
       options.add("ON");
       options.add("OFF");
       if (mode == SET_DO_BRACKET) mode = SET_DO_STATUS;
       else if (mode == SET_RO_BRACKET) mode = SET_RO_STATUS;
       which_option = 0;
       updateScreen(color(255,0,0), color(0));
       break;
    case SET_DO_STATUS:
    case SET_RO_STATUS:
       Program prog = programs.get(active_program);
       
       try {
         int bracketNum = Integer.parseInt(workingText);
         if (bracketNum >= 0) {
           ToolInstruction insert = new ToolInstruction(
              (mode == SET_DO_STATUS ? "DO" : "RO"),
              bracketNum,
              (which_option == 0 ? ON : OFF));
           prog.addInstruction(insert);
         }
       } catch (NumberFormatException NFEx) { /* Ignore invalid numbers */ }
       
       active_instruction = prog.getInstructions().size() - 1;
       active_col = 0;
       /* 13 is the maximum number of instructions that can be displayed at one point in time */
       active_row = min(active_instruction, ITEMS_TO_SHOW - 1);
       text_render_start = active_instruction - active_row;
       
       loadInstructions(active_program);
       active_row = contents.size()-1;
       mode = INSTRUCTION_NAV;
       options.clear();
       updateScreen(color(255,0,0), color(0,0,0));
       break;
    case SET_FRAME_INSTRUCTION:
        options = new ArrayList<String>();
        options.add("Select the index of the frame to use");
        workingText = "";
        options.add(workingText);
        
        which_option = 0;
        mode = SET_FRAME_INSTRUCTION_IDX;
        updateScreen(color(255, 0, 0), color(0));
        break;
    case SET_FRAME_INSTRUCTION_IDX:
       prog = programs.get(active_program);
       
       try {
         int num = Integer.parseInt(workingText)-1;
         if (num < -1) num = -1;
         else if (num >= userFrames.length) num = userFrames.length-1;
        
         int type = 0;
         if (active_row == 0) type = FTYPE_TOOL;
         else if (active_row == 1) type = FTYPE_USER;
         prog.addInstruction(new FrameInstruction(type, num));
      } catch (NumberFormatException NFEx) { /* Ignore invalid numbers */ }
       
      active_instruction = prog.getInstructions().size() - 1;
      active_col = 0;
      /* 13 is the maximum number of instructions that can be displayed at one point in time */
      active_row = min(active_instruction, ITEMS_TO_SHOW - 1);
      text_render_start = active_instruction - active_row;
      
      loadInstructions(active_program);
      mode = INSTRUCTION_NAV;
      which_option = -1;
      options.clear();
      updateScreen(color(255,0,0), color(0,0,0));
      break;
    case EDIT_MENU:
      if (active_row == 1) { // delete
         options = new ArrayList<String>();
         options.add("Delete this line? F4 = YES, F5 = NO");
         super_mode = INSTRUCTION_NAV;
         mode = CONFIRM_DELETE;
         which_option = 0;
         updateScreen(color(255,0,0), color(0,0,0));
      }
      break;
      
    case THREE_POINT_MODE:
    case FOUR_POINT_MODE:
    case SIX_POINT_MODE:
    
      if ((mode == THREE_POINT_MODE && teachPointTMatrices.size() == 3) ||
        (mode == FOUR_POINT_MODE && teachPointTMatrices.size() == 4) ||
        (mode == SIX_POINT_MODE && teachPointTMatrices.size() == 6)) {
  
        PVector origin = new PVector(0f, 0f, 0f), wpr = new PVector(0f, 0f, 0f);
        float[][] axes = new float[3][3];
        // Create identity matrix
        for (int diag = 0; diag < 3; ++diag) {
          axes[diag][diag] = 1f;
        }
        
        if (super_mode == NAV_TOOL_FRAMES && (mode == THREE_POINT_MODE || mode == SIX_POINT_MODE)) {
          // Calculate TCP via the 3-Point Method
          double[] tcp = calculateTCPFromThreePoints(teachPointTMatrices);
          
          if (tcp == null) {
            // Invalid point set
            loadFrameDetails();
            
            which_option = 0;
            options.add("Error: Invalid input values!");
            updateScreen(color(255, 0, 0), color(0));
        
            return;
          } else {
            origin = new PVector((float)tcp[0], (float)tcp[1], (float)tcp[2]);
          }
        } else if (mode == FOUR_POINT_MODE) {
          // Origin offset for the user frame
          origin = new PVector(teachPointTMatrices.get(3)[0][3], teachPointTMatrices.get(3)[1][3], teachPointTMatrices.get(3)[2][3]);
        }
        
        if (super_mode == NAV_USER_FRAMES || mode == SIX_POINT_MODE) {
          
          ArrayList<float[][]> axesPoints = new ArrayList<float[][]>();
          // Use the last three points to calculate the axes vectors
          if (mode == SIX_POINT_MODE) {
            axesPoints.add(teachPointTMatrices.get(3));
            axesPoints.add(teachPointTMatrices.get(4));
            axesPoints.add(teachPointTMatrices.get(5));
          } else {
            axesPoints.add(teachPointTMatrices.get(0));
            axesPoints.add(teachPointTMatrices.get(1));
            axesPoints.add(teachPointTMatrices.get(2));
          } 
          
          axes = createAxesFromThreePoints(axesPoints);
          
          if (axes == null) {
            // Invalid point set
            loadFrameDetails();
            
            which_option = 0;
            options.add("Error: Invalid input values!");
            updateScreen(color(255, 0, 0), color(0));
            return;
          }
          
          wpr = matrixToEuler(axes);
          
          if (DISPLAY_TEST_OUTPUT) { println(matrixToString(axes)); }
        }
          
        Frame[] frames = null;
        // Determine to which frame set (user or tool) to add the new frame
        if (super_mode == NAV_TOOL_FRAMES) {
          frames = toolFrames;
        } else if (super_mode == NAV_USER_FRAMES) {
          frames = userFrames;
        }
        
        if (frames != null) {
          
          if (curFrameIdx >= 0 && curFrameIdx < frames.length) {
            if (DISPLAY_TEST_OUTPUT) { System.out.printf("Frame set: %d\n", curFrameIdx); }
            
            frames[curFrameIdx] = new Frame();
            frames[curFrameIdx].setOrigin(origin);
            frames[curFrameIdx].setWpr(wpr);
            frames[curFrameIdx].setAxes(axes);
            saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
            
            // Set new Frame 
            if (super_mode == NAV_TOOL_FRAMES) {
              // Update the current frame of the Robot Arm
              activeToolFrame = curFrameIdx;
              armModel.currentFrame = userFrames[curFrameIdx].getNativeAxes();
            } else if (super_mode == NAV_USER_FRAMES) {
              // Update the current frame of the Robot Arm
              activeUserFrame = curFrameIdx;
              armModel.currentFrame = userFrames[curFrameIdx].getNativeAxes();
            }
          } else {
            System.out.printf("Error invalid index %d!\n", curFrameIdx);
          }
          
        } else {
          System.out.printf("Error: invalid frame list for mode: %d!\n", mode);
        }
        
        teachPointTMatrices = null;
        which_option = 0;
        options.clear();
        active_row = 0;
        
        if (super_mode == NAV_TOOL_FRAMES) {
          loadFrames(COORD_TOOL);
        } else if (super_mode == NAV_USER_FRAMES) {
          loadFrames(COORD_USER);
        } else {
          super_mode = MENU_NAV;
          mu();
        }
        
        mode = super_mode;
        super_mode = NONE;
        options.clear();
      }
  
      break;
    case DIRECT_ENTRY_MODE:
    
      options = new ArrayList<String>();
      which_option = -1;
      
      boolean error = false;
      // User defined x, y, z, w, p, and r values
      float[] inputs = new float[] { 0f, 0f, 0f, 0f, 0f, 0f };
      
      try {
        // Parse each input value
        for (int val = 0; val < inputs.length; ++val) {
          String str = contents.get(val + 1).get(0);
          
          if (str.length() < 4) {
            // No value entered
            error = true;
            options.add("All entries must have a value.");
            break;
          }
          
          // Remove prefix
          inputs[val] = Float.parseFloat(str.substring(3));
        }
      
      } catch (NumberFormatException NFEx) {
        // Invalid number
        error = true;
        options.add("Inputs must be real numbers.");
      }
      
      if (error) {
        which_option = 0;
        updateScreen(color(255, 0, 0) , color(0));
      } else {
        PVector origin = new PVector(inputs[0], inputs[1], inputs[2]),
                wpr = new PVector(inputs[3], inputs[4], inputs[5]);
        float[][] axesVectors = eulerToMatrix(wpr);
        
        origin.x = max(-9999f, min(origin.x, 9999f));
        origin.y = max(-9999f, min(origin.y, 9999f));
        origin.z = max(-9999f, min(origin.z, 9999f));
        wpr = matrixToEuler(axesVectors);
        
        if (DISPLAY_TEST_OUTPUT) { System.out.printf("\n\n%s\n%s\n%s\n", origin.toString(), wpr.toString(), matrixToString(axesVectors)); }
        
        Frame[] frames = null;
        // Determine to which frame set (user or tool) to add the new frame
        if (super_mode == NAV_TOOL_FRAMES) {
          frames = toolFrames;
        } else if (super_mode == NAV_USER_FRAMES) {
          frames = userFrames;
        }
      
        // Create axes vector and save the new frame
        if (frames != null && curFrameIdx >= 0 && curFrameIdx < frames.length) {
          if (DISPLAY_TEST_OUTPUT) { System.out.printf("Frame set: %d\n", curFrameIdx); }
          
          frames[curFrameIdx] = new Frame(origin, wpr, axesVectors);
          saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
          
          // Set New Frame
          if (super_mode == NAV_TOOL_FRAMES) {
            // Update the current frame of the Robot Arm
            activeToolFrame = curFrameIdx;
            armModel.currentFrame = userFrames[curFrameIdx].getNativeAxes();
          } else if (super_mode == NAV_USER_FRAMES) {
            // Update the current frame of the Robot Arm
            activeUserFrame = curFrameIdx;
            armModel.currentFrame = userFrames[curFrameIdx].getNativeAxes();
          }
          
          if (super_mode == NAV_TOOL_FRAMES) {
            loadFrames(COORD_TOOL);
          } else if (super_mode == NAV_USER_FRAMES) {
            loadFrames(COORD_USER);
          } else {
            super_mode = MENU_NAV;
            mu();
          }
          
          mode = super_mode;
          super_mode = NONE;
          options.clear();
        }
      }
      
      break;
    case PICK_REG_LIST:
      int modeCase = 0;
      
      if (super_mode == VIEW_REG) {
        modeCase = 1;
      } else if (super_mode == VIEW_POS_REG_J) {
        modeCase = 2;
      } else if (super_mode == VIEW_POS_REG_C) {
        modeCase = 3;
      }
      
      if (modeCase != 1 && which_option == 0) {
        // Register Menu
        mode = VIEW_REG;
      } else if ((modeCase == 1 && which_option == 0) ||
                 (modeCase != 1 && modeCase != 2 && which_option == 1)) {
        // Position Register Menu (in Joint mode)
        mode = VIEW_POS_REG_J;
      } else if ((modeCase == 0 && which_option == 2) ||
                 (modeCase != 0 && modeCase != 3 && which_option == 1)) {
        // Position Register Menu (in Cartesian mode)
        mode = VIEW_POS_REG_C;
      } else {
        mu();
      }
      
      active_row = 2;
      active_col = active_index = text_render_start = 0;
      super_mode = NONE;
      viewRegisters();
      
      break;
    case INPUT_FLOAT:
      
      Float input = null;
      
      try {
        // Read inputted Float value
        input = Float.parseFloat(workingText);
        // Clamp the value between -9999 and 9999, inclusive
        input = max(-9999f, min(input, 9999f));
      } catch (NumberFormatException NFEx) {
        // Invalid input value
        options = new ArrayList<String>();
        options.add("Only real numbers are acceptable input!");
        which_option = 0;
        
        mode = super_mode;
        super_mode = NONE;
        updateScreen(color(255, 0, 0), color(0));
        return;
      }
      
      if (active_index >= 0 && active_index < REG.length) {
          // Save inputted value
          REG[active_index].value = input;
          saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
      }
    
      mode = super_mode;
      super_mode = NONE;
      viewRegisters();
      updateScreen(color(255, 0, 0), color(0));
      
      break;
    case INPUT_POINT_C:
    case INPUT_POINT_J:
      // TODO save inputted values
      
      break;
  }
  println(mode);
}

public void ITEM() {
  if (mode == INSTRUCTION_NAV) {
    options = new ArrayList<String>();
    options.add("Use number keys to enter line number to jump to");
    workingText = "";
    options.add(workingText);
    mode = JUMP_TO_LINE;
    which_option = 0;
    updateScreen(color(255,0,0), color(0,0,0));
  }
}

public void LEFT() {
  if (mode == INPUT_FLOAT) {
    // Functions as a backspace key
    if (workingText.length() > 1) {
      workingText = workingText.substring(0, workingText.length() - 1);
    } else {
      workingText = "";
    }
    
    options.set(2, workingText);
  } else if (mode == DIRECT_ENTRY_MODE || mode == INPUT_POINT_J || mode == INPUT_POINT_C) {
    
    // backspace function for current row
    if (active_row >= 0 && active_row < contents.size()) {
      String line = contents.get(active_row).get(0);
      
      // Do not remove line prefix
      if (line.length() > which_option) {
        contents.get(active_row).set(0, line.substring(0, line.length() - 1));
      }
    }
  } else if (mode == INPUT_COMMENT_U || mode == INPUT_COMMENT_L) {
    // Backspace function
    if (workingText.length() > 1) {
      workingText = workingText.substring(0, workingText.length() - 1);
    } else {
      workingText = "";
    }
  }
  
  updateScreen(color(255, 0, 0), color(0));
}


public void COORD() {
  if (shift == ON) {
    // Show frame indices in the pendant window
    active_row = 1;
    active_col = 0;
    workingText = "";
    loadActiveFrames();
  } else {  
    // Update the coordinate mode
    updateCoordinateMode(armModel);
    liveSpeed = 0.1f;
  }
}

public void SPEEDUP() {
  if (liveSpeed == 0.01f) liveSpeed += 0.04f; 
  else if (liveSpeed < 0.5f) liveSpeed += 0.05f;
  else if (liveSpeed < 1) liveSpeed += 0.1f;
  if (liveSpeed > 1) liveSpeed = 1;
}


public void SLOWDOWN() {
  if (liveSpeed > 0.5f) liveSpeed -= 0.1f;
  else if (liveSpeed > 0) liveSpeed -= 0.05f;
  if (liveSpeed < 0.01f) liveSpeed = 0.01f;
}


/* navigation buttons */
// zoomin button when interface is at full size
public void zoomin_normal(){
   myscale *= 1.1f;
}

// zoomin button when interface is minimized
public void zoomin_shrink(){
   zoomin_normal();
}

// zoomout button when interface is at full size
public void zoomout_normal(){
   myscale *= 0.9f;
}

// zoomout button when interface is minimized
public void zoomout_shrink(){
   zoomout_normal();
}

// pan button when interface is at full size
public void pan_normal(){
  clickPan += 1;
  if ((clickPan % 2) == 1){
     if((clickRotate % 2) == 1){
       rotate_normal();
     }
     
     cursorMode = HAND;
     PImage[] pressed = {loadImage("images/pan_down.png"), 
                         loadImage("images/pan_down.png"), 
                         loadImage("images/pan_down.png")};
                         
     cp5.getController("pan_normal")
        .setImages(pressed);
  }
  else{
     cursorMode = ARROW;
     PImage[] released = {loadImage("images/pan_35x20.png"), 
                          loadImage("images/pan_over.png"), 
                          loadImage("images/pan_down.png")};
                          
     cp5.getController("pan_normal")
        .setImages(released);
     doPan = false;   
  }
  
  cursor(cursorMode);
}

// pan button when interface is minimized
public void pan_shrink(){
  pan_normal();
}

// rotate button when interface is at full size
public void rotate_normal(){
   clickRotate += 1;
   if ((clickRotate % 2) == 1){
     if((clickPan % 2) == 1){
       pan_normal();
     }
     
     cursorMode = MOVE;
     PImage[] pressed = {loadImage("images/rotate_down.png"), 
                         loadImage("images/rotate_down.png"), 
                         loadImage("images/rotate_down.png")};
                         
     cp5.getController("rotate_normal")
        .setImages(pressed);
  }
  else{
     cursorMode = ARROW;
     PImage[] released = {loadImage("images/rotate_35x20.png"), 
                          loadImage("images/rotate_over.png"), 
                          loadImage("images/rotate_down.png")};
                          
     cp5.getController("rotate_normal")
        .setImages(released);
     doRotate = false;   
  }
  
  cursor(cursorMode);
}

// rotate button when interface is minized
public void rotate_shrink(){
  rotate_normal();
}

public void record_normal(){
   if (record == OFF){
      record = ON;
      PImage[] record = {loadImage("images/record-on.png"), 
                         loadImage("images/record-on.png"),
                         loadImage("images/record-on.png")};   
      bt_record_normal.setImages(record);
      new Thread(new RecordScreen()).start();
   }else{
      record = OFF;
      PImage[] record = {loadImage("images/record-35x20.png"), 
                         loadImage("images/record-over.png"), 
                         loadImage("images/record-on.png")};   
      bt_record_normal.setImages(record);
      
   }
}

public void EE(){
  armModel.activeEndEffector++;
  if (armModel.activeEndEffector > ENDEF_CLAW) armModel.activeEndEffector = 0;
  // Drop an object if held by the Robot currently
  armModel.releaseHeldObject();
  // TODO collision checking if an object was held by the Robot
}

/**
 * Updates the motion of one of the Robot's joints based on
 * the joint index given and the value of dir (-/+ 1). The
 * Robot's joint indices range from 0 to 5. If the joint
 * Associate with the given index is already in motion,
 * in either direction, then calling this method for that
 * joint index will stop that joint's motion.
 */
public void activateLiveJointMotion(int joint, int dir) {
  
  if (armModel.segments.size() >= joint+1) {

    Model model = armModel.segments.get(joint);
    // Checks all rotational axes
    for (int n = 0; n < 3; n++) {
    
      if (model.rotations[n]) {
      
        if (model.jointsMoving[n] == 0) {
          model.jointsMoving[n] = dir;
        } else {
          model.jointsMoving[n] = 0;
        }
      }
    }
  }
}

/**
 * Updates the motion of the Robot with respect to one of the World axes for
 * either linear or rotational motion around the axis. Similiar to the
 * activateLiveJointMotion() method, calling this method for an axis, in which
 * the Robot is already moving, will result in the termination of the Robot's
 * motion in that axis. Rotational and linear motion for an axis are mutually
 * independent in this regard.
 * 
 * @param axis        The axis of movement for the robotic arm:
                      x - 0, y - 2, z - 1, w - 3, p - 5, r - 4
 * @pararm dir        +1 or -1: indicating the direction of motion
 *
 */
public void activateLiveWorldMotion(int axis, int dir) {
  armModel.tgtPos = armModel.getEEPos();
  armModel.tgtRot = armModel.getQuaternion();
  
  if (axis >= 0 && axis < 3) {
    if (armModel.mvLinear[axis] == 0) {
      //Begin movement on the given axis in the given direction
      armModel.mvLinear[axis] = dir;
    } else {
      //Halt movement
      armModel.mvLinear[axis] = 0;
    }
  }
  else if(axis >= 3 && axis < 6){
    axis -= 3;
    if(armModel.mvRot[axis] == 0){
      armModel.mvRot[axis] = dir;
    }
    else{
      armModel.mvRot[axis] = 0;
    }
  }
}

public void JOINT1_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(0, -1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(0, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT1_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT1_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT1_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT1_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT1_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT1_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(0, 1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(0, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT1_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT1_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT1_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    //stopping movement, set both buttons to default
    ((Button)cp5.get("JOINT1_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT1_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT2_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(1, -1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(2, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT2_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT2_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT2_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT2_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT2_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT2_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(1, 1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(2, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT2_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT2_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT2_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT2_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT2_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT3_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(2, -1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(1, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT3_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT3_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT3_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT3_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT3_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT3_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(2, 1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(1, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT3_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT3_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT3_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT3_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT3_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT4_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(3, -1);
  } else  {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(3, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT4_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT4_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT4_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else {
    ((Button)cp5.get("JOINT4_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT4_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT4_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(3, 1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(3, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT4_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT4_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT4_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT4_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT4_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT5_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(4, -1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(5, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT5_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT5_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT5_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT5_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT5_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT5_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(4, 1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(5, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT5_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT5_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT5_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT5_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT5_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT6_NEG() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(5, -1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(4, -1);
  }
  
  int c1 = ((Button)cp5.get("JOINT6_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT6_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT6_NEG")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT6_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT6_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void JOINT6_POS() {
  
  if (curCoordFrame == COORD_JOINT) {
    // Move single joint
    activateLiveJointMotion(5, 1);
  } else {
    // Move entire robot in a single axis plane
    activateLiveWorldMotion(4, 1);
  }
  
  int c1 = ((Button)cp5.get("JOINT6_NEG")).getColor().getBackground();
  int c2 = ((Button)cp5.get("JOINT6_POS")).getColor().getBackground();
  
  if(c1 == COLOR_DEFAULT && c2 == COLOR_DEFAULT){
    //both buttons have the default color, set this one to highlight
    ((Button)cp5.get("JOINT6_POS")).setColorBackground(COLOR_ACTIVE);
  }
  else{
    ((Button)cp5.get("JOINT6_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT6_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

//turn of highlighting on all active movement buttons
public void resetButtonColors(){
  for(int i = 1; i <= 6; i += 1){
    ((Button)cp5.get("JOINT"+i+"_NEG")).setColorBackground(COLOR_DEFAULT);
    ((Button)cp5.get("JOINT"+i+"_POS")).setColorBackground(COLOR_DEFAULT);
  }
}

public void updateButtonColors(){
  for(int i = 0; i < 6; i += 1){
    Model m = armModel.segments.get(i);
    for(int j = 0; j < 3; j += 1){
      if(m.rotations[j] && m.jointsMoving[j] == 0){
        ((Button)cp5.get("JOINT"+(i+1)+"_NEG")).setColorBackground(COLOR_DEFAULT);
        ((Button)cp5.get("JOINT"+(i+1)+"_POS")).setColorBackground(COLOR_DEFAULT);
      }
    }
  }
}

// update what displayed on screen
public void updateScreen(int active, int normal){
   int next_px = display_px;
   int next_py = display_py;
   
   if (cp5.getController("-1") != null) cp5.getController("-1").remove();
   
   // display the name of the program that is being edited 
   switch (mode){
      case INSTRUCTION_NAV:
         cp5.addTextlabel("-1")
            .setText(programs.get(active_program).getName())
            .setPosition(next_px, next_py)
            .setColorValue(normal)
            .show()
            .moveTo(g1)
            ;
         next_px = display_px;
         next_py += 14;
         break;
      case INSTRUCTION_EDIT:
      case SET_INSTRUCTION_SPEED:
      case SET_INSTRUCTION_REGISTER:
      case SET_INSTRUCTION_TERMINATION:
         cp5.addTextlabel("-1")
            .setText(programs.get(active_program).getName()) 
            .setPosition(next_px, next_py)
            .setColorValue(normal)
            .show()
            .moveTo(g1)
            ;
         next_px = display_px;
         next_py += 14;
         break;
   }
   
   // clear main list
   for (int i = 0; i < ITEMS_TO_SHOW*8; i++) {
     if (cp5.getGroup(Integer.toString(i)) != null){
       cp5.getGroup(Integer.toString(i)).remove();
     }
     else if (cp5.getController(Integer.toString(i)) != null){
       cp5.getController(Integer.toString(i)).remove();
     }
   }

   // display the main list on screen
   index_contents = 1;
   for(int i=0;i<contents.size();i++){
     ArrayList<String> temp = contents.get(i);
     if(i == active_row){
       cp5.addTextarea(Integer.toString(index_contents))
         .setText("")
         .setPosition(next_px, next_py)
         .setSize(10, 20)
         .setColorBackground(color(15))
         .hideScrollbar()
         .moveTo(g1)
         ;
     }
     else{
       cp5.addTextarea(Integer.toString(index_contents))
         .setText("")
         .setPosition(next_px, next_py)
         .setSize(10, 20)
         .setColorBackground(color(240))
         .hideScrollbar()
         .moveTo(g1)
         ;
     }
     index_contents++;
     next_px += 10;
     
     for (int j=0;j<temp.size();j++){
       if (i == active_row && j != active_col){
         cp5.addTextarea(Integer.toString(index_contents))
           .setText(temp.get(j))
           .setFont(fnt)
           .setPosition(next_px, next_py)
           .setSize(temp.get(j).length()*8 + 18, 20)
           .setLineHeight(18)
           .setColorValue(color(240))
           .setColorBackground(color(15))
           .hideScrollbar()
           .moveTo(g1)
           ;
       }
       else{
         cp5.addTextarea(Integer.toString(index_contents))
           .setText(temp.get(j))
           .setFont(fnt)
           .setPosition(next_px, next_py)
           .setSize(temp.get(j).length()*8 + 18, 20)
           .setLineHeight(18)
           .setColorValue(color(15))
           .setColorBackground(color(240))
           .setColorValue(normal)
           .hideScrollbar()
           .moveTo(g1)
           ;  
       }
       index_contents++;
       next_px += temp.get(j).length() * 8 + 18; 
     }
     next_px = display_px;
     next_py += 20;
   }
   
   // display options for an element being edited
   next_py += 14;
   index_options = 100;
   if (options.size() > 0){
     for(int i=0;i<options.size();i++){
       if (i==which_option){
         cp5.addTextlabel(Integer.toString(index_options))
           .setText(options.get(i))
           .setPosition(next_px, next_py)
           .setColorValue(active)
           .moveTo(g1)
           ;
       }else{
         cp5.addTextlabel(Integer.toString(index_options))
           .setText(options.get(i))
           .setPosition(next_px, next_py)
           .setColorValue(normal)
           .moveTo(g1)
           ;
       }
        
       index_options++;
       next_px = display_px;
       next_py += 14;    
     }
   }
   
   // display the numbers that the user has typed
   next_py += 14;
   index_nums = 1000;
   if (nums.size() > 0){
      for(int i=0;i<nums.size();i++){
         if (nums.get(i) == -1){
            cp5.addTextlabel(Integer.toString(index_nums))
               .setText(".")
               .setPosition(next_px, next_py)
               .setColorValue(normal)
               .moveTo(g1)
               ;
         }else{
            cp5.addTextlabel(Integer.toString(index_nums))
               .setText(Integer.toString(nums.get(i)))
               .setPosition(next_px, next_py)
               .setColorValue(normal)
               .moveTo(g1)
               ;
         }
         
         index_nums++;
         next_px += 5;   
      }
   }
   
   // display the comment for the user's input
   num_info.setPosition(next_px, next_py)
           .setColorValue(normal) 
           .show()
           ;
   next_px = display_px;
   next_py += 14;   
   
   // display hints for function keys
   next_py += 100;
   String text = null;
   
   if (mode == PROGRAM_NAV) {
     
     text = "F2: CREATE     F3: DELETE";
   } else if (mode == INSTRUCTION_NAV) {
     
     text = "SHIFT+F1: NEW PT     F4: CHOICE     F5: VIEW REG     SHIFT+F5: OVERWRITE";
   } else if (mode == NAV_TOOL_FRAMES || mode == NAV_USER_FRAMES) {
     
     text = "F1: SET     SHIFT+F1: DETAIL     F2: RESET     F3: SWITCH";
   } else if (mode == FRAME_DETAIL) {
     
     text = "F2: METHOD";
   } else if (mode == THREE_POINT_MODE || mode == FOUR_POINT_MODE || mode == SIX_POINT_MODE) {
     
     text = "F1: SAV REF PT     SHIFT+F1: RMV REF PT     SHIFT+F5: RECORD";
   } else if (mode == ACTIVE_FRAMES) {
     
     text = "F1: LIST     F2: RESET";
   } else if (mode == VIEW_REG || mode == VIEW_POS_REG_C || mode == VIEW_POS_REG_J) {
     
     text = "F1: EDIT     F2: SWITCH";
   } else if (mode == INPUT_COMMENT_U || mode == INPUT_COMMENT_L) {
     text = "F1: ABCDEF     F2: GHIJKL     F3: MNOPQR     F4: STUVWX     F5: YZ_@*.";
   }
   
   
   if (text != null) {
     fn_info.setText(text)
                 .setPosition(next_px, display_py+display_height-15)
                 .setColorValue(normal)
                 .show()
                 .moveTo(g1)
                 ;
   } else {
     fn_info.setText("")
                   .show()
                   .moveTo(g1)
                   ;
   }
   
} // end updateScreen()

// clear screen
public void clearScreen(){
   clearContents();
   clearOptions();
   
   // hide the text labels that show the start and end of a program
   if (mode != INSTRUCTION_NAV && mode != INSTRUCTION_EDIT){
      if (cp5.getController("-1") != null){
           cp5.getController("-1")
              .remove()
              ;
      }     
      if (cp5.getController("-2") != null){
           cp5.getController("-2")
              .remove()
              ;   
      }
      fn_info.remove();
   }
   
   clearNums();
   
   cp5.update();
   contents = new ArrayList<ArrayList<String>>();
}

public void clearContents(){
   for(int i=0;i<index_contents;i++){
     if(cp5.getController(Integer.toString(i)) != null)
       cp5.getController(Integer.toString(i)).remove();
     else if(cp5.getGroup(Integer.toString(i)) != null)
       cp5.getGroup(Integer.toString(i)).remove();
   }
   index_contents = 0;
}

public void clearOptions(){
   for(int i=100;i<index_options;i++){
      cp5.get(Integer.toString(i)).remove();
   }
   index_options = 100;
}

public void clearNums(){
   for(int i=1000;i<index_nums;i++){
      cp5.getController(Integer.toString(i)).remove();
   }
   index_nums = 1000;
}

/**
 * Displays the Interface for inputting the name of a program.
 */
public void inputProgramName() {
  active_row = active_col = -1;
  contents = new ArrayList<ArrayList<String>>();
  
  contents.add( newLine("") );
  contents.add( newLine("(ENTER: confirm name)") );
  contents.add( newLine("") );
  contents.add( newLine("") );
  contents.add( newLine("Program Name:   " + workingText) );
  
  which_option = -1;
  options = new ArrayList<String>();
  updateScreen(color(0), color(0));
}

/* Loads the set of Frames that correspond to the given coordinate frame.
 * Only COORD_TOOL and COOR_USER have Frames sets as of now.
 * 
 * @param coorFrame  the integer value representing the coordinate frame
 *                   of the desired frame set
 */
public void loadFrames(int coordFrame) {
  
  Frame[] frames = null;
  
  if (coordFrame == COORD_TOOL) {
    frames = toolFrames;
    mode = NAV_TOOL_FRAMES;
  } else if (coordFrame == COORD_USER) {
    frames = userFrames;
    mode = NAV_USER_FRAMES;
  }
  // Only the Tool and User Frame lists have been implemented
  if (frames != null) {
    contents = new ArrayList<ArrayList<String>>();
    
    for (int idx = 0; idx < frames.length; ++idx) {
      // Display each frame on its own line
      Frame frame = frames[idx];
      contents.add ( newLine( String.format("%d) %s", idx + 1, frame.getOrigin()) ) );
    }
    
    active_col = active_row = 0;
    updateScreen(color(255,0,0), color(0));
  }
}

/**
 * Displays the points along with their respective titles for the
 * current frame teach method (discluding the Direct Entry method).
 */
public void loadPointList() {
  options = new ArrayList<String>();
  
  if (teachPointTMatrices != null) {
  
    ArrayList<String> limbo = new ArrayList<String>();
    // Display TCP teach points
    if ((super_mode == NAV_TOOL_FRAMES && mode == THREE_POINT_MODE) || mode == SIX_POINT_MODE) {
      limbo.add("First Approach Point: ");
      limbo.add("Second Approach Point: ");
      limbo.add("Third Approach Point: ");
    }
    // Display Axes Vectors teach points
    if ((super_mode == NAV_USER_FRAMES && mode == THREE_POINT_MODE) || mode == FOUR_POINT_MODE || mode == SIX_POINT_MODE) {
      
      limbo.add("Orient Origin Point: ");
      limbo.add("X Direction Point: ");
      limbo.add("Y Direction Point: ");
    }
    // Display origin offset point
    if (super_mode == NAV_USER_FRAMES && mode == FOUR_POINT_MODE) {
      // Name of fourth point for the four point method?
      limbo.add("Origin: ");
    }
    
    int size = teachPointTMatrices.size();
    // Determine if the point has been set yet
    for (int idx = 0; idx < limbo.size(); ++idx) {
      // Add each line to options
      options.add( limbo.get(idx) + ((size > idx) ? "RECORDED" : "UNINIT") );
    }
  } else {
    // No teach points
    options.add("Error: teachPointTMatrices not set!");
  }
  
  updateScreen(color(255,0,0), color(0));
}

/**
 * Transitions to the Direct Entry menu, which resembles
 * the Frame Detail menu, however, the user is allowed
 * to input values for the x, y, z, w, p, r fields.
 */
public void loadDirectEntryMethod() {
  contents = new ArrayList<ArrayList<String>>();
  
  String str = "";
  
  if (super_mode == NAV_TOOL_FRAMES) {
    str = "TOOL FRAME ";
  } else if (super_mode == NAV_USER_FRAMES) {
    str = "USER FRAME ";
  }
  
  contents.add( newLine(str) );
  
  contents.add( newLine("X: 0.0") );
  contents.add( newLine("Y: 0.0") );
  contents.add( newLine("Z: 0.0") );
  contents.add( newLine("W: 0.0") );
  contents.add( newLine("P: 0.0") );
  contents.add( newLine("R: 0.0") );
  
  // Defines the length of a line's prefix
  which_option = 3;
  active_row = 1;
  active_col = 0;
  mode = DIRECT_ENTRY_MODE;
  updateScreen(color(255, 0, 0), color(0));
}

/**
 * Given a valid set of at least 3 points, this method will return the average
 * TCP point. If more than three points exist in the list then, only the first
 * three are used. If the list contains less than 3 points, then null is returned.
 * If an avergae TCP cannot be calculated from the given points then null is
 * returned as well.
 *
 * @param points  a set of at least 3 4x4 transformation matrices representating
 *                the position and orientation of three points in space
 */
public double[] calculateTCPFromThreePoints(ArrayList<float[][]> points) {
  
  if (points != null && points.size() >= 3) {
      /****************************************************************
         Three Point Method Calculation
         
         ------------------------------------------------------------
         A, B, C      transformation matrices
         Ar, Br, Cr   rotational portions of A, B, C respectively
         At, Bt, Ct   translational portions of A, B, C repectively
         x            TCP point with respect to the EE
         ------------------------------------------------------------
         
         Ax = Bx = Cx
         Ax = (Ar)x + At
         
         (A - B)x = 0
         (Ar - Br)x + At - Bt = 0
         
         Ax + Bx - 2Cx = 0
         (Ar + Br - 2Cr)x + At + Bt - 2Ct = 0
         (Ar + Br - 2Cr)x = 2Ct - At - Bt
         x = (Ar + Br - 2Cr) ^ -1 * (2Ct - At - Bt)
         
       ****************************************************************/
      RealVector avg_TCP = new ArrayRealVector(new double[] {0.0f, 0.0f, 0.0f} , false);
      
      for (int idxC = 0; idxC < 3; ++idxC) {
        
        int idxA = (idxC + 1) % 3,
            idxB = (idxA + 1) % 3;
        
        if (DISPLAY_TEST_OUTPUT) { System.out.printf("\nA = %d\nB = %d\nC = %d\n\n", idxA, idxB, idxC); }
        
        RealMatrix Ar = new Array2DRowRealMatrix(floatToDouble(points.get(idxA), 3, 3));
        RealMatrix Br = new Array2DRowRealMatrix(floatToDouble(points.get(idxB), 3, 3));
        RealMatrix Cr = new Array2DRowRealMatrix(floatToDouble(points.get(idxC), 3, 3));
        
        double [] t = new double[3];
        for (int idx = 0; idx < 3; ++idx) {
          // Build a double from the result of the translation portions of the transformation matrices
          t[idx] = 2 * points.get(idxC)[idx][3] - ( points.get(idxA)[idx][3] + points.get(idxB)[idx][3] );
        }
        
        /* 2Ct - At - Bt */
        RealVector b = new ArrayRealVector(t, false);
        /* Ar + Br - 2Cr */
        RealMatrix R = ( Ar.add(Br) ).subtract( Cr.scalarMultiply(2) );
        
        /* (R ^ -1) * b */
        avg_TCP = avg_TCP.add( (new SingularValueDecomposition(R)).getSolver().getInverse().operate(b) );
      }
      
      /* Take the average of the three cases: where C = the first point, the second point, and the third point */
      avg_TCP = avg_TCP.mapMultiply( 1.0f / 3.0f );
      
      if (DISPLAY_TEST_OUTPUT) {
        for (int pt = 0; pt < 3 && pt < points.size(); ++pt) {
          // Print out each matrix
          System.out.printf("Point %d:\n", pt);
          println( matrixToString(points.get(pt)) );
        }
        
        System.out.printf("(Ar + Br - 2Cr) ^ -1 * (2Ct - At - Bt):\n\n[%5.4f]\n[%5.4f]\n[%5.4f]\n\n", avg_TCP.getEntry(0), avg_TCP.getEntry(1), avg_TCP.getEntry(2));
      }
      
      for (int idx = 0 ; idx < avg_TCP.getDimension(); ++idx) {
        if (abs((float)avg_TCP.getEntry(idx)) > 1000.0f) {
          return null;
        }
      }
      
      return avg_TCP.toArray();
  }
  
  return null;
}

/**
 * Creates a 3x3 rotation matrix based off of two vectors defined by the
 * given set of three transformation matrices representing points in space.
 * If the list contains more than three points, then only the first three
 * points will be used.
 * The three points are used to form two vectors. The first vector is treated
 * as the negative x-axis and the second one is the psuedo-negative z-axis.
 * These vectors are crossed to form the y-axis. The y-axis is then crossed
 * with the negative x-axis to form the true y-axis.
 *
 * @param points  a set of at least three 4x4 transformation matrices
 * @return        a set of three unit vectors (down the columns) that
 *                represent an axes
 */
public float[][] createAxesFromThreePoints(ArrayList<float[][]> points) {
  // 3 points are necessary for the creation of the axes
  if (points.size() >= 3) {
    float[][] axes = new float[3][];
    float[] x_ndir = new float[3],
            z_ndir = new float[3];
            
    // From preliminary negative x and z axis vectors
    for (int row = 0; row < 3; ++row) {
      x_ndir[row] = points.get(1)[row][3] - points.get(0)[row][3];
      z_ndir[row] = points.get(2)[row][3] - points.get(0)[row][3];
    }
    
    // Form axes
    axes[0] = negate(x_ndir);                         // X axis
    axes[1] = crossProduct(axes[0], negate(z_ndir));  // Y axis
    axes[2] = crossProduct(axes[0], axes[1]);         // Z axis
    
    if ((axes[0][0] == 0f && axes[0][1] == 0f && axes[0][2] == 0f) ||
        (axes[1][0] == 0f && axes[1][1] == 0f && axes[1][2] == 0f) ||
        (axes[2][0] == 0f && axes[2][1] == 0f && axes[2][2] == 0f)) {
      // One of the three axis vectors is the zero vector
      return null;
    }
    
    float[] magnitudes = new float[axes.length];
    
    for (int v = 0; v < axes.length; ++v) {
      // Find the magnitude of each axis vector
      for (int e = 0; e < axes[0].length; ++e) {
        magnitudes[v] += pow(axes[v][e], 2);
      }
      
      magnitudes[v] = sqrt(magnitudes[v]);
      // Normalize each vector
      for (int e = 0; e < axes.length; ++e) {
        axes[v][e] /= magnitudes[v];
      }
    }
    
    return axes;
  }
  
  return null;
}

/**
 * Transitions to the Frame Details menu, which displays
 * the x, y, z, w, p, r values associated with the Frame
 * at curFrameIdx in either the Tool Frames or User Frames,
 * based on the value of super_mode.
 */
public void loadFrameDetails() {
  contents = new ArrayList<ArrayList<String>>();
  
  String header = null;
  Frame[] frames = null;
  // Display the frame set name as well as the index of the currently selected frame
  if (super_mode == NAV_TOOL_FRAMES) {
    frames = toolFrames;
    header = String.format("TOOL FRAME: %d", curFrameIdx + 1);
  } else if (super_mode == NAV_USER_FRAMES) {
    frames = userFrames;
    header = String.format("USER FRAME: %d", curFrameIdx + 1);
  }
  
  if (frames != null) {
    
    contents.add( newLine(header) );
    contents.add( newLine(String.format("X: %8.4f", frames[curFrameIdx].getOrigin().x) ) );
    contents.add( newLine(String.format("Y: %8.4f", frames[curFrameIdx].getOrigin().y) ) );
    contents.add( newLine(String.format("Z: %8.4f", frames[curFrameIdx].getOrigin().z) ) );
    contents.add( newLine(String.format("W: %8.4f", frames[curFrameIdx].getWpr().x) ) );
    contents.add( newLine(String.format("P: %8.4f", frames[curFrameIdx].getWpr().y) ) );
    contents.add( newLine(String.format("R: %8.4f", frames[curFrameIdx].getWpr().z) ) );
    
    active_row = -1;
    which_option = -1;
    options = new ArrayList<String>();
    
    mode = FRAME_DETAIL;
    updateScreen(color(255,0,0), color(0));
  }
}

/**
 * Allow the user to choose between viewing the Registers and
 * Position Registers and choosing which form the points will
 * be display in for Position Registers (either Joint or
 * Cartesian).
 */
public void pickRegisterList() {
  options = new ArrayList<String>();
  
  // Determine what registers are available to switch based on the current mode
  if (mode == VIEW_REG) {
     options.add("1. Position Registers (Joint)");
     options.add("2. Position Registers (Cartesian)");
   } else if (mode == VIEW_POS_REG_J) {
     options.add("1. Registers");
     options.add("2. Position Registers (Cartesian)");
   } else if (mode == VIEW_POS_REG_C) {
     options.add("1. Registers");
     options.add("2. Position Registers (Joint)");
   } else {
    options.add("1. Registers");
    options.add("2. Position Registers (Joint)");
    options.add("3. Position Registers (Cartesian)");
  }
     
  which_option = 0;
  
  super_mode = mode;
  mode = PICK_REG_LIST;
  updateScreen(color(255, 0, 0), color(0));
}

/**
 * Displays the list of Registers in mode VIEW_REG or the Position Registers
 * for modes VIEW_REG_J or VIEW_REG_C. In mode VIEW_REG_J the joint angles
 * associated with the Point are displayed and the Cartesian values are
 * displayed in mode VIEW_REG_C.
 */
public void viewRegisters() {
  options = new ArrayList<String>();
  which_option = -1;
  
  contents = new ArrayList<ArrayList<String>>();
  
  // View Registers
  if (mode == VIEW_REG) {
    // Header
    contents.add( newLine("REGISTERS") );
    contents.add( newLine("") );
    
    int start = text_render_start;
    int end = min(start + ITEMS_TO_SHOW - 1, REG.length);
    // Display a subset of the list of registers
    for (int idx = start; idx < end; ++idx) {
      String spaces;
      
      if (idx < 9) {
        spaces = "   ";
      } else if (idx < 99) {
        spaces = "  ";
      } else {
        spaces = " ";
      }
      // Display the line number
      String lineNum = String.format("%d)%s", (idx + 1), spaces);
      
      if (idx < 9) {
        spaces = "    ";
      } else if (idx < 99) {
        spaces = "   ";
      } else {
        spaces = "  ";
      }
      
      String lbl = (REG[idx].comment == null) ? "" : REG[idx].comment;
      // Display the comment asscoiated with a specific Register entry
      String regLbl = String.format("R[%d: %s]%s", (idx + 1), lbl, spaces);
      // Display Register value (* if uninitialized)
      String regEntry = (REG[idx].value == null) ? "*" : String.format("%4.3f", REG[idx].value);
      
      contents.add( newLine(lineNum, regLbl, regEntry) );
    }
    
  // View Position Registers
  } else if (mode == VIEW_POS_REG_J || mode == VIEW_POS_REG_C) {
    // Header
    ArrayList<String> line = new ArrayList<String>();
    line.add("POSITION REGISTERS");
    contents.add(line);
    line = new ArrayList<String>();
    line.add("");
    contents.add(line);
    
    int start = text_render_start;
    int end = min(start + ITEMS_TO_SHOW - 1, POS_REG.length);
    // Display a subset of the list of position registers
    for (int idx = start; idx < end; ++idx) {
      line = new ArrayList<String>();
      
      String spaces;
      
      if (idx < 9) {
        spaces = "   ";
      } else if (idx < 99) {
        spaces = "  ";
      } else {
        spaces = " ";
      }
      // Display the line number
      String lineNum = String.format("%d)%s", (idx + 1), spaces);
      
      if (idx < 9) {
        spaces = "    ";
      } else if (idx < 99) {
        spaces = "   ";
      } else {
        spaces = "  ";
      }
      
      String lbl = (POS_REG[idx].comment == null) ? "" : POS_REG[idx].comment;
      // Display the comment asscoiated with a specific Register entry
      String regLbl = String.format("PR[%d: %s]%s", (idx + 1), lbl, spaces);
      
      if (POS_REG[idx].point == null) {
        // No initialized entry
        String unini = (mode == VIEW_POS_REG_J) ? "*" : "#";
        
        contents.add( newLine(lineNum, regLbl, unini) );
      } else {
        String[] entries = null;
        
        if (mode == VIEW_POS_REG_J) {
          entries = POS_REG[idx].point.toJointStringArray();
        } else {
          // mode == VIEW_POS_REG_C
          entries = POS_REG[idx].point.toCartesianStringArray();
        }
        
        /* Display each portion of the Point's position and orientation in
         * a separate column  whether it be X, Y, Z, W, P, R (Cartesian) or 
         * J1 - J6 (Joint angles) */
         contents.add( newLine(lineNum, regLbl, entries[0], entries[1], entries[2], entries[3], entries[4], entries[5]) );
      }
      
      
    }
  } else {
    // mode must be VIEW_REG or VIEW_POS_REG_J(C)!
    contents.add( newLine( String.format("%d is not a valid mode for view registers!", mode)) );
    active_row = active_col = 0;
  }
  
  updateScreen(color(255, 0, 0), color(0));
}

/** TODO comment */
public void loadInputRegisterValueMethod() {
  options = new ArrayList<String>();
  options.add("Input a value using the keypad");
  options.add("");
  options.add(workingText);
  
  which_option = 0;
  super_mode = mode;
  mode = INPUT_FLOAT;
  updateScreen(color(255, 0, 0), color(0));
}

/** TODO comment */
public void loadInputRegisterPointMethod() {
  contents = new ArrayList<ArrayList<String>>();
  
  if (active_index >= 0 && active_index < POS_REG.length) {
    String header = "POSITION REGISTER";
    
    if (POS_REG[active_index].comment != null) {
      // Show comment if it exists
      header += ": " + POS_REG[active_index].comment;
    }
  
    contents.add( newLine(header) );
    
    if (POS_REG[active_index].point == null) {
      // Initialize valeus to zero if the entry is null
      if (mode == INPUT_POINT_C) {
        
        contents.add( newLine("X: 0.0") );
        contents.add( newLine("Y: 0.0") );
        contents.add( newLine("Z: 0.0") );
        contents.add( newLine("W: 0.0") );
        contents.add( newLine("P: 0.0") );
        contents.add( newLine("R: 0.0") );
      } else if (mode == INPUT_POINT_J) {
        
        for (int idx = 1; idx <= 6; ++idx) {
          contents.add( newLine(String.format("J%d: 0.0", idx)) );
        }
      }
    } else {
      // List current entry values if the Register is initialized
      String[] entries = (mode == INPUT_POINT_C) ? POS_REG[active_index].point.toCartesianStringArray()
                                                 : POS_REG[active_index].point.toJointStringArray();
      
      for (String entry : entries) {
        contents.add( newLine(entry) );
      }
    }
    
  }
  
  // Defines the length of a line's prefix
  which_option = (mode == INPUT_POINT_J) ? 4 : 3;
  active_row = 1;
  active_col = 0;
  updateScreen(color(255, 0, 0), color(0));
}

// prepare for displaying motion instructions on screen
public void loadInstructions(int programID){
   Program p = programs.get(programID);
   contents = new ArrayList<ArrayList<String>>();
   int size = p.getInstructions().size();
   
   int start = text_render_start;
   int end = min(start + ITEMS_TO_SHOW, size);
   if (end >= size) end = size;
   for(int i=start;i<end;i++){
      ArrayList<String> m = new ArrayList<String>();
      m.add(Integer.toString(i+1) + ")");
      Instruction instruction = p.getInstructions().get(i);
      if (instruction instanceof MotionInstruction) {
        MotionInstruction a = (MotionInstruction)instruction;
        if(armModel.getEEPos().dist(a.getVector(p).pos) < liveSpeed){
          println("at tgt position");
          m.add("@");
        }
        else{
          println(a.getVector(p).pos);
          m.add("_");
        }
        // add motion type
        switch (a.getMotionType()){
           case MTYPE_JOINT:
              m.add("J");
              break;
           case MTYPE_LINEAR:
              m.add("L");
              break;
           case MTYPE_CIRCULAR:
              m.add("C");
              break; 
        }
        // load register no, speed and termination type
        if (a.getGlobal()) m.add("PR[");
        else m.add("P[");
        
        m.add(a.getRegister()+"]");
        
        if (a.getMotionType() == MTYPE_JOINT) m.add((a.getSpeed() * 100) + "%");
        else m.add((int)(a.getSpeed()) + "mm/s");
        
        if (a.getTermination() == 0) m.add("FINE");
        else m.add("CONT" + (int)(a.getTermination()*100));
        
        contents.add(m);
      } 
      else if (instruction instanceof ToolInstruction ||
                 instruction instanceof FrameInstruction)
      {
        m.add(instruction.toString());
        contents.add(m);
      }
   } 
}

/**
 * Deals with updating the UI after confirming/canceling a deletion
 */
public void deleteInstEpilogue() {
  Program prog = programs.get(active_program);
  
  active_instruction = min(active_instruction,  prog.getInstructions().size() - 1);
  /* 13 is the maximum number of instructions that can be displayed at one point in time */
  active_row = min(active_instruction, ITEMS_TO_SHOW - 1);
  active_col = 0;
  text_render_start = active_instruction - active_row;
  
  loadInstructions(active_program);
  
  mode = super_mode;
  super_mode = NONE;
  options.clear();
  updateScreen(color(255,0,0), color(0,0,0));
}

/* Transitions to the active frames menu, which display
 * the label for each Frame set (Tool or User) as well
 * as the index of the currently active frame for each
 * respective frame set. */
public void loadActiveFrames() {
  options = new ArrayList<String>();
  contents = new ArrayList<ArrayList<String>>();
  active_row = 1;
  
  contents.add( newLine("ACTIVE FRAMES") );
  contents.add( newLine("Tool: " + (activeToolFrame + 1)) );
  contents.add( newLine("User: " + (activeUserFrame + 1)) );
  //contents.add( newLine("Jog: " + (activeJogFrame + 1)) );
  
  mode = ACTIVE_FRAMES;
  updateScreen(color(255,0,0), color(0));
}

public void loadPrograms() {
   options = new ArrayList<String>(); // clear options
   nums = new ArrayList<Integer>(); // clear numbers
   
   if (cp5.getController("-2") != null) cp5.getController("-2").remove();
   fn_info.setText("");
   
   int size = programs.size();
   /*if (size <= 0){
      programs.add(new Program("My Program 1"));
   }/* */
   
   active_instruction = 0;
   
   contents.clear();  
   int start = text_render_start;
   int end = min(start + ITEMS_TO_SHOW, size);
   
   for(int i=start;i<end;i++) {
      contents.add( newLine(programs.get(i).getName()) );
   }
}

/**
 * Given a set of Strings this method returns a single
 * String ArrayList, which contains all the given elements
 * in the order that they are given as arguments.
 * 
 * @param columns  A list of Strings
 * @return         An ArrayList containing all the given
 *                 Strings
 */
public ArrayList<String> newLine(String... columns) {
   ArrayList<String> line =  new ArrayList<String>();
   
   for (String col : columns) {
     line.add(col);
   }
   
   return line;
}
/* Transforms the given vector from the coordinate system defined by the given
 * transformation matrix (column major order). */
public PVector transform(PVector v, float[][] tMatrix) {
  if (tMatrix.length != 4 || tMatrix[0].length != 4) {
    return null;
  }

  PVector u = new PVector();
  // Apply the transformation matrix to the given vector
  u.x = v.x * tMatrix[0][0] + v.y * tMatrix[0][1] + v.z * tMatrix[0][2] + tMatrix[0][3];
  u.y = v.x * tMatrix[1][0] + v.y * tMatrix[1][1] + v.z * tMatrix[1][2] + tMatrix[1][3];
  u.z = v.x * tMatrix[2][0] + v.y * tMatrix[2][1] + v.z * tMatrix[2][2] + tMatrix[2][3];

  return u;
}

/* Transforms the given vector by the given 3x3 rotation matrix (row major order). */
public PVector rotate(PVector v, float[][] rotMatrix) {
  if (v == null || rotMatrix == null || rotMatrix.length != 3 || rotMatrix[0].length != 3) {
    return null;
  }
  
  PVector u = new PVector();
  // Apply the rotation matrix to the given vector
  u.x = v.x * rotMatrix[0][0] + v.y * rotMatrix[1][0] + v.z * rotMatrix[2][0];
  u.y = v.x * rotMatrix[0][1] + v.y * rotMatrix[1][1] + v.z * rotMatrix[2][1];
  u.z = v.x * rotMatrix[0][2] + v.y * rotMatrix[1][2] + v.z * rotMatrix[2][2];
  
  return u;
}

/**
 * Find the inverse of the given 4x4 Homogeneous Coordinate Matrix. 
 * 
 * This method is based off of the algorithm found on this webpage:
 *    https://web.archive.org/web/20130806093214/http://www-graphics.stanford.edu/
 *      courses/cs248-98-fall/Final/q4.html
 */
public float[][] invertHCMatrix(float[][] m) {
  if (m.length != 4 || m[0].length != 4) {
    return null;
  }

  float[][] inverse = new float[4][4];

  /* [ ux vx wx tx ] -1       [ ux uy uz -dot(u, t) ]
   * [ uy vy wy ty ]     =    [ vx vy vz -dot(v, t) ]
   * [ uz vz wz tz ]          [ wx wy wz -dot(w, t) ]
   * [  0  0  0  1 ]          [  0  0  0      1     ]
   */
  inverse[0][0] = m[0][0];
  inverse[0][1] = m[1][0];
  inverse[0][2] = m[2][0];
  inverse[0][3] = -(m[0][0] * m[0][3] + m[1][0] * m[1][3] + m[2][0] * m[2][3]);
  inverse[1][0] = m[0][1];
  inverse[1][1] = m[1][1];
  inverse[1][2] = m[2][1];
  inverse[1][3] = -(m[0][1] * m[0][3] + m[1][1] * m[1][3] + m[2][1] * m[2][3]);
  inverse[2][0] = m[0][2];
  inverse[2][1] = m[1][2];
  inverse[2][2] = m[2][2];
  inverse[2][3] = -(m[0][2] * m[0][3] + m[1][2] * m[1][3] + m[2][2] * m[2][3]);
  inverse[3][0] = 0;
  inverse[3][1] = 0;
  inverse[3][2] = 0;
  inverse[3][3] = 1;

  return inverse;
}

/* Returns a 4x4 vector array which reflects the current transform matrix on the top
 * of the stack (ignores scaling values though) */
public float[][] getTransformationMatrix() {
  float[][] transform = new float[4][4];

  // Caculate four vectors corresponding to the four columns of the transform matrix
  PVector col_4 = getCoordFromMatrix(0, 0, 0);
  PVector col_1 = getCoordFromMatrix(1, 0, 0).sub(col_4);
  PVector col_2 = getCoordFromMatrix(0, 1, 0).sub(col_4);
  PVector col_3 = getCoordFromMatrix(0, 0, 1).sub(col_4);

  // Place the values of each vector in the correct cells of the transform  matrix
  transform[0][0] = col_1.x;
  transform[1][0] = col_1.y;
  transform[2][0] = col_1.z;
  transform[3][0] = 0;
  transform[0][1] = col_2.x;
  transform[1][1] = col_2.y;
  transform[2][1] = col_2.z;
  transform[3][1] = 0;
  transform[0][2] = col_3.x;
  transform[1][2] = col_3.y;
  transform[2][2] = col_3.z;
  transform[3][2] = 0;
  transform[0][3] = col_4.x;
  transform[1][3] = col_4.y;
  transform[2][3] = col_4.z;
  transform[3][3] = 1;

  return transform;
}

/* This method transforms the given coordinates into a vector
 * in the Processing's native coordinate system. */
public PVector getCoordFromMatrix(float x, float y, float z) {
  PVector vector = new PVector();

  vector.x = modelX(x, y, z);
  vector.y = modelY(x, y, z);
  vector.z = modelZ(x, y, z);

  return vector;
}



/* Calculate v x v */
public float[] crossProduct(float[] v, float[] u) {
  if (v.length != 3 && v.length != u.length) { return null; }
  
  float[] w = new float[v.length];
  // [a, b, c] x [d, e, f] = [ bf - ce, cd - af, ae - bd ]
  w[0] = v[1] * u[2] - v[2] * u[1];
  w[1] = v[2] * u[0] - v[0] * u[2];
  w[2] = v[0] * u[1] - v[1] * u[0];
  
  return w;
}

/* Converts a PVector object to a float[] */
public float[] toVectorArray(PVector v) {
  return new float[] { v.x, v.y, v.z };
}

/* Returns a vector with the opposite sign
 * as the given vector. */
public float[] negate(float[] v) {
  float[] u = new float[v.length];
  
  for (int e = 0; e < v.length; ++e) {
    u[e] = -v[e];
  }
  
  return u;
}

//calculates rotation matrix from euler angles
public float[][] eulerToMatrix(PVector wpr) {
  float[][] r = new float[3][3];
  float xRot = wpr.x;
  float yRot = wpr.y;
  float zRot = wpr.z;

  r[0][0] = cos(yRot)*cos(zRot);
  r[0][1] = sin(xRot)*sin(yRot)*cos(zRot) - cos(xRot)*sin(zRot);
  r[0][2] = cos(xRot)*sin(yRot)*cos(zRot) + sin(xRot)*sin(zRot);
  r[1][0] = cos(yRot)*sin(zRot);
  r[1][1] = sin(xRot)*sin(yRot)*sin(zRot) + cos(xRot)*cos(zRot);
  r[1][2] = cos(xRot)*sin(yRot)*sin(zRot) - sin(xRot)*cos(zRot);
  r[2][0] = -sin(yRot);
  r[2][1] = sin(xRot)*cos(yRot);
  r[2][2] = cos(xRot)*cos(yRot);

  //println("matrix: ");
  //  for(int i = 0; i < 3; i += 1){
  //    for(int j = 0; j < 3; j += 1){
  //      print(String.format("  %4.3f", r[i][j]));
  //    }
  //  println();
  //}
  //println();

  return r;
}

//calculates quaternion from euler angles
public float[] eulerToQuat(PVector wpr) {
  //float[][] r = eulerToMatrix(wpr);
  //float[] q = matrixToQuat(r);

  /*Alternate computation method; produces equivalent result to above, but may
   *not have the same sign (certain quaternions are equivalent when negated).
   */
  float[] q = new float[4];
  float xRot = wpr.x;
  float yRot = wpr.y;
  float zRot = wpr.z;

  q[0] = sin(zRot/2)*sin(yRot/2)*sin(xRot/2) + cos(zRot/2)*cos(yRot/2)*cos(xRot/2);
  q[1] = -sin(zRot/2)*sin(yRot/2)*cos(xRot/2) + sin(xRot/2)*cos(zRot/2)*cos(yRot/2);
  q[2] = sin(zRot/2)*sin(xRot/2)*cos(yRot/2) + sin(yRot/2)*cos(zRot/2)*cos(zRot/2);
  q[3] = sin(zRot/2)*cos(yRot/2)*cos(xRot/2) - sin(yRot/2)*sin(xRot/2)*cos(xRot/2);

  return q;
}

//calculates euler angles from rotation matrix
public PVector matrixToEuler(float[][] r) {
  float yRot1, yRot2, xRot1, xRot2, zRot1, zRot2;
  PVector wpr, wpr2;

  if (r[2][0] != 1 && r[2][0] != -1) {
    //rotation about y-axis
    yRot1 = -asin(r[2][0]);
    yRot2 = PI - yRot1;
    //rotation about x-axis
    xRot1 = atan2(r[2][1]/cos(yRot1), r[2][2]/cos(yRot1));
    xRot2 = atan2(r[2][1]/cos(yRot2), r[2][2]/cos(yRot2));
    //rotation about z-axis
    zRot1 = atan2(r[1][0]/cos(yRot1), r[0][0]/cos(yRot1));
    zRot2 = atan2(r[1][0]/cos(yRot2), r[0][0]/cos(yRot2));
  } else {
    zRot1 = zRot2 = 0;
    if (r[2][0] == -1) {
      yRot1 = yRot2 = PI/2;
      xRot1 = xRot2 = zRot1 + atan2(r[0][1], r[0][2]);
    } else {
      yRot1 = yRot2 = -PI/2;
      xRot1 = xRot2 = -zRot1 + atan2(-r[0][1], -r[0][2]);
    }
  }

  wpr = new PVector(xRot1, yRot1, zRot1);
  wpr2 = new PVector(xRot2, yRot2, zRot2);

  return wpr;
}

//calculates quaternion from rotation matrix
public float[] matrixToQuat(float[][] r) {
  float[] q = new float[4];
  float tr = r[0][0] + r[1][1] + r[2][2];

  if (tr > 0) {
    float S = sqrt(1.0f + tr) * 2; // S=4*q[0] 
    q[0] = S / 4;
    q[1] = (r[2][1] - r[1][2]) / S;
    q[2] = (r[0][2] - r[2][0]) / S; 
    q[3] = (r[1][0] - r[0][1]) / S;
  } else if ((r[0][0] > r[1][1]) & (r[0][0] > r[2][2])) {
    float S = sqrt(1.0f + r[0][0] - r[1][1] - r[2][2]) * 2; // S=4*q[1] 
    q[0] = (r[2][1] - r[1][2]) / S;
    q[1] = S / 4;
    q[2] = (r[0][1] + r[1][0]) / S; 
    q[3] = (r[0][2] + r[2][0]) / S;
  } else if (r[1][1] > r[2][2]) {
    float S = sqrt(1.0f + r[1][1] - r[0][0] - r[2][2]) * 2; // S=4*q[2]
    q[0] = (r[0][2] - r[2][0]) / S;
    q[1] = (r[0][1] + r[1][0]) / S; 
    q[2] = S / 4;
    q[3] = (r[1][2] + r[2][1]) / S;
  } else {
    float S = sqrt(1.0f + r[2][2] - r[0][0] - r[1][1]) * 2; // S=4*q[3]
    q[0] = (r[1][0] - r[0][1]) / S;
    q[1] = (r[0][2] + r[2][0]) / S;
    q[2] = (r[1][2] + r[2][1]) / S;
    q[3] = S / 4;
  }

  return q;
}

//calculates euler angles from quaternion
public PVector quatToEuler(float[] q) {
  float[][] r = quatToMatrix(q);
  PVector wpr = matrixToEuler(r);
  return wpr;
}

//calculates rotation matrix from quaternion
public float[][] quatToMatrix(float[] q) {
  float[][] r = new float[3][3];

  r[0][0] = 1 - 2*(q[2]*q[2] + q[3]*q[3]);
  r[0][1] = 2*(q[1]*q[2] - q[0]*q[3]);
  r[0][2] = 2*(q[0]*q[2] + q[1]*q[3]);
  r[1][0] = 2*(q[1]*q[2] + q[0]*q[3]);
  r[1][1] = 1 - 2*(q[1]*q[1] + q[3]*q[3]);
  r[1][2] = 2*(q[2]*q[3] - q[0]*q[1]);
  r[2][0] = 2*(q[1]*q[3] - q[0]*q[2]);
  r[2][1] = 2*(q[0]*q[1] + q[2]*q[3]);
  r[2][2] = 1 - 2*(q[1]*q[1] + q[2]*q[2]);

  //println("matrix: ");
  //for(int i = 0; i < 3; i += 1){
  //  for(int j = 0; j < 3; j += 1){
  //    print(String.format("  %4.3f", m[i][j]));
  //  }
  //  println();
  //}
  //println();

  return r;
}

//converts a float array to a double array
public double[][] floatToDouble(float[][] m, int l, int w) {
  double[][] r = new double[l][w];

  for (int i = 0; i < l; i += 1) {
    for (int j = 0; j < w; j += 1) {
      r[i][j] = (double)m[i][j];
    }
  }

  return r;
}

//converts a double array to a float array
public float[][] doubleToFloat(double[][] m, int l, int w) {
  float[][] r = new float[l][w];

  for (int i = 0; i < l; i += 1) {
    for (int j = 0; j < w; j += 1) {
      r[i][j] = (float)m[i][j];
    }
  }

  return r;
}

//calculates the change in x, y, and z from p1 to p2
public float[] calculateVectorDelta(PVector p1, PVector p2) {
  float[] d = {p1.x - p2.x, p1.y - p2.y, p1.z - p2.z};
  return d;
}

//calculates the difference between each corresponding pair of
//elements for two vectors of n elements
public float[] calculateVectorDelta(float[] v1, float[] v2, int n) {
  float[] d = new float[n];
  for (int i = 0; i < n; i += 1) {
    d[i] = v1[i] - v2[i];
  }

  return d;
}

//produces a rotation matrix given a rotation 'theta' around
//a given axis
public float[][] rotateAxisVector(float[][] m, float theta, PVector axis) {
  float s = sin(theta);
  float c = cos(theta);
  float t = 1-c;

  if (c > 0.9f)
    t = 2*sin(theta/2)*sin(theta/2);

  float x = axis.x;
  float y = axis.y;
  float z = axis.z;
  
  float[][] r = new float[3][3];

  r[0][0] = x*x*t+c;
  r[0][1] = x*y*t-z*s;
  r[0][2] = x*z*t+y*s;
  r[1][0] = y*x*t+z*s;
  r[1][1] = y*y*t+c;
  r[1][2] = y*z*t-x*s;
  r[2][0] = z*x*t-y*s;
  r[2][1] = z*y*t+x*s;
  r[2][2] = z*z*t+c;
  
  RealMatrix M = new Array2DRowRealMatrix(floatToDouble(m, 3, 3));
  RealMatrix R = new Array2DRowRealMatrix(floatToDouble(r, 3, 3));
  RealMatrix MR = M.multiply(R);

  return doubleToFloat(MR.getData(), 3, 3);
}

/* Calculates the result of a rotation of quaternion 'p'
 * about axis 'u' by 'theta' degrees
 */
public float[] rotateQuat(float[] p, PVector u, float theta) {
  float[] q = new float[4];
  
  q[0] = cos(theta/2);
  q[1] = sin(theta/2)*u.x;
  q[2] = sin(theta/2)*u.y;
  q[3] = sin(theta/2)*u.z;
  
  float[] pq = quaternionMult(p, q);

  return pq;
}

public PVector rotateVectorQuat(PVector v, PVector u, float theta){
  float[] q = new float[4];
  float[] p = new float[4];
  float[] q_inv = new float[4];
  float[] p_prime = new float[4];
  
  q[0] = cos(theta/2);
  q[1] = sin(theta/2)*u.x;
  q[2] = sin(theta/2)*u.y;
  q[3] = sin(theta/2)*u.z;
  
  p[0] = 0;
  p[1] = v.x;
  p[2] = v.y;
  p[3] = v.z;
  
  q_inv[0] = q[0];
  q_inv[1] = -q[1];
  q_inv[2] = -q[2];
  q_inv[3] = -q[3];
  
  p_prime = quaternionMult(q, p);
  p_prime = quaternionMult(p_prime, q_inv);

  return new PVector(p_prime[1], p_prime[2], p_prime[3]);
}

/* Given 2 quaternions, calculates the quaternion representing the 
 * rotation from 'q1' to 'q2' such that 'qr'*'q1' = 'q2'. Note that 
 * the multiply operation should be taken to mean quaternion
 * multiplication, which is non-commutative.
 */
public float[] calculateQuatOffset(float[] q1, float[] q2){
  float[] q1_inv = new float[4];
  q1_inv[0] = q1[0];
  q1_inv[1] = -q1[1];
  q1_inv[2] = -q1[2];
  q1_inv[3] = -q1[3];
  
  float[] qr = quaternionMult(q2, q1_inv);
  
  for(int i = 0; i < 4; i += 1){
    if(qr[i] < 0.00001f)
      qr[i] = 0;
  }
  
  return qr;
}

//returns the result of a quaternion 'q1' multiplied by quaternion 'q2'
public float[] quaternionMult(float[] q1, float[] q2) {
  float[] r = new float[4];
  r[0] = q1[0]*q2[0] - q1[1]*q2[1] - q1[2]*q2[2] - q1[3]*q2[3];
  r[1] = q1[0]*q2[1] + q1[1]*q2[0] + q1[2]*q2[3] - q1[3]*q2[2];
  r[2] = q1[0]*q2[2] - q1[1]*q2[3] + q1[2]*q2[0] + q1[3]*q2[1];
  r[3] = q1[0]*q2[3] + q1[1]*q2[2] - q1[2]*q2[1] + q1[3]*q2[0];

  return r;
}

//returns the result of a quaternion 'q' multiplied by scalar 's'
public float[] quaternionScalarMult(float[] q, float s){
  float[] qr = new float[4];
  qr[0] = q[0]*s;
  qr[1] = q[1]*s;
  qr[2] = q[2]*s;
  qr[3] = q[3]*s;
  return qr;
}

//returns the result of the addition of two quaternions, 'q1' and 'q2'
public float[] quaternionAdd(float[] q1, float[] q2){
  float[] qr = new float[4];
  qr[0] = q1[0] + q2[0];
  qr[1] = q1[1] + q2[1];
  qr[2] = q1[2] + q2[2];
  qr[3] = q1[3] + q2[3];
  return qr;
}

//returns the magnitude of the input quaternion 'q'
public float calculateQuatMag(float[] q){
  return sqrt(pow(q[0], 2) + pow(q[1], 2) + pow(q[2], 2) + pow(q[3], 2));
}

public float[] quaternionNormalize(float[] q){
  float qMag = calculateQuatMag(q);
  return quaternionScalarMult(q, 1/qMag);
}

/* Given two input quaternions, 'q1' and 'q2', computes the spherical-
 * linear interpolation from 'q1' to 'q2' for a given fraction of the
 * complete transformation 'q1' to 'q2', denoted by 0 <= 'mu' <= 1. 
 */
public float[] quaternionSlerp(float[] q1, float[] q2, float mu){
  float[] qSlerp = new float[4];
  float[] q3 = new float[4];
  float cOmega = 0;
  
  if(mu == 0) return q1;
  if(mu == 1) return q2;
  
  for(int i = 0; i < 4; i += 1)
    cOmega += q1[i]*q2[i];
    
  if(cOmega < 0){
    cOmega = -cOmega;
    q3 = quaternionScalarMult(q2, -1);
  }
  else{
    q3 = quaternionScalarMult(q2, 1);
  }
  
  if(cOmega > 0.99999995f){
    qSlerp[0] = q1[0]*(1-mu) + q3[0]*mu;
    qSlerp[1] = q1[1]*(1-mu) + q3[1]*mu;
    qSlerp[2] = q1[2]*(1-mu) + q3[2]*mu;
    qSlerp[3] = q1[3]*(1-mu) + q3[3]*mu;
  }
  else{
    float omega = acos(cOmega);
    float scale1 = sin(omega*(1-mu))/sin(omega);
    float scale2 = sin(omega*mu)/sin(omega);
    
    qSlerp[0] = q1[0]*scale1 + q3[0]*scale2;
    qSlerp[1] = q1[1]*scale1 + q3[1]*scale2;
    qSlerp[2] = q1[2]*scale1 + q3[2]*scale2;
    qSlerp[3] = q1[3]*scale1 + q3[3]*scale2;
  }
  
  return quaternionNormalize(qSlerp);
}

/* Returns a string represenation of the given matrix.
 * 
 * @param matrixx  A non-null matrix
 */
public String matrixToString(float[][] matrix) {
  String mStr = "";
  
  for (int row = 0; row < matrix.length; ++row) {
    mStr += "\n[";

    for (int col = 0; col < matrix[0].length; ++col) {
      // Account for the negative sign character
      if (matrix[row][col] >= 0) { mStr += " "; }
      
      mStr += String.format(" %5.6f", matrix[row][col]);
    }

    mStr += "  ]";
  }
  
  return (mStr + "\n");
}

public String arrayToString(float[] array){
  String s = "[";
  
  for(int i = 0; i < array.length; i += 1){
    s += String.format("%5.4f", array[i]);
    if(i != array.length-1) s += ", ";
  }
  
  return s + "]";
}


//To-do list:
//Collision detection

public class Triangle {
  // normal, vertex 1, vertex 2, vertex 3
  public PVector[] components = new PVector[4];
}

public class Model {
  public PShape mesh;
  public String name;
  public boolean[] rotations = new boolean[3]; // is rotating on this joint valid?
  // Joint ranges follow a clockwise format running from the PVector.x to PVector.y, where PVector.x and PVector.y range from [0, TWO_PI]
  public PVector[] jointRanges = new PVector[3];
  public float[] currentRotations = new float[3]; // current rotation value
  public float[] targetRotations = new float[3]; // we want to be rotated to this value
  public int[] rotationDirections = new int[3]; // control rotation direction so we
                                                // don't "take the long way around"
  public float rotationSpeed;
  public float[] jointsMoving = new float[3]; // for live control using the joint buttons
  
  public Model(String filename, int col) {
    for (int n = 0; n < 3; n++) {
      rotations[n] = false;
      currentRotations[n] = 0;
      jointRanges[n] = null;
    }
    rotationSpeed = 0.01f;
    name = filename;
    loadSTLModel(filename, col);
  }
  
  public void loadSTLModel(String filename, int col) {
    ArrayList<Triangle> triangles = new ArrayList<Triangle>();
    byte[] data = loadBytes(filename);
    int n = 84; // skip header and number of triangles
    
    while (n < data.length) {
      Triangle t = new Triangle();
      for (int m = 0; m < 4; m++) {
        byte[] bytesX = new byte[4];
        bytesX[0] = data[n+3]; bytesX[1] = data[n+2];
        bytesX[2] = data[n+1]; bytesX[3] = data[n];
        n += 4;
        byte[] bytesY = new byte[4];
        bytesY[0] = data[n+3]; bytesY[1] = data[n+2];
        bytesY[2] = data[n+1]; bytesY[3] = data[n];
        n += 4;
        byte[] bytesZ = new byte[4];
        bytesZ[0] = data[n+3]; bytesZ[1] = data[n+2];
        bytesZ[2] = data[n+1]; bytesZ[3] = data[n];
        n += 4;
        t.components[m] = new PVector(
          ByteBuffer.wrap(bytesX).getFloat(),
          ByteBuffer.wrap(bytesY).getFloat(),
          ByteBuffer.wrap(bytesZ).getFloat()
        );
      }
      triangles.add(t);
      n += 2; // skip meaningless "attribute byte count"
    }
    mesh = createShape();
    mesh.beginShape(TRIANGLES);
    mesh.noStroke();
    mesh.fill(col);
    for (Triangle t : triangles) {
      mesh.normal(t.components[0].x, t.components[0].y, t.components[0].z);
      mesh.vertex(t.components[1].x, t.components[1].y, t.components[1].z);
      mesh.vertex(t.components[2].x, t.components[2].y, t.components[2].z);
      mesh.vertex(t.components[3].x, t.components[3].y, t.components[3].z);
    }
    mesh.endShape();
  } // end loadSTLModel
    
  public boolean anglePermitted(int idx, float angle) {
    
    if (jointRanges[idx].x < jointRanges[idx].y) {
      // Joint range does not overlap TWO_PI
      return angle >= jointRanges[idx].x && angle < jointRanges[idx].y;
    } else {
      // Joint range overlaps TWO_PI
      return !(angle >= jointRanges[idx].y && angle < jointRanges[idx].x);
    }
  }
  
  public void draw() {
    shape(mesh);
  }
  
} // end Model class

// The apporximate center of the base of the robot
public static final PVector base_center = new PVector(404, 137, -212);

public class ArmModel {
  
  public int activeEndEffector = ENDEF_NONE;
  public int endEffectorStatus = OFF;

  public ArrayList<Model> segments = new ArrayList<Model>();
  public int type;
  //public boolean calculatingArms = false, movingArms = false;
  public float motorSpeed;
  // Indicates translational motion in the World Frame
  public float[] mvLinear = new float[3];
  // Indicates rotational motion in the World Frame
  public float[] mvRot = new float[3];
  public float[] tgtRot = new float[4];
  public PVector tgtPos = new PVector();
  public float[][] currentFrame = {{1, 0, 0},
                                   {0, 1, 0}, 
                                   {0, 0, 1}};
  
  public Box[] bodyHitBoxes;
  private ArrayList<Box>[] eeHitBoxes;
      
  public Object held;
  public float[][] oldEETMatrix;
  
  public ArmModel() {
    
    motorSpeed = 1000.0f; // speed in mm/sec
    // Joint 1
    Model base = new Model("ROBOT_MODEL_1_BASE.STL", color(200, 200, 0));
    base.rotations[1] = true;
    base.jointRanges[1] = new PVector(0, TWO_PI);
    base.rotationSpeed = radians(150)/60.0f;
    // Joint 2
    Model axis1 = new Model("ROBOT_MODEL_1_AXIS1.STL", color(40, 40, 40));
    axis1.rotations[2] = true;
    axis1.jointRanges[2] = new PVector(4.34f, 2.01f);
    axis1.rotationSpeed = radians(150)/60.0f;
    // Joint 3
    Model axis2 = new Model("ROBOT_MODEL_1_AXIS2.STL", color(200, 200, 0));
    axis2.rotations[2] = true;
    axis2.jointRanges[2] = new PVector(12f * PI / 20f, 8f * PI / 20f);
    axis2.rotationSpeed = radians(200)/60.0f;
    // Joint 4
    Model axis3 = new Model("ROBOT_MODEL_1_AXIS3.STL", color(40, 40, 40));
    axis3.rotations[0] = true;
    axis3.jointRanges[0] = new PVector(0, TWO_PI);
    axis3.rotationSpeed = radians(250)/60.0f;
    // Joint 5
    Model axis4 = new Model("ROBOT_MODEL_1_AXIS4.STL", color(40, 40, 40));
    axis4.rotations[2] = true;
    axis4.jointRanges[2] = new PVector(59f * PI / 40f, 11f * PI / 20f);
    axis4.rotationSpeed = radians(250)/60.0f;
    // Joint 6
    Model axis5 = new Model("ROBOT_MODEL_1_AXIS5.STL", color(200, 200, 0));
    axis5.rotations[0] = true;
    axis5.jointRanges[0] = new PVector(0, TWO_PI);
    axis5.rotationSpeed = radians(420)/60.0f;
    Model axis6 = new Model("ROBOT_MODEL_1_AXIS6.STL", color(40, 40, 40));
    segments.add(base);
    segments.add(axis1);
    segments.add(axis2);
    segments.add(axis3);
    segments.add(axis4);
    segments.add(axis5);
    segments.add(axis6);
    
    for(int idx = 0; idx < mvLinear.length; ++idx){
      mvLinear[idx] = 0;
    }
    
    for(int idx = 0; idx < mvRot.length; ++idx){
      mvRot[idx] = 0;
    }
    
    /* Initialies dimensions of the Robot Arm's hit boxes */
    bodyHitBoxes = new Box[7];
    
    bodyHitBoxes[0] = new Box(420, 115, 420, color(0, 255, 0));
    bodyHitBoxes[1] = new Box(317, 85, 317, color(0, 255, 0));
    bodyHitBoxes[2] = new Box(130, 185, 170, color(0, 255, 0));
    bodyHitBoxes[3] = new Box(74, 610, 135, color(0, 255, 0));
    bodyHitBoxes[4] = new Box(165, 165, 165, color(0, 255, 0));
    bodyHitBoxes[5] = new Box(160, 160, 160, color(0, 255, 0));
    bodyHitBoxes[6] = new Box(128, 430, 128, color(0, 255, 0));
    
    eeHitBoxes = (ArrayList<Box>[])new ArrayList[4]; 
    // Face plate
    eeHitBoxes[0] = new ArrayList<Box>();
    eeHitBoxes[0].add( new Box(102, 102, 36, color(0, 255, 0)) );
    // Claw Gripper (closed)
    eeHitBoxes[1] = new ArrayList<Box>();
    eeHitBoxes[1].add( new Box(102, 102, 46, color(0, 255, 0)) );
    eeHitBoxes[1].add( new Box(89, 43, 31, color(0, 255, 0)) );
    // Claw Gripper (open)
    eeHitBoxes[2] = new ArrayList<Box>();
    eeHitBoxes[2].add( new Box(102, 102, 46, color(0, 255, 0)) );
    eeHitBoxes[2].add( new Box(89, 21, 31, color(0, 255, 0)) );
    eeHitBoxes[2].add( new Box(89, 21, 31, color(0, 255, 0)) );
    // Suction 
    eeHitBoxes[3] = new ArrayList<Box>();
    eeHitBoxes[3].add( new Box(102, 102, 46, color(0, 255, 0)) );
    eeHitBoxes[3].add( new Box(37, 37, 87, color(0, 255, 0)) );
    eeHitBoxes[3].add( new Box(37, 67, 37, color(0, 255, 0)) );
     
    held = null;
    // Initializes the old transformation matrix for the arm model
    pushMatrix();
    applyModelRotation(this, false);
    oldEETMatrix = getTransformationMatrix();
    popMatrix();
  } // end ArmModel constructor
  
  public void draw() {
    
    noStroke();
    fill(200, 200, 0);
    
    translate(600, 200, 0);

    rotateZ(PI);
    rotateY(PI/2);
    segments.get(0).draw();
    rotateY(-PI/2);
    rotateZ(-PI);
    
    fill(50);
  
    translate(-50, -166, -358); // -115, -213, -413
    rotateZ(PI);
    translate(150, 0, 150);
    rotateY(segments.get(0).currentRotations[1]);
    translate(-150, 0, -150);
    segments.get(1).draw();
    rotateZ(-PI);
  
    fill(200, 200, 0);
  
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    rotateX(segments.get(1).currentRotations[2]);
    translate(0, -62, -62);
    segments.get(2).draw();
    rotateY(-PI/2);
    rotateZ(-PI);
  
    fill(50);
 
    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    rotateX(segments.get(2).currentRotations[2]);
    translate(0, -75, -75);
    segments.get(3).draw();
    rotateY(PI/2);
    rotateZ(-PI);
  
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    rotateY(segments.get(3).currentRotations[0]);
    translate(-70, 0, -70);
    segments.get(4).draw();
    rotateY(-PI/2);
    rotateZ(-PI/2);
  
    fill(200, 200, 0);
  
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    rotateX(segments.get(4).currentRotations[2]);
    translate(0, -50, -50);
    segments.get(5).draw();
    rotateY(PI/2);
    rotateZ(-PI);
  
    fill(50);
  
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    rotateZ(segments.get(5).currentRotations[0]);
    translate(-45, -45, 0);
    segments.get(6).draw();
          
    // next, the end effector
    if (activeEndEffector == ENDEF_SUCTION) {
      rotateY(PI);
      translate(-88, -37, 0);
      eeModelSuction.draw();
    } else if (activeEndEffector == ENDEF_CLAW) {
      rotateY(PI);
      translate(-88, 0, 0);
      eeModelClaw.draw();
      rotateZ(PI/2);
      if (endEffectorStatus == OFF) {
        translate(10, -85, 30);
        eeModelClawPincer.draw();
        translate(55, 0, 0);
        eeModelClawPincer.draw();
      } else if (endEffectorStatus == ON) {
        translate(28, -85, 30);
        eeModelClawPincer.draw();
        translate(20, 0, 0);
        eeModelClawPincer.draw();
      }
    }
  }//end draw arm model
  
  /* Updates the position and orientation of the hit boxes related
   * to the Robot Arm. */
  private void updateBoxes() { 
    noFill();
    stroke(0, 255, 0);
    
    pushMatrix();
    resetMatrix();
    translate(600, 200, 0);

    rotateZ(PI);
    rotateY(PI/2);
    translate(200, 50, 200);
    // Segment 0
    bodyHitBoxes[0].setTransform(getTransformationMatrix());
    
    translate(0, 100, 0);
    bodyHitBoxes[1].setTransform(getTransformationMatrix());
    
    translate(-200, -150, -200);
    
    rotateY(-PI/2);
    rotateZ(-PI);
  
    translate(-50, -166, -358);
    rotateZ(PI);
    translate(150, 0, 150);
    rotateY(segments.get(0).currentRotations[1]);
    translate(10, 95, 0);
    rotateZ(-0.1f * PI);
    // Segment 1
    bodyHitBoxes[2].setTransform(getTransformationMatrix());
    
    rotateZ(0.1f * PI);
    translate(-160, -95, -150);
    rotateZ(-PI);
  
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    rotateX(segments.get(1).currentRotations[2]);
    translate(30, 240, 0);
    // Segment 2
    bodyHitBoxes[3].setTransform(getTransformationMatrix());
    
    translate(-30, -302, -62);
    rotateY(-PI/2);
    rotateZ(-PI);
    
    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    rotateX(segments.get(2).currentRotations[2]);
    translate(75, 0, 0);
    // Segment 3
    bodyHitBoxes[4].setTransform(getTransformationMatrix());
    
    translate(-75, -75, -75);
    rotateY(PI/2);
    rotateZ(-PI);
  
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    rotateY(segments.get(3).currentRotations[0]);
    translate(5, 75, 5);
    // Segment 4
    bodyHitBoxes[5].setTransform(getTransformationMatrix());
    
    translate(0, 295, 0);
    bodyHitBoxes[6].setTransform(getTransformationMatrix());
    
    translate(-75, -370, -75);
    
    rotateY(-PI/2);
    rotateZ(-PI/2);
  
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    rotateX(segments.get(4).currentRotations[2]);
    translate(0, -50, -50);
    // Segment 5
    rotateY(PI/2);
    rotateZ(-PI);
  
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    rotateZ(segments.get(5).currentRotations[0]);
    
    // End Effector
    // Face Plate EE
    translate(0, 0, 10);
    eeHitBoxes[0].get(0).setTransform(getTransformationMatrix());
    translate(0, 0, -10);
    
    // Claw Gripper EE
    float[][] transform = getTransformationMatrix();
    eeHitBoxes[1].get(0).setTransform(transform);
    eeHitBoxes[2].get(0).setTransform(transform);
    eeHitBoxes[3].get(0).setTransform(transform);
    
    translate(-2, 0, -54);
    eeHitBoxes[1].get(1).setTransform(getTransformationMatrix());
    translate(2, 0, 54);
    // The Claw EE has two separate hit box lists: one for the open claw and another for the closed claw
    translate(-2, 27, -54);
    eeHitBoxes[2].get(1).setTransform(getTransformationMatrix());
    translate(0, -54, 0);
    eeHitBoxes[2].get(2).setTransform(getTransformationMatrix());
    translate(2, 27, 54);
    
    // Suction EE
    translate(-2, 0, -66);
    eeHitBoxes[3].get(1).setTransform(getTransformationMatrix());
    translate(0, -52, 21);
    eeHitBoxes[3].get(2).setTransform(getTransformationMatrix());
    translate(2, 52, 35);
    
    translate(-45, -45, 0);
    popMatrix();
  }
  
  /* Returns one of the Arraylists for the End Effector hit boxes depending on the
   * current active End Effector and the status of the End Effector. */
  public ArrayList<Box> currentEEHitBoxList() {
    // Determine which set of hit boxes to display based on the active End Effector
    if (activeEndEffector == ENDEF_CLAW) {
        return (endEffectorStatus == ON) ? eeHitBoxes[1] : eeHitBoxes[2];
    } else if (activeEndEffector == ENDEF_SUCTION) {
      return eeHitBoxes[3];
    }
    
    return eeHitBoxes[0];
  }
  
  /* Changes all the Robot Arm's hit boxes to green */
  public void resetBoxColors() {
    for (Box b : bodyHitBoxes) {
      b.outline = color(0, 255, 0);
    }
    
    ArrayList<Box> eeHB = currentEEHitBoxList();
    
    for (Box b : eeHB) {
      b.outline = color(0, 255, 0);
    }
  }
  
  /* Determine if select pairs of hit boxes of the Robot Arm are colliding */
  public boolean checkSelfCollisions() {
    boolean collision = false;
    
    // Pairs of indices corresponding to two of the Arm body hit boxes, for which to check collisions
    int[] check_pairs = new int[] { 0, 3, 0, 4, 0, 5, 0, 6, 1, 5, 1, 6, 2, 5, 2, 6, 3, 5 };
    
    /* Check select collisions between the body segments of the Arm:
     * The base segment and the four upper arm segments
     * The base rotating segment and lower long arm segment as well as the upper long arm and
     *   upper rotating end segment
     * The second base rotating hit box and the upper long arm segment as well as the upper
     *   rotating end segment
     * The lower long arm segment and the upper rotating end segment
     */
    for (int idx = 0; idx < check_pairs.length - 1; idx += 2) {
      if ( collision3D(bodyHitBoxes[ check_pairs[idx] ], bodyHitBoxes[ check_pairs[idx + 1] ]) ) {
        bodyHitBoxes[ check_pairs[idx] ].outline = color(255, 0, 0);
        bodyHitBoxes[ check_pairs[idx + 1] ].outline = color(255, 0, 0);
        collision = true;
      }
    }
    
    ArrayList<Box> eeHB = currentEEHitBoxList();
    
    // Check collisions between all EE hit boxes and base as well as the first long arm hit boxes
    for (Box hb : eeHB) {
      for (int idx = 0; idx < 4; ++idx) {
        if (collision3D(hb, bodyHitBoxes[idx]) ) {
          hb.outline = color(255, 0, 0);
          bodyHitBoxes[idx].outline = color(255, 0, 0);
          collision = true;
        }
      }
    }
    
    return collision;
  }
  
  /* Determine if the given ojbect is collding with any part of the Robot. */
  public boolean checkObjectCollision(Object obj) {
    Box ohb = (Box)obj.hit_box;
    boolean collision = false;
    
    for (Box b : bodyHitBoxes) {
      if ( collision3D(ohb, b) ) {
        b.outline = color(255, 0, 0);
        collision = true;
      }
    }
    
    ArrayList<Box> eeHBs = currentEEHitBoxList();
    
    for (Box b : eeHBs) {
      // Special case for held objects
      if ( (activeEndEffector != ENDEF_CLAW || activeEndEffector != ENDEF_SUCTION || endEffectorStatus != ON || b != eeHitBoxes[1].get(1) || obj != armModel.held) && collision3D(ohb, b) ) {
        b.outline = color(255, 0, 0);
        collision = true;
      }
    }
    
    return collision;
  }
  
  /* Draws the Robot Arm's hit boxes in the world */
  public void drawBoxes() {
    // Draw hit boxes of the body poriotn of the Robot Arm
    for (Box b : bodyHitBoxes) {
      pushMatrix();
      b.applyTransform();
      b.draw();
      popMatrix();
    }
    
    int eeIdx = 0;
    // Determine which set of hit boxes to display based on the active End Effector
    if (activeEndEffector == ENDEF_CLAW) {
      if (endEffectorStatus == ON) {
        eeIdx = 1;
      } else {
        eeIdx = 2;
      }
    } else if (activeEndEffector == ENDEF_SUCTION) {
      eeIdx = 3;
    }
    // Draw End Effector hit boxes
    for (Box b : eeHitBoxes[eeIdx]) {
      pushMatrix();
      b.applyTransform();
      b.draw();
      popMatrix();
    }
  }
  
  //returns the rotational values for each arm joint
  public float[] getJointRotations() {
    float[] rot = new float[6];
    for (int i = 0; i < segments.size(); i += 1) {
      for (int j = 0; j < 3; j += 1) {
        if (segments.get(i).rotations[j]) {
          rot[i] = segments.get(i).currentRotations[j];
          break;
        }
      }
    }
    return rot;
  }//end get joint rotations
  
  /* Resets the robot's current reference frame to that of the
   * default world frame.
   */
  public void resetFrame(){
    currentFrame[0][0] = 1;
    currentFrame[0][1] = 0;
    currentFrame[0][2] = 0;
    
    currentFrame[1][0] = 0;
    currentFrame[1][1] = 1;
    currentFrame[1][2] = 0;
    
    currentFrame[2][0] = 0;
    currentFrame[2][1] = 0;
    currentFrame[2][2] = 1;
  }
  
  /* Calculate and returns a 3x3 matrix whose columns are the unit vectors of
   * the end effector's current x, y, z axes with respect to the current frame.
   */
  public float[][] getRotationMatrix() {
    pushMatrix();
    resetMatrix();
    // Switch to End Effector reference Frame
    applyModelRotation(armModel, true);
    /* Define vectors { 0, 0, 0 }, { 1, 0, 0 }, { 0, 1, 0 }, and { 0, 0, 1 }
     * Swap vectors:
     *   x' = z
     *   y' = x
     *   z' = y
     */
    PVector origin = new PVector(modelX(0, 0, 0), modelY(0, 0, 0), modelZ(0, 0, 0)),
            x = new PVector(modelX(0, 0, -1), modelY(0, 0, -1), modelZ(0, 0, -1)),
            y = new PVector(modelX(0, 1, 0), modelY(0, 1, 0), modelZ(0, 1, 0)),
            z = new PVector(modelX(1, 0, 0), modelY(1, 0, 0), modelZ(1, 0, 0));
            
    float[][] matrix = new float[3][3];
    // Calcualte Unit Vectors form difference between each axis vector and the origin
  
    matrix[0][0] = x.x - origin.x;
    matrix[0][1] = x.y - origin.y;
    matrix[0][2] = x.z - origin.z;
    matrix[1][0] = y.x - origin.x;
    matrix[1][1] = y.y - origin.y;
    matrix[1][2] = y.z - origin.z;
    matrix[2][0] = z.x - origin.x;
    matrix[2][1] = z.y - origin.y;
    matrix[2][2] = z.z - origin.z;
    
    popMatrix();
    
    return matrix;
  }
  
  /* Calculate and returns a 3x3 matrix whose columns are the unit vectors of
   * the end effector's current x, y, z axes with respect to an arbitrary coordinate
   * system specified by the rotation matrix 'frame.'
   */
  public float[][] getRotationMatrix(float[][] frame){
    float[][] m = getRotationMatrix();
    RealMatrix A = new Array2DRowRealMatrix(floatToDouble(m, 3, 3));
    RealMatrix B = new Array2DRowRealMatrix(floatToDouble(frame, 3, 3));
    RealMatrix AB = A.multiply(B.transpose());
    
    //println(AB);
    
    return doubleToFloat(AB.getData(), 3, 3);
  }
  
  /* Applies the transformation for the current tool frame.
   * NOTE: This method only works in the TOOL or WORLD frame! */
  public void applyToolFrame(int list_idx) {
    // If a tool Frame is active, then it overrides the World Frame
    if (list_idx >= 0 && list_idx < toolFrames.length) {
      
      // Apply a custom tool frame
      PVector tr = toolFrames[list_idx].getOrigin();
      translate(tr.x, tr.y, tr.z);
    } else {
      
      // Apply a default tool frame based on the current EE
      if (activeEndEffector == ENDEF_CLAW) {
        translate(0, 0, -54);
      } else if (activeEndEffector == ENDEF_SUCTION) {
        translate(0, 0, -105);
      }
    }
  }
  
 /* This method calculates the Euler angular rotations: roll, pitch and yaw of the Robot's
  * End Effector in the form of a vector array.
  *
  * @param axesMatrix  A 3x3 matrix containing unti vectors representing the Robot's End
  *                    Effector's x, y, z axes in respect of the World Coordinate Frame;
  * @returning         A array containing the End Effector's roll, pitch, and yaw, in that
  *                    order
  *
  *  Method based off of procedure outlined in the pdf at this location:
  *     http://www.staff.city.ac.uk/~sbbh653/publications/euler.pdf
  *     rotation about: x - psi, y - theta, z - phi
  */
  public PVector getWPR() {
    float[][] m = getRotationMatrix(currentFrame);
    PVector wpr = matrixToEuler(m);
    
    return wpr;
  }
  
  public PVector getWPR(float[] testAngles){
    float[] origAngles = getJointRotations();
    setJointRotations(testAngles);
    
    PVector ret = getWPR();
    setJointRotations(origAngles);
    return ret;
  }
  
  //returns the rotational value of the robot as a quaternion
  public float[] getQuaternion(){
    float[][] m = getRotationMatrix(currentFrame);
    float[] q = matrixToQuat(m);
    
    return q;
  }
  
  public float[] getQuaternion(float[] testAngles){
    float[] origAngles = getJointRotations();
    setJointRotations(testAngles);
    
    float[] ret = getQuaternion();
    setJointRotations(origAngles);
    return ret;
  }
  
  /**
   * Gives the current position of the end effector in
   * Processing native coordinates.
   * @param model Arm model whose end effector position to calculate
   * @param test Determines whether to use arm segments' actual
   *             rotation values or if we're checking trial rotations
   * @return The current end effector position
   */
  public PVector getEEPos() {
    pushMatrix();
    resetMatrix();
    
    translate(600, 200, 0);
    translate(-50, -166, -358); // -115, -213, -413
    rotateZ(PI);
    translate(150, 0, 150);
    
    rotateY(getJointRotations()[0]);
    
    translate(-150, 0, -150);
    rotateZ(-PI);    
    translate(-115, -85, 180);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 62, 62);
    
    rotateX(getJointRotations()[1]);
    
    translate(0, -62, -62);
    rotateY(-PI/2);
    rotateZ(-PI);   
    translate(0, -500, -50);
    rotateZ(PI);
    rotateY(PI/2);
    translate(0, 75, 75);
    
    rotateX(getJointRotations()[2]);
    
    translate(0, -75, -75);
    rotateY(PI/2);
    rotateZ(-PI);
    translate(745, -150, 150);
    rotateZ(PI/2);
    rotateY(PI/2);
    translate(70, 0, 70);
    
    rotateY(getJointRotations()[3]);
    
    translate(-70, 0, -70);
    rotateY(-PI/2);
    rotateZ(-PI/2);    
    translate(-115, 130, -124);
    rotateZ(PI);
    rotateY(-PI/2);
    translate(0, 50, 50);
    
    rotateX(getJointRotations()[4]);
    
    translate(0, -50, -50);
    rotateY(PI/2);
    rotateZ(-PI);    
    translate(150, -10, 95);
    rotateY(-PI/2);
    rotateZ(PI);
    translate(45, 45, 0);
    
    rotateZ(getJointRotations()[5]);
    
    if (curCoordFrame == COORD_TOOL || curCoordFrame == COORD_WORLD) { applyToolFrame(activeToolFrame); }
    
    PVector ret = new PVector(
      modelX(0, 0, 0),
      modelY(0, 0, 0),
      modelZ(0, 0, 0));
    
    popMatrix();
    return ret;
  } // end calculateEndEffectorPosition
  
  public PVector getEEPos(float[] testAngles) {
    float[] origAngles = getJointRotations();
    setJointRotations(testAngles);
    
    PVector ret = getEEPos();
    setJointRotations(origAngles);
    return ret;
    
  }
  
  //convenience method to set all joint rotation values of the robot arm
  public void setJointRotations(float[] rot){
    for(int i = 0; i < segments.size(); i += 1){
      for(int j = 0; j < 3; j += 1){
        if(segments.get(i).rotations[j]){
          segments.get(i).currentRotations[j] = rot[i];
          segments.get(i).currentRotations[j] %= TWO_PI;
          if(segments.get(i).currentRotations[j] < 0){
            segments.get(i).currentRotations[j] += TWO_PI;
          }
        }
      }
    }
    
    if (COLLISION_DISPLAY) { updateBoxes(); }
  }//end set joint rotations
  
  public boolean interpolateRotation(float speed) {
    boolean done = true;
    for (Model a : segments){
      for (int r = 0; r < 3; r++){
        if (a.rotations[r]){
          if (abs(a.currentRotations[r] - a.targetRotations[r]) > a.rotationSpeed*speed){
            done = false;
            a.currentRotations[r] += a.rotationSpeed * a.rotationDirections[r] * speed;
            a.currentRotations[r] = clampAngle(a.currentRotations[r]);
          }
        }
      } // end loop through rotation axes
    } // end loop through arm segments
    if (COLLISION_DISPLAY) { updateBoxes(); }
    return done;
  } // end interpolate rotation
  
  public void updateOrientation(){
    PVector u = new PVector(0, 0, 0);
    float theta = DEG_TO_RAD*2.5f*liveSpeed;
    
    u.x = mvRot[0];
    u.y = mvRot[1];
    u.z = mvRot[2];
    u.normalize();
    
    if(u.x != 0 || u.y != 0 || u.z != 0){
      tgtRot = rotateQuat(tgtRot, u, theta);
    }
  }

  public void executeLiveMotion() {
    if (curCoordFrame == COORD_JOINT) {
      for (int i = 0; i < segments.size(); i += 1) {
        Model model = segments.get(i);
        
        for (int n = 0; n < 3; n++) {
          if (model.rotations[n]) {
            float trialAngle = model.currentRotations[n] +
              model.rotationSpeed * model.jointsMoving[n] * liveSpeed;
              trialAngle = clampAngle(trialAngle);
            
            if (model.anglePermitted(n, trialAngle)) {
              
              float old_angle = model.currentRotations[n];
              model.currentRotations[n] = trialAngle;
              if (COLLISION_DISPLAY) { updateBoxes(); }
              
              if (armModel.checkSelfCollisions()) {
                // end robot arm movement
                model.currentRotations[n] = old_angle;
                updateBoxes();
                model.jointsMoving[n] = 0;
              }
            } 
            else {
              model.jointsMoving[n] = 0;
            }
          }
        }
      }
      updateButtonColors();
    } else {
      //only move if our movement vector is non-zero
      if(mvLinear[0] != 0 || mvLinear[1] != 0 || mvLinear[2] != 0 || 
         mvRot[0] != 0 || mvRot[1] != 0 || mvRot[2] != 0) {
        
        PVector move = new PVector(mvLinear[0], mvLinear[1], mvLinear[2]);
        // Convert the movement vector into the current reference frame
        move = rotate(move, currentFrame);
        
        //respond to user defined movement
        float distance = motorSpeed/60.0f * liveSpeed;
        tgtPos.x += move.x * distance;
        tgtPos.y += move.y * distance;
        tgtPos.z += move.z * distance;
        updateOrientation();
        
        //if (DISPLAY_TEST_OUT_PUT) { System.out.printf("%s -> %s: %d\n", getEEPos(), tgtPos, getEEPos().dist(tgtPos)); }
        
        //println(lockOrientation);
        int r = calculateIKJacobian(tgtPos, tgtRot);
        if(r == EXEC_FAILURE){
          updateButtonColors();
          mvLinear[0] = 0;
          mvLinear[1] = 0;
          mvLinear[2] = 0;
          mvRot[0] = 0;
          mvRot[1] = 0;
          mvRot[2] = 0;
        }
        else if(r == EXEC_PARTIAL){
          tgtPos = armModel.getEEPos();
          tgtRot = armModel.getQuaternion();
          
        }
      }
    }
  } // end execute live motion
  
  public boolean checkAngles(float[] angles) {
    float[] oldAngles = new float[6];
    /* Save the original angles of the Robot and apply the new set of angles */
    for(int i = 0; i < segments.size(); i += 1) {
      for(int j = 0; j < 3; j += 1) {
        if (segments.get(i).rotations[j]) {
          oldAngles[i] = segments.get(i).currentRotations[j];
          segments.get(i).currentRotations[j] = angles[i];
        }
      }
    }
    
    updateBoxes();
    // Check a collision of the Robot with itself
    boolean collision = checkSelfCollisions();
    
    /* Check for a collision between the Robot Arm and any world object as well as an object
     * held by the Robot Arm and any other world object */
    for (Object obj : objects) {
      if (checkObjectCollision(obj) || (held != null && held != obj && held.collision(obj))) {
        collision = true;
      }
    }
    
    if (collision) {
      // Reset the original position in the case of a collision
      setJointRotations(oldAngles);
    }
    
    return collision;
  }
  
  
  /* If an object is currently being held by the Robot arm, then release it */
  public void releaseHeldObject() {
    armModel.held = null;
  }
  
  /* Indicates that the Robot Arm is in Motion */
  public boolean modelInMotion() {
    for (Model m : segments) {
      for (int idx = 0; idx < m.jointsMoving.length; ++idx) {
        if (m.jointsMoving[idx] != 0) {
          return true;
        }
      }
    }
    
    return mvLinear[0] != 0 || mvLinear[1] != 0 || mvLinear[2] != 0 ||
           mvRot[0] != 0 || mvRot[1] != 0 || mvRot[2] != 0;
  }
  
} // end ArmModel class

public void printCurrentModelCoordinates(String msg) {
  print(msg + ": " );
  print(modelX(0, 0, 0) + " ");
  print(modelY(0, 0, 0) + " ");
  print(modelZ(0, 0, 0));
  println();
}

final int MTYPE_JOINT = 0, MTYPE_LINEAR = 1, MTYPE_CIRCULAR = 2;
final int FTYPE_TOOL = 0, FTYPE_USER = 1;

Frame[] toolFrames = null;
Frame[] userFrames = null;

// Position Registers
private final PositionRegister[] POS_REG = new PositionRegister[100];
// Registers
private final Register[] REG = new Register[100];

public class Point  {
  public PVector pos; // position
  public float[] ori = new float[4]; // orientation
  public float[] joints = new float[6]; // joint values
  
  public Point() {
    pos = new PVector(0,0,0);
    ori[0] = 1;
    ori[1] = 0;
    ori[2] = 0;
    ori[3] = 0; 
    for (int n = 0; n < joints.length; n++) joints[n] = 0;
  }
  
  public Point(float x, float y, float z, float r, float i, float j, float k,
               float j1, float j2, float j3, float j4, float j5, float j6)
  {
    pos = new PVector(x,y,z);
    ori[0] = r;
    ori[1] = i;
    ori[2] = j;
    ori[3] = k;
    joints[0] = j1;
    joints[1] = j2;
    joints[2] = j3;
    joints[3] = j4;
    joints[4] = j5;
    joints[5] = j6;
  }
  
  public Point(float x, float y, float z, float r, float i, float j, float k){
    pos = new PVector(x,y,z);
    ori[0] = r;
    ori[1] = i;
    ori[2] = j;
    ori[3] = k;
  }
  
  public Point(PVector position, float[] orientation){
    pos = position;
    ori = orientation;
  }
  
  ////create a new point with position, orientation, and associated joint angles
  //public Point(float x, float y, float z, float w, float p, float r,
  //             float j1, float j2, float j3, float j4, float j5, float j6)
  //{
  //  pos = new PVector(x,y,z);
  //  ori = eulerToQuat(new PVector(w,p,r));
  //  joints[0] = j1;
  //  joints[1] = j2;
  //  joints[2] = j3;
  //  joints[3] = j4;
  //  joints[4] = j5;
  //  joints[5] = j6;
  //}
  
  ////create a new point with position and orientation only
  //public Point(float x, float y, float z, float w, float p, float r){
  //  pos = new PVector(x,y,z);
  //  ori = eulerToQuat(new PVector(w,p,r));
  //}
  
  //public Point(PVector position, PVector orientation){
  //  pos = position;
  //  ori = eulerToQuat(orientation);
  //}
  
  public Point clone() {
    return new Point(pos.x, pos.y, pos.z, 
                     ori[0], ori[1], ori[2], ori[3], 
                     joints[0], joints[1], joints[2], joints[3], joints[4], joints[5]);
  }
  
  /**
   * Returns a String array, whose entries are the joint values of the
   * Point with their respective labels (J1-J6).
   * 
   * @return  A 6-element String array
   */
  public String[] toJointStringArray() {
    String[] entries = new String[6];
    
    for (int idx = 0; idx < joints.length; ++idx) {
      entries[idx] = String.format("J%d: %4.2f", (idx + 1), joints[idx]);
    }
    
    return entries;
  }
  
  /**
   * Returns a string array, where each entry is one of
   * the values of the Cartiesian represent of the Point:
   * (X, Y, Z, W, P, and R) and their respective labels.
   *
   * @return  A 6-element String array
   */
  public String[] toCartesianStringArray() {
    PVector angles = quatToEuler(ori);
    
    String[] entries = new String[6];
    entries[0] = String.format("X: %4.2f", pos.x);
    entries[1] = String.format("Y: %4.2f", pos.y);
    entries[2] = String.format("Z: %4.2f", pos.z);
    entries[3] = String.format("W: %4.2f", angles.x);
    entries[4] = String.format("P: %4.2f", angles.y);
    entries[5] = String.format("R: %4.2f", angles.z);
    
    return entries;
  }
} // end Point class

public class Frame {
  private PVector origin;
  private PVector wpr;
  // The unit vectors representing the x, y,z axes (in row major order)
  private float[][] axes;
  
  public Frame() {
    origin = new PVector(0,0,0);
    wpr = new PVector(0,0,0);
    axes = new float[3][3];
    // Create identity matrix
    for (int diag = 0; diag < 3; ++diag) {
      axes[diag][diag] = 1f;
    }
  }
  
  /* Used for loading Frames from a file */
  public Frame(PVector origin, PVector wpr, float[][] axesVectors) {
    this.origin = origin;
    this.wpr = wpr;
    this.axes = new float[3][3];
    
    for (int row = 0; row < 3; ++row) {
      for (int col = 0; col < 3; ++col) {
        axes[row][col] = axesVectors[row][col];
      }
     }
  }
  
  public PVector getOrigin() { return origin; }
  public void setOrigin(PVector in) { origin = in; }
  public PVector getWpr() { return wpr; }
  public void setWpr(PVector in) { wpr = in; }
  /* Returns a set of axes unit vectors representing the axes
   * of the frame in reference to the Native Coordinate System. */
  public float[][] getNativeAxes() { return axes.clone(); }
  /* Returns a set of axes unit vectors representing the axes
   * of the frame in reference to the World Coordinate System. */
  public float[][] getWorldAxes() {
    float[][] wAxes = new float[3][3];
    
    for (int col = 0; col < wAxes[0].length; ++col) {
      wAxes[0][col] = -axes[0][col];
      wAxes[1][col] = axes[2][col];
      wAxes[2][col] = -axes[1][col];
    }
    
    /*for (int row = 0; row < wAxes[0].length; ++row) {
      wAxes[row][0] = -axes[row][0];
      wAxes[row][1] = axes[row][2];
      wAxes[row][2] = -axes[row][1];
    }*/
    
    return wAxes;
  }
  
  public void setAxis(int idx, PVector in) {
    
    if (idx >= 0 && idx < axes.length) {
      axes[idx][0] = in.x;
      axes[idx][1] = in.y;
      axes[idx][2] = in.z;
      
      wpr = matrixToEuler(axes);
    }
  }
  
  public void setAxes(float[][] axesVectors) {
    axes = axesVectors.clone();
  }
} // end Frame class

public class Program  {
  private String name;
  private int nextRegister;
  private Point[] p = new Point[1000]; // local registers
  private ArrayList<Instruction> instructions;
  
  public Program(String theName) {
    instructions = new ArrayList<Instruction>();
    for (int n = 0; n < p.length; n++) p[n] = new Point();
    name = theName;
    nextRegister = 0;
  }
  
  public ArrayList<Instruction> getInstructions() {
    return instructions;
  }
  
  public void setName(String n) { name = n; }
  
  public String getName(){
    return name;
  }
  
  public void loadNextRegister(int next){
     nextRegister = next;
  }
  
  public int getRegistersLength(){
     return p.length;
  }
  /**** end ****/
  
  public void addInstruction(Instruction i) {
    instructions.add(i);
    if (i instanceof MotionInstruction ) {
      MotionInstruction castIns = (MotionInstruction)i;
      if (!castIns.getGlobal() && castIns.getRegister() >= nextRegister) {
        nextRegister = castIns.getRegister()+1;
        if (nextRegister >= p.length) nextRegister = p.length-1;
      }
    }
  }
  
  public void overwriteInstruction(int idx, Instruction i) {
    instructions.set(idx, i);
    nextRegister++;
  }
  
  public void addInstruction(int idx, Instruction i) {
    instructions.add(idx, i);
  }
  
  public void addRegister(Point in, int idx) {
    if (idx >= 0 && idx < p.length) p[idx] = in;
  }
  
  public int nextRegister() {
    return nextRegister;
  }
  
  public Point getRegister(int idx) {
    if (idx >= 0 && idx < p.length) return p[idx];
    else return null;
  }
} // end Program class


public int addProgram(Program p) {
  if (p == null) {
    return -1;
  } else {
    int idx = 0;
    
    if (programs.size() < 1) {
       programs.add(p);
     } else {
       while (idx < programs.size() && programs.get(idx).name.compareTo(p.name) < 0) { ++idx; }
       programs.add(idx, p);
     }
    
    return idx;
  }
}

public abstract class Instruction {}

public final class MotionInstruction extends Instruction  {
  private int motionType;
  private int register;
  private boolean globalRegister;
  private float speed;
  private float termination;
  private int userFrame, toolFrame;
  
  public MotionInstruction(int m, int r, boolean g, float s, float t,
                           int uf, int tf)
  {
    motionType = m;
    register = r;
    globalRegister = g;
    speed = s;
    termination = t;
    userFrame = uf;
    toolFrame = tf;
  }
  
  public MotionInstruction(int m, int r, boolean g, float s, float t) {
    motionType = m;
    register = r;
    globalRegister = g;
    speed = s;
    termination = t;
    userFrame = -1;
    toolFrame = -1;
  }
  
  public int getMotionType() { return motionType; }
  public void setMotionType(int in) { motionType = in; }
  public int getRegister() { return register; }
  public void setRegister(int in) { register = in; }
  public boolean getGlobal() { return globalRegister; }
  public void setGlobal(boolean in) { globalRegister = in; }
  public float getSpeed() { return speed; }
  public void setSpeed(float in) { speed = in; }
  public float getTermination() { return termination; }
  public void setTermination(float in) { termination = in; }
  public float getUserFrame() { return userFrame; }
  public void setUserFrame(int in) { userFrame = in; }
  public float getToolFrame() { return toolFrame; }
  public void setToolFrame(int in) { toolFrame = in; }
  
  public float getSpeedForExec(ArmModel model) {
    if (motionType == MTYPE_JOINT) return speed;
    else return (speed / model.motorSpeed);
  }
  
  public Point getVector(Program parent) {
    if (motionType != COORD_JOINT) {
      Point out;
      if (globalRegister) out = POS_REG[register].point.clone();
      else out = parent.p[register].clone();
      out.pos = convertWorldToNative(out.pos);
      return out;
    } else {
      Point ret;
      if (globalRegister) ret = POS_REG[register].point.clone();
      else ret = parent.p[register].clone();
      if (userFrame != -1) {
        ret.pos = rotate(ret.pos, userFrames[userFrame].getNativeAxes());
      }
      return ret;
    }
  } // end getVector()
  
  public String toString(){
     String me = "";
     switch (motionType){
        case MTYPE_JOINT:
           me += "J ";
           break;
        case MTYPE_LINEAR:
           me += "L ";
           break;
        case MTYPE_CIRCULAR:
           me += "C ";
           break;
     }
     if (globalRegister) me += "PR[";
     else me += "P[";
     me += Integer.toString(register)+"] ";
     if (motionType == MTYPE_JOINT) me += Float.toString(speed * 100) + "%";
     else me += Integer.toString((int)speed) + "mm/s";
     if (termination == 0) me += "FINE";
     else me += "CONT" + (int)(termination*100);
     return me;
  } // end toString()
  
} // end MotionInstruction class



public class FrameInstruction extends Instruction {
  private int frameType;
  private int idx;
  
  public FrameInstruction(int f, int i) {
    frameType = f;
    idx = i;
  }
  
  public void execute() {
    if (frameType == FTYPE_TOOL) activeToolFrame = idx;
    else if (frameType == FTYPE_USER) activeUserFrame = idx;
  }
  
  public String toString() {
    String ret = "";
    if (frameType == FTYPE_TOOL) ret += "UTOOL_NUM=";
    else if (frameType == FTYPE_USER) ret += "UFRAME_NUM=";
    ret += idx+1;
    return ret;
  }
} // end FrameInstruction class



public class ToolInstruction extends Instruction {
  private String type;
  private int bracket;
  private int setToolStatus;
  
  public ToolInstruction(String d, int b, int t) {
    type = d;
    bracket = b;
    setToolStatus = t;
  }
  
  public void execute() {
    if ((type.equals("RO") && bracket == 4 && armModel.activeEndEffector == ENDEF_CLAW) ||
        (type.equals("DO") && bracket == 101 && armModel.activeEndEffector == ENDEF_SUCTION))
    {
      
      armModel.endEffectorStatus = setToolStatus;
      
      // Check if the Robot is placing an object or picking up and object
      if (armModel.activeEndEffector == ENDEF_CLAW || armModel.activeEndEffector == ENDEF_SUCTION) {
        
        if (setToolStatus == ON & armModel.held == null) {
          
          PVector ee_pos = armModel.getEEPos();
          
          // Determine if an object in the world can be picked up by the Robot
          for (Object s : objects) {
            
            if (s.collision(ee_pos)) {
              armModel.held = s;
              break;
            }
          }
        } else if (setToolStatus == OFF && armModel.held != null) {
          // Release the object
          armModel.releaseHeldObject();
        }
      }
    }
  }
  
  public String toString() {
    return type + "[" + bracket + "]=" + (setToolStatus == ON ? "ON" : "OFF");
  }
} // end ToolInstruction class



public class CoordinateFrame {
  private PVector origin = new PVector();
  private PVector rotation = new PVector();
  
  public PVector getOrigin() { return origin; }
  public void setOrigin(PVector in) { origin = in; }
  public PVector getRotation() { return rotation; }
  public void setRotation(PVector in) { rotation = in; }
} // end FrameInstruction class

public class RecordScreen implements Runnable{
   public RecordScreen(){
     System.out.format("Record screen...\n");
   }
    public void run(){
       try{ 
            // create a timestamp and attach it to the filename
            Calendar calendar = Calendar.getInstance();
            java.util.Date now = calendar.getTime();
            java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());
            String filename = "output_" + currentTimestamp.toString() + ".flv"; 
            filename = filename.replace(' ', '_');
            filename = filename.replace(':', '_');   

            // record screen
            System.out.format("run script to record screen...\n");
            Runtime rt = Runtime.getRuntime();
            Process proc = rt.exec("ffmpeg -f dshow -i " + 
                           "video=\"screen-capture-recorder\":audio=\"Microphone" + 
                           " (Conexant SmartAudio HD)\" " + filename );
            //Process proc = rt.exec(script);
            while(record == ON){
              Thread.sleep(4000);
            }
            rt.exec("taskkill /F /IM ffmpeg.exe"); // close ffmpeg
            System.out.format("finish recording\n");
            
        }catch (Throwable t){
            t.printStackTrace();
        }
        
    }
}

/* A simple class for a Register of the Robot Arm, which holds a value associated with a comment. */
public class Register {
  public String comment = null;
  public Float value = null;
  
  public Register(String c, Float v) {
    value = v;
    comment = c;
  }
}

/* A simple class for a Position Register of the Robot Arm, which holds a point associated with a comment. */
public class PositionRegister {
  public String comment = null;
  public Point point = null;
  
  public PositionRegister() {
    point = new Point(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f);
  }
  
  public PositionRegister(String c, Point p) {
    point = p;
    comment = c;
  }
}
/**
 * This method saves all programs, frames, and initialized registers,
 * each to separate files
 */
public void saveState() {
  saveProgramBytes( new File(sketchPath("tmp/programs.bin")) );
  saveFrameBytes( new File(sketchPath("tmp/frames.bin")) );
  saveRegisterBytes( new File(sketchPath("tmp/registers.bin")) );
}

/**
 * Load program, frames, and registers from their respective
 * binary files.
 *
 * @return  0 if all loads were successful,
 *          1 if only the program loading failed,
 *          2 if only the frame loading failed,
 *          3 if only program and frame loading failed,
 *          4 if only register loading failed,
 *          5 if only register and program loading failed,
 *          6 if only register and frame loading failed,
 *          7 if all loads failed
 */
public int loadState() {
  int ret = 0,
      error = 0;
  
  File f = new File(sketchPath("tmp/"));
  if (!f.exists()) { f.mkdirs(); }
  
  /* Load all saved Programs */
  
  File progFile = new File( sketchPath("tmp/programs.bin") );
  
  if (!progFile.exists()) {
    // Create 'programs.bin' if it does not already exist
    try {
      progFile.createNewFile();
      System.out.printf("Successfully created %s.\n", progFile.getName());
    } catch (IOException IOEx) {
      System.out.printf("Could not create %s ...\n", progFile.getName());
      IOEx.printStackTrace();
      error = 1;
    }
  } else {
    ret = loadProgramBytes(progFile);
    
    if (ret == 0) {
      println("Successfully loaded programs.\n");
    }
  }
  
  
  /* Load and Initialize the Tool and User Frames */
  
  ret = 1;
  
  File frameFile = new File( sketchPath("tmp/frames.bin") );
  
  if (!frameFile.exists()) {
    try {
      // Create 'frames.bin' if it does not already exist
      frameFile.createNewFile();
      System.out.printf("Successfully created %s.\n", frameFile.getName());
    } catch (IOException IOEx) {
      System.out.printf("Could not create %s ...\n", frameFile.getName());
      IOEx.printStackTrace();
      
      if (error == 0) {
        error = 2;
      } else {
        error = 3;
      }
    }
  } else {
    // Load both the User and Tool Frames
    ret = loadFrameBytes(frameFile);
    
    if (ret == 0) {
      println("Successfully loaded Frames.");
    }
  }
  
  if (ret != 0) {
    // Create new frames if they could not be loaded
    toolFrames = new Frame[10];
    userFrames = new Frame[10];
    
    for (int n = 0; n < toolFrames.length; ++n) {
      toolFrames[n] = new Frame();
      userFrames[n] = new Frame();
    }
  }
  
    
  /* Load and Initialize the Position Register and Registers */
  
  File regFile = new File(sketchPath("tmp/registers.bin"));
  
  if (!regFile.exists()) {
    // Create the 'registers.bin' file
    try {
      regFile.createNewFile();
      System.out.printf("Successfully created %s.\n", regFile.getName());
    } catch (IOException IOEx) {
      System.out.printf("Could not create %s ...\n", regFile.getName());
      IOEx.printStackTrace();
      
      if (error == 0) {
        error = 4;
      } else if (error == 1) {
        error = 5;
      } else if (error == 2) {
        error = 6;
      } else if (error == 3) {
        error = 7;
      }
    }
  } else {
      ret = loadRegisterBytes(regFile);
      
      if (ret == 0) {
        println("Successfully loaded the Registers.");
      }
  }
  
  // Initialize uninitialized registers and position registers to with null fields
  for (int reg = 0; reg < REG.length; ++reg) {
    
    if (REG[reg] == null) {
      REG[reg] = new Register(null, null);
    }
    
    if (POS_REG[reg] == null) {  
      POS_REG[reg] = new PositionRegister(null, null);
    }
  }
  
  return error;
}

/**
 * Saves all the Programs currently in ArrayList programs to the
 * given file.
 * 
 * @param dest  where to save all the programs
 * @return      0 if the save was successful,
 *              1 if the dest could not be found,
 *              2 if an error occurs when saving the Programs
 */
public int saveProgramBytes(File dest) {
  
  try {
    FileOutputStream out = new FileOutputStream(dest);
    DataOutputStream dataOut = new DataOutputStream(out);
    // Save the number of programs
    dataOut.writeInt(programs.size());
    
    for (Program prog : programs) {
      // Save each program
      saveProgram(prog, dataOut);
    }
    
    dataOut.close();
    out.close();
    return 0;
  } catch (FileNotFoundException FNFEx) {
    // Could not locate dest
    System.out.printf("%s does not exist!\n", dest.getName());
    FNFEx.printStackTrace();
    return 1;
  } catch (IOException IOEx) {
    // An error occrued with writing to dest
    System.out.printf("%s is corrupt!\n", dest.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Loads all Programs stored in the given file. This method expects that the number of
 * programs to be stored is stored at the immediate beginning of the file as an integer.
 * Though, no more then 200 programs will be loaded.
 * 
 * @param src  The file from which to load the progarms
 * @return     0 if the load was successful,
 *             1 if src could not be found,
 *             2 if an error occured while reading the programs,
 *             3 if the end of the file is reached before all the expected programs are
 *               read
 */
public int loadProgramBytes(File src) {
  
  try {
    FileInputStream in = new FileInputStream(src);
    DataInputStream dataIn = new DataInputStream(in);
    // Read the number of programs stored in src
    int size = max(0, min(dataIn.readInt(), 200));
    
    while (size-- > 0) {
      // Read each program from src
      programs.add( loadProgram(dataIn) );
    }
    
    dataIn.close();
    in.close();
    return 0;
  } catch (FileNotFoundException FNFEx) {
    // Could not locate src
    System.out.printf("%s does not exist!\n", src.getName());
    FNFEx.printStackTrace();
    return 1;
  } catch (EOFException EOFEx) {
    // Reached the end of src unexpectedly
    System.out.printf("End of file, %s, was reached unexpectedly!\n", src.getName());
    EOFEx.printStackTrace();
    return 3;
  } catch (IOException IOEx) {
    // An error occured with reading from src
    System.out.printf("%s is corrupt!\n", src.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Saves the data associated with the given Program to the given output stream.
 * Not all the Points in a programs Point array are stored: only the Points
 * associated with a MotionInstruction are saved after the MotionInstruction,
 * to which it belongs.
 * 
 * @param  p            The program to save
 * @param  out          The output stream to which to save the Program
 * @throws IOException  If an error occurs with saving the Program
 */
private void saveProgram(Program p, DataOutputStream out) throws IOException {
  
  out.writeUTF(p.name);
  out.writeInt(p.nextRegister);
  out.writeInt(p.instructions.size());
  // Save each instruction
  for (Instruction inst : p.instructions) {
    saveInstruction(inst, out);
    // Save only the Points associated with a MotionInstruction
    if (inst instanceof MotionInstruction) {
      savePoint(p.p[ ((MotionInstruction)inst).register ], out);
    }
  }
}

/**
 * Creates a program from data in the given input stream. A maximum of
 * 500 instructions will be read for a single program
 * 
 * @param in            The input stream to read from
 * @return              A program created from data in the input stream
 * @throws IOException  If an error occurs with reading from the input
 *                      stream
 */
private Program loadProgram(DataInputStream in) throws IOException {
  // Read program name
  String name = in.readUTF();
  Program prog = new Program(name);
  // Read the next register value
  int nReg = in.readInt();
  prog.loadNextRegister(nReg);
  // Read the number of instructions stored for this porgram
  int numOfInst = max(0, min(in.readInt(), 500));
  
  while (numOfInst-- > 0) {
    // Read each instruction
    Instruction inst = loadInstruction(in);
    prog.addInstruction(inst);
    // Read the points stored after each MotionIntruction
    if (inst instanceof MotionInstruction) {
      Point pt = loadPoint(in);
      prog.addRegister(pt, ((MotionInstruction)inst).register);
    }
  }
  
  return prog;
}

/**
 * Saves the data associated with the given Point object to the file opened
 * by the given output stream.
 * 
 * @param   p            The Point of which to save the data
 * @param   out          The output stream used to save the Point
 * @throws  IOException  If an error occurs with writing the data of the Point
 */
private void savePoint(Point p, DataOutputStream out) throws IOException {
  // Write position of the point
  out.writeFloat(p.pos.x);
  out.writeFloat(p.pos.y);
  out.writeFloat(p.pos.z);
  
  // Write point's orientation
  for (float o : p.ori) {
    out.writeFloat(o);
  }
  
  // Write the joint angles for the point's position
  for (float j : p.joints) {
    out.writeFloat(j);
  }
}

/**
 * Loads the data of a Point from the file opened by the given
 * input stream.
 *
 * @param  in           The input stream used to read the data of
 *                      a Point
 * @return              The Point stored at the current position
 *                      of the input stream
 * @throws IOException  If an error occurs with reading the data
 *                      of the Point
 */
private Point loadPoint(DataInputStream in) throws IOException {
        // Read the point's position
  float pos_x = in.readFloat(),
        pos_y = in.readFloat(),
        pos_z = in.readFloat(),
        // Read the point's orientation
        orien_r = in.readFloat(),
        orien_i = in.readFloat(),
        orien_j = in.readFloat(),
        orien_k = in.readFloat(),
        // Read the joint angles for the joint's position
        joint_1 = in.readFloat(),
        joint_2 = in.readFloat(),
        joint_3 = in.readFloat(),
        joint_4 = in.readFloat(),
        joint_5 = in.readFloat(),
        joint_6 = in.readFloat();
  
  return new Point(pos_x, pos_y, pos_z,
                   orien_r, orien_i, orien_j, orien_k,
                   joint_1, joint_2, joint_3, joint_4, joint_5, joint_6);
}

/**
 * Saves the data stored in the given instruction to the file opened by the give output
 * stream. Currently, this method will only work for instructions of type: Motion, Frame
 * and Tool.
 * 
 * @param inst          The instruction of which to save the data
 * @pararm out          The output stream used to save the given instruction
 * @throws IOException  If an error occurs with saving the instruction
 */
private void saveInstruction(Instruction inst, DataOutputStream out) throws IOException {
  
  // Each Instruction subclass MUST have its own saving code block associated with its unique data fields
  if (inst instanceof MotionInstruction) {
    
    MotionInstruction m_inst = (MotionInstruction)inst;
    // Flag byte denoting this instruction as a MotionInstruction
    out.writeByte(0);
    // Write data associated with the MotionIntruction object
    out.writeInt(m_inst.motionType);
    out.writeInt(m_inst.register);
    out.writeBoolean(m_inst.globalRegister);
    out.writeFloat(m_inst.speed);
    out.writeFloat(m_inst.termination);
    out.writeInt(m_inst.userFrame);
    out.writeInt(m_inst.toolFrame);
  } else if (inst instanceof FrameInstruction) {
    
    FrameInstruction f_inst = (FrameInstruction)inst;
    // Flag byte denoting this instruction as a FrameInstruction
    out.writeByte(1);
    // Write data associated with the FrameInstruction object
    out.writeInt(f_inst.frameType);
    out.writeInt(f_inst.idx);
  } else if (inst instanceof ToolInstruction) {
    
    ToolInstruction t_inst = (ToolInstruction)inst;
    // Flag byte denoting this instruction as a ToolInstruction
    out.writeByte(2);
    // Write data associated with the ToolInstruction object
    out.writeUTF(t_inst.type);
    out.writeInt(t_inst.bracket);
    out.writeInt(t_inst.setToolStatus);
  } else {/* TODO add other instructions! */}
}

/**
 * The next instruction stored in the file opened by the given input stream
 * is read, created, and returned. This method is currently only functional
 * for instructions of type: Motion, Frame, and Tool.
 *
 * @param in            The input stream from which to read the data of an
 *                      instruction
 * @return              The instruction saved at the current position of the
 *                      input stream
 * @throws IOException  If an error occurs with reading the data of the
 *                      instruciton
 */
private Instruction loadInstruction(DataInputStream in) throws IOException {
  Instruction inst = null;
  // Determine what type of instruction is stored in the succeding bytes
  byte instType = in.readByte();
  
  if (instType == 0) {
    
    // Read data for a MotionInstruction object
    int mType = in.readInt();
    int reg = in.readInt();
    boolean isGlobal = in.readBoolean();
    float spd = in.readFloat();
    float term = in.readFloat();
    int uFrame = in.readInt();
    int tFrame = in.readInt();
    
    inst = new MotionInstruction(mType, reg, isGlobal, spd, term, uFrame, tFrame);
  } else if (instType == 1) {
    
    // Read data for a FrameInstruction object
    inst = new FrameInstruction( in.readInt(), in.readInt() );
  } else if (instType == 2) {
    
    // Read data for a ToolInstruction object
    String type = in.readUTF();
    int bracket = in.readInt();
    int setting = in.readInt();
    
    inst = new ToolInstruction(type, bracket, setting);
  } else {/* TODO add other instructions! */}
  
  return inst;
}

/**
 * Given a valid file path, both the Tool Frame and then the User
 * Frame sets are saved to the file. First the length of a list
 * is saved and then its respective elements.
 *
 * @param dest  the file to which the frame sets will be saved
 * @return      0 if successful,
 *              1 if an error occurs with accessing the give file
 *              2 if an error occurs with writing to the file
 */
public int saveFrameBytes(File dest) {
  
  try {
    FileOutputStream out = new FileOutputStream(dest);
    DataOutputStream dataOut = new DataOutputStream(out);
    
    // Save Tool Frames
    dataOut.writeInt(toolFrames.length);
    for (Frame frame : toolFrames) {
      saveFrame(frame, dataOut);
    }
    
    // Save User Frames
    dataOut.writeInt(userFrames.length);
    for (Frame frame : userFrames) {
      saveFrame(frame, dataOut);
    }
    
    dataOut.close();
    out.close();
    return 0;
  } catch (FileNotFoundException FNFEx) {
    // Could not find dest
    System.out.printf("%s does not exist!\n", dest.getName());
    FNFEx.printStackTrace();
    return 1;
  } catch (IOException IOEx) {
    // Error with writing to dest
    System.out.printf("%s is corrupt!\n", dest.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Loads both the Tool and User Frames from the file path denoted
 * by the given String. The Tool Frames are expected to come before
 * the Usser Frames. In addition, it is expected that both frame
 * sets store the length of the set before the first element.
 * 
 * @param src  the file, which contains the data for the Tool and
 *             User Frames
 * @return     0 if successful,
 *             1 if an error occurs with accessing the give file
 *             2 if an error occurs with reading from the file
 *             3 if the end of the file is reached before reading
 *             all the data for the frames
 */
public int loadFrameBytes(File src) {
  
  try {
    FileInputStream in = new FileInputStream(src);
    DataInputStream dataIn = new DataInputStream(in);
    
    // Load Tool Frames
    int size = max(0, min(dataIn.readInt(), 10));
    toolFrames = new Frame[size];
    int idx;
    
    for (idx = 0; idx < size; ++idx) {
      toolFrames[idx] = loadFrame(dataIn);
    }
    
    // Load User Frames
    size = max(0, min(dataIn.readInt(), 10));
    userFrames = new Frame[size];
    
    for (idx = 0; idx < size; ++idx) {
      userFrames[idx] = loadFrame(dataIn);
    }
    
    dataIn.close();
    in.close();
    return 0;
  } catch (FileNotFoundException FNFEx) {
    // Could not find src
    System.out.printf("%s does not exist!\n", src.getName());
    FNFEx.printStackTrace();
    return 1;
  } catch (EOFException EOFEx) {
    // Reached the end of src unexpectedly
    System.out.printf("End of file, %s, was reached unexpectedly!\n", src.getName());
    EOFEx.printStackTrace();
    return 3;
  } catch (IOException IOEx) {
    // Error with reading from src
    System.out.printf("%s is corrupt!\n", src.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Saves the data of the given frame's origin, orientation and axes vectors
 * to the file opened by the given DataOutputStream.
 * 
 * @param f    A non-null frame object
 * @param out  An output stream used to write the given frame to a file
 * @throw IOException  if an error occurs with writing the frame to the file
 */
private void saveFrame(Frame f, DataOutputStream out) throws IOException {
  // Write frame origin
  PVector v = f.getOrigin();
  out.writeFloat(v.x);
  out.writeFloat(v.y);
  out.writeFloat(v.z);
  // Write frame orientation
  v = f.getWpr();
  out.writeFloat(v.x);
  out.writeFloat(v.y);
  out.writeFloat(v.z);
  // Write frame axes
  for (int row = 0; row < 3; ++row) {
    for (int col = 0; col < 3; ++col) {
      out.writeFloat(f.axes[row][col]);
    }
  }
}

/**
 * Loads the data associated with a Frame object (origin,
 * orientation and axes vectors) from the file opened by
 * the given DataOutputStream.
 *
 * @param out  An input stream used to read from a file
 * @return     The next frame stored in the file
 * @throw IOException  if an error occurs while reading the frame
 *                     from to the file
 */
private Frame loadFrame(DataInputStream in) throws IOException {
  // Read origin values
  PVector origin = new PVector();
  origin.x = in.readFloat();
  origin.y = in.readFloat();
  origin.z = in.readFloat();
  // Read orientation values
  PVector wpr = new PVector();
  wpr.x = in.readFloat();
  wpr.y = in.readFloat();
  wpr.z = in.readFloat();
  
  float[][] axesVectors = new float[3][3];
  // Read axes vector values
  for (int row = 0; row < 3; ++row) {
    for (int col = 0; col < 3; ++col) {
      axesVectors[row][col] = in.readFloat();
    }
  }
  
  return new Frame(origin, wpr, axesVectors);
}

/**
 * Saves all initialized Register and Position Register Entries with their
 * respective indices in their respective lists to dest. In addition, the
 * number of Registers and Position Registers saved is saved to the file
 * before each respective set of entries.
 * 
 * @param dest  Some binary file to which to save the Register entries
 * @return      0 if the save was successful,
 *              1 if dest could not be found
 *              2 if an error occrued while writing to dest
 */
public int saveRegisterBytes(File dest) {
  
  try {
    FileOutputStream out = new FileOutputStream(dest);
    DataOutputStream dataOut = new DataOutputStream(out);
    
    int numOfREntries = 0,
        numOfPREntries = 0;
    
    ArrayList<Integer> initializedR = new ArrayList<Integer>(),
                       initializedPR = new ArrayList<Integer>();
    
    // Count the number of initialized entries and save their indices
    for (int idx = 0 ; idx < REG.length; ++idx) {
      if (REG[idx].value != null || REG[idx].comment != null) {
        initializedR.add(idx);
        ++numOfREntries;
      }
      
      if (POS_REG[idx].point != null || POS_REG[idx].comment != null) {
        initializedPR.add(idx);
        ++numOfPREntries;
      }
    }
    
    dataOut.writeInt(numOfREntries);
    // Save the Register entries
    for (Integer idx : initializedR) {
      dataOut.writeInt(idx);
      
      if (REG[idx].value == null) {
        // save for null Float value
        dataOut.writeFloat(Float.NaN);
      } else {
        dataOut.writeFloat(REG[idx].value);
      }
      
      if (REG[idx].comment == null) {
        dataOut.writeUTF("");
      } else {
        dataOut.writeUTF(REG[idx].comment);
      }
    }
    
    dataOut.writeInt(numOfPREntries);
    // Save the Position Register entries
    for (Integer idx : initializedPR) {
      dataOut.writeInt(idx);
      
      if (POS_REG[idx].point == null) {
        // Save for null Point value
        savePoint( new Point(Float.NaN, Float.NaN, Float.NaN,
                             Float.NaN, Float.NaN, Float.NaN, Float.NaN), dataOut );
      } else {
        savePoint(POS_REG[idx].point, dataOut);
      }
      
      if (POS_REG[idx].comment == null) {
        dataOut.writeUTF("");
      } else {
        dataOut.writeUTF(POS_REG[idx].comment);
      }
    }
    
    dataOut.close();
    out.close();
    return 0;
  } catch (FileNotFoundException FNFEx) {
    // Could not be located dest
    System.out.printf("%s does not exist!\n", dest.getName());
    FNFEx.printStackTrace();
    return 1;
  } catch (IOException IOEx) {
    // Error occured while reading from dest
    System.out.printf("%s is corrupt!\n", dest.getName());
    IOEx.printStackTrace();
    return 2;
  }
}

/**
 * Loads all the saved Registers and Position Registers from the
 * given binary file. It is expected that the number of entries
 * saved for both the Registers and Position Registers exist in the
 * file before each respective list. Also, the index of an entry
 * in the Register (or Position Register) list should also exist
 * before each antry in the file.
 * 
 * @param src  The binary file from which to load the Register and
 *             Position Register entries
 * @return     0 if the load was successful,
 *             1 if src could not be located,
 *             2 if an error occured while reading from src
 *             3 if the end of file is reached in source, before
 *               all expected entries were read
 */
public int loadRegisterBytes(File src) {
  
  try {
    FileInputStream in = new FileInputStream(src);
    DataInputStream dataIn = new DataInputStream(in);
    
    int size = max(0, min(dataIn.readInt(), REG.length));
    
    // Load the Register entries
    while (size-- > 0) {
      // Each entry is saved after its respective index in REG
      int reg = dataIn.readInt();
      
      Float v = dataIn.readFloat();
      // Null values are saved as NaN
      if (Float.isNaN(v)) { v = null; }
      
      String c = dataIn.readUTF();
      // Null comments are saved as ""
      if (c == "") { c = null; }
      
      REG[reg] = new Register(c, v);
    }
    
    size = max(0, min(dataIn.readInt(), POS_REG.length));
    
    // Load the Position Register entries
    while (size-- > 0) {
      // Each entry is saved after its respective index in POS_REG
      int idx = dataIn.readInt();
      
      Point p = loadPoint(dataIn);
      // Null points are stored with pos Vectors filled with NaNs
      if (Float.isNaN(p.pos.x)) { p = null; }
      
      String c = dataIn.readUTF();
      // Null comments are stored as ""
      if (c == "") { c = null; }
      
      POS_REG[idx] = new PositionRegister(c, p);
    }
    
    dataIn.close();
    in.close();
    return 0;
  } catch (FileNotFoundException FNFEx) {
    // Could not be located src
    System.out.printf("%s does not exist!\n", src.getName());
    FNFEx.printStackTrace();
    return 1;
  } catch (EOFException EOFEx) {
    // Unexpectedly reached the end of src
    System.out.printf("End of file, %s, was reached unexpectedly!\n", src.getName());
    EOFEx.printStackTrace();
    return 3;
  } catch (IOException IOEx) {
    // Error occrued while reading from src
    System.out.printf("%s is corrupt!\n", src.getName());
    IOEx.printStackTrace();
    return 2;
  }
}
/**
 * A basic definition of a shape in processing that has a fill and outline color.
 */
public abstract class Shape {
  protected int fill;
  protected int outline;
  protected final boolean no_fill;
  
  /* Create a shpae with the given outline/fill colors */
  public Shape(int f, int o) {
    fill = f;
    outline = o;
    no_fill = false;
  }
  
  /* Creates a shape with no fill */
  public Shape(int o) {
    outline = o;
    no_fill = true;
  } 
  
  /* Returns the x, y, z values of the shape's center point */
  public abstract float[] position();
  
  /* Applies necessary rotations and translations to convert the Native cooridinate
   * system into the cooridnate system relative to the center of the Shape */
  public abstract void applyTransform();
  
  /* Define the transformation matrix for the coordinate system of the shape */
  public abstract void setTransform(float[][] tMatrix);
  
  /* Returns the Homogeneous Coordinate Matrix repesenting the conversion from
   * the object's coordinate frame to the Native coordinate frame */
  public abstract float[][] getTransform();
  
  /* Returns a 3x3 matrix, whose rows contain the x, y, z axes of the Shape's relative
   * coordinate frame in native coordinates */
  public abstract float[][] getRelativeAxes();
  
  /* Define how a shape is drawn in the window */
  public abstract void draw();
}

/**
 * A shape that resembles a cube or rectangle
 */
public class Box extends Shape {
  public final PVector dimensions;
  public float[][] transform;
  
  /* Create a normal box */
  public Box(float wdh, float hgt, float dph, int f, int o) {
    super(f, o);
    
    transform = getTransformationMatrix();
    dimensions = new PVector(wdh, hgt, dph);
  }
  
  /* Create an empty box */
  public Box(float wdh, float hgt, float dph, int o) {
    super(o);
    
    transform = getTransformationMatrix();
    dimensions = new PVector(wdh, hgt, dph);
  }
  
  public float[] position() {
    pushMatrix();
    resetMatrix();
    applyTransform();
    float[] origin = new float[] { modelX(0, 0, 0), modelY(0, 0, 0), modelZ(0, 0, 0) };
    popMatrix();
    
    return origin;
  }
  
  /* This method modifies the transform matrix! */
  public void applyTransform() {
    applyMatrix(transform[0][0], transform[0][1], transform[0][2], transform[0][3],
                transform[1][0], transform[1][1], transform[1][2], transform[1][3],
                transform[2][0], transform[2][1], transform[2][2], transform[2][3],
                transform[3][0], transform[3][1], transform[3][2], transform[3][3]);
  }
  
  public void setTransform(float[][] tMatrix) { transform = tMatrix.clone(); }
  
  public float[][] getTransform() {return transform.clone(); }
  
  public void draw() {
    stroke(outline);
    
    if (no_fill) {
      noFill();
    } else {
      fill(fill);
    }
    
    box(dimensions.x, dimensions.y, dimensions.z);
  }
  
  public float[][] getRelativeAxes() {
    float[][] Axes = new float[3][3];
    
    for(int r = 0; r < Axes[0].length; ++r) {
      for(int c = 0; c < Axes.length; ++c) {
        Axes[c][r] = transform[r][c];
      }
    }
    
    return Axes;
  }
  
  /* Returns the dimension of the box corresponding to the
   * axes index given; the axi indices are as follows:
   * 
   * 0 -> x
   * 1 -> y
   * 2 -> z
   */
  public float getDim(int axes) {
    
    switch (axes) {
      case 0:   return dimensions.x;
      case 1:   return dimensions.y;
      case 2:   return dimensions.z;
      default:  return -1f;
    }
  }
  
  /* Check if the given point is within the dimensions of the box */
  public boolean within(PVector pos) {
    
    boolean is_inside = pos.x >= -(dimensions.x / 2f) && pos.x <= (dimensions.x / 2f)
                     && pos.y >= -(dimensions.y / 2f) && pos.y <= (dimensions.y / 2f)
                     && pos.z >= -(dimensions.z / 2f) && pos.z <= (dimensions.z / 2f);
    
    return is_inside;
  }
}

public class Object {
  // The actual object
  public final Shape form;
  // The area around an object used for collision handling
  public final Shape hit_box;
  
  public Object(float wdh, float hgt, float dph, int f, int o) {
    form = new Box(wdh, hgt, dph, f, o);
    // green outline for hitboxes
    hit_box = new Box(wdh + 20f, hgt + 20f, dph + 20f, color(0, 255, 0));
  }
  
  public void draw() {
    pushMatrix();
    
    form.applyTransform();
    
    noFill();
    stroke(255, 0, 0);
    //line(5000, 0, 0, -5000, 0, 0);
    stroke(0, 255, 0);
    //line(0, 5000, 0, 0, -5000, 0);
    stroke(0, 0, 255);
    //line(0, 0, 5000, 0, 0, -5000);
    
    form.draw();
    if (COLLISION_DISPLAY) { hit_box.draw(); }
    
    popMatrix();
  }
  
  public boolean collision(PVector pos) {
    // Convert the point to the current reference frame
    pos = transform(pos, invertHCMatrix(hit_box.getTransform()));
    
    return ((Box)hit_box).within(pos);
  }
  
  /* Determines if the collider boxes of this object
   * and the given object intersect. */
  public boolean collision(Object obj) {
    Box A = (Box)hit_box;
    Box B = (Box)obj.hit_box;
    
    return collision3D(A, B);
  }
}

/*
 * This algorithm uses the Separating Axis Theorm to project radi of each Box on to several 
 * axes to determine if a there is any overlap between the boxes. The method strongy resembles 
 * the method outlined in Section 4.4 of "Real Time Collision Detection" by Christer Ericson
 *
 * @param A  The hit box associated with some object in space
 * @param B  The hit box associated with another object in space
 * @return   Whether the two hit boxes intersect
 */
public boolean collision3D(Box A, Box B) {
  // Rows are x, y, z axis vectors for A and B: Ax, Ay, Az, Bx, By, and Bz
  float[][] axes_A = A.getRelativeAxes();
  float[][] axes_B = B.getRelativeAxes();
  
  // Rotation matrices to convert B into A's coordinate system
  float[][] rotMatrix = new float[3][3];
  float[][] absRotMatrix = new float[3][3];
  
  for(int v = 0; v < axes_A.length; v += 1){
    for (int u = 0; u < axes_B.length; u += 1) {
      // PLEASE do not change to matrix mutliplication
      rotMatrix[v][u] = axes_A[v][0] * axes_B[u][0] +  axes_A[v][1] * axes_B[u][1] +  axes_A[v][2] * axes_B[u][2];
      // Add offset for valeus close to zero (parallel axes)
      absRotMatrix[v][u] = abs(rotMatrix[v][u]) + 0.00000000175f;
    }
  }
  
  // T = B's position - A's
  PVector posA = new PVector().set(A.position());
  PVector posB = new PVector().set(B.position());
  PVector limbo = posB.sub(posA);
  // Convert T into A's coordinate frame
  float[] T = new float[] { limbo.dot(new PVector().set(axes_A[0])), 
                            limbo.dot(new PVector().set(axes_A[1])), 
                            limbo.dot(new PVector().set(axes_A[2])) };
  
  float radiA, radiB;
  
  for(int idx = 0; idx < absRotMatrix.length; ++idx){
    radiA = (A.getDim(idx) / 2);
    radiB = (B.getDim(0) / 2) * absRotMatrix[idx][0] + 
            (B.getDim(1) / 2) * absRotMatrix[idx][1] + 
            (B.getDim(2) / 2) * absRotMatrix[idx][2];
    
    // Check Ax, Ay, and Az
    if (abs(T[idx]) > (radiA + radiB)) { return false; }
  }
  
  for(int idx = 0; idx < absRotMatrix[0].length; ++idx){
    radiA = (A.getDim(0) / 2) * absRotMatrix[0][idx] + 
            (A.getDim(1) / 2) * absRotMatrix[1][idx] + 
            (A.getDim(2) / 2) * absRotMatrix[2][idx];
    radiB = (B.getDim(idx) / 2);
    
    float check = abs(T[0]*rotMatrix[0][idx] + 
                      T[1]*rotMatrix[1][idx] + 
                      T[2]*rotMatrix[2][idx]);
    
    // Check Bx, By, and Bz
    if(check > (radiA + radiB)) { return false; }
  }
    
  radiA = (A.getDim(1) / 2) * absRotMatrix[2][0] + (A.getDim(2) / 2) * absRotMatrix[1][0];
  radiB = (B.getDim(1) / 2) * absRotMatrix[0][2] + (B.getDim(2) / 2) * absRotMatrix[0][1];
  // Check axes Ax x Bx
  if(abs(T[2] * rotMatrix[1][0] - T[1] * rotMatrix[2][0]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(1) / 2) * absRotMatrix[2][1] + (A.getDim(2) / 2) * absRotMatrix[1][1];
  radiB = (B.getDim(0) / 2) * absRotMatrix[0][2] + (B.getDim(2) / 2) * absRotMatrix[0][0];
  // Check axes Ax x By
  if(abs(T[2] * rotMatrix[1][1] - T[1] * rotMatrix[2][1]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(1) / 2) * absRotMatrix[2][2] + (A.getDim(2) / 2) * absRotMatrix[1][2];
  radiB = (B.getDim(0) / 2) * absRotMatrix[0][1] + (B.getDim(1) / 2) * absRotMatrix[0][0];
  // Check axes Ax x Bz
  if(abs(T[2] * rotMatrix[1][2] - T[1] * rotMatrix[2][2]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[2][0] + (A.getDim(2) / 2) * absRotMatrix[0][0];
  radiB = (B.getDim(1) / 2) * absRotMatrix[1][2] + (B.getDim(2) / 2) * absRotMatrix[1][1];
  // Check axes Ay x Bx
  if(abs(T[0] * rotMatrix[2][0] - T[2] * rotMatrix[0][0]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[2][1] + (A.getDim(2) / 2) * absRotMatrix[0][1];
  radiB = (B.getDim(0) / 2) * absRotMatrix[1][2] + (B.getDim(2) / 2) * absRotMatrix[1][0];
  // Check axes Ay x By
  if(abs(T[0] * rotMatrix[2][1] - T[2] * rotMatrix[0][1]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[2][2] + (A.getDim(2) / 2) * absRotMatrix[0][2];
  radiB = (B.getDim(0) / 2) * absRotMatrix[1][1] + (B.getDim(1) / 2) * absRotMatrix[1][0];
  // Check axes Ay x Bz
  if(abs(T[0] * rotMatrix[2][2] - T[2] * rotMatrix[0][2]) > (radiA + radiB)) { return false; }
  
  
  radiA = (A.getDim(0) / 2) * absRotMatrix[1][0] + (A.getDim(1) / 2) * absRotMatrix[0][0];
  radiB = (B.getDim(1) / 2) * absRotMatrix[2][2] + (B.getDim(2) / 2) * absRotMatrix[2][1];
  // Check axes Az x Bx
  if(abs(T[1] * rotMatrix[0][0] - T[0] * rotMatrix[1][0]) > (radiA + radiB)) { return false; }
  
  radiA = (A.getDim(0) / 2) * absRotMatrix[1][1] + (A.getDim(1) / 2) * absRotMatrix[0][1];
  radiB = (B.getDim(0) / 2) * absRotMatrix[2][2] + (B.getDim(2) / 2) * absRotMatrix[2][0];
  // Check axes Az x By
  if(abs(T[1] * rotMatrix[0][1] - T[0] * rotMatrix[1][1]) > (radiA + radiB)) { return false; }
    
  radiA = (A.getDim(0) / 2) * absRotMatrix[1][2] + (A.getDim(1) / 2) * absRotMatrix[0][2];
  radiB = (B.getDim(0) / 2) * absRotMatrix[2][1] + (B.getDim(1) / 2) * absRotMatrix[2][0];
  // Check axes Az x Bz
  if(abs(T[1] * rotMatrix[0][2] - T[0] * rotMatrix[1][2]) > (radiA + radiB)) { return false; }
    
  return true;
}
  public void settings() {  size(1200, 800, P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "RobotRun" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
